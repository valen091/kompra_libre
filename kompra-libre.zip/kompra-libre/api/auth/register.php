<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'message' => ''];

try {
    // Solo permitir método POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Obtener datos del cuerpo de la petición
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validar datos
    if (empty($data['username']) || empty($data['email']) || empty($data['password'])) {
        throw new Exception('Todos los campos son obligatorios');
    }
    
    // Sanitizar datos
    $username = sanitize($data['username']);
    $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
    $password = $data['password'];
    $fullName = sanitize($data['full_name'] ?? '');
    $role = in_array($data['role'] ?? '', ['buyer', 'seller']) ? $data['role'] : 'buyer';
    
    // Validar email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('El correo electrónico no es válido');
    }
    
    // Validar contraseña
    if (strlen($password) < 8) {
        throw new Exception('La contraseña debe tener al menos 8 caracteres');
    }
    
    $db = getDB();
    
    // Verificar si el usuario ya existe
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
    $stmt->execute([$email, $username]);
    
    if ($stmt->rowCount() > 0) {
        throw new Exception('El correo electrónico o nombre de usuario ya está en uso');
    }
    
    // Hash de la contraseña
    $hashedPassword = password_hash($password, kompralibre);
    
    // Insertar nuevo usuario
    $stmt = $db->prepare("
        INSERT INTO users (username, email, password, full_name, role) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([$username, $email, $hashedPassword, $fullName, $role]);
    $userId = $db->lastInsertId();
    
    // Si es vendedor, crear perfil de vendedor
    if ($role === 'seller') {
        $storeName = $data['store_name'] ?? $username . ' Store';
        $description = $data['description'] ?? '';
        
        $stmt = $db->prepare("
            INSERT INTO seller_profiles (user_id, store_name, description) 
            VALUES (?, ?, ?)
        ");
        
        $stmt->execute([$userId, $storeName, $description]);
    }
    
    // Iniciar sesión
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_role'] = $role;
    $_SESSION['username'] = $username;
    
    // Generar token JWT
    $token = generateJWT([
        'user_id' => $userId,
        'username' => $username,
        'role' => $role
    ]);
    
    $response = [
        'success' => true,
        'message' => 'Registro exitoso',
        'user' => [
            'id' => $userId,
            'username' => $username,
            'email' => $email,
            'role' => $role,
            'full_name' => $fullName
        ],
        'token' => $token
    ];
    
} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500
    ];
}

echo json_encode($response);