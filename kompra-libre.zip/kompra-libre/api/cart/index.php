<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Obtener el ID del carrito de la sesión o crear uno nuevo
    $cartId = getOrCreateCartId();
    $userId = isAuthenticated() ? getCurrentUserId() : null;
    
    // Si el usuario está autenticado, asociar el carrito a su cuenta
    if ($userId && !isset($_SESSION['cart_user_id'])) {
        $stmt = $db->prepare("UPDATE carts SET user_id = ? WHERE id = ?");
        $stmt->execute([$userId, $cartId]);
        $_SESSION['cart_user_id'] = $userId;
    }
    
    // Manejar diferentes métodos HTTP
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            // Obtener los ítems del carrito
            $stmt = $db->prepare("
                SELECT 
                    ci.*,
                    p.title as product_title,
                    p.price as product_price,
                    p.slug as product_slug,
                    (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as product_image,
                    (SELECT name FROM users WHERE id = p.seller_id) as seller_name
                FROM cart_items ci
                JOIN products p ON ci.product_id = p.id
                WHERE ci.cart_id = ?
            ");
            
            $stmt->execute([$cartId]);
            $items = $stmt->fetchAll();
            
            // Calcular totales
            $subtotal = 0;
            $items = array_map(function($item) use (&$subtotal) {
                $itemTotal = $item['price'] * $item['quantity'];
                $subtotal += $itemTotal;
                
                return [
                    'id' => $item['id'],
                    'product_id' => $item['product_id'],
                    'variant_id' => $item['variant_id'],
                    'title' => $item['product_title'],
                    'price' => (float)$item['price'],
                    'quantity' => (int)$item['quantity'],
                    'total' => $itemTotal,
                    'image' => $item['product_image'] ?: '/img/placeholder-product.jpg',
                    'url' => "/producto/{$item['product_slug']}",
                    'seller' => $item['seller_name']
                ];
            }, $items);
            
            $response = [
                'success' => true,
                'data' => [
                    'items' => $items,
                    'summary' => [
                        'subtotal' => $subtotal,
                        'shipping' => 0, // Se calcularía según la dirección de envío
                        'tax' => 0, // Se calcularía según la ubicación
                        'total' => $subtotal
                    ]
                ]
            ];
            break;
            
        case 'POST':
            // Agregar un ítem al carrito
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (empty($data['product_id']) || empty($data['quantity']) || $data['quantity'] < 1) {
                throw new Exception('Datos inválidos', 400);
            }
            
            $productId = (int)$data['product_id'];
            $variantId = isset($data['variant_id']) ? (int)$data['variant_id'] : null;
            $quantity = (int)$data['quantity'];
            
            // Verificar si el producto existe y está disponible
            $product = getProductDetails($productId, $variantId);
            
            if (!$product) {
                throw new Exception('Producto no encontrado', 404);
            }
            
            if ($product['quantity'] < $quantity) {
                throw new Exception('No hay suficiente stock disponible', 400);
            }
            
            // Verificar si el producto ya está en el carrito
            $stmt = $db->prepare("
                SELECT id, quantity 
                FROM cart_items 
                WHERE cart_id = ? AND product_id = ? AND (variant_id = ? OR (? IS NULL AND variant_id IS NULL))
            ");
            
            $stmt->execute([$cartId, $productId, $variantId, $variantId]);
            $existingItem = $stmt->fetch();
            
            if ($existingItem) {
                // Actualizar cantidad
                $newQuantity = $existingItem['quantity'] + $quantity;
                
                $stmt = $db->prepare("
                    UPDATE cart_items 
                    SET quantity = ?, updated_at = NOW() 
                    WHERE id = ?
                ");
                
                $stmt->execute([$newQuantity, $existingItem['id']]);
            } else {
                // Agregar nuevo ítem
                $stmt = $db->prepare("
                    INSERT INTO cart_items (cart_id, product_id, variant_id, quantity, price, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, NOW(), NOW())
                ");
                
                $stmt->execute([
                    $cartId,
                    $productId,
                    $variantId,
                    $quantity,
                    $product['price']
                ]);
            }
            
            $response = [
                'success' => true,
                'message' => 'Producto agregado al carrito',
                'cart_item_count' => getCartItemCount($cartId)
            ];
            break;
            
        case 'PUT':
            // Actualizar cantidad de un ítem
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (empty($data['item_id']) || empty($data['quantity']) || $data['quantity'] < 0) {
                throw new Exception('Datos inválidos', 400);
            }
            
            $itemId = (int)$data['item_id'];
            $quantity = (int)$data['quantity'];
            
            if ($quantity === 0) {
                // Eliminar el ítem si la cantidad es 0
                $stmt = $db->prepare("DELETE FROM cart_items WHERE id = ? AND cart_id = ?");
                $stmt->execute([$itemId, $cartId]);
                
                $response = [
                    'success' => true,
                    'message' => 'Producto eliminado del carrito',
                    'cart_item_count' => getCartItemCount($cartId)
                ];
            } else {
                // Actualizar cantidad
                $stmt = $db->prepare("
                    UPDATE cart_items 
                    SET quantity = ?, updated_at = NOW() 
                    WHERE id = ? AND cart_id = ?
                ");
                
                $stmt->execute([$quantity, $itemId, $cartId]);
                
                if ($stmt->rowCount() === 0) {
                    throw new Exception('Ítem no encontrado en el carrito', 404);
                }
                
                $response = [
                    'success' => true,
                    'message' => 'Carrito actualizado',
                    'cart_item_count' => getCartItemCount($cartId)
                ];
            }
            break;
            
        case 'DELETE':
            // Eliminar un ítem del carrito
            $itemId = isset($_GET['item_id']) ? (int)$_GET['item_id'] : null;
            
            if (!$itemId) {
                throw new Exception('ID de ítem no especificado', 400);
            }
            
            $stmt = $db->prepare("DELETE FROM cart_items WHERE id = ? AND cart_id = ?");
            $stmt->execute([$itemId, $cartId]);
            
            if ($stmt->rowCount() === 0) {
                throw new Exception('Ítem no encontrado en el carrito', 404);
            }
            
            $response = [
                'success' => true,
                'message' => 'Producto eliminado del carrito',
                'cart_item_count' => getCartItemCount($cartId)
            ];
            break;
            
        default:
            throw new Exception('Método no permitido', 405);
    }
    
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500
    ];
}

echo json_encode($response);

// Función auxiliar para obtener o crear un ID de carrito
function getOrCreateCartId() {
    global $db;
    
    // Si ya hay un carrito en la sesión, devolverlo
    if (isset($_SESSION['cart_id'])) {
        // Verificar que el carrito aún existe
        $stmt = $db->prepare("SELECT id FROM carts WHERE id = ?");
        $stmt->execute([$_SESSION['cart_id']]);
        
        if ($stmt->rowCount() > 0) {
            return $_SESSION['cart_id'];
        }
    }
    
    // Crear un nuevo carrito
    $stmt = $db->prepare("
        INSERT INTO carts (user_id, session_id, created_at, updated_at)
        VALUES (?, ?, NOW(), NOW())
    ");
    
    $userId = isAuthenticated() ? getCurrentUserId() : null;
    $sessionId = session_id();
    
    $stmt->execute([$userId, $sessionId]);
    $cartId = $db->lastInsertId();
    
    // Guardar en la sesión
    $_SESSION['cart_id'] = $cartId;
    
    return $cartId;
}

// Función auxiliar para obtener detalles de un producto
function getProductDetails($productId, $variantId = null) {
    global $db;
    
    if ($variantId) {
        $stmt = $db->prepare("
            SELECT p.*, v.price, v.quantity, v.sku, v.option1, v.option2, v.option3
            FROM products p
            JOIN product_variants v ON p.id = v.product_id
            WHERE p.id = ? AND v.id = ? AND p.status = 'active'
        ");
        
        $stmt->execute([$productId, $variantId]);
    } else {
        $stmt = $db->prepare("
            SELECT * FROM products 
            WHERE id = ? AND status = 'active'
        ");
        
        $stmt->execute([$productId]);
    }
    
    return $stmt->fetch();
}

// Función auxiliar para contar ítems en el carrito
function getCartItemCount($cartId) {
    global $db;
    
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(quantity), 0) as total 
        FROM cart_items 
        WHERE cart_id = ?
    ");
    
    $stmt->execute([$cartId]);
    return (int)$stmt->fetch()['total'];
}