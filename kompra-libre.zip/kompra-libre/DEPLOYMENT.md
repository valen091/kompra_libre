# Deployment Guide for Kompra Libre

## Option 1: Railway (Recommended)

Railway is perfect for full-stack applications like yours with Node.js, PHP, and MySQL support.

### Steps:

1. **Create a Railway Account**: Go to [railway.app](https://railway.app) and sign up.

2. **Install Railway CLI**:
   ```bash
   npm install -g @railway/cli
   ```

3. **Login to Railway**:
   ```bash
   railway login
   ```

4. **Initialize Project**:
   ```bash
   railway init
   ```

5. **Add MySQL Database**:
   ```bash
   railway add mysql
   ```

6. **Deploy**:
   ```bash
   railway up
   ```

7. **Set Environment Variables**:
   Update your production environment variables in the Railway dashboard or using:
   ```bash
   railway variables set NODE_ENV=production
   railway variables set JWT_SECRET=your_secure_random_string
   # Set other variables as needed
   ```

## Option 2: Render

Render also supports full-stack applications:

1. Create account at [render.com](https://render.com)
2. Connect your GitHub repository
3. Create a new Web Service
4. Use build command: `npm install`
5. Start command: `npm start`

## Option 3: Heroku

1. Install Heroku CLI
2. Login: `heroku login`
3. Create app: `heroku create your-app-name`
4. Add MySQL addon: `heroku addons:create heroku-postgresql:hobby-dev`
5. Deploy: `git push heroku main`

## Environment Variables Setup

Copy `.env.production` to `.env` and update with your production values:

```bash
cp .env.production .env
```

Then update the following variables:
- `DB_HOST`: Your production database host
- `DB_USER`: Your database username
- `DB_PASS`: Your secure database password
- `DB_NAME`: Your database name
- `JWT_SECRET`: A long, random secret key
- `APP_URL`: Your production domain URL

## Database Setup

1. Update your database connection in `.env`
2. Run the database initialization:
   ```bash
   npm run db:init
   ```

## Important Notes

- Never commit `.env` files with real credentials
- Update CORS settings in `src/server.js` for production
- Consider adding a reverse proxy for PHP endpoints if needed
- Set up proper error handling and logging for production

## Post-Deployment

1. Test all API endpoints
2. Verify database connections
3. Check file upload functionality
4. Test real-time features (Socket.IO)
5. Set up monitoring and error tracking

Would you like me to help you with any specific part of the deployment process?
