module.exports = {
  content: ["./public/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        primary: '#3483FA',
        secondary: '#FFE600',
      }
    },
  },
  plugins: [],
}