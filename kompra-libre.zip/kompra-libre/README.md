
# Kompra Libre (tipo Mercado Libre)

E-commerce educativo con Node.js + Express, MySQL, HTML + Tailwind + JS, Socket.IO y PHP notifier.

## Pasos
1) Copia `.env.example` a `.env` y ajusta credenciales MySQL.
2) `npm install`
3) `npm run db:init` (crea schema y seeds)
4) `npm run dev`
Abre http://localhost:3000

### Usuarios de prueba
- comprador@test.com / comprador123!
- vendedor@test.com  / vendedor123!
- admin@test.com     / Admin123!

Si el login falla por hashes del seed, abre **una vez** `GET /api/dev/seed-users`.

## Endpoints principales
- Auth: `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`
- Usuarios: `GET /api/users/me`, `PUT /api/users/me`, `PUT /api/users/me/password`, `GET /api/users/me/favorites`
- Categorías: `GET /api/categories`
- Productos: `GET /api/products`, `GET /api/products/:id`, `POST /api/products` (seller), `PUT/DELETE /api/products/:id` (dueño/admin), `POST /api/products/:id/report`, `GET/POST /api/products/:id/reviews`
- Carrito: `GET /api/cart`, `POST /api/cart`, `PUT /api/cart/:itemId`, `DELETE /api/cart/:itemId`
- Órdenes: `POST /api/orders`, `GET /api/orders`, `PUT /api/orders/:id/status` (admin)
- Vendedor: `GET /api/sellers/me/products`
- Admin: `GET /api/admin/dashboard`
- Mensajes (API + Socket.IO): `GET/POST /api/messages`, WS canal `message:new`
- Notificaciones (PHP/Node): `POST /api/notify/order-status`
- Búsqueda: `GET /api/search/suggest?q=`

Logs en `/logs/app.log`.
