# Implementación de Kompra Libre en AWS EC2

Esta guía te ayudará a implementar Kompra Libre en una instancia EC2 de AWS con Linux.

## Requisitos previos

1. Una cuenta de AWS con acceso a EC2
2. Un dominio configurado para apuntar a tu instancia EC2 (opcional pero recomendado)
3. Acceso SSH a la instancia EC2

## Pasos de implementación

### 1. Configuración inicial de la instancia EC2

1. Inicia una instancia EC2 con Amazon Linux 2 o Ubuntu Server 20.04 LTS
2. Asegúrate de que los siguientes puertos estén abiertos en el grupo de seguridad:
   - 22 (SSH)
   - 80 (HTTP)
   - 443 (HTTPS)

### 2. Conexión a la instancia

```bash
ssh -i tu-clave.pem ec2-user@tu-ip-publica
# O para Ubuntu:
# ssh -i tu-clave.pem ubuntu@tu-ip-publica
```

### 3. Instalación y configuración

1. Actualiza el sistema:
   ```bash
   sudo apt update && sudo apt upgrade -y  # Para Ubuntu/Debian
   # O para Amazon Linux:
   # sudo yum update -y
   ```

2. Clona el repositorio o sube los archivos a la instancia:
   ```bash
   sudo apt install -y git
   git clone https://github.com/tu-usuario/kompra-libre.git
   sudo mv kompra-libre /var/www/
   ```

3. Ejecuta el script de configuración:
   ```bash
   cd /var/www/kompra-libre
   chmod +x setup-ec2.sh
   sudo ./setup-ec2.sh
   ```

4. Configura la base de datos:
   ```bash
   # Importar la estructura de la base de datos
   mysql -u root -p kompra_libre < database/kompra_libre.sql
   
   # O crear la base de datos manualmente
   mysql -u root -p
   ```
   ```sql
   CREATE DATABASE kompra_libre CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'kompra_user'@'localhost' IDENTIFIED BY 'una_contraseña_segura';
   GRANT ALL PRIVILEGES ON kompra_libre.* TO 'kompra_user'@'localhost';
   FLUSH PRIVILEGES;
   EXIT;
   ```

### 4. Configuración del dominio y SSL

1. Asegúrate de que tu dominio apunte a la IP pública de tu instancia EC2
2. El script de configuración ya incluye la instalación de Certbot para SSL
3. Si necesitas renovar manualmente el certificado:
   ```bash
   sudo certbot --apache -d tu-dominio.com --non-interactive --agree-tos -m admin@tu-dominio.com --redirect
   ```

### 5. Configuración final

1. Asegúrate de que el archivo de configuración de producción esté en su lugar:
   ```bash
   cp /var/www/kompra-libre/public_html/includes/config.production.php /var/www/kompra-libre/public_html/includes/config.php
   ```

2. Configura los permisos correctos:
   ```bash
   sudo chown -R www-data:www-data /var/www/kompra-libre
   sudo find /var/www/kompra-libre -type d -exec chmod 755 {} \;
   sudo find /var/www/kompra-libre -type f -exec chmod 644 {} \;
   sudo chmod -R 775 /var/www/kompra-libre/public_html/uploads
   ```

3. Reinicia los servicios:
   ```bash
   sudo systemctl restart apache2
   sudo systemctl enable apache2
   ```

## Mantenimiento

### Copias de seguridad

1. Crea un script de respaldo (por ejemplo, `/usr/local/bin/backup-kompra-libre.sh`):
   ```bash
   #!/bin/bash
   DATE=$(date +%Y%m%d%H%M%S)
   BACKUP_DIR="/backups/kompra-libre"
   
   mkdir -p $BACKUP_DIR
   
   # Respaldar base de datos
   mysqldump -u root -p'tu_contraseña' kompra_libre > $BACKUP_DIR/kompra-libre-db-$DATE.sql
   
   # Respaldar archivos
   tar -czf $BACKUP_DIR/kompra-libre-files-$DATE.tar.gz /var/www/kompra-libre
   
   # Eliminar copias de seguridad antiguas (más de 30 días)
   find $BACKUP_DIR -type f -mtime +30 -delete
   ```

2. Haz el script ejecutable:
   ```bash
   sudo chmod +x /usr/local/bin/backup-kompra-libre.sh
   ```

3. Programa la tarea de respaldo diario:
   ```bash
   sudo crontab -e
   ```
   Agrega la siguiente línea para ejecutar el respaldo todos los días a la 1 AM:
   ```
   0 1 * * * /usr/local/bin/backup-kompra-libre.sh
   ```

## Solución de problemas

### Verificar logs de Apache
```bash
sudo tail -f /var/log/apache2/error.log
sudo tail -f /var/log/apache2/access.log
```

### Verificar logs de PHP
```bash
sudo tail -f /var/log/php/kompra-libre-error.log
```

### Verificar estado de los servicios
```bash
sudo systemctl status apache2
sudo systemctl status mysql
```

## Optimizaciones recomendadas

1. **Caché**: Instala y configura Redis o Memcached para el almacenamiento en caché
2. **CDN**: Configura CloudFront o Cloudflare para servir activos estáticos
3. **Base de datos**: Considera usar Amazon RDS para la base de datos en lugar de una base de datos local
4. **Almacenamiento**: Usa Amazon S3 para almacenar archivos subidos
5. **Monitoreo**: Configura Amazon CloudWatch para monitorear el rendimiento

## Seguridad

1. Mantén el sistema operativo y el software actualizados
2. Usa contraseñas seguras y únicas
3. Limita el acceso SSH solo a direcciones IP de confianza
4. Considera usar un WAF (Web Application Firewall) como AWS WAF
5. Realiza copias de seguridad periódicas y guárdalas en un lugar seguro

## Soporte

Si necesitas ayuda, por favor abre un issue en el repositorio de GitHub o contacta al equipo de soporte.
