<?php
// Configuración de la aplicación
define('APP_NAME', 'Kompra Libre');
define('APP_URL', 'http://localhost/kompra-libre');
define('APP_DEBUG', true);

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'kompra_libre');
define('DB_USER', 'root');
define('DB_PASS', 'kompralibre');

// Configuración de sesión
define('SESSION_NAME', 'kompra_libre_session');
define('SESSION_LIFETIME', 86400); // 24 horas

// Configuración de JWT
define('JWT_SECRET', 'tu_clave_secreta_muy_segura');
define('JWT_EXPIRE', 86400); // 24 horas

// Configuración de subida de archivos
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif']);

// Habilitar manejo de errores
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Configuración de zona horaria
date_default_timezone_set('America/Uruguay/Montevideo');

// Iniciar sesión
session_name(SESSION_NAME);
session_set_cookie_params([
    'lifetime' => SESSION_LIFETIME,
    'path' => '/',
    'domain' => '',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();