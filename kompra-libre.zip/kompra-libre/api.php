<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$endpoint = str_replace('/kompra-libre/api/', '', $request_uri);
$endpoint = explode('?', $endpoint)[0]; // Eliminar parámetros de consulta

// Conexión a la base de datos
function getDBConnection() {
    $host = 'localhost';
    $dbname = 'kompra_libre';
    $username = 'root';
    $password = ''; // Asegúrate de que esta contraseña coincida con tu configuración de XAMPP

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error de conexión a la base de datos: ' . $e->getMessage()]);
        exit;
    }
}

// Endpoint: /api/categories
if ($endpoint === 'categories' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->query('SELECT id, name FROM categories');
        $categories = $stmt->fetchAll();
        echo json_encode($categories);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener categorías: ' . $e->getMessage()]);
    }
    exit;
}

// Endpoint: /api/products
if ($endpoint === 'products' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $pdo = getDBConnection();
        
        // Parámetros de consulta
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 9;
        $offset = ($page - 1) * $limit;
        
        // Construir consulta
        $where = ['1=1'];
        $params = [];
        
        // Filtros
        if (!empty($_GET['q'])) {
            $where[] = 'title LIKE :search';
            $params[':search'] = '%' . $_GET['q'] . '%';
        }
        
        if (!empty($_GET['category'])) {
            $where[] = 'category_id = :category';
            $params[':category'] = $_GET['category'];
        }
        
        if (!empty($_GET['price_min'])) {
            $where[] = 'price >= :price_min';
            $params[':price_min'] = floatval($_GET['price_min']);
        }
        
        if (!empty($_GET['price_max'])) {
            $where[] = 'price <= :price_max';
            $params[':price_max'] = floatval($_GET['price_max']);
        }
        
        if (!empty($_GET['condition'])) {
            $where[] = 'condition = :condition';
            $params[':condition'] = $_GET['condition'];
        }
        
        $whereClause = implode(' AND ', $where);
        
        // Contar total de productos
        $countStmt = $pdo->prepare("SELECT COUNT(*) as total FROM products WHERE $whereClause");
        $countStmt->execute($params);
        $total = $countStmt->fetch()['total'];
        
        // Obtener productos
        $stmt = $pdo->prepare("
            SELECT p.*, c.name as category_name 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE $whereClause
            ORDER BY p.created_at DESC
            LIMIT :limit OFFSET :offset
        ");
        
        $params[':limit'] = $limit;
        $params[':offset'] = $offset;
        
        // Asignar tipos de parámetros
        foreach ($params as $key => $value) {
            if (is_int($value)) {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        $products = $stmt->fetchAll();
        
        // Formatear respuesta
        $response = [
            'items' => $products,
            'page' => $page,
            'total' => (int)$total,
            'limit' => $limit
        ];
        
        echo json_encode($response);
        
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener productos: ' . $e->getMessage()]);
    }
    exit;
}

// Endpoint: /api/search/suggest
if ($endpoint === 'search/suggest' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    
    if (empty($q)) {
        echo json_encode([]);
        exit;
    }
    
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("
            SELECT DISTINCT title 
            FROM products 
            WHERE title LIKE :search
            LIMIT 5
        ");
        $stmt->execute([':search' => "%$q%"]);
        $suggestions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo json_encode(array_map(function($title) {
            return ['title' => $title];
        }, $suggestions));
        
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener sugerencias: ' . $e->getMessage()]);
    }
    exit;
}

// Si no se encontró la ruta
http_response_code(404);
echo json_encode(['error' => 'Ruta no encontrada: ' . $endpoint]);