<?php
namespace App\Models;

class User extends Model {
    protected $table = 'users';
    protected $fillable = [
        'name', 'email', 'password', 'user_role', 'phone', 'avatar', 'email_verified'
    ];
    protected $hidden = ['password'];

    public function findByEmail($email) {
        return $this->firstWhere('email', '=', $email);
    }

    public function createUser($data) {
        if (isset($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        }
        return $this->create($data);
    }

    public function updateUser($id, $data) {
        if (isset($data['password']) && !empty($data['password'])) {
            $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        } else {
            unset($data['password']);
        }
        return $this->update($id, $data);
    }

    public function verifyCredentials($email, $password) {
        $user = $this->findByEmail($email);
        if (!$user) {
            return false;
        }
        
        if (password_verify($password, $user->password)) {
            return $user;
        }
        
        return false;
    }
}
