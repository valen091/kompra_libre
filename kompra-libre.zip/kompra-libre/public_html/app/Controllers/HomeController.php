<?php
namespace App\Controllers;

use App\Core\Session;

class HomeController {
    protected $session;

    public function __construct() {
        $this->session = new Session();
    }

    public function index() {
        $this->view('home', [
            'title' => 'Inicio - Kompra Libre',
            'user' => $this->session->get('user')
        ]);
    }

    protected function view($view, $data = []) {
        extract($data);
        $viewPath = dirname(__DIR__, 2) . "/views/$view.php";
        
        if (file_exists($viewPath)) {
            ob_start();
            include $viewPath;
            echo ob_get_clean();
        } else {
            throw new \Exception("View $view not found");
        }
    }
}
