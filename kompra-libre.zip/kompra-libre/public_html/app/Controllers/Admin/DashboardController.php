<?php
namespace App\Controllers\Admin;

use App\Controllers\DashboardController as BaseDashboard;

class DashboardController extends BaseDashboard {
    public function index() {
        $this->view('admin/dashboard', [
            'title' => 'Panel de Administración',
            'user' => $this->session->get('user')
        ]);
    }
}
