<?php
namespace App\Controllers;

use App\Core\Session;

class ErrorController {
    protected $session;

    public function __construct() {
        $this->session = new Session();
    }

    public function unauthorized() {
        header('HTTP/1.0 403 Forbidden');
        $this->view('errors/403', [
            'title' => 'Acceso No Autorizado',
            'message' => 'No tienes permiso para acceder a esta página.'
        ]);
    }

    public function notFound() {
        header('HTTP/1.0 404 Not Found');
        $this->view('errors/404', [
            'title' => 'Página No Encontrada',
            'message' => 'La página que estás buscando no existe.'
        ]);
    }

    public function serverError() {
        header('HTTP/1.1 500 Internal Server Error');
        $this->view('errors/500', [
            'title' => 'Error del Servidor',
            'message' => 'Ha ocurrido un error inesperado. Por favor, inténtalo de nuevo más tarde.'
        ]);
    }

    protected function view($view, $data = []) {
        extract($data);
        $viewPath = dirname(__DIR__, 2) . "/views/$view.php";
        
        if (file_exists($viewPath)) {
            ob_start();
            include $viewPath;
            echo ob_get_clean();
        } else {
            // Fallback to a simple error message if the view doesn't exist
            echo "<h1>{$data['title']}</h1>";
            echo "<p>{$data['message']}</p>";
        }
    }
}
