<?php
namespace App\Controllers;

use App\Core\Session;

class DashboardController {
    protected $session;

    public function __construct() {
        $this->session = new Session();
        if (!$this->session->has('user')) {
            header('Location: /login');
            exit();
        }
    }

    public function index() {
        $user = $this->session->get('user');
        $this->view('dashboard/index', [
            'title' => 'Panel de Control',
            'user' => $user
        ]);
    }

    protected function view($view, $data = []) {
        extract($data);
        $viewPath = dirname(__DIR__, 2) . "/views/$view.php";
        
        if (file_exists($viewPath)) {
            ob_start();
            include $viewPath;
            echo ob_get_clean();
        } else {
            throw new \Exception("View $view not found");
        }
    }
}
