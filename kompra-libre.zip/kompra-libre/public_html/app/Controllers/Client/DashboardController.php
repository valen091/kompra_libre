<?php
namespace App\Controllers\Client;

use App\Controllers\DashboardController as BaseDashboard;

class DashboardController extends BaseDashboard {
    public function index() {
        $this->view('client/dashboard', [
            'title' => 'Mi Cuenta - Cliente',
            'user' => $this->session->get('user')
        ]);
    }
}
