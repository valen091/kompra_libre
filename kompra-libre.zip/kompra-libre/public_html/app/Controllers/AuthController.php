<?php
namespace App\Controllers;

use App\Core\Session;
use App\Core\Validator;
use App\Models\User;

class AuthController {
    protected $user;
    protected $session;
    protected $validator;

    public function __construct() {
        $this->user = new User();
        $this->session = new Session();
        $this->validator = new Validator();
    }

    public function showLoginForm() {
        if ($this->isLoggedIn()) {
            $this->redirectToDashboard();
        }
        
        $this->view('auth/login', [
            'title' => 'Iniciar Sesión',
            'old' => $this->session->get('old') ?? [],
            'errors' => $this->session->getFlash('errors') ?? []
        ]);
    }

    public function login() {
        $data = $_POST;
        $this->session->set('old', $data);

        $rules = [
            'email' => 'required|email',
            'password' => 'required|min:6'
        ];

        if ($this->validator->make($data, $rules)->fails()) {
            $this->session->setFlash('errors', $this->validator->errors());
            $this->redirect('/login');
        }

        $user = $this->user->verifyCredentials($data['email'], $data['password']);

        if (!$user) {
            $this->session->setFlash('errors', ['email' => 'Credenciales incorrectas']);
            $this->redirect('/login');
        }

        $this->session->set('user', [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'role' => $user->user_role
        ]);

        $this->session->remove('old');
        $this->redirectToDashboard();
    }

    public function showRegisterForm() {
        if ($this->isLoggedIn()) {
            $this->redirectToDashboard();
        }
        
        $this->view('auth/register', [
            'title' => 'Registro de Usuario',
            'old' => $this->session->get('old') ?? [],
            'errors' => $this->session->getFlash('errors') ?? []
        ]);
    }

    public function register() {
        $data = $_POST;
        $this->session->set('old', $data);

        $rules = [
            'name' => 'required|min:3|max:100',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6|confirmed',
            'phone' => 'required|min:10|max:15',
            'user_role' => 'required|in:client,seller,admin'
        ];

        if ($this->validator->make($data, $rules)->fails()) {
            $this->session->setFlash('errors', $this->validator->errors());
            $this->redirect('/register');
        }

        unset($data['password_confirmation']);
        $data['email_verified'] = 1; // Auto-verify for now
        
        if ($this->user->createUser($data)) {
            $this->session->setFlash('success', '¡Registro exitoso! Por favor inicia sesión.');
            $this->redirect('/login');
        }

        $this->session->setFlash('errors', ['general' => 'Error al registrar el usuario. Intente nuevamente.']);
        $this->redirect('/register');
    }

    public function logout() {
        $this->session->destroy();
        $this->redirect('/login');
    }

    protected function isLoggedIn() {
        return $this->session->has('user');
    }

    protected function redirectToDashboard() {
        $user = $this->session->get('user');
        $role = $user['role'] ?? 'guest';
        
        $routes = [
            'admin' => '/admin/dashboard',
            'seller' => '/seller/dashboard',
            'client' => '/client/dashboard',
            'default' => '/'
        ];

        $this->redirect($routes[$role] ?? $routes['default']);
    }

    protected function redirect($path) {
        header("Location: $path");
        exit();
    }

    protected function view($view, $data = []) {
        extract($data);
        $viewPath = dirname(__DIR__, 2) . "/views/$view.php";
        
        if (file_exists($viewPath)) {
            ob_start();
            include $viewPath;
            echo ob_get_clean();
        } else {
            throw new \Exception("View $view not found");
        }
    }
}
