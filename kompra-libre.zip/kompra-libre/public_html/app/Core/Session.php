<?php
namespace App\Core;

class Session {
    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function set($key, $value) {
        $_SESSION[$key] = $value;
    }

    public function get($key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }

    public function has($key) {
        return isset($_SESSION[$key]);
    }

    public function remove($key) {
        if ($this->has($key)) {
            unset($_SESSION[$key]);
        }
    }

    public function flash($key, $message = null) {
        if ($message === null) {
            $message = $this->get("flash_$key");
            $this->remove("flash_$key");
            return $message;
        }
        
        $this->set("flash_$key", $message);
    }

    public function setFlash($key, $message) {
        $this->set("flash_$key", $message);
    }

    public function getFlash($key) {
        return $this->flash($key);
    }

    public function hasFlash($key) {
        return $this->has("flash_$key");
    }

    public function destroy() {
        session_destroy();
        $_SESSION = [];
    }

    public function regenerate() {
        session_regenerate_id(true);
    }
}
