<?php
namespace App\Core;

class Validator {
    protected $data = [];
    protected $rules = [];
    protected $errors = [];
    protected $messages = [
        'required' => 'El campo :field es obligatorio',
        'email' => 'El campo :field debe ser un correo electrónico válido',
        'min' => 'El campo :field debe tener al menos :min caracteres',
        'max' => 'El campo :field no debe exceder los :max caracteres',
        'confirmed' => 'La confirmación de :field no coincide',
        'unique' => 'El valor del campo :field ya está en uso',
        'in' => 'El campo :field no es válido',
    ];

    public function __construct(array $data = []) {
        $this->data = $data;
    }

    public static function make(array $data, array $rules) {
        $validator = new self($data);
        $validator->setRules($rules);
        return $validator;
    }

    public function setRules(array $rules) {
        $this->rules = $rules;
        return $this;
    }

    public function validate() {
        foreach ($this->rules as $field => $rules) {
            $rules = is_string($rules) ? explode('|', $rules) : $rules;
            
            foreach ($rules as $rule) {
                $params = [];
                
                if (strpos($rule, ':') !== false) {
                    list($rule, $param) = explode(':', $rule, 2);
                    $params = explode(',', $param);
                }
                
                $method = 'validate' . ucfirst($rule);
                
                if (method_exists($this, $method)) {
                    $value = $this->getValue($field);
                    
                    if (!$this->$method($field, $value, $params)) {
                        $this->addError($field, $rule, $params);
                        break;
                    }
                }
            }
        }
        
        return empty($this->errors);
    }

    public function errors() {
        return $this->errors;
    }

    public function fails() {
        return !$this->validate();
    }

    protected function getValue($field) {
        return $this->data[$field] ?? null;
    }

    protected function addError($field, $rule, $params = []) {
        $message = $this->messages[$rule] ?? "El campo :field no es válido";
        
        foreach ($params as $key => $value) {
            $message = str_replace(":$key", $value, $message);
        }
        
        $this->errors[$field] = str_replace(':field', $field, $message);
    }

    // Validation Rules
    protected function validateRequired($field, $value) {
        return !is_null($value) && $value !== '';
    }

    protected function validateEmail($field, $value) {
        return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }

    protected function validateMin($field, $value, $params) {
        return mb_strlen($value) >= $params[0];
    }

    protected function validateMax($field, $value, $params) {
        return mb_strlen($value) <= $params[0];
    }

    protected function validateConfirmed($field, $value, $params) {
        $confirmation = $this->getValue($field . '_confirmation');
        return $value === $confirmation;
    }

    protected function validateUnique($field, $value, $params) {
        $table = $params[0] ?? 'users';
        $column = $params[1] ?? $field;
        $exceptId = $params[2] ?? null;
        
        $db = Database::getInstance()->getConnection();
        $query = "SELECT COUNT(*) as count FROM $table WHERE $column = :value";
        $params = [':value' => $value];
        
        if ($exceptId) {
            $query .= " AND id != :id";
            $params[':id'] = $exceptId;
        }
        
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $result = $stmt->fetch(PDO::FETCH_OBJ);
        
        return $result->count === 0;
    }

    protected function validateIn($field, $value, $params) {
        return in_array($value, $params);
    }
}
