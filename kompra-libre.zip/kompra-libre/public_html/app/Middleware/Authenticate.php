<?php
namespace App\Middleware;

use App\Core\Session;

class Authenticate {
    protected $session;

    public function __construct() {
        $this->session = new Session();
    }

    public function handle($request, $next) {
        if (!$this->session->has('user')) {
            $this->session->setFlash('error', 'Por favor inicia sesión para continuar');
            header('Location: /login');
            exit();
        }

        return $next($request);
    }
}
