<?php
namespace App\Middleware;

use App\Core\Session;

class CheckRole {
    protected $session;
    protected $allowedRoles;

    public function __construct($roles) {
        $this->session = new Session();
        $this->allowedRoles = is_array($roles) ? $roles : [$roles];
    }

    public function handle($request, $next) {
        $user = $this->session->get('user');
        
        if (!isset($user['role']) || !in_array($user['role'], $this->allowedRoles)) {
            $this->session->setFlash('error', 'No tienes permiso para acceder a esta sección');
            header('Location: /unauthorized');
            exit();
        }

        return $next($request);
    }
}
