<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$pageTitle = 'Registro';
$success = '';
$error = '';

// Si el usuario ya está autenticado, redirigir al inicio
if (isset($_SESSION['user_id'])) {
    header('Location: /');
    exit();
}

// Procesar el formulario de registro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validaciones
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = 'Todos los campos son obligatorios';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'El correo electrónico no es válido';
    } elseif (strlen($password) < 8) {
        $error = 'La contraseña debe tener al menos 8 caracteres';
    } elseif ($password !== $confirm_password) {
        $error = 'Las contraseñas no coinciden';
    } else {
        try {
            // Verificar si el correo ya está registrado
            $stmt = $db->prepare("SELECT id FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                $error = 'Este correo electrónico ya está registrado';
            } else {
                // Crear el hash de la contraseña
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // Insertar el nuevo usuario
                $stmt = $db->prepare("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'user')");
                $stmt->execute([$name, $email, $hashedPassword]);
                
                // Iniciar sesión automáticamente
                $userId = $db->lastInsertId();
                $_SESSION['user_id'] = $userId;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_role'] = 'user';
                
                // Redirigir a la página de bienvenida
                header('Location: /welcome.php');
                exit();
            }
        } catch (PDOException $e) {
            error_log('Error en registro: ' . $e->getMessage());
            $error = 'Error al registrar el usuario. Por favor, inténtalo de nuevo.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es" class="<?= isset($_COOKIE['dark_mode']) && $_COOKIE['dark_mode'] === 'true' ? 'dark' : '' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - Kompra Libre</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',
                        secondary: '#FF69B4',
                        accent: '#87CEEB',
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 dark:bg-gray-900 min-h-screen flex items-center justify-center">
    <div class="w-full max-w-md p-8 space-y-8 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
        <div class="text-center">
            <a href="/">
                <img src="/assets/img/logo.png" alt="Kompra Libre" class="h-16 mx-auto mb-6">
            </a>
            <h2 class="text-2xl font-bold text-gray-900 dark:text-white">Crear una cuenta</h2>
            <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">
                ¿Ya tienes una cuenta? 
                <a href="/auth/login.php" class="font-medium text-primary-600 hover:text-primary-500 dark:text-primary-400 dark:hover:text-primary-300">
                    Inicia sesión aquí
                </a>
            </p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <form class="mt-8 space-y-6" action="" method="POST">
            <div class="rounded-md shadow-sm space-y-4">
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Nombre completo
                    </label>
                    <input id="name" name="name" type="text" required 
                           class="appearance-none relative block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 
                                  placeholder-gray-500 text-gray-900 dark:text-white dark:bg-gray-700 rounded-md 
                                  focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                           placeholder="Tu nombre" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                </div>
                
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Correo electrónico
                    </label>
                    <input id="email" name="email" type="email" required 
                           class="appearance-none relative block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 
                                  placeholder-gray-500 text-gray-900 dark:text-white dark:bg-gray-700 rounded-md 
                                  focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                           placeholder="tu@email.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>
                
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Contraseña
                    </label>
                    <input id="password" name="password" type="password" required 
                           class="appearance-none relative block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 
                                  placeholder-gray-500 text-gray-900 dark:text-white dark:bg-gray-700 rounded-md 
                                  focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                           placeholder="••••••••" minlength="8">
                    <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">Mínimo 8 caracteres</p>
                </div>
                
                <div>
                    <label for="confirm_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Confirmar contraseña
                    </label>
                    <input id="confirm_password" name="confirm_password" type="password" required 
                           class="appearance-none relative block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 
                                  placeholder-gray-500 text-gray-900 dark:text-white dark:bg-gray-700 rounded-md 
                                  focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                           placeholder="••••••••" minlength="8">
                </div>
            </div>

            <div class="flex items-center">
                <input id="terms" name="terms" type="checkbox" required
                       class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded">
                <label for="terms" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                    Acepto los <a href="/terminos" class="text-primary-600 hover:text-primary-500 dark:text-primary-400">Términos de Servicio</a> y la <a href="/privacidad" class="text-primary-600 hover:text-primary-500 dark:text-primary-400">Política de Privacidad</a>
                </label>
            </div>

            <div>
                <button type="submit" 
                        class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                    Crear cuenta
                </button>
            </div>
        </form>
        
        <div class="mt-6">
            <div class="relative">
                <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-gray-300 dark:border-gray-600"></div>
                </div>
                <div class="relative flex justify-center text-sm">
                    <span class="px-2 bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400">
                        O regístrate con
                    </span>
                </div>
            </div>

            <div class="mt-6 grid grid-cols-2 gap-3">
                <a href="/auth/google" class="w-full inline-flex justify-center py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600">
                    <i class="fab fa-google text-red-500"></i>
                    <span class="ml-2">Google</span>
                </a>
                <a href="/auth/facebook" class="w-full inline-flex justify-center py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600">
                    <i class="fab fa-facebook text-blue-600"></i>
                    <span class="ml-2">Facebook</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Dark mode toggle script -->
    <script>
        // Verificar el modo oscuro al cargar la página
        if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>
</body>
</html>
