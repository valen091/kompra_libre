# 📁 scripts/ - Scripts Utilitarios

Este directorio contiene scripts utilitarios y componentes principales del proyecto Kompra Libre.

## 📋 Contenido

### 🌐 API Principal
- **`api.php`** - API principal del sistema con todos los endpoints

## 🔍 Uso

### Para Desarrollo
1. **API**: El archivo principal `api.php` maneja todas las peticiones
2. **Debug**: Revisa logs y errores en el navegador/consola
3. **Testing**: Usa herramientas como Postman para probar endpoints

### Para Producción
1. **Performance**: Optimiza consultas y respuestas
2. **Security**: Asegura que todos los endpoints estén protegidos
3. **Monitoring**: Monitorea uso y performance de la API

## 📁 Estructura Padre

```
📦 kompra-libre/
└── 📂 public_html/
    ├── 📂 config/
    ├── 📂 docs/
    ├── 📂 setup/
    ├── 📂 pages/
    ├── 📂 tests/
    ├── 📂 scripts/        ← Estás aquí
    └── ... (otros directorios)
```

## 🔧 Funcionalidades de api.php

### Endpoints Disponibles
- **Autenticación** - Login, registro, logout
- **Productos** - CRUD de productos
- **Carrito** - Gestión del carrito de compras
- **Pedidos** - Procesamiento de pedidos
- **Usuarios** - Gestión de perfiles de usuario

### Características
- ✅ **RESTful** - Sigue estándares REST
- ✅ **JSON** - Respuestas en formato JSON
- ✅ **CORS** - Configurado para cross-origin
- ✅ **Error handling** - Manejo robusto de errores
- ✅ **Authentication** - Sistema de autenticación seguro

## 📊 Monitoreo

### Logs
- Revisa logs del servidor para errores
- Monitorea performance de consultas
- Trackea uso de endpoints

### Performance
- Optimiza consultas lentas
- Implementa caching si es necesario
- Monitorea uso de memoria

## 🔒 Seguridad

### Autenticación
- ✅ **Sessions** - Manejo seguro de sesiones
- ✅ **CSRF** - Protección contra CSRF
- ✅ **XSS** - Sanitización de inputs
- ✅ **SQL Injection** - Prepared statements

### Validación
- ✅ **Inputs** - Validación de todos los datos de entrada
- ✅ **Permisos** - Control de acceso por roles
- ✅ **Rate limiting** - Límite de peticiones por IP

## 🚀 Desarrollo

### Agregar Endpoints
1. **Define** la estructura del endpoint
2. **Implementa** la lógica en `api.php`
3. **Documenta** el nuevo endpoint
4. **Prueba** con herramientas como Postman

### Modificar API
1. **Backup** antes de hacer cambios
2. **Test** en entorno de desarrollo
3. **Documenta** cambios realizados
4. **Deploy** con precaución

## 📞 Soporte

Si encuentras problemas:
1. **Revisa** logs del servidor
2. **Test** endpoints individualmente
3. **Consulta** documentación en `docs/`
4. **Debug** paso a paso

## 🔄 Mantenimiento

- **Actualiza** dependencias regularmente
- **Revisa** logs de errores
- **Optimiza** consultas lentas
- **Documenta** cambios en la API
