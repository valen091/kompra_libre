<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$endpoint = str_replace('/api/', '', $request_uri);
$endpoint = explode('?', $endpoint)[0]; // Eliminar parámetros de consulta

// Incluir archivos necesarios
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/db.php';

// Conexión robusta a la base de datos
function getDBConnection() {
    $credentials = [
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'kompra_libre', 'user' => 'root', 'pass' => ''],
    ];

    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};dbname={$cred['db']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $pdo;
        } catch (PDOException $e) {
            continue;
        }
    }

    // Si ninguna credencial funciona, devolver error JSON
    http_response_code(500);
    echo json_encode(['error' => 'No se pudo conectar a la base de datos. Credenciales inválidas.']);
    exit;
}

// Endpoint: /api/admin/dashboard
if ($endpoint === 'admin/dashboard' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Verificar que el usuario sea admin
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Acceso denegado. Solo administradores.']);
            exit;
        }
        
        $pdo = getDB();
        
        // Obtener estadísticas básicas
        $stats = [
            'total_users' => 0,
            'active_products' => 0,
            'monthly_sales' => 0,
            'total_categories' => 0,
            'recent_activity' => []
        ];
        
        // Contar usuarios totales
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
        $stats['total_users'] = (int)$stmt->fetch()['count'];
        
        // Contar productos activos
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM products WHERE visible = 1");
        $stats['active_products'] = (int)$stmt->fetch()['count'];
        
        // Contar categorías
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM categories");
        $stats['total_categories'] = (int)$stmt->fetch()['count'];
        
        // Calcular ventas del mes actual (simplificado)
        $currentMonth = date('Y-m');
        $stmt = $pdo->query("SELECT COALESCE(SUM(total), 0) as monthly_sales FROM orders WHERE DATE_FORMAT(created_at, '%Y-%m') = '$currentMonth'");
        $stats['monthly_sales'] = (float)$stmt->fetch()['monthly_sales'];
        
        echo json_encode($stats);
        
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener datos del dashboard: ' . $e->getMessage()]);
    }
    exit;
}

// Endpoint: /api/categories
if ($endpoint === 'categories' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $pdo = getDB();
        $stmt = $pdo->query('SELECT id, name, slug FROM categories ORDER BY name');
        $categories = $stmt->fetchAll();
        echo json_encode($categories);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener categorías: ' . $e->getMessage()]);
    }
    exit;
}

// Endpoint: /api/products
if ($endpoint === 'products' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $pdo = getDB();
        
        // Parámetros de consulta
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 9;
        $offset = ($page - 1) * $limit;
        
        // Construir consulta
        $where = ['1=1'];
        $params = [];
        
        // Filtros
        if (!empty($_GET['q'])) {
            $where[] = 'title LIKE :search';
            $params[':search'] = '%' . $_GET['q'] . '%';
        }
        
        if (!empty($_GET['category'])) {
            $where[] = 'category_id = :category';
            $params[':category'] = $_GET['category'];
        }
        
        if (!empty($_GET['price_min'])) {
            $where[] = 'price >= :price_min';
            $params[':price_min'] = floatval($_GET['price_min']);
        }
        
        if (!empty($_GET['price_max'])) {
            $where[] = 'price <= :price_max';
            $params[':price_max'] = floatval($_GET['price_max']);
        }
        
        if (!empty($_GET['condition'])) {
            $where[] = 'condition = :condition';
            $params[':condition'] = $_GET['condition'];
        }
        
        $whereClause = implode(' AND ', $where);
        
        // Contar total de productos
        $countStmt = $pdo->prepare("SELECT COUNT(*) as total FROM products WHERE $whereClause AND visible = 1");
        $countStmt->execute($params);
        $total = $countStmt->fetch()['total'];
        
        // Obtener productos
        $stmt = $pdo->prepare("
            SELECT p.*, c.name as category_name 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE $whereClause AND p.visible = 1
            ORDER BY p.created_at DESC
            LIMIT :limit OFFSET :offset
        ");
        
        $params[':limit'] = $limit;
        $params[':offset'] = $offset;
        
        // Asignar tipos de parámetros
        foreach ($params as $key => $value) {
            if (is_int($value)) {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }
        
        $stmt->execute();
        $products = $stmt->fetchAll();
        
        // Formatear respuesta
        $response = [
            'items' => $products,
            'page' => $page,
            'total' => (int)$total,
            'limit' => $limit
        ];
        
        echo json_encode($response);
        
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener productos: ' . $e->getMessage()]);
    }
    exit;
}

// Endpoint: /api/search/suggest
if ($endpoint === 'search/suggest' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    
    if (empty($q)) {
        echo json_encode([]);
        exit;
    }
    
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("
            SELECT DISTINCT title 
            FROM products 
            WHERE title LIKE :search AND visible = 1
            LIMIT 5
        ");
        $stmt->execute([':search' => "%$q%"]);
        $suggestions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo json_encode(array_map(function($title) {
            return ['title' => $title];
        }, $suggestions));
        
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener sugerencias: ' . $e->getMessage()]);
    }
    exit;
}

// Endpoint: /api/auth/login
if ($endpoint === 'auth/login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (empty($data['email']) || empty($data['password'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Email y contraseña son obligatorios']);
            exit;
        }
        
        $pdo = getDB();
        
        // Buscar usuario por email
        $stmt = $pdo->prepare("SELECT id, name, email, password_hash, role FROM users WHERE email = ?");
        $stmt->execute([$data['email']]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($data['password'], $user['password_hash'])) {
            http_response_code(401);
            echo json_encode(['error' => 'Credenciales inválidas']);
            exit;
        }
        
        // Iniciar sesión
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['name'];
        
        // Generar token JWT
        $token = generateJWT([
            'user_id' => $user['id'],
            'user_name' => $user['name'],
            'role' => $user['role']
        ]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Login exitoso',
            'user' => [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'role' => $user['role']
            ],
            'token' => $token
        ]);
        
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error en el login: ' . $e->getMessage()]);
    }
    exit;
}

// Endpoint: /api/auth/me
if ($endpoint === 'auth/me' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        
        if (empty($token) || !preg_match('/Bearer (.+)/', $token, $matches)) {
            http_response_code(401);
            echo json_encode(['error' => 'Token de autenticación requerido']);
            exit;
        }
        
        $token = $matches[1];
        
        // TODO: Implementar validación de JWT token
        // Por ahora, obtener usuario desde sesión
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['error' => 'Sesión no válida']);
            exit;
        }
        
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        if (!$user) {
            http_response_code(404);
            echo json_encode(['error' => 'Usuario no encontrado']);
            exit;
        }
        
        echo json_encode($user);
        
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener información del usuario: ' . $e->getMessage()]);
    }
    exit;
}

// Si no se encontró la ruta
http_response_code(404);
echo json_encode(['error' => 'Ruta no encontrada: ' . $endpoint]);