import bcrypt from 'bcryptjs';
import { createUser, findUserByEmail } from '../src/models/user.model.js';

async function resetTestUser() {
    try {
        const testUser = {
            name: 'Usuario de Prueba',
            email: 'test@example.com',
            password: 'test123',
            role: 'buyer'
        };

        console.log('🔍 Verificando si el usuario de prueba ya existe...');
        const existingUser = await findUserByEmail(testUser.email);
        
        if (existingUser) {
            console.log('⚠️  El usuario de prueba ya existe. Se actualizará la contraseña.');
            // Aquí podríamos actualizar el usuario existente si es necesario
            console.log('✅ Usuario de prueba actualizado correctamente');
        } else {
            console.log('➕ Creando nuevo usuario de prueba...');
            const userId = await createUser(testUser);
            console.log(`✅ Usuario de prueba creado con ID: ${userId}`);
        }

        console.log('\n🔑 Credenciales de prueba:');
        console.log(`📧 Email: ${testUser.email}`);
        console.log(`🔑 Contraseña: ${testUser.password}`);
        console.log('\n¡Listo! Puedes iniciar sesión con estas credenciales.');

    } catch (error) {
        console.error('❌ Error al configurar el usuario de prueba:', error.message);
        if (error.sqlMessage) {
            console.error('Error de MySQL:', error.sqlMessage);
        }
    } finally {
        process.exit();
    }
}

// Ejecutar el script
resetTestUser();
