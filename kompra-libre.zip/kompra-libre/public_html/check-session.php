<?php
// Iniciar sesión
session_start();

// Verificar si hay una sesión activa
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['user']);
$userName = '';
$userRole = '';

if (isset($_SESSION['user'])) {
    $userName = $_SESSION['user']['name'] ?? '';
    $userRole = $_SESSION['user']['role'] ?? '';
} elseif (isset($_SESSION['user_name'])) {
    $userName = $_SESSION['user_name'];
    $userRole = $_SESSION['user_role'] ?? '';
}

// Mostrar información
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Sesión - Kompra Libre</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
        <h1 class="text-2xl font-bold mb-6">Estado de la Sesión</h1>
        
        <div class="mb-6 p-4 border rounded-lg">
            <h2 class="text-xl font-semibold mb-2">Información del Usuario</h2>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <p class="font-medium">Estado:</p>
                    <p class="text-lg <?= $isLoggedIn ? 'text-green-600' : 'text-red-600' ?>">
                        <?= $isLoggedIn ? 'Sesión Iniciada' : 'No hay sesión activa' ?>
                    </p>
                </div>
                <?php if ($isLoggedIn): ?>
                    <div>
                        <p class="font-medium">Nombre:</p>
                        <p class="text-lg"><?= htmlspecialchars($userName) ?></p>
                    </div>
                    <div>
                        <p class="font-medium">Rol:</p>
                        <p class="text-lg"><?= htmlspecialchars($userRole) ?></p>
                    </div>
                    <div>
                        <p class="font-medium">ID de Sesión:</p>
                        <p class="text-sm font-mono"><?= session_id() ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="mb-6 p-4 border rounded-lg">
            <h2 class="text-xl font-semibold mb-2">Datos de la Sesión</h2>
            <pre class="bg-gray-100 p-4 rounded overflow-auto"><?php print_r($_SESSION) ?></pre>
        </div>

        <div class="flex space-x-4">
            <?php if ($isLoggedIn): ?>
                <a href="/auth/logout.php" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">Cerrar Sesión</a>
                <a href="/" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Ir al Inicio</a>
            <?php else: ?>
                <a href="/login" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Iniciar Sesión</a>
                <a href="/register" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Registrarse</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
