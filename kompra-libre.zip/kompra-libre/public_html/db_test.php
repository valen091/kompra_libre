<?php
// Configuración de la base de datos
$host = 'localhost';
$dbname = 'u472738607_kompra_libre';
$username = 'u472738607_kompralibre';
$password = 'Kompralibre1';

try {
    // Intentar conectar a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h1>Conexión exitosa a la base de datos</h1>";
    
    // Listar usuarios
    $stmt = $pdo->query("SELECT id, nombre, email, rol FROM usuarios");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>Usuarios en la base de datos:</h2>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Nombre</th><th>Email</th><th>Rol</th></tr>";
    
    foreach ($users as $user) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($user['id']) . "</td>";
        echo "<td>" . htmlspecialchars($user['nombre']) . "</td>";
        echo "<td>" . htmlspecialchars($user['email']) . "</td>";
        echo "<td>" . htmlspecialchars($user['rol']) . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
} catch(PDOException $e) {
    echo "<h1>Error de conexión</h1>";
    echo "<p><strong>Mensaje de error:</strong> " . $e->getMessage() . "</p>";
    echo "<p><strong>Código de error:</strong> " . $e->getCode() . "</p>";
    
    // Mostrar información de depuración
    echo "<h2>Información de depuración:</h2>";
    echo "<pre>";
    echo "PDO::ATTR_ERRMODE: " . PDO::ERRMODE_EXCEPTION . "\n";
    echo "Intentando conectar a: mysql:host=$host;dbname=$dbname\n";
    echo "Usuario: $username\n";
    echo "</pre>";
}
?>
