<?php
header('Content-Type: application/json');

$configs = [
    'current' => [
        'host' => defined('DB_HOST') ? DB_HOST : 'localhost',
        'name' => defined('DB_NAME') ? DB_NAME : 'u472738607_kompra_libre',
        'user' => defined('DB_USER') ? DB_USER : 'u472738607_kompra_libre',
        'pass' => defined('DB_PASS') ? DB_PASS : 'Kompralibre1'
    ],
    'hostinger_standard' => [
        'host' => 'localhost',
        'name' => 'u472738607_kompra_libre',
        'user' => 'u472738607_kompra_libre',
        'pass' => 'Kompralibre1'
    ]
];

$results = [];

foreach ($configs as $name => $config) {
    try {
        $pdo = new PDO(
            "mysql:host={$config['host']};dbname={$config['name']};charset=utf8",
            $config['user'],
            $config['pass']
        );
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Verificar tablas
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

        // Verificar datos
        $users = $pdo->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
        $categories = $pdo->query("SELECT COUNT(*) as count FROM categories")->fetch()['count'];
        $products = $pdo->query("SELECT COUNT(*) as count FROM products WHERE visible = 1")->fetch()['count'];

        $results[$name] = [
            'success' => true,
            'message' => 'Conexión exitosa',
            'tables' => $tables,
            'data' => [
                'users' => $users,
                'categories' => $categories,
                'products' => $products
            ]
        ];

    } catch (Exception $e) {
        $results[$name] = [
            'success' => false,
            'error' => $e->getMessage(),
            'config' => $config
        ];
    }
}

echo json_encode([
    'debug_info' => $results,
    'working_config' => array_filter($results, function($r) { return $r['success']; }),
    'timestamp' => date('Y-m-d H:i:s')
], JSON_PRETTY_PRINT);
?>
