<?php
header('Content-Type: application/json');

try {
    $db = new PDO("mysql:host=localhost;dbname=u472738607_kompra_libre", "u472738607_kompra_libre", "Kompralibre1");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar tablas existentes
    $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

    // Verificar usuarios existentes
    $users = $db->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];

    // Verificar categorías existentes
    $categories = $db->query("SELECT COUNT(*) as count FROM categories")->fetch()['count'];

    // Verificar productos existentes
    $products = $db->query("SELECT COUNT(*) as count FROM products WHERE visible = 1")->fetch()['count'];

    echo json_encode([
        'success' => true,
        'message' => 'Conexión a BD exitosa',
        'database' => 'u472738607_kompra_libre',
        'tables' => $tables,
        'users_count' => $users,
        'categories_count' => $categories,
        'products_count' => $products,
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}
?>
