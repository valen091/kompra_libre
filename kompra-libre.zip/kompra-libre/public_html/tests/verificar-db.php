<?php
// Script de VERIFICACIÓN COMPLETA de la base de datos
// Verifica que todo esté configurado correctamente

header('Content-Type: text/plain');

try {
    // Intentar conectar con diferentes credenciales
    $credentials = [
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => ''],
    ];

    $pdo = null;
    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};dbname={$cred['db']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "✅ CONEXIÓN EXITOSA\n";
            echo "📍 Base de datos: {$cred['db']}\n";
            echo "👤 Usuario: {$cred['user']}\n\n";
            break;
        } catch (Exception $e) {
            continue;
        }
    }

    if (!$pdo) {
        throw new Exception("❌ No se pudo conectar con ninguna configuración de base de datos");
    }

    echo "🔍 VERIFICANDO ESTRUCTURA DE LA BASE DE DATOS...\n\n";

    // Verificar tablas existentes
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "📋 TABLAS ENCONTRADAS (" . count($tables) . "):\n";
    foreach ($tables as $table) {
        echo "  ✅ {$table}\n";
    }
    echo "\n";

    // Verificar usuarios
    $users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    echo "👤 USUARIOS: {$users}\n";

    if ($users > 0) {
        $userDetails = $pdo->query("SELECT id, name, email, role FROM users")->fetchAll();
        foreach ($userDetails as $user) {
            echo "  📍 ID {$user['id']}: {$user['name']} ({$user['email']}) - {$user['role']}\n";
        }
    }
    echo "\n";

    // Verificar categorías
    $categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
    echo "🏷️ CATEGORÍAS: {$categories}\n";

    if ($categories > 0) {
        $catDetails = $pdo->query("SELECT id, name, slug FROM categories")->fetchAll();
        foreach ($catDetails as $cat) {
            echo "  📍 ID {$cat['id']}: {$cat['name']} ({$cat['slug']})\n";
        }
    }
    echo "\n";

    // Verificar productos
    $products = $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn();
    echo "📦 PRODUCTOS VISIBLES: {$products}\n";

    if ($products > 0) {
        $prodDetails = $pdo->query("SELECT id, title, price, category_id FROM products WHERE visible = 1 LIMIT 5")->fetchAll();
        foreach ($prodDetails as $prod) {
            echo "  📍 {$prod['title']} - $" . number_format($prod['price'], 2) . " (Cat: {$prod['category_id']})\n";
        }
        if ($products > 5) {
            echo "  ... y " . ($products - 5) . " productos más\n";
        }
    }
    echo "\n";

    // Verificar vendedores
    $sellers = $pdo->query("SELECT COUNT(*) FROM sellers")->fetchColumn();
    echo "🏪 VENDEDORES: {$sellers}\n";

    if ($sellers > 0) {
        $sellerDetails = $pdo->query("SELECT s.user_id, s.shop_alias, u.email FROM sellers s JOIN users u ON s.user_id = u.id")->fetchAll();
        foreach ($sellerDetails as $seller) {
            echo "  📍 {$seller['shop_alias']} (Usuario: {$seller['email']})\n";
        }
    }
    echo "\n";

    // Verificar otras tablas importantes
    $carts = $pdo->query("SELECT COUNT(*) FROM carts")->fetchColumn();
    echo "🛒 CARRITOS: {$carts}\n";

    $orders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
    echo "📋 PEDIDOS: {$orders}\n";

    $reviews = $pdo->query("SELECT COUNT(*) FROM reviews")->fetchColumn();
    echo "⭐ RESEÑAS: {$reviews}\n";

    echo "\n🎯 ESTADO GENERAL:\n";

    if ($users > 0) {
        echo "✅ Usuarios configurados\n";
    } else {
        echo "❌ No hay usuarios - ejecuta el setup de datos\n";
    }

    if ($categories > 0) {
        echo "✅ Categorías configuradas\n";
    } else {
        echo "❌ No hay categorías - ejecuta el setup de datos\n";
    }

    if ($products > 0) {
        echo "✅ Productos disponibles ({$products})\n";
    } else {
        echo "❌ No hay productos - ejecuta el setup de datos\n";
    }

    if ($sellers > 0) {
        echo "✅ Vendedores configurados\n";
    } else {
        echo "❌ No hay vendedores - ejecuta el setup de datos\n";
    }

    echo "\n📊 RESUMEN COMPLETO:\n";
    echo "🔗 Total de tablas: " . count($tables) . "\n";
    echo "👤 Usuarios: {$users}\n";
    echo "🏷️ Categorías: {$categories}\n";
    echo "📦 Productos: {$products}\n";
    echo "🏪 Vendedores: {$sellers}\n";
    echo "🛒 Carritos: {$carts}\n";
    echo "📋 Pedidos: {$orders}\n";
    echo "⭐ Reseñas: {$reviews}\n";

    echo "\n🎉 VERIFICACIÓN COMPLETADA!\n";

    if ($products > 0 && $users > 0 && $categories > 0) {
        echo "✅ Todo está configurado correctamente\n";
        echo "🌐 Puedes usar la aplicación normalmente\n";
    } else {
        echo "⚠️ Faltan datos - ejecuta uno de los scripts de setup\n";
        echo "🔧 Recomendación: https://kompralibre.shop/setup-automatico.html\n";
    }

} catch (Exception $e) {
    echo "❌ ERROR EN VERIFICACIÓN: " . $e->getMessage() . "\n";
    echo "\n🔧 POSIBLES SOLUCIONES:\n";
    echo "1. Verifica que la base de datos existe\n";
    echo "2. Verifica las credenciales de conexión\n";
    echo "3. Verifica que las tablas están creadas\n";
    echo "4. Ejecuta el script de setup de datos\n";
}
?>
