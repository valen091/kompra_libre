<?php
header('Content-Type: application/json');

$results = [];

// Probar diferentes configuraciones
$configs = [
    'config_actual' => [
        'host' => 'localhost',
        'name' => 'u472738607_kompra_libre',
        'user' => 'u472738607_kompra_libre',
        'pass' => 'Kompralibre1'
    ],
    'sin_prefijo' => [
        'host' => 'localhost',
        'name' => 'kompra_libre',
        'user' => 'kompra_libre',
        'pass' => 'Kompralibre1'
    ],
    'hostinger_default' => [
        'host' => 'localhost',
        'name' => 'u472738607_kompra_libre',
        'user' => 'root',
        'pass' => ''
    ]
];

foreach ($configs as $name => $config) {
    try {
        $pdo = new PDO(
            "mysql:host={$config['host']};charset=utf8",
            $config['user'],
            $config['pass']
        );
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Verificar si la base de datos existe
        $databases = $pdo->query("SHOW DATABASES")->fetchAll(PDO::FETCH_COLUMN);
        $dbExists = in_array($config['name'], $databases);

        if ($dbExists) {
            // Usar la base de datos específica
            $pdo->exec("USE {$config['name']}");

            // Verificar tablas
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

            // Verificar datos
            $users = 0;
            $categories = 0;
            $products = 0;

            if (in_array('users', $tables)) {
                $users = $pdo->query("SELECT COUNT(*) FROM users")->fetch()['count'] ?? 0;
            }
            if (in_array('categories', $tables)) {
                $categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetch()['count'] ?? 0;
            }
            if (in_array('products', $tables)) {
                $products = $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetch()['count'] ?? 0;
            }

            $results[$name] = [
                'success' => true,
                'message' => 'Conexión exitosa',
                'database_exists' => true,
                'tables' => $tables,
                'data' => [
                    'users' => $users,
                    'categories' => $categories,
                    'products' => $products
                ]
            ];
        } else {
            $results[$name] = [
                'success' => true,
                'message' => 'Conexión exitosa pero base de datos no existe',
                'database_exists' => false,
                'available_databases' => $databases
            ];
        }

    } catch (Exception $e) {
        $results[$name] = [
            'success' => false,
            'error' => $e->getMessage(),
            'config' => $config
        ];
    }
}

echo json_encode([
    'connection_tests' => $results,
    'working_configs' => array_filter($results, function($r) {
        return isset($r['success']) && $r['success'] === true;
    }),
    'recommendations' => [
        'best_config' => array_key_first(array_filter($results, function($r) {
            return isset($r['success']) && $r['success'] === true && isset($r['database_exists']) && $r['database_exists'] === true;
        })) ?: 'none',
        'needs_schema' => array_filter($results, function($r) {
            return isset($r['success']) && $r['success'] === true && isset($r['tables']) && empty($r['tables']);
        }) ? 'yes' : 'no'
    ],
    'timestamp' => date('Y-m-d H:i:s')
], JSON_PRETTY_PRINT);
?>
