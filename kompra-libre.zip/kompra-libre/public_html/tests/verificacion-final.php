<?php
// Script de verificación final - confirma que todo esté funcionando
header('Content-Type: text/plain');

echo "🔍 VERIFICACIÓN FINAL DE LA BASE DE DATOS\n";
echo "==========================================\n\n";

try {
    // Intentar conectar
    $credentials = [
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => ''],
    ];

    $pdo = null;
    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};dbname={$cred['db']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "✅ CONEXIÓN EXITOSA como {$cred['user']}\n\n";
            break;
        } catch (Exception $e) {
            continue;
        }
    }

    if (!$pdo) {
        echo "❌ No se pudo conectar con ninguna configuración\n";
        exit;
    }

    // Verificar tablas
    echo "📋 TABLAS EN LA BASE DE DATOS:\n";
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        echo "  ✅ {$table}\n";
    }
    echo "\n";

    // Verificar usuarios
    $users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    echo "👤 USUARIOS: {$users}\n";

    if ($users > 0) {
        $userDetails = $pdo->query("SELECT name, email, role FROM users LIMIT 3")->fetchAll();
        foreach ($userDetails as $user) {
            echo "  📍 {$user['name']} ({$user['email']}) - {$user['role']}\n";
        }
    }
    echo "\n";

    // Verificar categorías
    $categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
    echo "🏷️ CATEGORÍAS: {$categories}\n";

    if ($categories > 0) {
        $catDetails = $pdo->query("SELECT name, slug FROM categories")->fetchAll();
        foreach ($catDetails as $cat) {
            echo "  📍 {$cat['name']} ({$cat['slug']})\n";
        }
    }
    echo "\n";

    // Verificar productos
    $products = $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn();
    echo "📦 PRODUCTOS VISIBLES: {$products}\n";

    if ($products > 0) {
        $prodDetails = $pdo->query("SELECT title, price, category_id FROM products WHERE visible = 1 LIMIT 5")->fetchAll();
        foreach ($prodDetails as $prod) {
            echo "  📍 {$prod['title']} - $" . number_format($prod['price'], 2) . " (Cat: {$prod['category_id']})\n";
        }
        if ($products > 5) {
            echo "  ... y " . ($products - 5) . " productos más\n";
        }
    }
    echo "\n";

    // Estado final
    echo "🎯 ESTADO GENERAL:\n";
    if ($users > 0) echo "✅ Usuarios configurados\n"; else echo "❌ No hay usuarios\n";
    if ($categories > 0) echo "✅ Categorías configuradas\n"; else echo "❌ No hay categorías\n";
    if ($products > 0) echo "✅ Productos disponibles ({$products})\n"; else echo "❌ No hay productos\n";

    if ($products >= 10) {
        echo "\n🎉 ¡TODO CONFIGURADO CORRECTAMENTE!\n";
        echo "🌐 La aplicación debería funcionar perfectamente\n";
        echo "📧 Usuario demo: demo@kompralibre.shop (contraseña: demo123)\n";
    } else {
        echo "\n⚠️ FALTAN DATOS - Ejecuta uno de los scripts de setup:\n";
        echo "1. https://kompralibre.shop/setup-sencillo.html (más fácil)\n";
        echo "2. https://kompralibre.shop/setup-definitivo.php (automático)\n";
        echo "3. Copia sql/datos-100-compatibles.sql en PHPMyAdmin\n";
    }

} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    echo "\n🔧 Verifica que:\n";
    echo "- La base de datos existe\n";
    echo "- Las credenciales son correctas\n";
    echo "- Las tablas están creadas\n";
}
?>
