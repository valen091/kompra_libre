<?php
header('Content-Type: application/json');

echo json_encode([
    'server_info' => $_SERVER,
    'php_info' => [
        'version' => phpversion(),
        'error_reporting' => error_reporting(),
        'display_errors' => ini_get('display_errors')
    ],
    'database_config' => [
        'host' => defined('DB_HOST') ? DB_HOST : 'not defined',
        'name' => defined('DB_NAME') ? DB_NAME : 'not defined',
        'user' => defined('DB_USER') ? DB_USER : 'not defined',
        'pass' => defined('DB_PASS') ? '[hidden]' : 'not defined'
    ],
    'files_includes' => file_exists(__DIR__ . '/includes/config.php') ? 'exists' : 'missing',
    'current_dir' => __DIR__,
    'timestamp' => date('Y-m-d H:i:s')
]);
?>
