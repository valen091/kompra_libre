# 📁 tests/ - Scripts de Prueba y Verificación

Este directorio contiene todos los scripts de prueba, verificación y diagnóstico del proyecto Kompra Libre.

## 📋 Contenido

### 🧪 Scripts de Prueba de API
- **`test-api.php`** - Pruebas de los endpoints de la API
- **`test-demo-data.php`** - Pruebas de datos de demostración
- **`test-demo-data-corregido.php`** - Pruebas de datos corregidos

### 🗄️ Scripts de Prueba de Base de Datos
- **`test-db.php`** - Pruebas básicas de base de datos
- **`test-db-connection.php`** - Pruebas de conexión a la base de datos
- **`check-db.php`** - Verificación rápida de base de datos
- **`verificar-db.php`** - Verificación completa de base de datos

### 🔍 Scripts de Diagnóstico
- **`debug-info.php`** - Información de debug del sistema
- **`diagnose-db.php`** - Diagnóstico completo de base de datos

### ✅ Scripts de Verificación
- **`verificacion-final.php`** - Verificación final del sistema

## 🔍 Uso

### Para Debugging
1. **Conexión BD**: Ejecuta `test-db-connection.php`
2. **Estado general**: Usa `debug-info.php`
3. **Problemas BD**: `diagnose-db.php` o `check-db.php`

### Para Testing
1. **API**: Prueba `test-api.php`
2. **Datos demo**: Usa `test-demo-data.php`
3. **Verificación**: Ejecuta `verificacion-final.php`

### Para Desarrollo
1. **Después de cambios**: Ejecuta pruebas relevantes
2. **Antes de deploy**: Corre verificación final
3. **Debug de errores**: Usa los scripts de diagnóstico

## 📁 Estructura Padre

```
📦 kompra-libre/
└── 📂 public_html/
    ├── 📂 config/
    ├── 📂 docs/
    ├── 📂 setup/
    ├── 📂 pages/
    ├── 📂 tests/          ← Estás aquí
    └── ... (otros directorios)
```

## ⚠️ Importante

### Antes de Ejecutar
1. **Verifica** que la base de datos esté accesible
2. **Haz respaldo** si vas a modificar datos
3. **Revisa** las credenciales en cada script

### Interpretar Resultados
1. **Errores**: Lee los mensajes de error detalladamente
2. **Warnings**: No ignores las advertencias
3. **Success**: Confirma que todo esté funcionando

## 🔧 Personalización

### Modificar Scripts
1. **Credenciales**: Actualiza usuario/contraseña de BD
2. **Configuración**: Ajusta parámetros según tu entorno
3. **Debug**: Agrega más logs si necesitas

### Crear Nuevos Tests
1. **Sigue** el patrón de nombres existente (test-*.php)
2. **Documenta** qué prueba cada script
3. **Mantén** consistencia en la estructura

## 📊 Tipos de Pruebas

### Unit Tests
- ✅ **Individuales** - Prueban componentes específicos
- ✅ **Rápidas** - Se ejecutan en segundos
- ✅ **Específicas** - Fácil identificar problemas

### Integration Tests
- ✅ **Completas** - Prueban flujo completo
- ✅ **Reales** - Usan datos reales
- ✅ **Exhaustivas** - Cubren múltiples componentes

### System Tests
- ✅ **End-to-end** - Prueban el sistema completo
- ✅ **Realistas** - Simulan uso real
- ✅ **Confianza** - Aseguran que todo funcione

## 📞 Troubleshooting

Si las pruebas fallan:
1. **Revisa** `docs/DEPLOYMENT.md` para configuración
2. **Verifica** `config/.env` para credenciales
3. **Consulta** `docs/README.md` para problemas comunes
4. **Debug** paso a paso con `debug-info.php`

## 🚀 Mejores Prácticas

- **Ejecuta** pruebas regularmente durante desarrollo
- **Automatiza** pruebas antes de deploy
- **Documenta** cualquier problema encontrado
- **Mantén** scripts actualizados con cambios del código
