-- ✅ KOMPRA LIBRE - BASE DE DATOS COMPLETA (VERSIÓN PHPMYADMIN)
-- Sin consultas complejas que puedan fallar en PHPMyAdmin
-- Compatible con MySQL 5.7+ y MariaDB 10.0+

-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS u472738607_kompra_libre 
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- Usar la base de datos
USE u472738607_kompra_libre;

-- Deshabilitar temporalmente las restricciones de clave foránea
SET FOREIGN_KEY_CHECKS = 0;

-- =================================================================
-- TABLAS PRINCIPALES (orden correcto para foreign keys)
-- =================================================================

-- Categorías de productos (primero por ser referenciada por otras tablas)
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  description TEXT,
  parent_id INT NULL,
  icon VARCHAR(50),
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_categories_parent (parent_id),
  INDEX idx_categories_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usuarios del sistema
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  user_role VARCHAR(20) NOT NULL DEFAULT 'buyer',
  phone VARCHAR(20),
  avatar VARCHAR(255),
  email_verified TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_email (email),
  INDEX idx_users_role (user_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Métodos de envío
CREATE TABLE IF NOT EXISTS shipping_methods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  estimated_days VARCHAR(50),
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_shipping_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vendedores (depende de users)
CREATE TABLE IF NOT EXISTS sellers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  shop_alias VARCHAR(120) NOT NULL,
  shop_description TEXT,
  shop_logo VARCHAR(255),
  reputation_score DECIMAL(3,2) DEFAULT 5.00,
  total_sales INT DEFAULT 0,
  total_products INT DEFAULT 0,
  verified TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_seller (user_id),
  INDEX idx_sellers_alias (shop_alias)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Administradores del sistema (depende de users)
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  permissions TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_admin (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Productos (depende de sellers y categories)
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seller_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(200) NOT NULL UNIQUE,
  description TEXT,
  short_description VARCHAR(500),
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2) NULL,
  stock INT NOT NULL DEFAULT 0,
  min_stock_alert INT DEFAULT 5,
  product_condition VARCHAR(20) DEFAULT 'nuevo',
  category_id INT,
  subcategory_id INT,
  brand VARCHAR(100),
  model VARCHAR(100),
  sku VARCHAR(100) UNIQUE,
  weight DECIMAL(8,3),
  dimensions VARCHAR(50),
  visible TINYINT(1) DEFAULT 1,
  featured TINYINT(1) DEFAULT 0,
  view_count INT DEFAULT 0,
  sales_count INT DEFAULT 0,
  rating_average DECIMAL(3,2) DEFAULT 0.00,
  rating_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  FOREIGN KEY (subcategory_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_products_seller (seller_id),
  INDEX idx_products_category (category_id),
  INDEX idx_products_visible (visible),
  INDEX idx_products_featured (featured),
  INDEX idx_products_price (price),
  INDEX idx_products_slug (slug)
);

-- Pedidos (depende de users, sellers y shipping_methods)
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(50) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  seller_id INT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  shipping_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
  tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(10,2) NOT NULL,
  order_status VARCHAR(20) DEFAULT 'pendiente',
  payment_status VARCHAR(20) DEFAULT 'pendiente',
  payment_method VARCHAR(50),
  shipping_method_id INT,
  shipping_address JSON,
  billing_address JSON,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE CASCADE,
  FOREIGN KEY (shipping_method_id) REFERENCES shipping_methods(id) ON DELETE SET NULL,
  INDEX idx_orders_user (user_id),
  INDEX idx_orders_seller (seller_id),
  INDEX idx_orders_status (order_status),
  INDEX idx_orders_number (order_number)
);

-- Items de pedido (depende de orders y products)
CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  product_title VARCHAR(200) NOT NULL,
  product_price DECIMAL(10,2) NOT NULL,
  quantity INT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_order_items_order (order_id)
);

-- Carritos de compra (depende de users)
CREATE TABLE IF NOT EXISTS carts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  session_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_carts_user (user_id),
  INDEX idx_carts_session (session_id)
);

-- Items del carrito (depende de carts y products)
CREATE TABLE IF NOT EXISTS cart_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cart_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cart_id) REFERENCES carts(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  UNIQUE KEY unique_cart_product (cart_id, product_id),
  INDEX idx_cart_items_cart (cart_id)
);

-- Imágenes de productos (depende de products)
CREATE TABLE IF NOT EXISTS product_images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  image_path VARCHAR(255) NOT NULL,
  alt_text VARCHAR(255),
  sort_order INT DEFAULT 0,
  is_primary TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_images_product (product_id),
  INDEX idx_images_primary (is_primary)
);

-- Reseñas de productos (depende de products, orders y users) - AHORA AL FINAL
CREATE TABLE IF NOT EXISTS reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  order_id INT NOT NULL,
  user_id INT NOT NULL,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_title VARCHAR(200),
  review_comment TEXT,
  verified_purchase TINYINT(1) DEFAULT 1,
  helpful_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_review (product_id, user_id),
  INDEX idx_reviews_product (product_id),
  INDEX idx_reviews_rating (rating)
);

-- =================================================================
-- DATOS DE EJEMPLO
-- =================================================================

-- Insertar métodos de envío
INSERT INTO shipping_methods (name, description, price, estimated_days) VALUES
('Envío estándar', 'Entrega en 3-5 días hábiles', 299.99, '3-5 días'),
('Envío express', 'Entrega en 1-2 días hábiles', 599.99, '1-2 días'),
('Retiro en tienda', 'Retirar en punto de venta', 0.00, 'Inmediato'),
('Envío gratis', 'Para compras mayores a $5000', 0.00, '3-5 días');

-- Tabla de configuraciones del sistema
CREATE TABLE IF NOT EXISTS system_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value VARCHAR(255),
  setting_description TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de mensajes
CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  from_user_id INT,
  to_user_id INT,
  message_text TEXT,
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_messages_from (from_user_id),
  INDEX idx_messages_to (to_user_id)
);

-- Tabla de notificaciones
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  message TEXT,
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notifications_user (user_id),
  INDEX idx_notifications_read (is_read)
);

-- Insertar configuraciones del sistema
INSERT INTO system_settings (setting_key, setting_value, setting_description) VALUES
('site_name', 'Kompra Libre', 'Nombre del sitio'),
('site_description', 'Marketplace educativo de productos variados', 'Descripción del sitio'),
('contact_email', 'admin@kompralibre.shop', 'Email de contacto'),
('min_order_amount', '100.00', 'Monto mínimo de pedido'),
('max_products_per_seller', '1000', 'Máximo productos por vendedor'),
('enable_reviews', '1', 'Permitir reseñas de productos'),
('enable_messaging', '1', 'Permitir mensajería entre usuarios'),
('default_currency', 'ARS', 'Moneda por defecto')
ON DUPLICATE KEY UPDATE 
  setting_value = VALUES(setting_value),
  setting_description = VALUES(setting_description);

-- Usuarios demo con Gmail (se insertarán solo si no existen)
DELETE FROM users WHERE email IN ('comprador@gmail.com', 'vendedor@gmail.com', 'admin@gmail.com');

INSERT INTO users (name, email, password_hash, user_role) VALUES
('Demo Comprador', 'comprador@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer'),
('Demo Vendedor', 'vendedor@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller'),
('Demo Admin', 'admin@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Obtener IDs de usuarios demo
SET @buyer_id = (SELECT id FROM users WHERE email = 'comprador@gmail.com' LIMIT 1);
SET @seller_id = (SELECT id FROM users WHERE email = 'vendedor@gmail.com' LIMIT 1);
SET @admin_id = (SELECT id FROM users WHERE email = 'admin@gmail.com' LIMIT 1);

-- Configurar vendedor (con ID fijo para asegurar consistencia)
SET @demo_seller_id = 1; -- Usamos un ID fijo para el vendedor demo

-- Primero eliminamos cualquier vendedor existente con este ID
DELETE FROM sellers WHERE id = @demo_seller_id OR user_id = @seller_id;

-- Insertamos el vendedor demo con ID fijo
INSERT INTO sellers (id, user_id, shop_alias, shop_description, verified) VALUES
(@demo_seller_id, @seller_id, 'Tienda Demo', 'Tienda oficial de demostración con los mejores productos', 1)
ON DUPLICATE KEY UPDATE 
  user_id = VALUES(user_id),
  shop_alias = VALUES(shop_alias),
  shop_description = VALUES(shop_description),
  verified = VALUES(verified);

-- Configurar admin (eliminar si existe primero)
DELETE FROM admins WHERE user_id = @admin_id;
INSERT INTO admins (user_id, permissions) VALUES
(@admin_id, 'all');

-- Asegurarnos de que el vendedor existe antes de continuar
-- Primero eliminamos cualquier vendedor existente con este ID
DELETE FROM sellers WHERE id = @demo_seller_id;

-- Luego insertamos el vendedor demo con ID fijo
-- Usamos INSERT IGNORE para evitar errores si ya existe
INSERT IGNORE INTO sellers (id, user_id, shop_alias, shop_description, verified)
VALUES (@demo_seller_id, @seller_id, 'Tienda Demo', 'Tienda de demostración', 1);

-- Eliminar categorías demo si existen
-- Primero eliminamos las categorías hijas que podrían tener restricciones de clave foránea
UPDATE categories SET parent_id = NULL WHERE parent_id IS NOT NULL AND parent_id <= 10;
-- Luego eliminamos las categorías principales
DELETE FROM categories WHERE id <= 10;

-- Insertar categorías demo
INSERT IGNORE INTO categories (id, name, slug, description, icon, sort_order) VALUES
(1, 'Electrónica', 'electronica', 'Productos electrónicos y tecnología', 'fas fa-laptop', 1),
(2, 'Ropa y Accesorios', 'ropa', 'Moda, ropa y accesorios personales', 'fas fa-tshirt', 2),
(3, 'Hogar y Jardín', 'hogar', 'Artículos para el hogar y jardín', 'fas fa-home', 3),
(4, 'Deportes', 'deportes', 'Artículos deportivos y fitness', 'fas fa-football-ball', 4),
(5, 'Libros y Educación', 'libros', 'Libros, cursos y material educativo', 'fas fa-book', 5),
(6, 'Automóvil', 'automovil', 'Accesorios y repuestos para autos', 'fas fa-car', 6),
(7, 'Belleza y Cuidado Personal', 'belleza', 'Productos de belleza y cuidado personal', 'fas fa-spa', 7),
(8, 'Juguetes y Juegos', 'juguetes', 'Juguetes y juegos para todas las edades', 'fas fa-gamepad', 8),
(9, 'Música e Instrumentos', 'musica', 'Instrumentos musicales y accesorios', 'fas fa-music', 9),
(10, 'Salud y Bienestar', 'salud', 'Productos para la salud y bienestar', 'fas fa-heart', 10)
ON DUPLICATE KEY UPDATE
  name = VALUES(name),
  description = VALUES(description),
  icon = VALUES(icon),
  sort_order = VALUES(sort_order);

-- Reiniciar el contador de auto-incremento para categories
SET @max_id = (SELECT IFNULL(MAX(id), 0) FROM categories);
SET @sql = CONCAT('ALTER TABLE categories AUTO_INCREMENT = ', @max_id + 1);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Insertar categorías adicionales (solo si no existen)
INSERT IGNORE INTO categories (name, slug, description, icon, sort_order) VALUES
('Alimentos y Bebidas', 'alimentos', 'Comida, bebidas y productos gourmet', 'fas fa-utensils', 11),
('Arte y Manualidades', 'arte', 'Materiales para arte y manualidades', 'fas fa-palette', 12)
ON DUPLICATE KEY UPDATE
  name = VALUES(name),
  description = VALUES(description),
  icon = VALUES(icon),
  sort_order = VALUES(sort_order);

-- Eliminar registros relacionados en tablas con claves foráneas
-- Solo se eliminan los datos de las tablas existentes
DELETE FROM cart_items WHERE 1;
DELETE FROM order_items WHERE 1;
DELETE FROM product_images WHERE 1;
-- La tabla product_reviews no existe, se omite
-- La tabla wishlist_items no existe, se omite

-- Finalmente, eliminar todos los productos
DELETE FROM products WHERE 1;

-- Reiniciar el contador de auto-incremento
ALTER TABLE products AUTO_INCREMENT = 1;

-- Insertar productos de ejemplo
-- Insertar productos de ejemplo
-- Primero eliminamos cualquier producto existente del vendedor demo para evitar duplicados
DELETE FROM products WHERE seller_id = @demo_seller_id;

-- Verificar nuevamente que el vendedor existe
SET @demo_seller_id = 1; -- Forzar el ID del vendedor demo

-- Asegurarnos de que el vendedor existe
-- Usamos INSERT IGNORE para evitar errores si ya existe
INSERT IGNORE INTO sellers (id, user_id, shop_alias, shop_description, verified)
VALUES (@demo_seller_id, @seller_id, 'Tienda Demo', 'Tienda de demostración', 1);

-- Insertar productos con el ID fijo del vendedor
INSERT INTO products (seller_id, title, slug, description, short_description, price, original_price, stock, product_condition, category_id, brand, model, visible, featured) VALUES
(@demo_seller_id, 'iPhone 15 Pro Max 256GB', 'iphone-15-pro-max-256gb', 'El iPhone más avanzado con cámara profesional de 48MP, chip A17 Pro y pantalla Super Retina XDR de 6.7 pulgadas.', 'iPhone 15 Pro Max con cámara profesional', 1299999.99, 1399999.99, 10, 'nuevo', 1, 'Apple', 'iPhone 15 Pro Max', 1, 1),
(@demo_seller_id, 'MacBook Air M3 13" 8GB 256GB', 'macbook-air-m3-13-8gb-256gb', 'MacBook Air ultraligera con chip M3, 8GB de RAM unificada y 256GB de almacenamiento SSD. Perfecta para estudiantes.', 'MacBook Air con chip M3 ultraligera', 1099999.99, 1199999.99, 5, 'nuevo', 1, 'Apple', 'MacBook Air M3', 1, 1),
(@demo_seller_id, 'Camiseta Deportiva Nike Dri-FIT', 'camiseta-deportiva-nike-dri-fit', 'Camiseta transpirable para entrenamientos intensos. Tecnología Dri-FIT que mantiene la piel seca y cómoda.', 'Camiseta deportiva transpirable Nike', 29999.99, 34999.99, 20, 'nuevo', 2, 'Nike', 'Dri-FIT Sports', 1, 0),
(@demo_seller_id, 'Juego de Sartenes Antiaderentes 3 Piezas', 'juego-sartenes-antiaderentes-3-piezas', 'Set completo de sartenes antiaderentes con mangos ergonómicos. Incluye 20cm, 24cm y 28cm.', 'Set de sartenes antiaderentes de calidad', 89999.99, 99999.99, 15, 'nuevo', 3, 'KitchenPro', 'Professional Set', 1, 0),
(@demo_seller_id, 'Balón de Fútbol Adidas FIFA Approved', 'balon-futbol-adidas-fifa-approved', 'Balón oficial tamaño 5 homologado por FIFA. Perfecto para partidos profesionales y entrenamiento.', 'Balón oficial Adidas tamaño 5', 39999.99, 44999.99, 8, 'nuevo', 4, 'Adidas', 'FIFA Approved', 1, 0),
(@demo_seller_id, 'Clean Code: A Handbook of Agile Software Craftsmanship', 'clean-code-handbook-agile-software-craftsmanship', 'Libro fundamental sobre mejores prácticas de programación. Incluye ejemplos reales y consejos de expertos.', 'Libro sobre mejores prácticas de programación', 49999.99, 59999.99, 12, 'usado', 5, 'Prentice Hall', 'Clean Code', 1, 0),
(@demo_seller_id, 'Auriculares Bluetooth Sony WH-1000XM5', 'auriculares-bluetooth-sony-wh-1000xm5', 'Auriculares inalámbricos con cancelación de ruido líder en la industria. Hasta 30 horas de batería.', 'Auriculares con cancelación de ruido Sony', 199999.99, 229999.99, 7, 'nuevo', 1, 'Sony', 'WH-1000XM5', 1, 1),
(@demo_seller_id, 'Zapatillas Running Adidas Ultraboost 23', 'zapatillas-running-adidas-ultraboost-23', 'Zapatillas deportivas para running con tecnología Boost que proporciona retorno de energía en cada paso.', 'Zapatillas running con tecnología Boost', 89999.99, 99999.99, 15, 'nuevo', 4, 'Adidas', 'Ultraboost 23', 1, 0),
(@demo_seller_id, 'Lámpara de Escritorio LED Articulada', 'lampara-escritorio-led-articulada', 'Lámpara articulada con luz LED regulable en intensidad y temperatura de color. Base con cargador USB.', 'Lámpara LED articulada con cargador USB', 45999.99, 55999.99, 10, 'nuevo', 3, 'DeskLight', 'LED Pro', 1, 0),
(@demo_seller_id, 'Chaqueta Impermeable Outdoor Adventure', 'chaqueta-impermeable-outdoor-adventure', 'Chaqueta resistente al agua y viento para actividades outdoor. Con capucha y múltiples bolsillos.', 'Chaqueta impermeable para outdoor', 79999.99, 89999.99, 8, 'nuevo', 2, 'Adventure', 'Waterproof Pro', 1, 0),
(@demo_seller_id, 'Televisor Smart TV Samsung 55" 4K UHD', 'televisor-smart-tv-samsung-55-4k-uhd', 'Smart TV con resolución 4K UHD, HDR10+ y sistema operativo Tizen. Incluye asistentes de voz.', 'Smart TV 4K UHD 55 pulgadas Samsung', 899999.99, 999999.99, 3, 'nuevo', 1, 'Samsung', 'Crystal UHD', 1, 1),
(1, 'Reloj Inteligente Apple Watch Series 9 GPS', 'reloj-inteligente-apple-watch-series-9-gps', 'Apple Watch Series 9 con GPS, monitor de salud avanzado y hasta 18 horas de batería.', 'Apple Watch Series 9 con GPS', 399999.99, 449999.99, 6, 'nuevo', 1, 'Apple', 'Watch Series 9', 1, 1),
(1, 'Sofá Moderno de 3 Plazas', 'sofa-moderno-3-plazas', 'Sofá moderno y cómodo con tapizado en tela resistente. Ideal para sala de estar o living.', 'Sofá moderno de 3 plazas', 599999.99, 699999.99, 4, 'nuevo', 3, 'HomeStyle', 'Modern Comfort', 1, 0),
(1, 'Bicicleta Mountain Bike 21 Velocidades', 'bicicleta-mountain-bike-21-velocidades', 'Bicicleta todo terreno con 21 velocidades, frenos de disco y suspensión delantera.', 'Bicicleta mountain bike 21 velocidades', 299999.99, 349999.99, 2, 'nuevo', 4, 'BikePro', 'Mountain Trail', 1, 0),
(1, 'Guitarra Acústica Yamaha F310', 'guitarra-acustica-yamaha-f310', 'Guitarra acústica de madera de abeto con cuerdas de nailon. Perfecta para principiantes.', 'Guitarra acústica Yamaha para principiantes', 199999.99, 229999.99, 5, 'nuevo', 9, 'Yamaha', 'F310', 1, 0);

-- Imágenes de productos
INSERT INTO product_images (product_id, image_path, alt_text, sort_order, is_primary) VALUES
(1, '/img/products/iphone-15-pro-1.jpg', 'iPhone 15 Pro Max vista frontal', 1, 1),
(1, '/img/products/iphone-15-pro-2.jpg', 'iPhone 15 Pro Max vista trasera', 2, 0),
(1, '/img/products/iphone-15-pro-3.jpg', 'iPhone 15 Pro Max con cámara', 3, 0),
(2, '/img/products/macbook-air-1.jpg', 'MacBook Air M3 vista lateral', 1, 1),
(2, '/img/products/macbook-air-2.jpg', 'MacBook Air M3 teclado', 2, 0),
(3, '/img/products/nike-shirt-1.jpg', 'Camiseta Nike vista frontal', 1, 1),
(3, '/img/products/nike-shirt-2.jpg', 'Camiseta Nike detalle tela', 2, 0),
(4, '/img/products/sartenes-1.jpg', 'Set de sartenes completo', 1, 1),
(4, '/img/products/sartenes-2.jpg', 'Sartenes antiaderentes', 2, 0),
(5, '/img/products/balon-1.jpg', 'Balón Adidas oficial', 1, 1),
(6, '/img/products/clean-code-1.jpg', 'Libro Clean Code portada', 1, 1);

-- Obtener IDs de usuarios y vendedores demo
SET @buyer_id = (SELECT id FROM users WHERE email = 'comprador@gmail.com' LIMIT 1);
SET @seller_id = (SELECT id FROM users WHERE email = 'vendedor@gmail.com' LIMIT 1);
SET @demo_seller_id = (SELECT id FROM sellers WHERE user_id = @seller_id LIMIT 1);

-- Eliminar pedido existente con el mismo número si existe
DELETE FROM order_items WHERE order_id IN (SELECT id FROM orders WHERE order_number = 'KL20241027-000001');
DELETE FROM orders WHERE order_number = 'KL20241027-000001';

-- Insertar pedido de ejemplo para las reseñas
-- Primero insertamos el pedido usando los IDs correctos
INSERT INTO orders (order_number, user_id, seller_id, subtotal, shipping_cost, total_amount, order_status, payment_status, shipping_method_id, created_at) 
SELECT 
    'KL20241027-000001', 
    @buyer_id, 
    @demo_seller_id, 
    1449999.98, 
    299.99, 
    1450299.97, 
    'entregado', 
    'completado', 
    1, 
    '2024-10-27 10:00:00'
FROM dual
WHERE EXISTS (SELECT 1 FROM users WHERE id = @buyer_id)
AND EXISTS (SELECT 1 FROM sellers WHERE id = @demo_seller_id);

-- Obtenemos el ID del pedido recién insertado
SET @order_id = LAST_INSERT_ID();

-- Items del pedido usando el ID correcto
INSERT INTO order_items (order_id, product_id, product_title, product_price, quantity, subtotal) VALUES
(@order_id, 1, 'iPhone 15 Pro Max 256GB', 1299999.99, 1, 1299999.99),
(@order_id, 2, 'MacBook Air M3 13" 8GB 256GB', 1099999.99, 1, 1099999.99),
(@order_id, 3, 'Camiseta Deportiva Nike Dri-FIT', 29999.99, 1, 29999.99),
(@order_id, 4, 'Juego de Sartenes Antiaderentes 3 Piezas', 89999.99, 1, 89999.99),
(@order_id, 5, 'Balón de Fútbol Adidas FIFA Approved', 39999.99, 1, 39999.99),
(@order_id, 6, 'Clean Code: A Handbook of Agile Software Craftsmanship', 49999.99, 1, 49999.99);

-- Reseñas de ejemplo usando el order_id y user_id correctos
-- Primero verificamos que el pedido existe y obtenemos el user_id del comprador
SET @reviewer_id = (SELECT user_id FROM orders WHERE id = @order_id LIMIT 1);

-- Solo insertar reseñas si el pedido existe
INSERT INTO reviews (product_id, order_id, user_id, rating, review_title, review_comment, verified_purchase) 
SELECT 1, @order_id, @reviewer_id, 5, 'Excelente producto', 'El iPhone llegó en perfectas condiciones y funciona de maravilla. La cámara es impresionante.', 1
WHERE @reviewer_id IS NOT NULL
UNION ALL
SELECT 2, @order_id, @reviewer_id, 5, 'Perfecta para el trabajo', 'La MacBook Air es rapidísima y la batería dura todo el día. Ideal para estudiantes.', 1
WHERE @reviewer_id IS NOT NULL
UNION ALL
SELECT 3, @order_id, @reviewer_id, 4, 'Buena calidad', 'La camiseta es cómoda y transpirable, aunque el talle es un poco pequeño.', 1
WHERE @reviewer_id IS NOT NULL
UNION ALL
SELECT 4, @order_id, @reviewer_id, 5, 'Excelentes sartenes', 'Se calientan rápido y no se pega nada. Muy buena calidad por el precio.', 1
WHERE @reviewer_id IS NOT NULL
UNION ALL
SELECT 5, @order_id, @reviewer_id, 5, 'Perfecto para jugar', 'Balón de muy buena calidad, igual que los profesionales usan.', 1
WHERE @reviewer_id IS NOT NULL
UNION ALL
SELECT 6, @order_id, @reviewer_id, 5, 'Libro fundamental', 'Excelente libro para aprender buenas prácticas de programación. Muy recomendado.', 1
WHERE @reviewer_id IS NOT NULL;

-- =================================================================
-- ÍNDICES PARA OPTIMIZACIÓN
-- =================================================================

-- Eliminar índices si existen
DROP INDEX IF EXISTS idx_products_price_range ON products;
DROP INDEX IF EXISTS idx_products_category_visible ON products;
DROP INDEX IF EXISTS idx_products_seller_visible ON products;
DROP INDEX IF EXISTS idx_orders_status_date ON orders;
DROP INDEX IF EXISTS idx_messages_conversation_read ON messages;

-- Crear índices para optimización
CREATE INDEX IF NOT EXISTS idx_products_price_range ON products (price, visible);
CREATE INDEX IF NOT EXISTS idx_products_category_visible ON products (category_id, visible);
CREATE INDEX IF NOT EXISTS idx_products_seller_visible ON products (seller_id, visible);
CREATE INDEX IF NOT EXISTS idx_orders_status_date ON orders (order_status, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_conversation_read ON messages (from_user_id, to_user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications (user_id, is_read, created_at);

-- Índices para búsquedas fulltext
-- Primero eliminamos los índices fulltext si existen
SET @dbname = DATABASE();

-- Eliminar índices fulltext existentes para evitar duplicados
SET @drop_products_ft = CONCAT('ALTER TABLE products DROP INDEX IF EXISTS idx_products_fulltext');
SET @drop_categories_ft = CONCAT('ALTER TABLE categories DROP INDEX IF EXISTS idx_categories_fulltext');

PREPARE stmt FROM @drop_products_ft;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

PREPARE stmt FROM @drop_categories_ft;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Crear índices fulltext
ALTER TABLE products ADD FULLTEXT INDEX idx_products_fulltext (title, description, short_description, brand, model);
ALTER TABLE categories ADD FULLTEXT INDEX idx_categories_fulltext (name, description);

-- =================================================================
-- RESULTADO
-- =================================================================

-- Mostrar resumen (sin consultas complejas que fallen en PHPMyAdmin)
SELECT '✅ SETUP COMPLETADO' as status;
SELECT '📊 RESUMEN DE DATOS INSERTADOS' as info;
SELECT CONCAT('👤 Usuarios: ', COUNT(*)) as usuarios FROM users;
SELECT CONCAT('🏷️ Categorías: ', COUNT(*)) as categorias FROM categories;
SELECT CONCAT('📦 Productos: ', COUNT(*)) as productos FROM products WHERE visible = 1;
SELECT CONCAT('🏪 Vendedores: ', COUNT(*)) as vendedores FROM sellers;
SELECT CONCAT('👨‍💼 Admins: ', COUNT(*)) as admins FROM admins;
SELECT CONCAT('📸 Imágenes: ', COUNT(*)) as imagenes FROM product_images;
SELECT CONCAT('🛒 Pedidos: ', COUNT(*)) as pedidos FROM orders;
SELECT CONCAT('📋 Items de pedido: ', COUNT(*)) as order_items FROM order_items;
SELECT CONCAT('⭐ Reseñas: ', COUNT(*)) as reseñas FROM reviews;

-- Reactivar restricciones de clave foránea
SET FOREIGN_KEY_CHECKS = 1;
