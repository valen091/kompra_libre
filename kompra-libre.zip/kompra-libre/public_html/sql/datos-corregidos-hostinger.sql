-- Script SQL ULTRA COMPATIBLE para Kompra Libre
-- Base de datos: u472738607_kompra_libre
-- Usuario: u472738607_kompra_libre (Contraseña: Kompralibre1)
-- Compatible con MySQL/MariaDB en Hostinger
-- Sin subconsultas, maneja duplicados con INSERT IGNORE
-- Ejecuta en orden: primero este script, luego verifica

USE u472738607_kompra_libre;

-- 1. Insertar usuario demo (evita duplicados)
INSERT IGNORE INTO users (name, email, password_hash, role) VALUES
('Demo User', 'demo@kompralibre.shop', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller');

-- 2. Insertar categorías (evita duplicados)
INSERT IGNORE INTO categories (name, slug) VALUES
('Electrónica', 'electronica');

INSERT IGNORE INTO categories (name, slug) VALUES
('Ropa', 'ropa');

INSERT IGNORE INTO categories (name, slug) VALUES
('Hogar', 'hogar');

INSERT IGNORE INTO categories (name, slug) VALUES
('Deportes', 'deportes');

INSERT IGNORE INTO categories (name, slug) VALUES
('Libros', 'libros');

-- 3. Insertar vendedor (usa user_id = 1, asumiendo que el usuario insertado es el primero)
INSERT IGNORE INTO sellers (user_id, shop_alias) VALUES
(1, 'Tienda Demo');

-- 4. Insertar productos (usa IDs fijos para category_id, sin subconsultas)
INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 10, 'nuevo', 1, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 5, 'nuevo', 1, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 20, 'nuevo', 2, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 15, 'nuevo', 3, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 8, 'nuevo', 4, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 12, 'usado', 5, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 7, 'nuevo', 1, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, 15, 'nuevo', 4, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 10, 'nuevo', 3, 1);

INSERT IGNORE INTO products (seller_id, title, description, price, stock, `condition`, category_id, visible) VALUES
(1, 'Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, 8, 'nuevo', 2, 1);

-- 5. Verificación final
SELECT '✅ Usuarios:' as resultado, COUNT(*) as cantidad FROM users
UNION ALL
SELECT '✅ Categorías:', COUNT(*) FROM categories
UNION ALL
SELECT '✅ Productos visibles:', COUNT(*) FROM products WHERE visible = 1
UNION ALL
SELECT '✅ Vendedores:', COUNT(*) FROM sellers;
