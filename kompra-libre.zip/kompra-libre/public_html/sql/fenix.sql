-- Create fenix_chat table to store chat messages
CREATE TABLE IF NOT EXISTS fenix_chat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    mensaje TEXT NOT NULL,
    tipo ENUM('pregunta', 'respuesta') NOT NULL,
    fecha_creacion DATETIME NOT NULL,
    leido BOOLEAN DEFAULT FALSE,
    metadata JSON,
    INDEX idx_usuario (usuario_id),
    INDEX idx_fecha (fecha_creacion),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create table for suggested questions
CREATE TABLE IF NOT EXISTS fenix_suggested_questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pregunta VARCHAR(255) NOT NULL,
    categoria VARCHAR(50),
    es_activa BOOLEAN DEFAULT TRUE,
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_categoria (categoria),
    INDEX idx_activa (es_activa)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create table for chat sessions
CREATE TABLE IF NOT EXISTS fenix_chat_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    session_id VARCHAR(255) NOT NULL,
    estado ENUM('activa', 'inactiva', 'en_espera') DEFAULT 'activa',
    fecha_inicio DATETIME NOT NULL,
    fecha_ultima_interaccion DATETIME NOT NULL,
    metadata JSON,
    UNIQUE KEY uk_session (session_id),
    INDEX idx_usuario (usuario_id),
    INDEX idx_estado (estado),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert some default suggested questions
INSERT INTO fenix_suggested_questions (pregunta, categoria) VALUES
('¿Cómo realizo un pedido?', 'pedidos'),
('¿Cuáles son los métodos de pago?', 'pagos'),
('¿Cómo hogo un seguimiento de mi envío?', 'envios'),
('¿Cuál es la política de devoluciones?', 'devoluciones'),
('¿Tienen envío a mi zona?', 'envios'),
('¿Cómo cambio mi contraseña?', 'cuenta'),
('¿Dónde veo mis pedidos anteriores?', 'pedidos'),
('¿Cómo contacto al servicio al cliente?', 'soporte'),
('¿Ofrecen descuentos al por mayor?', 'pagos'),
('¿Cómo actualizo mi información de envío?', 'cuenta');

-- Add a column to users table to store chat preferences if it doesn't exist
SET @dbname = DATABASE();
SET @preparedStatement = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE table_schema = @dbname 
     AND table_name = 'usuarios' 
     AND column_name = 'chat_preferences') > 0,
    'SELECT 1',
    'ALTER TABLE usuarios ADD COLUMN chat_preferences JSON DEFAULT NULL'
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;