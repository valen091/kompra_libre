/**
 * Sistema de autenticación con persistencia de sesión
 */

class AuthManager {
        constructor() {
            // Usar URL absoluta para evitar problemas de ruta
            this.API_URL = window.location.origin + '/api/auth';
            this.TOKEN_KEY = 'kompra_libre_token';
            this.USER_KEY = 'kompra_libre_user';
            this.redirectUrls = {
                'admin': '/admin/dashboard.html',
                'seller': '/vendedor/dashboard.html',
                'buyer': '/index.html'
            };
            this.defaultRedirect = '/index.html';
        }

        /**
         * Guardar sesión en localStorage
         */
        saveSession(token, user) {
            try {
                localStorage.setItem(this.TOKEN_KEY, token);
                localStorage.setItem(this.USER_KEY, JSON.stringify(user));
                console.log('Sesión guardada correctamente');
            } catch (error) {
                console.error('Error al guardar la sesión:', error);
            }
        }

        /**
         * Obtener token guardado
         */
        getToken() {
            try {
                return localStorage.getItem(this.TOKEN_KEY);
            } catch (error) {
                console.error('Error al obtener el token:', error);
                return null;
            }
        }

        /**
         * Obtener usuario guardado
         */
        getUser() {
            try {
                const userStr = localStorage.getItem(this.USER_KEY);
                return userStr ? JSON.parse(userStr) : null;
            } catch (error) {
                console.error('Error al obtener el usuario:', error);
                return null;
            }
        }

        /**
         * Verificar si hay sesión activa
         */
        isAuthenticated() {
            return !!this.getToken();
        }

        /**
         * Cerrar sesión
     */
    logout() {
        localStorage.removeItem(this.TOKEN_KEY);
        localStorage.removeItem(this.USER_KEY);
        window.location.replace('/login.html');
    }

    /**
     * Registrar nuevo usuario
     */
    async register(data) {
        try {
            const response = await fetch(`${this.API_URL}/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Error en el registro');
            }

            if (result.success && result.token) {
                this.saveSession(result.token, result.user);
                window.notify.success('¡Registro exitoso! Bienvenido a Kompra Libre');
                return result;
            } else {
                throw new Error(result.message || 'Error en el registro');
            }
        } catch (error) {
            window.notify.error(error.message);
            throw error;
        }
    }

    /**
     * Iniciar sesión
     */
    async login(email, password) {
        try {
            const response = await fetch(`${this.API_URL}/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'include',
                body: JSON.stringify({ email, password })
            });

            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.message || 'Error al iniciar sesión');
            }
            
            if (result.success && result.token) {
                this.saveSession(result.token, result.user);
                window.notify.success('¡Inicio de sesión exitoso!');
                
                // Obtener el parámetro de redirección de la URL
                const urlParams = new URLSearchParams(window.location.search);
                const redirect = urlParams.get('redirect');
                
                // Redirigir según el rol o la URL de redirección
                if (redirect) {
                    window.location.href = redirect === 'cart' ? '/carrito.html' : 
                                       redirect === 'wishlist' ? '/lista-deseos.html' :
                                       '/index.html';
                } else {
                    this.redirectByRole();
                }
                
                return result;
            } else {
                throw new Error(result.message || 'Error al iniciar sesión');
            }

            if (!response.ok) {
                const errorMsg = result.message || 'Credenciales incorrectas';
                console.error('Error en login:', { status: response.status, error: errorMsg });
                throw new Error(errorMsg);
            }

            if (!result.token || !result.user) {
                console.error('Respuesta inesperada del servidor:', result);
                throw new Error('Error en la respuesta del servidor');
            }

            // Guardar la sesión
            this.saveSession(result.token, result.user);
            window.notify.success('¡Inicio de sesión exitoso!');
            
            return result;
        } catch (error) {
            window.notify.error(error.message);
            throw error;
        }
    }

    /**
     * Obtener perfil del usuario
     */
    async getProfile() {
        const token = this.getToken();
        if (!token) {
            throw new Error('No hay sesión activa');
        }

        try {
            const response = await fetch(`${this.API_URL}/auth/profile`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const result = await response.json();

            if (!response.ok) {
                if (response.status === 401) {
                    // Token expirado, cerrar sesión
                    this.logout();
                }
                throw new Error(result.message || 'Error al obtener perfil');
            }

            return result.user;
        } catch (error) {
            throw error;
        }
    }

    /**
     * Hacer petición autenticada
     */
    async fetchAuth(url, options = {}) {
        const token = this.getToken();
        if (!token) {
            throw new Error('No hay sesión activa');
        }

        const headers = {
            ...options.headers,
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };

        const response = await fetch(url, {
            ...options,
            headers
        });

        if (response.status === 401) {
            // Token expirado
            this.logout();
            throw new Error('Sesión expirada');
        }

        return response;
    }

    /**
     * Actualizar información del usuario en localStorage
     */
    updateUser(userData) {
        const currentUser = this.getUser();
        const updatedUser = { ...currentUser, ...userData };
        localStorage.setItem(this.USER_KEY, JSON.stringify(updatedUser));
    }

    /**
     * Redirigir según el rol del usuario
     */
    redirectByRole() {
        const user = this.getUser();
        if (!user) {
            console.warn('No hay usuario para redirigir');
            window.location.href = this.defaultRedirect;
            return;
        }

        // Obtener la ruta de redirección según el rol
        const redirectTo = this.redirectUrls[user.user_role] || this.defaultRedirect;
        console.log(`Redirigiendo usuario ${user.user_role} a:`, redirectTo);
        
        // Usar replace para evitar problemas con el historial
        window.location.replace(redirectTo);
    }
}

// Asignar a window.auth
if (typeof window !== 'undefined') {
    // Crear instancia global
    const auth = new AuthManager();
    
    // Asegurar que la instancia esté disponible globalmente
    window.AuthManager = AuthManager;
    window.auth = auth;
    
    // Métodos de compatibilidad
    window.isAuthenticated = () => auth.isAuthenticated();
    window.getCurrentUser = () => auth.getUser();
    
    // Inicializar notificaciones si no existen
    if (!window.notify) {
        console.warn('Sistema de notificaciones no encontrado. Inicializando uno básico...');
        window.notify = {
            success: (msg) => console.log('Éxito:', msg),
            error: (msg) => console.error('Error:', msg),
            warning: (msg) => console.warn('Advertencia:', msg),
            info: (msg) => console.info('Info:', msg)
        };
    }
    
    console.log('Sistema de autenticación inicializado correctamente');
}
