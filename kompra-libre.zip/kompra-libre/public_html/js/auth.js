/**
 * Sistema de autenticación con persistencia de sesión
 */

class AuthManager {
    constructor() {
        this.API_URL = '/api';
        this.TOKEN_KEY = 'kompra_libre_token';
        this.USER_KEY = 'kompra_libre_user';
    }

    /**
     * Guardar sesión en localStorage
     */
    saveSession(token, user) {
        localStorage.setItem(this.TOKEN_KEY, token);
        localStorage.setItem(this.USER_KEY, JSON.stringify(user));
    }

    /**
     * Obtener token guardado
     */
    getToken() {
        return localStorage.getItem(this.TOKEN_KEY);
    }

    /**
     * Obtener usuario guardado
     */
    getUser() {
        const userStr = localStorage.getItem(this.USER_KEY);
        return userStr ? JSON.parse(userStr) : null;
    }

    /**
     * Verificar si hay sesión activa
     */
    isAuthenticated() {
        return !!this.getToken();
    }

    /**
     * Cerrar sesión
     */
    logout() {
        localStorage.removeItem(this.TOKEN_KEY);
        localStorage.removeItem(this.USER_KEY);
        window.location.href = '/login.html';
    }

    /**
     * Registrar nuevo usuario
     */
    async register(data) {
        try {
            const response = await fetch(`${this.API_URL}/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Error en el registro');
            }

            if (result.success && result.token) {
                this.saveSession(result.token, result.user);
                window.notify.success('¡Registro exitoso! Bienvenido a Kompra Libre');
                return result;
            } else {
                throw new Error(result.message || 'Error en el registro');
            }
        } catch (error) {
            window.notify.error(error.message);
            throw error;
        }
    }

    /**
     * Iniciar sesión
     */
    async login(email, password) {
        try {
            const response = await fetch(`${this.API_URL}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message || 'Credenciales incorrectas');
            }

            if (result.success && result.token) {
                this.saveSession(result.token, result.user);
                window.notify.success('¡Inicio de sesión exitoso!');
                return result;
            } else {
                throw new Error(result.message || 'Error al iniciar sesión');
            }
        } catch (error) {
            window.notify.error(error.message);
            throw error;
        }
    }

    /**
     * Obtener perfil del usuario
     */
    async getProfile() {
        const token = this.getToken();
        if (!token) {
            throw new Error('No hay sesión activa');
        }

        try {
            const response = await fetch(`${this.API_URL}/auth/profile`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const result = await response.json();

            if (!response.ok) {
                if (response.status === 401) {
                    // Token expirado, cerrar sesión
                    this.logout();
                }
                throw new Error(result.message || 'Error al obtener perfil');
            }

            return result.user;
        } catch (error) {
            throw error;
        }
    }

    /**
     * Hacer petición autenticada
     */
    async fetchAuth(url, options = {}) {
        const token = this.getToken();
        if (!token) {
            throw new Error('No hay sesión activa');
        }

        const headers = {
            ...options.headers,
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };

        const response = await fetch(url, {
            ...options,
            headers
        });

        if (response.status === 401) {
            // Token expirado
            this.logout();
            throw new Error('Sesión expirada');
        }

        return response;
    }

    /**
     * Actualizar información del usuario en localStorage
     */
    updateUser(userData) {
        const currentUser = this.getUser();
        const updatedUser = { ...currentUser, ...userData };
        localStorage.setItem(this.USER_KEY, JSON.stringify(updatedUser));
    }

    /**
     * Redirigir según el rol del usuario
     */
    redirectByRole() {
        const user = this.getUser();
        if (!user) {
            window.location.href = '/login.html';
            return;
        }

        const roleRedirects = {
            'admin': '/panel-admin.html',
            'seller': '/panel-vendedor.html',
            'buyer': '/panel-usuario.html'
        };

        const redirectUrl = roleRedirects[user.user_role] || '/panel-usuario.html';
        window.location.href = redirectUrl;
    }
}

// Instancia global
window.auth = new AuthManager();

// Exportar
export default AuthManager;
