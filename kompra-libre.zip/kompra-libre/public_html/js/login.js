// public/js/login.js
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const errorMessage = document.getElementById('errorMessage');
    const errorText = document.getElementById('errorText');
    const successMessage = document.getElementById('successMessage');

    const API_BASE_URL = '/api/auth';
    const API_LOGIN = `${API_BASE_URL}/login`;

    // Si viene ?email=... desde el registro, precarga
    const params = new URLSearchParams(window.location.search);
    const emailFromReg = params.get('email');
    if (emailFromReg) emailInput.value = emailFromReg;

    // Mostrar mensaje de registro exitoso si viene del registro
    if (params.get('registered') === 'true') {
        showMessage('¡Registro exitoso! Por favor inicia sesión.', 'success');
    }

    function setBusy(isBusy) {
        if (!form) return;
        const btn = form.querySelector('button[type="submit"]');
        if (!btn) return;
        
        btn.disabled = isBusy;
        btn.classList.toggle('opacity-60', isBusy);
        btn.innerHTML = isBusy ? 
            '<i class="fas fa-spinner fa-spin mr-2"></i> Ingresando...' : 
            '<i class="fas fa-sign-in-alt mr-2"></i> Iniciar Sesión';
    }

    function showMessage(text, type = 'error') {
        if (type === 'error') {
            errorText.textContent = text || 'Ocurrió un error inesperado';
            errorMessage.classList.remove('hidden');
            successMessage.classList.add('hidden');
        } else {
            errorMessage.classList.add('hidden');
            successMessage.classList.remove('hidden');
        }
    }

    function hideMessages() {
        errorMessage.classList.add('hidden');
        successMessage.classList.add('hidden');
    }

    async function postJSON(url, data) {
        try {
            const res = await fetch(url, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify(data),
            });
            
            const payload = await res.json().catch(() => ({}));
            return { 
                ok: res.ok, 
                status: res.status, 
                data: payload 
            };
        } catch (error) {
            console.error('Error en la petición:', error);
            return { 
                ok: false, 
                status: 0, 
                data: { message: 'Error de conexión' } 
            };
        }
    }

    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            hideMessages();
            setBusy(true);

            const formData = new FormData(form);
            const email = String(formData.get('email') || '').trim().toLowerCase();
            const password = String(formData.get('password') || '');
            const rememberMe = Boolean(formData.get('remember_me'));

            // Validaciones básicas
            if (!email || !password) {
                setBusy(false);
                return showMessage('Por favor ingresa tu correo y contraseña');
            }

            if (!email.endsWith('@gmail.com')) {
                setBusy(false);
                return showMessage('Solo se permiten cuentas de Gmail (@gmail.com)');
            }

            try {
                const { ok, status, data } = await postJSON(API_LOGIN, { 
                    email, 
                    password,
                    remember_me: rememberMe
                });

                if (!ok) {
                    const errorMsg = data?.message || data?.error || 'Credenciales inválidas';
                    throw new Error(errorMsg);
                }

                // Guardar datos del usuario en localStorage
                if (data.token) {
                    localStorage.setItem('auth_token', data.token);
                    localStorage.setItem('user', JSON.stringify(data.user));
                    
                    // Mostrar mensaje de éxito
                    showMessage('', 'success');
                    
                    // Redirigir según el rol del usuario
                    setTimeout(() => {
                        if (data.user.role === 'admin') {
                            window.location.href = '/admin/dashboard';
                        } else if (data.user.is_seller) {
                            window.location.href = '/seller/dashboard';
                        } else {
                            window.location.href = '/dashboard';
                        }
                    }, 1500);
                } else {
                    throw new Error('Error en la autenticación');
                }
            } catch (error) {
                console.error('Error en el inicio de sesión:', error);
                showMessage(error.message || 'Error al iniciar sesión. Intenta nuevamente.');
                setBusy(false);
            }
        });
    }
