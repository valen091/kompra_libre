// Base API configuration
const API_CONFIG = {
    // Use relative URLs to avoid CORS issues
    baseUrl: '',
    apiPrefix: '/api',
    defaultHeaders: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
    },
    // Define API endpoints with full paths
    endpoints: {
        categories: '/api/categories.php',
        products: '/api/products.php',
        // Add other endpoints as needed
    },
    // Timeout for API requests (in milliseconds)
    timeout: 10000,
    // Debug mode
    debug: true
};

// Fallback data in case API is not available
const FALLBACK_DATA = {
    'categorias.php': [
        { id: 1, name: 'Electrónica' },
        { id: 2, name: 'Ropa' },
        { id: 3, name: 'Hogar' },
        { id: 4, name: 'Deportes' },
        { id: 5, name: 'Juguetes' }
    ],
    'productos.php': {
        data: [
            {
                id: 1,
                nombre: 'Producto de Ejemplo 1',
                precio: 99.99,
                imagen: 'https://via.placeholder.com/300',
                descripcion: 'Descripción del producto de ejemplo.'
            },
            {
                id: 2,
                nombre: 'Producto de Ejemplo 2',
                precio: 149.99,
                imagen: 'https://via.placeholder.com/300',
                descripcion: 'Otro producto de ejemplo.'
            }
        ],
        meta: {
            pagina_actual: 1,
            ultima_pagina: 1,
            por_pagina: 10,
            total: 2
        }
    }
};

/**
 * Make an API request
 * @param {string} endpoint - API endpoint (e.g., 'categories.php' or 'products.php')
 * @param {Object} options - Fetch options
 * @param {boolean} useFallback - Whether to use fallback data if API fails
 * @returns {Promise<any>} - Parsed JSON response or fallback data
 */
async function api(endpoint, options = {}, useFallback = true) {
    // Clean up the endpoint
    let cleanEndpoint = endpoint.replace(/^\/+|\/+$/g, '');
    let fullUrl;
    
    // If the endpoint is a full URL, use it as is
    if (endpoint.startsWith('http') || endpoint.startsWith('/api/')) {
        fullUrl = endpoint;
    }
    // If the endpoint is a key in the endpoints object, use the corresponding value
    else if (API_CONFIG.endpoints[cleanEndpoint]) {
        fullUrl = API_CONFIG.endpoints[cleanEndpoint];
    }
    // If the endpoint is in the format 'endpoint.php', add the API prefix
    else if (cleanEndpoint.endsWith('.php')) {
        fullUrl = `${API_CONFIG.apiPrefix}/${cleanEndpoint}`;
    }
    // Otherwise, treat it as a relative path
    else {
        fullUrl = `${API_CONFIG.apiPrefix}/${cleanEndpoint}${cleanEndpoint.includes('?') ? '' : '.php'}`;
    }
    
    // Ensure the URL is absolute if baseUrl is not set
    const url = fullUrl.startsWith('http') ? fullUrl : `${window.location.origin}${fullUrl}`;
    
    // Merge headers
    const headers = {
        ...API_CONFIG.defaultHeaders,
        ...(options.headers || {})
    };
    
    console.log(`[API] ${options.method || 'GET'} ${url}`);
    
    // If we're in development mode, check for fallback data first
    if (process.env.NODE_ENV === 'development' && useFallback && FALLBACK_DATA[cleanEndpoint.split('?')[0]]) {
        console.warn('[API] Using fallback data for', cleanEndpoint);
        return Promise.resolve(FALLBACK_DATA[cleanEndpoint.split('?')[0]]);
    }
    
    // Create a timeout promise
    const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => {
            reject(new Error('Request timed out'));
        }, API_CONFIG.timeout);
    });
    
    try {
        // Race the fetch against the timeout
        const fetchPromise = fetch(url, {
            ...options,
            method: options.method || 'GET',
            headers,
            credentials: 'include',
            cache: 'no-store', // Ensure we don't get cached errors
            redirect: 'follow'
        });
        
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        console.log(`[API] ${response.status} ${response.statusText} - ${url}`);
        
        // Get the response text first to handle both JSON and non-JSON responses
        let responseText;
        try {
            responseText = await response.text();
            // Try to parse as JSON first
            if (responseText) {
                return JSON.parse(responseText);
            }
            return null;
        } catch (e) {
            // If it's not JSON, continue with the text
            console.warn('[API] Response is not valid JSON, returning as text');
            return responseText;
        }
        
        // Handle non-OK responses
        if (!response.ok) {
            let errorMessage = `HTTP ${response.status} ${response.statusText}`;
            
            // Try to extract error message from HTML response
            if (contentType.includes('text/html')) {
                const errorMatch = responseText.match(/<h1[^>]*>([^<]+)<\/h1>/i) || 
                                 responseText.match(/<title[^>]*>([^<]+)<\/title>/i) ||
                                 responseText.match(/<p[^>]*>([^<]+)<\/p>/i);
                if (errorMatch) {
                    errorMessage = errorMatch[1].trim();
                } else if (responseText.includes('<body>')) {
                    // If we have a body but couldn't parse it, return a generic error
                    errorMessage = `Error del servidor (${response.status})`;
                }
            } 
            // Try to parse as JSON if possible
            else if (contentType.includes('application/json')) {
                try {
                    const errorData = JSON.parse(responseText);
                    errorMessage = errorData.message || errorData.error || JSON.stringify(errorData);
                } catch (e) {
                    // If JSON parsing fails, use the text as is
                    errorMessage = responseText || errorMessage;
                }
            }
            
            const error = new Error(errorMessage);
            error.status = response.status;
            error.response = response;
            throw error;
        }
        
        // If the response is empty, return an empty object
        if (!responseText.trim()) {
            return {};
        }
        
        // Try to parse as JSON
        try {
            return JSON.parse(responseText);
        } catch (e) {
            console.warn('Response is not valid JSON, returning as text');
            return responseText;
        }
    } catch (error) {
        console.error('[API Error]', {
            message: error.message,
            endpoint,
            url,
            status: error.status,
            stack: error.stack
        });
        
        // If we have fallback data for this endpoint, use it
        const endpointKey = cleanEndpoint.split('?')[0]; // Remove query params
        if (FALLBACK_DATA[endpointKey] && useFallback) {
            console.warn(`Using fallback data for ${endpoint}`);
            return FALLBACK_DATA[endpointKey];
        }
        
        throw error;
    }
}

// Helper functions for common HTTP methods
const apiGet = (endpoint, options = {}, useFallback = true) => 
    api(endpoint, { ...options, method: 'GET' }, useFallback);

const apiPost = (endpoint, data, options = {}) => 
    api(endpoint, { 
        ...options, 
        method: 'POST',
        body: JSON.stringify(data)
    });

const apiPut = (endpoint, data, options = {}) => 
    api(endpoint, { 
        ...options, 
        method: 'PUT',
        body: JSON.stringify(data)
    });

const apiDelete = (endpoint, options = {}) => 
    api(endpoint, { ...options, method: 'DELETE' });

export { api, apiGet, apiPost, apiPut, apiDelete };
