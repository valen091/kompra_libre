class FenixChat {
    constructor() {
        this.isOpen = false;
        this.messages = [];
        this.hasUnreadMessages = false;
        this.initialize();
        this.setupEventListeners();
    }

    initialize() {
        // Get existing chat elements
        this.chatContainer = document.getElementById('fenix-chat-container');
        this.chatHeader = document.getElementById('fenix-chat-header');
        this.chatContent = document.getElementById('fenix-chat-content');
        this.chatMessages = document.getElementById('chat-messages');
        this.notificationBadge = document.getElementById('fenix-notification');
        
        // Check if chat was previously open
        const chatState = localStorage.getItem('fenixChatState');
        this.isOpen = chatState === 'open';
        
        // Apply initial state
        this.updateChatState();

        // Add welcome message if chat is empty
        if (this.chatMessages.children.length <= 1) {  // Only welcome message exists
            this.addMessage('¡Hola! Soy Fénix, tu asistente de Kompra Libre. ¿En qué puedo ayudarte hoy?', 'bot');
        }

        // Update chat state based on initial state
        this.updateChatState();
    }

    setupEventListeners() {
        // Toggle chat
        this.chatHeader.addEventListener('click', () => {
            this.toggleChat();
        });

        // Minimize button
        document.getElementById('minimize-chat').addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleChat();
        });

        // Close button
        document.getElementById('close-chat').addEventListener('click', (e) => {
            e.stopPropagation();
            this.closeChat();
        });

        // Send message on Enter key
        const input = document.getElementById('user-input');
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Send message on button click
        document.getElementById('send-message').addEventListener('click', () => {
            this.sendMessage();
        });
        
        // Handle page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible' && this.hasUnreadMessages) {
                this.showNotification();
            }
        });
    }

    updateChatState() {
        if (this.isOpen) {
            this.chatContent.classList.remove('hidden');
            this.chatHeader.querySelector('i').classList.replace('fa-comment', 'fa-window-minimize');
            document.getElementById('minimize-chat').innerHTML = '<i class="fas fa-window-minimize"></i>';
            this.hasUnreadMessages = false;
            this.hideNotification();
            // Auto-scroll to bottom when opening
            setTimeout(() => {
                this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
            }, 100);
        } else {
            this.chatContent.classList.add('hidden');
            this.chatHeader.querySelector('i').classList.replace('fa-window-minimize', 'fa-comment');
            document.getElementById('minimize-chat').innerHTML = '<i class="fas fa-comment"></i>';
        }
        
        // Save state to localStorage
        localStorage.setItem('fenixChatState', this.isOpen ? 'open' : 'closed');
    }
    
    toggleChat() {
        this.isOpen = !this.isOpen;
        this.updateChatState();
        
        if (this.isOpen) {
            document.getElementById('user-input').focus();
            this.hasUnreadMessages = false;
            this.hideNotification();
        }
    }

    closeChat() {
        this.isOpen = false;
        this.updateChatState();
    }
    
    showNotification() {
        if (!this.isOpen) {
            this.hasUnreadMessages = true;
            this.notificationBadge.classList.remove('hidden');
            
            // Add animation class
            this.notificationBadge.classList.add('animate-ping-once');
            
            // Remove animation class after it completes
            setTimeout(() => {
                this.notificationBadge.classList.remove('animate-ping-once');
            }, 1000);
        }
    }
    
    hideNotification() {
        this.hasUnreadMessages = false;
        this.notificationBadge.classList.add('hidden');
    }

    async sendMessage() {
        const input = document.getElementById('user-input');
        const message = input.value.trim();
        
        if (!message) return;

        // Add user message to chat
        this.addMessage(message, 'user');
        input.value = '';
        
        // Show typing indicator
        const typingId = this.showTypingIndicator();
        
        try {
            // Send message to backend
            const response = await fetch('/api/fenix/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
                },
                body: JSON.stringify({ message })
            });
            
            const data = await response.json();
            
            // Remove typing indicator
            this.removeTypingIndicator(typingId);
            
            // Add bot response to chat
            if (data.success) {
                this.addMessage(data.response, 'bot');
                
                // If there are suggested questions, show them
                if (data.suggestedQuestions && data.suggestedQuestions.length > 0) {
                    this.showSuggestedQuestions(data.suggestedQuestions);
                }
            } else {
                this.addMessage('Lo siento, ha ocurrido un error. Por favor, inténtalo de nuevo más tarde.', 'bot');
            }
            
        } catch (error) {
            console.error('Error:', error);
            this.removeTypingIndicator(typingId);
            this.addMessage('Lo siento, no puedo responder en este momento. Por favor, inténtalo de nuevo más tarde.', 'bot');
        }
    }

    addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `flex items-start space-x-2 message-${sender} ${sender === 'user' ? 'justify-end' : ''} animate-message-in`;
        
        // Format the message with line breaks
        const formattedText = text.replace(/\n/g, '<br>');
        
        const messageContent = `
            ${sender === 'bot' ? `
                <div class="w-8 h-8 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-robot text-sm"></i>
                </div>
            ` : ''}
            <div class="${sender === 'bot' ? 'bg-white' : 'bg-yellow-500 text-white'} p-3 rounded-lg shadow-sm max-w-[80%]">
                <p class="text-sm break-words">${formattedText}</p>
                <p class="text-xs ${sender === 'bot' ? 'text-gray-400' : 'text-yellow-100'} mt-1">Ahora</p>
            </div>
            ${sender === 'user' ? `
                <div class="w-8 h-8 bg-yellow-500 text-white rounded-full flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-user text-sm"></i>
                </div>
            ` : ''}
        `;
        
        messageDiv.innerHTML = messageContent;
        this.chatMessages.appendChild(messageDiv);
        
        // Auto-scroll to the new message
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
        
        // Show notification for new bot messages when chat is closed
        if (sender === 'bot' && !this.isOpen) {
            this.showNotification();
        }
    }

    showTypingIndicator() {
        const messagesContainer = document.getElementById('chat-messages');
        const typingId = 'typing-' + Date.now();
        
        const typingDiv = document.createElement('div');
        typingDiv.id = typingId;
        typingDiv.className = 'flex items-start space-x-2';
        typingDiv.innerHTML = `
            <div class="w-8 h-8 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center flex-shrink-0">
                <i class="fas fa-robot text-sm"></i>
            </div>
            <div class="bg-white p-3 rounded-lg shadow-sm">
                <div class="flex space-x-1">
                    <div class="w-2 h-2 bg-gray-300 rounded-full animate-bounce"></div>
                    <div class="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
                    <div class="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
                </div>
            </div>
        `;
        
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        return typingId;
    }

    removeTypingIndicator(id) {
        const typingElement = document.getElementById(id);
        if (typingElement) {
            typingElement.remove();
        }
    }

    showSuggestedQuestions(questions) {
        const messagesContainer = document.getElementById('chat-messages');
        const questionsDiv = document.createElement('div');
        questionsDiv.className = 'mt-4 space-y-2';
        
        questionsDiv.innerHTML = `
            <p class="text-xs text-gray-500 mb-2">¿Te refieres a alguna de estas preguntas?</p>
            <div class="grid grid-cols-1 gap-2">
                ${questions.map(q => `
                    <button class="suggested-question text-left text-sm bg-gray-100 hover:bg-gray-200 text-gray-800 p-2 rounded-lg transition-colors">
                        ${q}
                    </button>
                `).join('')}
            </div>
        `;
        
        messagesContainer.appendChild(questionsDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Add click handlers to suggested questions
        document.querySelectorAll('.suggested-question').forEach(button => {
            button.addEventListener('click', (e) => {
                const question = e.target.textContent.trim();
                document.getElementById('user-input').value = question;
                this.sendMessage();
            });
        });
    }
}

// Initialize chat when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Only initialize if the chat container exists
    if (document.getElementById('fenix-chat-container')) {
        const fenixChat = new FenixChat();
        
        // Make chat draggable on desktop
        if (window.innerWidth >= 768) {
            const header = document.getElementById('fenix-chat-header');
            const chatContent = document.getElementById('fenix-chat-content');
            
            header.style.cursor = 'grab';
            
            let isDragging = false;
            let offsetX, offsetY;
            
            header.addEventListener('mousedown', (e) => {
                if (e.target === header || header.contains(e.target)) {
                    isDragging = true;
                    offsetX = e.clientX - chatContent.getBoundingClientRect().left;
                    offsetY = e.clientY - chatContent.getBoundingClientRect().top;
                    header.style.cursor = 'grabbing';
                    e.preventDefault();
                }
            });
            
            document.addEventListener('mousemove', (e) => {
                if (isDragging) {
                    const x = e.clientX - offsetX;
                    const y = e.clientY - offsetY;
                    
                    // Keep within viewport bounds
                    const maxX = window.innerWidth - chatContent.offsetWidth;
                    const maxY = window.innerHeight - chatContent.offsetHeight - 20; // 20px from bottom
                    
                    chatContent.style.left = `${Math.max(0, Math.min(x, maxX))}px`;
                    chatContent.style.top = `${Math.max(0, Math.min(y, maxY))}px`;
                    chatContent.style.right = 'auto';
                    chatContent.style.bottom = 'auto';
                    chatContent.style.position = 'fixed';
                }
            });
            
            document.addEventListener('mouseup', () => {
                isDragging = false;
                header.style.cursor = 'grab';
            });
        }
    }
});
