// app-functions.js
import { api, apiGet } from './api.js';

// Cache DOM elements
let page = 1;
const limit = window.innerWidth < 768 ? 6 : 9;

// Update limit on window resize
window.addEventListener('resize', () => {
    const newLimit = window.innerWidth < 768 ? 6 : 9;
    if (newLimit !== limit) {
        limit = newLimit;
        page = 1;
        loadProducts();
    }
});

/**
 * Load categories from API
 */
export async function loadCategories() {
    const sel = document.getElementById('f_categoria');
    if (!sel) return;

    // Show loading state
    sel.disabled = true;
    sel.innerHTML = '<option value="">Cargando categorías...</option>';

    try {
        // Try main categories endpoint
        try {
            const categories = await apiGet('categories');
            updateCategoriesDropdown(sel, categories);
        } catch (error) {
            console.warn('Error with main categories API, trying simple version...', error);
            // Fallback to simple categories
            const categories = await apiGet('categories-simple');
            updateCategoriesDropdown(sel, categories);
        }
    } catch (error) {
        console.error('Error loading categories:', error);
        sel.innerHTML = '<option value="">Error al cargar categorías</option>';
    } finally {
        sel.disabled = false;
    }
}

/**
 * Update categories dropdown
 */
function updateCategoriesDropdown(selectElement, categories) {
    if (!Array.isArray(categories)) {
        if (categories.data && Array.isArray(categories.data)) {
            categories = categories.data;
        } else {
            throw new Error('Invalid categories format');
        }
    }

    selectElement.innerHTML = '<option value="">Todas las categorías</option>' +
        categories.map(cat => 
            `<option value="${cat.id}">${cat.name}</option>`
        ).join('');
}

/**
 * Load products from API
 */
export async function loadProducts() {
    const container = document.getElementById('productos');
    if (!container) return;

    // Show loading state
    container.innerHTML = '<div class="col-span-full text-center py-10">Cargando productos...</div>';

    try {
        const params = new URLSearchParams({
            page,
            limit,
            category: document.getElementById('f_categoria')?.value || '',
            q: document.getElementById('q')?.value || '',
            price_min: document.getElementById('f_pmin')?.value || '',
            price_max: document.getElementById('f_pmax')?.value || '',
            condition: document.getElementById('f_cond')?.value || ''
        }).toString();

        let products;
        try {
            // Try main products endpoint
            const response = await apiGet(`products?${params}`);
            products = Array.isArray(response) ? response : 
                      (response.data?.products || response.products || response.data || []);
        } catch (error) {
            console.warn('Error with main products API, trying simple version...', error);
            // Fallback to simple products
            const response = await apiGet(`products-simple?${params}`);
            products = Array.isArray(response) ? response : 
                      (response.data?.products || response.products || response.data || []);
        }

        renderProducts(products);
        
    } catch (error) {
        console.error('Error loading products:', error);
        container.innerHTML = `
            <div class="col-span-full text-center py-10">
                <div class="text-red-500 mb-2">Error al cargar los productos</div>
                <div class="text-gray-600 mb-4">${error.message}</div>
                <button onclick="window.location.reload()" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Reintentar
                </button>
            </div>
        `;
    }
}

/**
 * Render products in the UI
 */
function renderProducts(products) {
    const container = document.getElementById('productos');
    if (!container) return;

    if (!products || products.length === 0) {
        container.innerHTML = '<div class="col-span-full text-center py-10">No se encontraron productos</div>';
        return;
    }

    container.innerHTML = products.map(product => `
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="relative pb-48 overflow-hidden">
                <img class="absolute inset-0 h-full w-full object-cover" 
                     src="${product.image || 'https://via.placeholder.com/300'}" 
                     alt="${product.name}">
            </div>
            <div class="p-4">
                <div class="flex items-center justify-between">
                    <h3 class="text-gray-900 font-semibold text-lg">${product.name}</h3>
                    <span class="text-green-600 font-bold">$${product.price?.toFixed(2) || '0.00'}</span>
                </div>
                <p class="text-gray-600 mt-2">${product.description?.substring(0, 60) || ''}...</p>
                <button class="mt-4 w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600">
                    Ver Detalles
                </button>
            </div>
        </div>
    `).join('');
}

// Initialize the application
document.addEventListener('DOMContentLoaded', async () => {
    try {
        await loadCategories();
        await loadProducts();
    } catch (error) {
        console.error('Error initializing app:', error);
    }
});