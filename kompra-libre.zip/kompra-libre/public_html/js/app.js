// Import only from api.js
import { api, apiGet } from './api.js';

// Debug function to check API response
async function debugApiCall(endpoint) {
    try {
        console.log(`[DEBUG] Testing endpoint: ${endpoint}`);
        const response = await fetch(`${window.location.origin}/api/${endpoint}`, {
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache',
                'Expires': '0'
            }
        });
        const text = await response.text();
        console.log(`[DEBUG] Response from ${endpoint}:`, {
            status: response.status,
            statusText: response.statusText,
            contentType: response.headers.get('content-type'),
            text: text.substring(0, 500) + (text.length > 500 ? '...' : '')
        });
        
        // Try to parse as JSON if content-type is JSON
        if (response.headers.get('content-type')?.includes('application/json')) {
            try {
                const json = JSON.parse(text);
                console.log('[DEBUG] Parsed JSON:', json);
            } catch (e) {
                console.warn('[DEBUG] Failed to parse response as JSON');
            }
        }
    } catch (error) {
        console.error(`[DEBUG] Error testing ${endpoint}:`, error);
    }
}

// Debug available endpoints
// debugApiCall('categories.php');
// debugApiCall('products/index.php');

let page = 1;
const limit = window.innerWidth < 768 ? 6 : 9; // Menos productos en mobile para mejor performance

// Update limit on resize
window.addEventListener('resize', () => {
    const newLimit = window.innerWidth < 768 ? 6 : 9;
    if (newLimit !== limit) {
        limit = newLimit;
        page = 1; // Reset to first page
        loadProducts();
    }
});

async function loadCategories() {
    const categorySelect = document.getElementById('category');
    const mobileCategorySelect = document.getElementById('mobile-category');
    
    if (!categorySelect || !mobileCategorySelect) return;
    
    try {
        // Show loading state
        [categorySelect, mobileCategorySelect].forEach(select => {
            select.innerHTML = '<option value="">Cargando categorías...</option>';
            select.disabled = true;
        });
        
        // Debug: Check if the API endpoint is accessible
        await debugApiCall('categories.php');
        
        // Try to load categories from API using the full URL
        const response = await apiGet('/api/categories.php');
        
        // Log the response to debug
        console.log('Categories API Response:', response);
        
        let categories = [];
        
        // Handle different response formats
        if (Array.isArray(response)) {
            categories = response;
        } else if (response && Array.isArray(response.data)) {
            categories = response.data;
        } else if (response && response.categories) {
            categories = response.categories;
        }
        
        // If no categories from API, use fallback
        if (!categories || categories.length === 0) {
            console.warn('No categories found in API response, using fallback data');
            categories = [
                { id: 1, name: 'Electrónica' },
                { id: 2, name: 'Ropa' },
                { id: 3, name: 'Hogar' },
                { id: 4, name: 'Deportes' },
                { id: 5, name: 'Juguetes' }
            ];
        }
        
        // Update category selects
        [categorySelect, mobileCategorySelect].forEach(select => {
            // Clear existing options
            select.innerHTML = '<option value="">Todas las categorías</option>';
            
            // Add categories
            categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category.id || category.id_categoria || '';
                option.textContent = category.nombre || category.name || 'Categoría sin nombre';
                select.appendChild(option);
            });
            
            select.disabled = false;
        });
        
    } catch (error) {
        console.error('Error loading categories:', error);
        
        // Update UI to show error
        [categorySelect, mobileCategorySelect].forEach(select => {
            select.innerHTML = `
                <option value="">Error al cargar categorías</option>
                <option value="1">Electrónica</option>
                <option value="2">Ropa</option>
                <option value="3">Hogar</option>
                <option value="4">Deportes</option>
                <option value="5">Juguetes</option>
            `;
            select.disabled = false;
        });
    }
}

async function loadProducts() {
    const cont = document.getElementById('productos');
    if (!cont) return;

    // Mostrar estado de carga
    cont.innerHTML = '<div class="col-span-full text-center py-10">Cargando productos...</div>';

    try {
        // Obtener valores de los filtros
        const q = document.getElementById('q')?.value || '';
        const category = document.getElementById('f_categoria')?.value || '';
        const priceMin = document.getElementById('f_pmin')?.value || '';
        const priceMax = document.getElementById('f_pmax')?.value || '';
        const cond = document.getElementById('f_cond')?.value || '';

        // Construir parámetros de consulta
        const params = new URLSearchParams();
        
        // Solo agregar los parámetros que tengan valor
        if (q) params.append('q', q);
        if (category) params.append('category', category); // Cambiado de 'categoria' a 'category'
        if (priceMin) params.append('min_price', priceMin); // Cambiado de 'precio_min' a 'min_price'
        if (priceMax) params.append('max_price', priceMax); // Cambiado de 'precio_max' a 'max_price'
        if (cond) params.append('condition', cond); // Cambiado de 'estado' a 'condition'
        
        // Agregar parámetros de paginación
        params.append('page', page);
        params.append('per_page', limit);

        // Intentar cargar productos
        try {
            const response = await apiGet(`products.php?${params.toString()}`);
            
            // Manejar diferentes formatos de respuesta
            let products = [];
            let meta = {};
            
            if (Array.isArray(response)) {
                products = response;
            } else if (response && typeof response === 'object') {
                products = response.data || response.productos || [];
                meta = response.meta || response.paginacion || {};
            }
            
            if (!Array.isArray(products)) {
                throw new Error('Formato de productos no válido');
            }
            
            // Si no hay productos, mostrar mensaje
            if (products.length === 0) {
                cont.innerHTML = `
                    <div class="col-span-full text-center py-10">
                        <div class="text-gray-600">No se encontraron productos que coincidan con los filtros</div>
                        <button onclick="document.getElementById('f_categoria').value=''; loadProducts();" 
                                class="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                            Limpiar filtros
                        </button>
                    </div>
                `;
                return;
            }
            
            // Renderizar productos
            renderProducts(products);
            
            // Actualizar paginación si está disponible
            if (meta && (meta.total_paginas || meta.ultima_pagina)) {
                updatePagination(meta);
            } else {
                // Ocultar la paginación si no hay datos de paginación
                const pagination = document.querySelector('.pagination-container');
                if (pagination) {
                    pagination.style.display = 'none';
                }
            }
            
        } catch (error) {
            console.error('Error al cargar productos:', error);
            throw error;
        }

    } catch (error) {
        console.error('Error en loadProducts:', error);
        
        // Mostrar mensaje de error amigable con opción de reintentar
        const errorHtml = `
            <div class="col-span-full text-center py-10">
                <div class="text-red-500 mb-2">¡Ups! Algo salió mal</div>
                <div class="text-gray-600 mb-4">No se pudieron cargar los productos. ${error.message || ''}</div>
                <button onclick="loadProducts()" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 mr-2">
                    Reintentar
                </button>
                <button onclick="location.reload()" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">
                    Recargar página
                </button>
            </div>
        `;
        
        cont.innerHTML = errorHtml;
    }
}

function renderProducts(products) {
    const cont = document.getElementById('productos');
    if (cont) {
        cont.innerHTML = products.map(p => `
            <article class="bg-white p-3 sm:p-4 rounded-lg shadow-sm hover:shadow-md transition-all duration-300 product-card group">
                <a href="producto.html?id=${p.id}" class="block">
                    <div class="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-3">
                        <img src="${p.cover || 'https://via.placeholder.com/300x300/3483FA/FFFFFF?text=' + encodeURIComponent(p.title)}"
                             alt="${p.title}"
                             class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                             loading="lazy">
                    </div>
                    <h3 class="font-semibold text-gray-900 line-clamp-2 h-12 text-sm sm:text-base leading-tight">${p.title}</h3>
                    <div class="text-xs sm:text-sm text-gray-500 mb-2">${p.category_name || 'Sin categoría'}</div>
                    <div class="text-lg sm:text-xl font-bold text-green-600 mb-1 price">$${parseFloat(p.price).toFixed(2)}</div>
                    <div class="text-xs text-gray-400 flex items-center gap-1">
                        <span class="${p.condition === 'nuevo' ? 'text-green-600' : 'text-blue-600'}">${p.condition === 'nuevo' ? '●' : '●'}</span>
                        <span>${p.condition === 'nuevo' ? 'Nuevo' : 'Usado'}</span>
                    </div>
                </a>
            </article>
        `).join('');
    }

    // Actualizar paginación
    const pageEl = document.getElementById('page');
    if (pageEl) {
        pageEl.textContent = page;
    }
}

// Sincronizar filtros mobile y desktop
function syncFilters() {
    const desktopCategory = document.getElementById('f_categoria');
    const mobileCategory = document.getElementById('f_categoria_mobile');
    const desktopPriceMin = document.getElementById('f_pmin');
    const mobilePriceMin = document.getElementById('f_pmin_mobile');
    const desktopPriceMax = document.getElementById('f_pmax');
    const mobilePriceMax = document.getElementById('f_pmax_mobile');
    const desktopCond = document.getElementById('f_cond');
    const mobileCond = document.getElementById('f_cond_mobile');

    // Función para sincronizar valores
    function syncValues() {
        if (desktopCategory && mobileCategory) {
            mobileCategory.value = desktopCategory.value;
        }
        if (desktopPriceMin && mobilePriceMin) {
            mobilePriceMin.value = desktopPriceMin.value;
        }
        if (desktopPriceMax && mobilePriceMax) {
            mobilePriceMax.value = desktopPriceMax.value;
        }
        if (desktopCond && mobileCond) {
            mobileCond.value = desktopCond.value;
        }
    }

    // Función para aplicar filtros desde mobile
    function applyMobileFilters() {
        if (desktopCategory && mobileCategory) {
            desktopCategory.value = mobileCategory.value;
        }
        if (desktopPriceMin && mobilePriceMin) {
            desktopPriceMin.value = mobilePriceMin.value;
        }
        if (desktopPriceMax && mobilePriceMax) {
            desktopPriceMax.value = mobilePriceMax.value;
        }
        if (desktopCond && mobileCond) {
            desktopCond.value = mobileCond.value;
        }
        page = 1;
        loadProducts();
    }

    // Sincronizar al cargar
    syncValues();

    // Sincronizar cambios en desktop a mobile
    if (desktopCategory) desktopCategory.addEventListener('change', syncValues);
    if (desktopPriceMin) desktopPriceMin.addEventListener('input', syncValues);
    if (desktopPriceMax) desktopPriceMax.addEventListener('input', syncValues);
    if (desktopCond) desktopCond.addEventListener('change', syncValues);

    // Aplicar filtros mobile
    const mobileBtnFiltrar = document.getElementById('btnFiltrarMobile');
    if (mobileBtnFiltrar) {
        mobileBtnFiltrar.addEventListener('click', () => {
            applyMobileFilters();
            // Cerrar panel mobile
            const mobileFilters = document.getElementById('mobileFilters');
            if (mobileFilters) {
                mobileFilters.classList.add('hidden');
            }
        });
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', async () => {
    await loadCategories();
    await loadProducts();

    // Sincronizar filtros mobile y desktop
    syncFilters();

    // Buscar al hacer clic en el botón
    const btnBuscar = document.getElementById('btnBuscar');
    if (btnBuscar) {
        btnBuscar.addEventListener('click', () => {
            page = 1;
            loadProducts();
        });
    }

    // Buscar al presionar Enter en el input
    function setupSearchInput() {
        const searchInput = document.getElementById('q');
        if (!searchInput) {
            console.warn('Search input element not found');
            return;
        }

        // Asegurarse de que el input sea visible y habilitado
        if (searchInput.offsetParent === null || searchInput.disabled) {
            console.warn('Search input is not visible or is disabled');
            return;
        }

        const handleSearch = (e) => {
            if (e.key === 'Enter' || e.type === 'click') {
                e.preventDefault();
                page = 1;
                loadProducts();

                // Opcional: Quitar el foco del input después de buscar
                if (e.type === 'keypress') {
                    searchInput.blur();
                }
            }
        };

        // Agregar event listeners
        searchInput.addEventListener('keypress', handleSearch);

        // También manejar el clic en el botón de búsqueda
        const searchButton = document.querySelector('.search-button, [type="submit"], button[type="button"]');
        if (searchButton) {
            searchButton.addEventListener('click', handleSearch);
        }
    }

    // Configurar el input de búsqueda
    setupSearchInput();

    // Filtros
    const btnFiltrar = document.getElementById('btnFiltrar');
    if (btnFiltrar) {
        btnFiltrar.addEventListener('click', () => {
            page = 1;
            loadProducts();
        });
    }

    // Paginación
    const prevBtn = document.getElementById('prev');
    const nextBtn = document.getElementById('next');

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (page > 1) {
                page--;
                loadProducts();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            page++;
            loadProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Autocompletado de búsqueda
    const searchInput = document.getElementById('q');
    const datalist = document.getElementById('sugs');
    let timeoutId;

    if (searchInput && datalist) {
        searchInput.addEventListener('input', () => {
            clearTimeout(timeoutId);
            const query = searchInput.value.trim();

            if (query.length < 2) {
                datalist.innerHTML = '';
                return;
            }

            timeoutId = setTimeout(async () => {
                try {
                    const suggestions = await api(`/api/search/suggest?q=${encodeURIComponent(query)}`);
                    datalist.innerHTML = suggestions.map(s =>
                        `<option value="${s.title}">`
                    ).join('');
                } catch (error) {
                    console.error('Error al obtener sugerencias:', error);
                }
            }, 300);
        });
    }
});