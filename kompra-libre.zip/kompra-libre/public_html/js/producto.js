
import { api, apiPost } from '/js/utils.js';
const id = new URLSearchParams(location.search).get('id');
async function load(){
  const p = await api(`/api/products/${id}`);
  document.getElementById('img').src = p.cover;
  document.getElementById('title').textContent = p.title;
  document.getElementById('price').textContent = '$'+p.price;
  document.getElementById('stock').textContent = 'Stock: '+p.stock;
  document.getElementById('desc').textContent = p.description;
  const reviews = await api(`/api/products/${id}/reviews`);
  document.getElementById('reviews').innerHTML = reviews.map(r=>`<div class='border p-2 rounded'><b>${'★'.repeat(r.rating)}</b> — ${r.comment} <span class='text-xs text-gray-500'>por ${r.user_name}</span></div>`).join('');
}
document.getElementById('btnAddCart').addEventListener('click', async ()=>{ await apiPost('/api/cart', { product_id: id, quantity: 1 }); alert('Agregado'); });
document.getElementById('btnFav').addEventListener('click', async ()=>{ await apiPost(`/api/products/${id}/favorite`, {}); alert('Favoritos'); });
document.getElementById('formReview').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  await apiPost(`/api/products/${id}/reviews`, { rating: Number(fd.get('rating')), comment: fd.get('comment') });
  e.target.reset(); load();
});
load();
