document.addEventListener('DOMContentLoaded', function() {
    // Verificar si el usuario está autenticado
    const isAuthenticated = checkAuthStatus(); // Implementa esta función según tu sistema de autenticación
    
    if (isAuthenticated) {
        initializeChatbot();
    }

    function checkAuthStatus() {
        // Verificar si hay un token de autenticación en localStorage
        return localStorage.getItem('authToken') !== null;
    }

    function initializeChatbot() {
        // Crear el contenedor del chatbot
        const chatbotHTML = `
            <div class="chatbot-container" id="felixChatbot">
                <div class="chatbot-header" id="chatbotToggle">
                    <h3><i class="fas fa-robot"></i> Felix - Asistente</h3>
                    <button class="toggle-chat">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div class="chatbot-messages" id="chatbotMessages">
                    <div class="message bot">
                        <div class="message-content">
                            ¡Hola! Soy Felix, tu asistente virtual. ¿En qué puedo ayudarte hoy?
                        </div>
                    </div>
                </div>
                <div class="chatbot-input">
                    <input type="text" id="userInput" placeholder="Escribe tu mensaje..." />
                    <button id="sendMessage">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        `;

        // Agregar el chatbot al final del body
        document.body.insertAdjacentHTML('beforeend', chatbotHTML);

        // Referencias a los elementos del DOM
        const chatbot = document.getElementById('felixChatbot');
        const toggleButton = document.querySelector('.toggle-chat');
        const sendButton = document.getElementById('sendMessage');
        const userInput = document.getElementById('userInput');
        const messagesContainer = document.getElementById('chatbotMessages');

        // Estado del chat
        let isOpen = false;

        // Función para alternar la visibilidad del chat
        function toggleChat() {
            isOpen = !isOpen;
            chatbot.classList.toggle('open');
            const icon = toggleButton.querySelector('i');
            icon.className = isOpen ? 'fas fa-chevron-down' : 'fas fa-chevron-up';
            
            if (isOpen) {
                userInput.focus();
                scrollToBottom();
            }
        }

        // Función para desplazarse al final de los mensajes
        function scrollToBottom() {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }

        // Función para agregar un mensaje al chat
        function addMessage(content, isUser = false) {
            const messageClass = isUser ? 'user' : 'bot';
            const messageHTML = `
                <div class="message ${messageClass}">
                    <div class="message-content">${content}</div>
                </div>
            `;
            messagesContainer.insertAdjacentHTML('beforeend', messageHTML);
            scrollToBottom();
        }

        // Función para mostrar el indicador de escritura
        function showTypingIndicator() {
            const typingHTML = `
                <div class="message bot" id="typingIndicator">
                    <div class="message-content">
                        <div class="typing">
                            <span class="typing-dot"></span>
                            <span class="typing-dot"></span>
                            <span class="typing-dot"></span>
                        </div>
                    </div>
                </div>
            `;
            messagesContainer.insertAdjacentHTML('beforeend', typingHTML);
            scrollToBottom();
        }

        // Función para ocultar el indicador de escritura
        function hideTypingIndicator() {
            const typingIndicator = document.getElementById('typingIndicator');
            if (typingIndicator) {
                typingIndicator.remove();
            }
        }

        // Función para procesar la entrada del usuario
        async function processUserInput() {
            const message = userInput.value.trim();
            if (!message) return;

            // Agregar el mensaje del usuario al chat
            addMessage(message, true);
            userInput.value = '';

            // Mostrar indicador de escritura
            showTypingIndicator();

            try {
                // Enviar el mensaje a la API de OpenAI
                const response = await fetch('/api/chat', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                    },
                    body: JSON.stringify({ message })
                });

                const data = await response.json();
                
                // Ocultar indicador de escritura
                hideTypingIndicator();
                
                // Mostrar la respuesta del asistente
                if (data.reply) {
                    addMessage(data.reply);
                } else {
                    addMessage('Lo siento, no pude procesar tu solicitud en este momento.');
                }
            } catch (error) {
                console.error('Error al procesar el mensaje:', error);
                hideTypingIndicator();
                addMessage('Lo siento, hubo un error al procesar tu mensaje. Por favor, inténtalo de nuevo más tarde.');
            }
        }

        // Event Listeners
        document.getElementById('chatbotToggle').addEventListener('click', toggleChat);
        
        sendButton.addEventListener('click', processUserInput);
        
        userInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                processUserInput();
            }
        });

        // Inicializar el chat cerrado
        toggleChat();
    }
});
