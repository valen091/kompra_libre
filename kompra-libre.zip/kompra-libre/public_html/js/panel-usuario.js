import { api, apiPost } from './utils.js';

// Estado de la aplicación
let currentUser = null;
let currentSection = 'profile';

// Funciones de utilidad
function showMessage(message, type = 'info') {
    const container = document.getElementById('messageContainer');
    const messageDiv = document.createElement('div');
    messageDiv.className = `px-4 py-3 rounded-lg mb-4 ${
        type === 'success' ? 'bg-green-100 text-green-800 border border-green-200' :
        type === 'error' ? 'bg-red-100 text-red-800 border border-red-200' :
        'bg-blue-100 text-blue-800 border border-blue-200'
    }`;

    messageDiv.innerHTML = `
        <div class="flex items-center justify-between">
            <span>${message}</span>
            <button class="ml-4 text-gray-400 hover:text-gray-600" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    container.appendChild(messageDiv);
    setTimeout(() => messageDiv.remove(), 5000);
}

function showLoading() {
    document.getElementById('loading').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loading').classList.add('hidden');
}

function switchSection(section) {
    // Ocultar todas las secciones
    document.querySelectorAll('.panel-section').forEach(sec => {
        sec.classList.add('hidden');
    });

    // Mostrar la sección seleccionada
    document.getElementById(`${section}-section`).classList.remove('hidden');

    // Actualizar botones activos
    document.querySelectorAll('[data-section]').forEach(btn => {
        btn.classList.remove('bg-blue-100', 'text-blue-700');
        btn.classList.add('text-gray-700');
    });

    document.querySelector(`[data-section="${section}"]`).classList.add('bg-blue-100', 'text-blue-700');

    currentSection = section;
}

// Cargar información del usuario
async function loadUserInfo() {
    try {
        showLoading();

        // Obtener datos del usuario desde localStorage o API
        const userData = localStorage.getItem('user');
        const token = localStorage.getItem('auth_token');

        if (!token) {
            window.location.href = 'login.html';
            return;
        }

        if (userData) {
            currentUser = JSON.parse(userData);
        } else {
            // Si no hay datos en localStorage, intentar obtener de API
            const response = await fetch('api/auth/me', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                currentUser = await response.json();
                localStorage.setItem('user', JSON.stringify(currentUser));
            }
        }

        // Actualizar información en el sidebar
        document.getElementById('userName').textContent = currentUser.name || 'Usuario';
        document.getElementById('userEmail').textContent = currentUser.email || 'email@ejemplo.com';
        document.getElementById('userRole').textContent = currentUser.role === 'seller' ? 'Vendedor' : 'Comprador';
        document.getElementById('userRole').className = `inline-block text-xs px-2 py-1 rounded-full mt-2 ${
            currentUser.role === 'seller' ? 'bg-purple-100 text-purple-800' : 'bg-green-100 text-green-800'
        }`;

        // Cargar datos de la sección actual
        await loadSectionData(currentSection);

    } catch (error) {
        console.error('Error al cargar información del usuario:', error);
        showMessage('Error al cargar la información del usuario', 'error');
    } finally {
        hideLoading();
    }
}

// Cargar datos de la sección actual
async function loadSectionData(section) {
    try {
        switch (section) {
            case 'orders':
                await loadOrders();
                break;
            case 'favorites':
                await loadFavorites();
                break;
            case 'profile':
                loadProfileData();
                break;
        }
    } catch (error) {
        console.error('Error al cargar datos de la sección:', error);
        showMessage('Error al cargar los datos', 'error');
    }
}

// Cargar pedidos del usuario
async function loadOrders() {
    try {
        const ordersList = document.getElementById('ordersList');
        const ordersEmpty = document.getElementById('ordersEmpty');

        // Por ahora, mostrar mensaje de que no hay pedidos
        // TODO: Implementar API de pedidos cuando esté disponible
        ordersList.innerHTML = '';
        ordersEmpty.classList.remove('hidden');

    } catch (error) {
        console.error('Error al cargar pedidos:', error);
    }
}

// Cargar productos favoritos
async function loadFavorites() {
    try {
        const favoritesList = document.getElementById('favoritesList');
        const favoritesEmpty = document.getElementById('favoritesEmpty');

        // TODO: Implementar API de favoritos cuando esté disponible
        favoritesList.innerHTML = '';
        favoritesEmpty.classList.remove('hidden');

    } catch (error) {
        console.error('Error al cargar favoritos:', error);
    }
}

// Cargar datos del perfil
function loadProfileData() {
    if (currentUser) {
        document.getElementById('profileName').value = currentUser.name || '';
        document.getElementById('profileEmail').value = currentUser.email || '';
    }
}

// Guardar cambios del perfil
async function saveProfile() {
    try {
        showLoading();

        const newName = document.getElementById('profileName').value.trim();

        if (!newName) {
            showMessage('El nombre es obligatorio', 'error');
            return;
        }

        // TODO: Implementar API de actualización de perfil
        showMessage('Funcionalidad de actualización de perfil próximamente', 'info');

    } catch (error) {
        console.error('Error al guardar perfil:', error);
        showMessage('Error al guardar los cambios', 'error');
    } finally {
        hideLoading();
    }
}

// Cerrar sesión
function logout() {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Cargar información del usuario
    loadUserInfo();

    // Event listeners para navegación
    document.querySelectorAll('[data-section]').forEach(button => {
        button.addEventListener('click', () => {
            const section = button.getAttribute('data-section');
            switchSection(section);
        });
    });

    // Event listener para guardar perfil
    document.getElementById('saveProfile').addEventListener('click', saveProfile);

    // Event listener para cerrar sesión
    document.getElementById('logoutBtn').addEventListener('click', logout);

    // Mostrar sección de perfil por defecto
    switchSection('profile');
});

// Funciones globales para mensajes
window.showMessage = showMessage;

