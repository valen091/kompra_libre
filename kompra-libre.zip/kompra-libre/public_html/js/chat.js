// Chat state
let chatState = {
    isOpen: false,
    isMinimized: false,
    sessionId: null,
    isTyping: false
};

// DOM Elements
const chatWidget = document.getElementById('chatbot-widget');
const chatContainer = document.getElementById('chatbot-container');
const chatToggle = document.getElementById('chat-toggle');
const minimizeBtn = document.getElementById('minimize-chat');
const closeBtn = document.getElementById('close-chat');
const chatMessages = document.getElementById('chat-messages');
const chatForm = document.getElementById('chat-form');
const userInput = document.getElementById('user-message');
const submitBtn = chatForm?.querySelector('button[type="submit"]');

// Get auth token from cookies
function getAuthToken() {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; token=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}

// Get auth headers
function getAuthHeaders() {
    const token = getAuthToken();
    return {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
    };
}

// Initialize chat
async function initChat() {
    try {
        // Enable input
        if (userInput) userInput.disabled = false;
        if (submitBtn) submitBtn.disabled = false;
        
        // Start a new chat session
        const response = await fetch('/api/chatbot/start', {
            method: 'POST',
            headers: getAuthHeaders()
        });
        
        if (!response.ok) {
            throw new Error('Error al iniciar la sesión de chat');
        }
        
        const { sessionId } = await response.json();
        chatState.sessionId = sessionId;
        
    } catch (error) {
        console.error('Error initializing chat:', error);
        if (chatMessages) {
            chatMessages.innerHTML = `
                <div class="p-4 text-center">
                    <i class="fas fa-exclamation-triangle text-yellow-500 text-2xl mb-2"></i>
                    <p class="text-sm text-gray-600">No se pudo conectar con el asistente. Por favor, recarga la página para intentar de nuevo.</p>
                </div>
            `;
        }
    }
}

// Add a message to the chat
function addMessage(role, content) {
    if (!chatMessages) return;
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${role} mb-4`;
    
    const isBot = role === 'bot';
    
    messageDiv.innerHTML = `
        <div class="flex items-start ${isBot ? '' : 'justify-end'}">
            ${isBot ? `
            <div class="h-8 w-8 rounded-full bg-yellow-100 flex-shrink-0 flex items-center justify-center mr-2">
                <i class="fas fa-robot text-yellow-600"></i>
            </div>
            ` : ''}
            <div class="max-w-[80%] ${isBot ? 'bg-gray-100' : 'bg-yellow-100'} rounded-lg p-3">
                <p class="text-sm">${content}</p>
            </div>
            ${!isBot ? `
            <div class="h-8 w-8 rounded-full bg-yellow-500 flex-shrink-0 flex items-center justify-center ml-2">
                <i class="fas fa-user text-white text-xs"></i>
            </div>
            ` : ''}
        </div>
    `;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Add bot message
function addBotMessage(content) {
    addMessage('bot', content);
}

// Add user message
function addUserMessage(content) {
    addMessage('user', content);
}

// Send message to Fénix
async function sendMessage(message) {
    if (!message.trim() || chatState.isTyping || !chatMessages) return;
    
    // Add user message to chat
    addUserMessage(message);
    if (userInput) userInput.value = '';
    
    // Show typing indicator
    chatState.isTyping = true;
    const typingIndicator = document.createElement('div');
    typingIndicator.id = 'typing-indicator';
    typingIndicator.className = 'chat-message bot mb-4';
    typingIndicator.innerHTML = `
        <div class="flex items-start">
            <div class="h-8 w-8 rounded-full bg-yellow-100 flex-shrink-0 flex items-center justify-center mr-2">
                <i class="fas fa-robot text-yellow-600"></i>
            </div>
            <div class="typing-indicator flex space-x-1 bg-gray-100 rounded-lg p-3">
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.2s"></div>
                <div class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay: 0.4s"></div>
            </div>
        </div>
    `;
    chatMessages.appendChild(typingIndicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    try {
        // Send message to backend
        const response = await fetch('/api/chatbot/message', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
                message: message,
                sessionId: chatState.sessionId
            })
        });
        
        if (!response.ok) {
            throw new Error('Error al enviar el mensaje');
        }
        
        const { reply } = await response.json();
        
        // Remove typing indicator and add bot's response
        document.getElementById('typing-indicator')?.remove();
        addBotMessage(reply);
        
    } catch (error) {
        console.error('Error sending message:', error);
        document.getElementById('typing-indicator')?.remove();
        
        const errorDiv = document.createElement('div');
        errorDiv.className = 'text-red-500 text-sm text-center p-2';
        errorDiv.textContent = 'Error al enviar el mensaje. Intenta de nuevo.';
        chatMessages.appendChild(errorDiv);
    } finally {
        chatState.isTyping = false;
    }
}

// Toggle chat window
function toggleChat() {
    if (!chatContainer) return;
    
    chatState.isOpen = !chatState.isOpen;
    
    if (chatState.isOpen) {
        chatContainer.classList.remove('hidden');
        chatContainer.classList.add('flex');
        
        if (chatState.isMinimized) {
            chatContainer.style.height = '500px';
            chatState.isMinimized = false;
        }
        
        // Focus input when opening
        setTimeout(() => userInput?.focus(), 100);
    } else {
        chatContainer.classList.add('hidden');
        chatContainer.classList.remove('flex');
    }
}

// Minimize chat window
function minimizeChat() {
    if (!chatContainer) return;
    
    if (chatState.isMinimized) {
        chatContainer.style.height = '500px';
        chatState.isMinimized = false;
    } else {
        chatContainer.style.height = '60px';
        chatState.isMinimized = true;
    }
}

// Close chat window
function closeChat() {
    if (!chatContainer) return;
    
    chatState.isOpen = false;
    chatContainer.classList.add('hidden');
    chatContainer.classList.remove('flex');
}

// Initialize chat when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize if chat elements exist
    if (chatWidget && chatContainer && chatToggle && minimizeBtn && closeBtn && 
        chatMessages && chatForm && userInput && submitBtn) {
        
        // Event Listeners
        chatToggle.addEventListener('click', toggleChat);
        minimizeBtn.addEventListener('click', minimizeChat);
        closeBtn.addEventListener('click', closeChat);
        
        chatForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const message = userInput.value.trim();
            if (message) {
                await sendMessage(message);
            }
        });
        
        // Initialize the chat when the page loads
        initChat();
        
        // Show chat after a short delay
        setTimeout(() => {
            toggleChat();
        }, 2000);
    }
});
