/**
 * Sistema de carrito con notificaciones
 */

class CartManager {
    constructor() {
        this.CART_KEY = 'kompra_libre_cart';
        this.cart = this.loadCart();
    }

    /**
     * Cargar carrito desde localStorage
     */
    loadCart() {
        const cartStr = localStorage.getItem(this.CART_KEY);
        return cartStr ? JSON.parse(cartStr) : [];
    }

    /**
     * Guardar carrito en localStorage
     */
    saveCart() {
        localStorage.setItem(this.CART_KEY, JSON.stringify(this.cart));
        this.updateCartUI();
    }

    /**
     * Agregar producto al carrito
     */
    addProduct(product, quantity = 1) {
        // Buscar si el producto ya está en el carrito
        const existingItem = this.cart.find(item => item.id === product.id);

        if (existingItem) {
            // Aumentar cantidad
            existingItem.quantity += quantity;
            window.notify.success(`Se actualizó la cantidad de "${product.name}" en el carrito`, 3000);
        } else {
            // Agregar nuevo producto
            this.cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.image,
                quantity: quantity
            });
            window.notify.success(`"${product.name}" agregado al carrito ✓`, 3000);
        }

        this.saveCart();
        return true;
    }

    /**
     * Eliminar producto del carrito
     */
    removeProduct(productId) {
        const product = this.cart.find(item => item.id === productId);
        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCart();
        
        if (product) {
            window.notify.info(`"${product.name}" eliminado del carrito`, 3000);
        }
    }

    /**
     * Actualizar cantidad de un producto
     */
    updateQuantity(productId, quantity) {
        const item = this.cart.find(item => item.id === productId);
        if (item) {
            if (quantity <= 0) {
                this.removeProduct(productId);
            } else {
                item.quantity = quantity;
                this.saveCart();
            }
        }
    }

    /**
     * Obtener productos del carrito
     */
    getCart() {
        return this.cart;
    }

    /**
     * Obtener cantidad total de productos
     */
    getTotalItems() {
        return this.cart.reduce((total, item) => total + item.quantity, 0);
    }

    /**
     * Obtener total del carrito
     */
    getTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    /**
     * Vaciar carrito
     */
    clearCart() {
        this.cart = [];
        this.saveCart();
        window.notify.info('Carrito vaciado', 2000);
    }

    /**
     * Actualizar UI del carrito (badge de cantidad)
     */
    updateCartUI() {
        const totalItems = this.getTotalItems();
        const badges = document.querySelectorAll('.cart-badge, [data-cart-count]');
        
        badges.forEach(badge => {
            if (totalItems > 0) {
                badge.textContent = totalItems;
                badge.classList.remove('hidden');
            } else {
                badge.classList.add('hidden');
            }
        });
    }

    /**
     * Verificar si un producto está en el carrito
     */
    hasProduct(productId) {
        return this.cart.some(item => item.id === productId);
    }

    /**
     * Obtener cantidad de un producto específico
     */
    getProductQuantity(productId) {
        const item = this.cart.find(item => item.id === productId);
        return item ? item.quantity : 0;
    }
}

// Asignar a window.cart
if (typeof window !== 'undefined') {
    window.CartManager = CartManager;
    
    // Si no existe una instancia de cart, crear una
    if (!window.cart) {
        window.cart = new CartManager();
        
        // Actualizar UI al cargar la página
        document.addEventListener('DOMContentLoaded', () => {
            window.cart.updateCartUI();
        });
    }
}
