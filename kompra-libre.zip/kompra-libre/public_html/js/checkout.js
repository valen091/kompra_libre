import { handlePayment } from './payment.js';

// Función para mostrar notificaciones al usuario
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
        type === 'error' ? 'bg-red-100 border-l-4 border-red-500 text-red-700' : 
        type === 'warning' ? 'bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700' :
        'bg-green-100 border-l-4 border-green-500 text-green-700'
    }`;
    
    notification.innerHTML = `
        <div class="flex items-center">
            <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                ${type === 'error' ? 
                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>' :
                    type === 'warning' ?
                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>' :
                    '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>'
                }
            </svg>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Eliminar la notificación después de 5 segundos
    setTimeout(() => {
        notification.classList.add('opacity-0', 'transition-opacity', 'duration-500');
        setTimeout(() => notification.remove(), 500);
    }, 5000);
}

// Inicializar el módulo de pagos
document.addEventListener('DOMContentLoaded', function() {
    // Verificar si hay una respuesta de pago en la URL
    checkUrlForPaymentResponse();
    
    // Configurar máscaras para los campos de formulario
    const phoneInput = document.getElementById('phone');
    const postalCodeInput = document.getElementById('postal-code');
    
    if (phoneInput) {
        // Formato de teléfono uruguayo: 098 123 456
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 2) {
                value = value.replace(/^(\d{3})/, '$1 ');
            }
            if (value.length > 7) {
                value = value.replace(/^(\d{3})(\d{3})/, '$1 $2 ');
            }
            e.target.value = value.substring(0, 11); // 9 dígitos + 2 espacios
        });
    }
    
    if (postalCodeInput) {
        // Formato de código postal uruguayo: 5 dígitos
        postalCodeInput.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '').substring(0, 5);
        });
    }
    
    // Cargar departamentos de Uruguay
    const stateSelect = document.getElementById('state');
    if (stateSelect) {
        const uruguayStates = [
            'Artigas', 'Canelones', 'Cerro Largo', 'Colonia', 'Durazno',
            'Flores', 'Florida', 'Lavalleja', 'Maldonado', 'Montevideo',
            'Paysandú', 'Río Negro', 'Rivera', 'Rocha', 'Salto',
            'San José', 'Soriano', 'Tacuarembó', 'Treinta y Tres'
        ];
        
        // Ordenar alfabéticamente
        uruguayStates.sort();
        
        // Limpiar opciones existentes
        stateSelect.innerHTML = '';
        
        // Agregar opción por defecto
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = 'Selecciona un departamento';
        defaultOption.disabled = true;
        defaultOption.selected = true;
        stateSelect.appendChild(defaultOption);
        
        // Agregar departamentos
        uruguayStates.forEach(state => {
            const option = document.createElement('option');
            option.value = state;
            option.textContent = state;
            stateSelect.appendChild(option);
        });
    }

    const checkoutForm = document.getElementById('checkout-form');
    const placeOrderBtn = document.getElementById('place-order-btn');
    
    if (!checkoutForm || !placeOrderBtn) return;

    // Cargar el carrito
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    updateOrderSummary(cart);

    // Manejar el envío del formulario
    checkoutForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Deshabilitar botón para evitar doble envío
        placeOrderBtn.disabled = true;
        placeOrderBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';
        
        try {
            // Obtener datos del formulario
            const formData = new FormData(checkoutForm);
            const formValues = Object.fromEntries(formData.entries());
            
            // Validar formulario
            if (!validateForm(formValues)) {
                throw new Error('Por favor completa todos los campos requeridos');
            }
            
            // Crear objeto con los datos del usuario
            const userData = {
                name: formValues.first_name,
                surname: formValues.last_name,
                email: formValues.email,
                phone: formValues.phone,
                address: {
                    street_name: formValues.address,
                    street_number: formValues.address_number || 'S/N',
                    zip_code: formValues.postal_code,
                    city: formValues.city,
                    state: formValues.state,
                    country: formValues.country
                }
            };
            
            // Preparar items del carrito para Uruguay
            const cartItems = cart.map(item => ({
                id: item.id,
                title: item.name,
                description: item.description || '',
                quantity: item.quantity,
                price: item.price, // Precio ya debe incluir IVA
                picture_url: item.image || '',
                category_id: 'others',
                currency_id: 'UYU',
                unit_price: item.price, // Precio unitario con IVA
                warranty: false
            }));
            
            // Agregar costo de envío como ítem adicional
            const shippingCost = parseFloat(process.env.STORE_SHIPPING_COST || 250);
            if (shippingCost > 0) {
                cartItems.push({
                    id: 'shipping',
                    title: 'Envío a domicilio',
                    description: 'Costo de envío estándar dentro de Uruguay',
                    quantity: 1,
                    price: shippingCost,
                    category_id: 'shipping',
                    currency_id: 'UYU',
                    unit_price: shippingCost
                });
            }
            
            // Iniciar el proceso de pago con Mercado Pago
            await handlePayment('place-order-btn', cartItems, userData);
            
        } catch (error) {
            console.error('Error en el proceso de pago:', error);
            alert(`Error: ${error.message}`);
            
            // Restaurar el botón
            placeOrderBtn.disabled = false;
            placeOrderBtn.innerHTML = 'Realizar pedido';
        }
    });
    
    // Función para formatear moneda uruguaya
    function formatCurrency(amount) {
        return new Intl.NumberFormat('es-UY', {
            style: 'currency',
            currency: 'UYU',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    }
    
    // Función para actualizar el resumen del pedido
    function updateOrderSummary(cart) {
        const orderItems = document.getElementById('order-items');
        const subtotalEl = document.getElementById('order-subtotal');
        const shippingEl = document.getElementById('order-shipping');
        const taxEl = document.getElementById('order-tax');
        const totalEl = document.getElementById('order-total');
        
        if (!orderItems || !subtotalEl || !shippingEl || !taxEl || !totalEl) return;
        
        // Calcular subtotal (sin IVA)
        const ivaRate = parseFloat(process.env.STORE_TAX_RATE || 22) / 100;
        const subtotal = cart.reduce(( sum, item ) => sum + (item.price * item.quantity), 0);
        const subtotalWithoutTax = subtotal / (1 + ivaRate);
        const taxAmount = subtotal - subtotalWithoutTax;
        
        // Costo de envío fijo para Uruguay
        const shippingCost = parseFloat(process.env.STORE_SHIPPING_COST || 250);
        const total = subtotal + shippingCost;
        
        // Actualizar resumen
        orderItems.innerHTML = cart.map(item => `
            <li class="flex py-6 px-4 sm:px-6">
                <div class="flex-shrink-0">
                    <img src="${item.image || 'img/placeholder-product.png'}" alt="${item.name}" 
                         class="w-20 h-20 object-cover rounded-md">
                </div>
                <div class="ml-6 flex-1 flex flex-col">
                    <div class="flex">
                        <div class="min-w-0 flex-1">
                            <h4 class="text-sm font-medium text-gray-900">${item.name}</h4>
                            <p class="mt-1 text-sm text-gray-500">Cantidad: ${item.quantity}</p>
                            ${item.description ? `<p class="mt-1 text-xs text-gray-400">${item.description.substring(0, 50)}${item.description.length > 50 ? '...' : ''}</p>` : ''}
                        </div>
                        <div class="ml-4 flex-shrink-0">
                            <p class="text-sm font-medium text-gray-900">${formatCurrency(item.price * item.quantity)}</p>
                            ${item.quantity > 1 ? `<p class="mt-1 text-xs text-gray-500">${formatCurrency(item.price)} c/u</p>` : ''}
                        </div>
                    </div>
                </div>
            </li>
        `).join('');
        
        // Actualizar totales
        subtotalEl.textContent = formatCurrency(subtotalWithoutTax);
        taxEl.textContent = formatCurrency(taxAmount);
        shippingEl.textContent = shippingCost === 0 ? 'Gratis' : formatCurrency(shippingCost);
        totalEl.textContent = formatCurrency(total);
    }
    
    // Función para validar el formulario con validaciones específicas para Uruguay
    function validateForm(data) {
        const requiredFields = [
            'first_name', 'last_name', 'email', 'phone',
            'address', 'city', 'state', 'postal_code', 'country'
        ];
        
        // Validar campos requeridos
        for (const field of requiredFields) {
            if (!data[field] || data[field].trim() === '') {
                showNotification('Por favor completa todos los campos obligatorios', 'error');
                return false;
            }
        }
        
        // Validar formato de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            showNotification('Por favor ingresa un correo electrónico válido', 'error');
            return false;
        }
        
        // Validar formato de teléfono uruguayo (ej: 098 123 456)
        const phoneRegex = /^(?:(?:09|9)\d{7}|\d{8})$/;
        const cleanPhone = data.phone.replace(/[^0-9]/g, ''); // Eliminar caracteres no numéricos
        if (!phoneRegex.test(cleanPhone)) {
            showNotification('Por favor ingresa un número de teléfono uruguayo válido (ej: 098123456)', 'error');
            return false;
        }
        
        // Validar código postal uruguayo (5 dígitos)
        const postalCodeRegex = /^\d{5}$/;
        if (!postalCodeRegex.test(data.postal_code.replace(/[^0-9]/g, ''))) {
            showNotification('Por favor ingresa un código postal uruguayo válido (5 dígitos)', 'error');
            return false;
        }
        
        // Validar términos y condiciones
        if (!data.terms) {
            showNotification('Debes aceptar los términos y condiciones para continuar', 'error');
            return false;
        }
        
        return true;
    }
});
