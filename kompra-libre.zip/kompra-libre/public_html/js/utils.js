// Base API configuration
const API_CONFIG = {
    baseUrl: window.location.origin,
    apiPrefix: '/api',
    defaultHeaders: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
    }
};

/**
 * Make an API request
 * @param {string} endpoint - API endpoint (e.g., 'categories' or 'products')
 * @param {Object} options - Fetch options
 * @returns {Promise<any>} - Parsed JSON response
 */
async function api(endpoint, options = {}) {
    // Ensure endpoint doesn't start with a slash
    const cleanEndpoint = endpoint.startsWith('/') ? endpoint.substring(1) : endpoint;
    
    // Build the full URL
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.apiPrefix}/${cleanEndpoint}`;
    
    // Merge headers
    const headers = {
        ...API_CONFIG.defaultHeaders,
        ...(options.headers || {})
    };
    
    console.log(`[API] ${options.method || 'GET'} ${url}`);
    
    try {
        const response = await fetch(url, {
            ...options,
            method: options.method || 'GET',
            headers,
            credentials: 'include',
            cache: 'no-cache'
        });
        
        console.log(`[API] ${response.status} ${response.statusText} - ${url}`);
        
        // Handle non-OK responses
        if (!response.ok) {
            let errorData;
            const contentType = response.headers.get('content-type');
            const responseText = await response.text();
            
            // Try to parse error response as JSON if possible
            if (contentType && contentType.includes('application/json')) {
                try {
                    errorData = JSON.parse(responseText);
                } catch (e) {
                    errorData = { message: responseText };
                }
            } else if (responseText.trim().startsWith('<!')) {
                throw new Error(`Server returned HTML error page (${response.status} ${response.statusText})`);
            } else {
                errorData = { message: responseText };
            }
            
            const error = new Error(errorData.message || `HTTP ${response.status}: ${response.statusText}`);
            error.status = response.status;
            error.data = errorData;
            throw error;
        }
        
        // Parse successful response
        if (response.status === 204) return null; // No content
        
        try {
            return await response.json();
        } catch (jsonError) {
            console.warn('Failed to parse JSON response, trying text:', jsonError);
            const text = await response.text();
            return { data: text };
        }
        
    } catch (error) {
        console.error('[API Error]', {
            message: error.message,
            endpoint,
            url,
            status: error.status,
            stack: error.stack
        });
        
        if (!(error instanceof Error)) {
            error = new Error(String(error));
        }
        
        error.endpoint = endpoint;
        error.url = url;
        
        throw error;
    }
}

// Helper functions for common HTTP methods
export const apiGet = (endpoint, options = {}) => 
    api(endpoint, { ...options, method: 'GET' });

export const apiPost = (endpoint, data, options = {}) => 
    api(endpoint, { 
        ...options, 
        method: 'POST',
        body: JSON.stringify(data)
    });

export const apiPut = (endpoint, data, options = {}) => 
    api(endpoint, { 
        ...options, 
        method: 'PUT',
        body: JSON.stringify(data)
    });

export const apiDelete = (endpoint, options = {}) => 
    api(endpoint, { ...options, method: 'DELETE' });