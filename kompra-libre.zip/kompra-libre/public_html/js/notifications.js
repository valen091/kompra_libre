/**
 * Sistema de notificaciones estilo e-commerce minimalista
 * Compatible con navegadores modernos
 */

class NotificationManager {
    constructor() {
        this.container = null;
        this.initialized = false;
        this.initQueue = [];
        
        // Inicializar cuando el DOM esté listo
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            // Si el DOM ya está listo, inicializar de inmediato
            setTimeout(() => this.init(), 0);
        }
    }

    init() {
        try {
            // Crear contenedor de notificaciones si no existe
            if (!document.getElementById('notification-container')) {
                this.container = document.createElement('div');
                this.container.id = 'notification-container';
                this.container.className = 'fixed top-4 right-4 z-50 flex flex-col gap-3 pointer-events-none';
                
                // Asegurarse de que el body esté disponible
                if (!document.body) {
                    console.warn('document.body no está disponible aún, reintentando...');
                    setTimeout(() => this.init(), 100);
                    return;
                }
                
                document.body.appendChild(this.container);
            } else {
                this.container = document.getElementById('notification-container');
            }
            
            this.initialized = true;
            console.log('Sistema de notificaciones inicializado');
            
            // Procesar cualquier notificación en cola
            this.processQueue();
            
        } catch (error) {
            console.error('Error al inicializar notificaciones:', error);
            // Reintentar después de un breve retraso
            setTimeout(() => this.init(), 1000);
        }
    }

    /**
     * Obtener clases CSS según el tipo de notificación
     */
    getTypeClasses(type) {
        const classes = {
            success: 'border-green-500',
            error: 'border-red-500',
            warning: 'border-yellow-500',
            info: 'border-blue-500'
        };
        return classes[type] || classes.info;
    }

    /**
     * Obtener icono según el tipo de notificación
     */
    getIcon(type) {
        const icons = {
            success: `
                <svg class="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                </svg>
            `,
            error: `
                <svg class="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            `,
            warning: `
                <svg class="h-5 w-5 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
            `,
            info: `
                <svg class="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            `
        };
        return icons[type] || icons.info;
    }

    /**
     * Mostrar notificación
     * @param {string} message - Mensaje a mostrar
     * @param {string} type - Tipo: 'success', 'error', 'info', 'warning'
     * @param {number} duration - Duración en ms (0 = no desaparece automáticamente)
     */
    // Procesar notificaciones en cola
    processQueue() {
        if (!this.initialized) return;
        
        while (this.initQueue.length > 0) {
            const { message, type, duration } = this.initQueue.shift();
            this._showNotification(message, type, duration);
        }
    }
    
    show(message, type = 'info', duration = 4000) {
        if (!this.initialized) {
            console.log('El sistema de notificaciones no está listo, encolando notificación...');
            this.initQueue.push({ message, type, duration });
            
            // Si no se ha iniciado la inicialización, hacerlo ahora
            if (!this.container) {
                this.init();
            }
            return;
        }
        
        this._showNotification(message, type, duration);
    }
    
    _showNotification(message, type = 'info', duration = 4000) {
        try {
            if (!this.container) {
                console.error('El contenedor de notificaciones no está disponible');
                return;
            }

            const notification = document.createElement('div');
            notification.className = `
                pointer-events-auto
                transform transition-all duration-300 ease-out
                translate-x-full opacity-0
                max-w-sm w-full
                bg-white rounded-lg shadow-lg
                border-l-4
                ${this.getTypeClasses(type)}
                p-4 flex items-start gap-3
            `;

            // Icono según el tipo
            const icon = this.getIcon(type);
            
            notification.innerHTML = `
                <div class="flex-shrink-0">
                    ${icon}
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900">${message}</p>
                </div>
                <button type="button" class="text-gray-400 hover:text-gray-500">
                    <span class="sr-only">Cerrar</span>
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            `;

            // Agregar al contenedor
            this.container.appendChild(notification);

            // Forzar reflow para activar la animación
            void notification.offsetWidth;
            notification.classList.remove('translate-x-full', 'opacity-0');
            notification.classList.add('translate-x-0', 'opacity-100');

            // Configurar cierre automático
            if (duration > 0) {
                setTimeout(() => {
                    this.removeNotification(notification);
                }, duration);
            }

            // Configurar botón de cierre
            const closeButton = notification.querySelector('button');
            closeButton.addEventListener('click', () => this.removeNotification(notification));

            return notification;
        } catch (error) {
            console.error('Error al mostrar notificación:', error);
            return null;
        }
    }

    /**
     * Eliminar notificación con animación
     */
    removeNotification(notification) {
        if (!notification) return;
        
        notification.classList.remove('translate-x-0', 'opacity-100');
        notification.classList.add('translate-x-full', 'opacity-0');
        
        // Esperar a que termine la animación antes de eliminar
        setTimeout(() => {
            if (notification && notification.parentNode === this.container) {
                this.container.removeChild(notification);
            }
        }, 300);
    }

    // Métodos abreviados para tipos de notificación
    success(message, duration = 4000) {
        return this.show(message, 'success', duration);
    }

    error(message, duration = 4000) {
        return this.show(message, 'error', duration);
    }

    info(message, duration = 4000) {
        return this.show(message, 'info', duration);
    }

    warning(message, duration = 4000) {
        return this.show(message, 'warning', duration);
    }
}

// Asignar a window.notify
if (typeof window !== 'undefined') {
    window.NotificationManager = NotificationManager;
    
    // Si no existe una instancia de notify, crear una
    if (!window.notify) {
        window.notify = new NotificationManager();
    }
}
