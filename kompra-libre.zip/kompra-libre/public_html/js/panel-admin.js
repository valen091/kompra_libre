import { api, apiPost } from './utils.js';

// Estado de la aplicación
let currentUser = null;
let currentSection = 'dashboard';

// Funciones de utilidad
function showMessage(message, type = 'info') {
    const container = document.getElementById('messageContainer');
    const messageDiv = document.createElement('div');
    messageDiv.className = `px-4 py-3 rounded-lg mb-4 ${
        type === 'success' ? 'bg-green-100 text-green-800 border border-green-200' :
        type === 'error' ? 'bg-red-100 text-red-800 border border-red-200' :
        'bg-blue-100 text-blue-800 border border-blue-200'
    }`;

    messageDiv.innerHTML = `
        <div class="flex items-center justify-between">
            <span>${message}</span>
            <button class="ml-4 text-gray-400 hover:text-gray-600" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    container.appendChild(messageDiv);
    setTimeout(() => messageDiv.remove(), 5000);
}

function showLoading() {
    document.getElementById('loading').classList.remove('hidden');
}

function hideLoading() {
    document.getElementById('loading').classList.add('hidden');
}

function switchSection(section) {
    // Ocultar todas las secciones
    document.querySelectorAll('.panel-section').forEach(sec => {
        sec.classList.add('hidden');
    });

    // Mostrar la sección seleccionada
    document.getElementById(`${section}-section`).classList.remove('hidden');

    // Actualizar botones activos
    document.querySelectorAll('[data-section]').forEach(btn => {
        btn.classList.remove('bg-red-100', 'text-red-700');
        btn.classList.add('text-gray-700');
    });

    document.querySelector(`[data-section="${section}"]`).classList.add('bg-red-100', 'text-red-700');

    currentSection = section;
    loadSectionData(section);
}

// Cargar información del admin
async function loadUserInfo() {
    try {
        showLoading();
        
        const userData = localStorage.getItem('user');
        const token = localStorage.getItem('auth_token');

        if (!token) {
            window.location.href = 'login.html';
            return;
        }

        if (userData) {
            currentUser = JSON.parse(userData);
        } else {
            // Si no hay datos en localStorage, intentar obtener de API
            const response = await fetch('api/auth/me', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                currentUser = await response.json();
                localStorage.setItem('user', JSON.stringify(currentUser));
            }
        }

        // Verificar que el usuario sea admin
        if (currentUser.role !== 'admin') {
            showMessage('Acceso denegado. Solo administradores pueden acceder a este panel.', 'error');
            setTimeout(() => window.location.href = 'index.html', 2000);
            return;
        }

        // Actualizar información en el sidebar
        const nameElement = document.querySelector('aside h2');
        const emailElement = document.querySelector('aside .text-gray-600');
        const roleElement = document.querySelector('aside .bg-red-100');
        
        if (nameElement) nameElement.textContent = currentUser.name || 'Administrador';
        if (emailElement) emailElement.textContent = currentUser.email || 'admin@kompralibre.shop';
        if (roleElement) {
            roleElement.textContent = currentUser.role === 'admin' ? 'Administrador' : 'Usuario';
            roleElement.className = `inline-block text-xs px-2 py-1 rounded-full mt-2 ${
                currentUser.role === 'admin' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'
            }`;
        }

    } catch (error) {
        console.error('Error al cargar información del admin:', error);
        showMessage('Error al cargar la información del admin', 'error');
    } finally {
        hideLoading();
    }
}

// Cargar datos del dashboard
async function loadDashboard() {
    try {
        const dashboardData = await api('api/admin/dashboard');
        const statsContainer = document.getElementById('dashboardStats');
        const activityContainer = document.getElementById('recentActivity');

        statsContainer.innerHTML = `
            <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 border-blue-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Total de Usuarios</p>
                        <p class="text-3xl font-bold text-gray-900">${dashboardData.total_users || 0}</p>
                    </div>
                    <div class="bg-blue-100 p-3 rounded-full">
                        <i class="fas fa-users text-blue-600"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 border-green-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Productos Activos</p>
                        <p class="text-3xl font-bold text-gray-900">${dashboardData.active_products || 0}</p>
                    </div>
                    <div class="bg-green-100 p-3 rounded-full">
                        <i class="fas fa-box text-green-600"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 border-yellow-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Ventas del Mes</p>
                        <p class="text-3xl font-bold text-gray-900">$${dashboardData.monthly_sales?.toFixed(2) || '0.00'}</p>
                    </div>
                    <div class="bg-yellow-100 p-3 rounded-full">
                        <i class="fas fa-dollar-sign text-yellow-600"></i>
                    </div>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 border-purple-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium text-gray-600">Categorías</p>
                        <p class="text-3xl font-bold text-gray-900">${dashboardData.total_categories || 0}</p>
                    </div>
                    <div class="bg-purple-100 p-3 rounded-full">
                        <i class="fas fa-tags text-purple-600"></i>
                    </div>
                </div>
            </div>
        `;

        activityContainer.innerHTML = `
            <div class="flex items-center space-x-3 p-3 bg-white rounded-lg">
                <div class="w-2 h-2 bg-green-500 rounded-full"></div>
                <span class="text-sm text-gray-600">Panel de admin iniciado</span>
                <span class="text-xs text-gray-400 ml-auto">Ahora</span>
            </div>
            <div class="flex items-center space-x-3 p-3 bg-white rounded-lg">
                <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span class="text-sm text-gray-600">Estadísticas actualizadas</span>
                <span class="text-xs text-gray-400 ml-auto">Ahora</span>
            </div>
        `;

    } catch (error) {
        console.error('Error al cargar dashboard:', error);
        showMessage('Error al cargar el dashboard', 'error');
    }
}

// Cargar usuarios
async function loadUsers() {
    try {
        const usersList = document.getElementById('usersList');
        const searchInput = document.getElementById('userSearch');
        const roleFilter = document.getElementById('userRoleFilter');

        // TODO: Implementar API de usuarios
        usersList.innerHTML = `
            <div class="text-center py-12 text-gray-500">
                <i class="fas fa-users text-4xl mb-4"></i>
                <p class="text-lg font-medium mb-2">No hay usuarios</p>
                <p class="text-sm">Los usuarios aparecerán aquí cuando se implemente la API</p>
            </div>
        `;

        // Event listeners para filtros
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                // TODO: Implementar búsqueda
                console.log('Buscar:', e.target.value);
            });
        }

        if (roleFilter) {
            roleFilter.addEventListener('change', (e) => {
                // TODO: Implementar filtro por rol
                console.log('Filtrar por rol:', e.target.value);
            });
        }

    } catch (error) {
        console.error('Error al cargar usuarios:', error);
        showMessage('Error al cargar usuarios', 'error');
    }
}

// Cargar productos
async function loadProducts() {
    try {
        const productsList = document.getElementById('productsList');
        const searchInput = document.getElementById('productSearch');
        const statusFilter = document.getElementById('productStatusFilter');

        // TODO: Implementar API de productos admin
        productsList.innerHTML = `
            <div class="text-center py-12 text-gray-500">
                <i class="fas fa-box text-4xl mb-4"></i>
                <p class="text-lg font-medium mb-2">No hay productos</p>
                <p class="text-sm">Los productos aparecerán aquí cuando se implemente la API</p>
            </div>
        `;

        // Event listeners para filtros
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                // TODO: Implementar búsqueda
                console.log('Buscar productos:', e.target.value);
            });
        }

        if (statusFilter) {
            statusFilter.addEventListener('change', (e) => {
                // TODO: Implementar filtro por estado
                console.log('Filtrar por estado:', e.target.value);
            });
        }

    } catch (error) {
        console.error('Error al cargar productos:', error);
        showMessage('Error al cargar productos', 'error');
    }
}

// Cargar categorías
async function loadCategories() {
    try {
        const categoriesList = document.getElementById('categoriesList');

        // Cargar categorías desde API
        const categories = await api('api/categories');

        if (categories.length === 0) {
            categoriesList.innerHTML = `
                <div class="text-center py-12 text-gray-500">
                    <i class="fas fa-tags text-4xl mb-4"></i>
                    <p class="text-lg font-medium mb-2">No hay categorías</p>
                    <p class="text-sm">Las categorías aparecerán aquí</p>
                </div>
            `;
            return;
        }

        categoriesList.innerHTML = categories.map(category => `
            <div class="bg-white border border-gray-200 rounded-lg p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <h4 class="text-lg font-medium text-gray-900">${category.name}</h4>
                        <p class="text-sm text-gray-500">Slug: ${category.slug}</p>
                    </div>
                    <div class="flex space-x-2">
                        <button class="text-blue-600 hover:text-blue-800" onclick="editCategory('${category.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="text-red-600 hover:text-red-800" onclick="deleteCategory('${category.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

    } catch (error) {
        console.error('Error al cargar categorías:', error);
        showMessage('Error al cargar categorías', 'error');
    }
}

// Cargar reportes
async function loadReports() {
    try {
        // TODO: Implementar API de reportes
        document.getElementById('salesChart').innerHTML = `
            <div class="text-center py-12 text-gray-500">
                <i class="fas fa-chart-line text-4xl mb-4"></i>
                <p class="text-lg font-medium mb-2">Gráficos próximamente</p>
                <p class="text-sm">Los reportes gráficos se implementarán pronto</p>
            </div>
        `;

        document.getElementById('topProducts').innerHTML = `
            <div class="text-center py-8 text-gray-500">
                <p class="text-sm">Productos más vendidos aparecerán aquí</p>
            </div>
        `;

    } catch (error) {
        console.error('Error al cargar reportes:', error);
        showMessage('Error al cargar reportes', 'error');
    }
}

// Cargar configuración
async function loadSettings() {
    try {
        // TODO: Implementar API de configuración
        // Por ahora solo mostrar controles estáticos
        console.log('Configuración cargada');

    } catch (error) {
        console.error('Error al cargar configuración:', error);
        showMessage('Error al cargar configuración', 'error');
    }
}

// Cargar datos de la sección actual
async function loadSectionData(section) {
    try {
        switch (section) {
            case 'dashboard':
                await loadDashboard();
                break;
            case 'users':
                await loadUsers();
                break;
            case 'products':
                await loadProducts();
                break;
            case 'categories':
                await loadCategories();
                break;
            case 'reports':
                await loadReports();
                break;
            case 'settings':
                await loadSettings();
                break;
        }
    } catch (error) {
        console.error('Error al cargar datos de la sección:', error);
        showMessage('Error al cargar los datos', 'error');
    }
}

// Crear nuevo usuario
function createUser() {
    showMessage('Funcionalidad de crear usuario próximamente', 'info');
}

// Crear nueva categoría
function createCategory() {
    showMessage('Funcionalidad de crear categoría próximamente', 'info');
}

// Crear backup
function createBackup() {
    showMessage('Funcionalidad de backup próximamente', 'info');
}

// Cerrar sesión
function logout() {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

// Funciones globales
window.editCategory = function(id) {
    showMessage(`Funcionalidad de editar categoría ${id} próximamente`, 'info');
};

window.deleteCategory = function(id) {
    if (confirm('¿Estás seguro de que quieres eliminar esta categoría?')) {
        showMessage(`Funcionalidad de eliminar categoría ${id} próximamente`, 'info');
    }
};

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Cargar información del admin
    loadUserInfo().then(() => {
        // Cargar datos de la sección actual
        loadSectionData(currentSection);
    });

    // Event listeners para navegación
    document.querySelectorAll('[data-section]').forEach(button => {
        button.addEventListener('click', () => {
            const section = button.getAttribute('data-section');
            switchSection(section);
        });
    });

    // Event listeners para acciones
    document.getElementById('addUserBtn')?.addEventListener('click', createUser);
    document.getElementById('addCategoryBtn')?.addEventListener('click', createCategory);
    document.getElementById('backupBtn')?.addEventListener('click', createBackup);
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    document.getElementById('logoutBtnSidebar')?.addEventListener('click', logout);

    // Mostrar sección de dashboard por defecto
    switchSection('dashboard');
});
