import { api } from '/js/utils.js';
async function load(){ const favs = await api('/api/users/me/favorites'); const c = document.getElementById('items'); c.innerHTML = favs.map(p=>`<article class='border p-2 rounded'><img src='${p.cover}' class='w-full h-40 object-cover'><h3>${p.title}</h3></article>`).join(''); } load();
