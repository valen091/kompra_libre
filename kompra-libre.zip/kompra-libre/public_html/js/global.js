/**
 * Script global que se carga en todas las páginas
 */

// Inicializar sistemas globales cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    // Actualizar UI de autenticación
    updateAuthUI();
    
    // Actualizar contador del carrito
    if (window.cart) {
        window.cart.updateCartUI();
    }
    
    // Event listeners para botones de agregar al carrito
    setupCartButtons();
    
    // Event listeners para logout
    setupLogoutButtons();
});

/**
 * Actualizar UI según el estado de autenticación
 */
function updateAuthUI() {
    const isAuth = window.auth && window.auth.isAuthenticated();
    const user = isAuth ? window.auth.getUser() : null;
    
    // Mostrar/ocultar elementos según autenticación
    document.querySelectorAll('[data-auth-show]').forEach(el => {
        el.style.display = isAuth ? '' : 'none';
    });
    
    document.querySelectorAll('[data-auth-hide]').forEach(el => {
        el.style.display = isAuth ? 'none' : '';
    });
    
    // Actualizar nombre de usuario
    if (user) {
        document.querySelectorAll('[data-user-name]').forEach(el => {
            el.textContent = user.name;
        });
    }
}

/**
 * Configurar botones de agregar al carrito
 */
function setupCartButtons() {
    document.querySelectorAll('[data-add-to-cart]').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const productId = this.dataset.productId || this.dataset.addToCart;
            const productName = this.dataset.productName || 'Producto';
            const productPrice = parseFloat(this.dataset.productPrice || 0);
            const productImage = this.dataset.productImage || '';
            const quantity = parseInt(this.dataset.quantity || 1);
            
            const product = {
                id: productId,
                name: productName,
                price: productPrice,
                image: productImage
            };
            
            if (window.cart) {
                window.cart.addProduct(product, quantity);
            }
        });
    });
}

/**
 * Configurar botones de logout
 */
function setupLogoutButtons() {
    document.querySelectorAll('[data-logout]').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (confirm('¿Estás seguro de que deseas cerrar sesión?')) {
                if (window.auth) {
                    window.auth.logout();
                }
            }
        });
    });
}

/**
 * Helper: Formatear precio en pesos uruguayos
 */
function formatPrice(price) {
    return new Intl.NumberFormat('es-UY', {
        style: 'currency',
        currency: 'UYU'
    }).format(price);
}

/**
 * Helper: Hacer petición autenticada
 */
async function fetchAuth(url, options = {}) {
    if (window.auth) {
        return await window.auth.fetchAuth(url, options);
    }
    throw new Error('Sistema de autenticación no disponible');
}

// Exportar helpers globalmente
window.formatPrice = formatPrice;
window.fetchAuth = fetchAuth;
