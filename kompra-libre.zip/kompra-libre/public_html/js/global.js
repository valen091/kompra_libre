/**
 * Script global que se carga en todas las páginas
 */

// Esperar a que todo esté cargado
window.addEventListener('load', function() {
    // Verificar dependencias críticas
    const requiredGlobals = ['auth', 'notify'];
    const missingDeps = requiredGlobals.filter(g => !window[g]);
    
    if (missingDeps.length > 0) {
        console.error('Faltan dependencias requeridas:', missingDeps);
        return;
    }
    
    console.log('Inicializando aplicación...');
    
    // Inicializar componentes en el orden correcto
    try {
        // 1. Actualizar UI de autenticación
        updateAuthUI();
        
        // 2. Inicializar menú de usuario
        initUserMenu();
        
        // 3. Configurar botones de la interfaz
        setupCartButtons();
        setupLogoutButtons();
        
        // 4. Verificar páginas protegidas
        checkProtectedPages();
        
        // 5. Actualizar carrito si existe
        if (window.cart && typeof window.cart.updateCartUI === 'function') {
            window.cart.updateCartUI();
        }
        
        console.log('Aplicación inicializada correctamente');
    } catch (error) {
        console.error('Error durante la inicialización:', error);
        if (window.notify) {
            window.notify.error('Error al cargar la aplicación. Por favor, recarga la página.');
        }
    }
});

/**
 * Inicializar el menú desplegable de usuario
 */
function initUserMenu() {
    console.log('Inicializando menú de usuario...');
    const userMenuButton = document.getElementById('userMenuButton');
    const userMenu = document.getElementById('userMenu');

    if (!userMenuButton || !userMenu) {
        console.warn('No se encontraron los elementos del menú de usuario');
        return;
    }

    // Estado del menú
    let isMenuOpen = false;
    let clickOutsideHandler = null;

    // Función para abrir el menú
    const openMenu = () => {
        if (isMenuOpen) return;
        
        console.log('Abriendo menú...');
        isMenuOpen = true;
        userMenu.classList.add('show');
        userMenu.style.display = 'block';
        userMenu.setAttribute('aria-expanded', 'true');
        
        // Forzar reflow para activar la transición
        void userMenu.offsetHeight;
        
        // Cerrar el menú al hacer clic fuera de él
        clickOutsideHandler = (event) => {
            if (!userMenu.contains(event.target) && !userMenuButton.contains(event.target)) {
                closeMenu();
            }
        };

        // Usar capture para asegurar que se ejecute antes que otros manejadores
        document.addEventListener('click', clickOutsideHandler, { capture: true });
        
        // Enfocar el primer elemento del menú
        setTimeout(() => {
            const firstFocusable = userMenu.querySelector('a, button, [tabindex="0"]');
            if (firstFocusable) firstFocusable.focus();
        }, 50);
    };

    // Función para cerrar el menú
    const closeMenu = () => {
        if (!isMenuOpen) return;
        
        console.log('Cerrando menú...');
        isMenuOpen = false;
        userMenu.classList.remove('show');
        userMenu.setAttribute('aria-expanded', 'false');
        
        // Remover el manejador de clic fuera
        if (clickOutsideHandler) {
            document.removeEventListener('click', clickOutsideHandler, { capture: true });
            clickOutsideHandler = null;
        }
        
        // Devolver el foco al botón del menú
        userMenuButton.focus();
    };

    // Manejar clic en el botón del menú
    const handleMenuButtonClick = (e) => {
        e.stopPropagation();
        
        if (isMenuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    };

    // Limpiar manejadores de eventos anteriores
    const cleanUp = () => {
        userMenuButton.removeEventListener('click', handleMenuButtonClick);
        document.removeEventListener('keydown', handleEscapeKey);
        if (clickOutsideHandler) {
            document.removeEventListener('click', clickOutsideHandler, { capture: true });
        }
    };

    // Manejar tecla Escape
    const handleEscapeKey = (e) => {
        if (e.key === 'Escape' && isMenuOpen) {
            e.preventDefault();
            closeMenu();
        }
    };

    // Configurar manejadores de eventos
    cleanUp(); // Limpiar cualquier manejador existente
    userMenuButton.addEventListener('click', handleMenuButtonClick);
    document.addEventListener('keydown', handleEscapeKey);

    // Manejar la navegación con el teclado
    userMenu.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeMenu();
            userMenuButton.focus();
        } else if (e.key === 'Tab') {
            const focusableElements = Array.from(userMenu.querySelectorAll('a[href], button:not([disabled]), [tabindex="0"]'));
            const firstElement = focusableElements[0];
            const lastElement = focusableElements[focusableElements.length - 1];
            
            if (!e.shiftKey && document.activeElement === lastElement) {
                e.preventDefault();
                closeMenu();
            } else if (e.shiftKey && document.activeElement === firstElement) {
                e.preventDefault();
                closeMenu();
                userMenuButton.focus();
            }
        }
    });

    // Asegurarse de que el menú esté cerrado al inicio
    closeMenu();
    
    // Configurar atributos de accesibilidad
    userMenuButton.setAttribute('aria-haspopup', 'true');
    userMenuButton.setAttribute('aria-expanded', 'false');
    userMenu.setAttribute('role', 'menu');
    
    // Prevenir cierre al hacer clic dentro del menú
    userMenu.addEventListener('click', (e) => {
        e.stopPropagation();
        
        // Cerrar menú al hacer clic en un enlace
        if (e.target.tagName === 'A' || e.target.closest('a')) {
            setTimeout(closeMenu, 200);
        }
    });
    
    // Limpiar al desmontar
    window.addEventListener('unload', cleanUp);
    
    console.log('Menú de usuario inicializado correctamente');
    return cleanUp; // Devolver función de limpieza
        newMenu.addEventListener('keydown', (e) => {
            const items = Array.from(newMenu.querySelectorAll('a, button'));
            const currentIndex = items.indexOf(document.activeElement);
            
            if (e.key === 'Escape' || e.key === 'Esc') {
                e.preventDefault();
                e.stopPropagation();
                closeMenu();
                newButton.focus();
            } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                const nextIndex = (currentIndex + 1) % items.length;
                items[nextIndex]?.focus();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                const prevIndex = (currentIndex - 1 + items.length) % items.length;
                items[prevIndex]?.focus();
            } else if (e.key === 'Tab' && !e.shiftKey && currentIndex === items.length - 1) {
                // Cerrar menú al salir del último elemento con Tab
                setTimeout(closeMenu, 0);
            } else if (e.key === 'Tab' && e.shiftKey && currentIndex <= 0) {
                // Cerrar menú al salir del primer elemento con Shift+Tab
                setTimeout(closeMenu, 0);
            }
        });
        
        console.log('Menú de usuario inicializado correctamente');
        
    } catch (error) {
        console.error('Error al inicializar el menú de usuario:', error);
    }
}

/**
 * Verificar páginas protegidas
 */
function checkProtectedPages() {
    // Lista de páginas que requieren autenticación
    const protectedPages = ['/mi-cuenta.html', '/mis-compras.html'];
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    if (protectedPages.includes(`/${currentPage}`) || protectedPages.includes(currentPage)) {
        if (!window.auth.isAuthenticated()) {
            window.notify.warning('Debes iniciar sesión para acceder a esta página');
            window.location.href = '/login.html?redirect=' + encodeURIComponent(window.location.pathname);
        }
    }
}

/**
 * Actualizar UI según el estado de autenticación
 */
function updateAuthUI() {
    try {
        console.log('Actualizando UI de autenticación...');
        
        const loginLink = document.getElementById('loginLink');
        const registerLink = document.getElementById('registerLink');
        const userMenuContainer = document.getElementById('userMenuContainer');
        const userMenuButton = document.getElementById('userMenuButton');
        
        if (!window.auth) {
            console.error('Sistema de autenticación no disponible');
            return;
        }
        
        const isAuthenticated = window.auth.isAuthenticated();
        const user = window.auth.getUser();
        
        console.log('Estado de autenticación:', { isAuthenticated, user });
        
        // Actualizar elementos de autenticación
        if (isAuthenticated && user) {
            // Usuario autenticado - Mostrar menú de usuario
            console.log('Usuario autenticado:', user);
            
            // Ocultar enlaces de login/registro
            [loginLink, registerLink].forEach(el => {
                if (el) el.classList.add('hidden');
            });
            
            // Mostrar menú de usuario
            if (userMenuContainer) {
                // Asegurarse de que el contenedor sea visible
                userMenuContainer.style.display = 'block';
                userMenuContainer.style.visibility = 'visible';
                userMenuContainer.style.opacity = '1';
                userMenuContainer.classList.remove('hidden', 'invisible');
                
                // Asegurarse de que el menú esté oculto inicialmente
                const userMenu = document.getElementById('userMenu');
                if (userMenu) {
                    userMenu.classList.add('hidden');
                    userMenu.style.display = 'none';
                }
                
                // Actualizar información del usuario en el menú
                const userNameElements = userMenuContainer.querySelectorAll('[data-user-name]');
                const userEmailElements = userMenuContainer.querySelectorAll('[data-user-email]');
                
                userNameElements.forEach(el => {
                    if (el) el.textContent = user.name || user.username || user.email.split('@')[0];
                });
                
                userEmailElements.forEach(el => {
                    if (el) el.textContent = user.email;
                });
                
                // Actualizar información del usuario en el menú
                const userAvatarElement = userMenuContainer.querySelector('[data-user-avatar]');
                
                if (userAvatarElement) {
                    // Si hay una imagen de perfil, actualizarla
                    if (user.avatar || user.image) {
                        userAvatarElement.src = user.avatar || user.image;
                        userAvatarElement.alt = `Avatar de ${user.name || user.email}`;
                        userAvatarElement.classList.remove('hidden');
                    } else {
                        // Mostrar iniciales o ícono por defecto
                        const initials = user.name 
                            ? user.name.split(' ').map(n => n[0]).join('').toUpperCase()
                            : user.email[0].toUpperCase();
                        
                        const defaultAvatar = document.createElement('div');
                        defaultAvatar.className = 'w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 font-medium';
                        defaultAvatar.textContent = initials;
                        
                        userAvatarElement.parentNode.replaceChild(defaultAvatar, userAvatarElement);
                    }
                }
                
                // Actualizar enlaces del menú con el ID de usuario
                const userLinks = userMenuContainer.querySelectorAll('a[href*="mi-cuenta"], a[href*="mis-compras"]');
                userLinks.forEach(link => {
                    try {
                        if (user && user.id) {
                            const url = new URL(link.href, window.location.origin);
                            // Asegurarse de que la URL no tenga parámetros duplicados
                            const baseUrl = url.origin + url.pathname;
                            link.href = `${baseUrl}?userId=${user.id}`;
                            console.log('Enlace actualizado:', link.href);
                        }
                    } catch (e) {
                        console.error('Error actualizando enlace de usuario:', e);
                    }
                });
                
                // Mostrar el menú de usuario
                userMenuContainer.style.display = 'block';
            }
            
        } else {
            // Usuario no autenticado - Mostrar enlaces de login/registro
            console.log('Usuario no autenticado');
            
            // Mostrar enlaces de login/registro
            [loginLink, registerLink].forEach(el => {
                if (el) el.classList.remove('hidden');
            });
            
            // Ocultar menú de usuario
            if (userMenuContainer) {
                userMenuContainer.classList.add('hidden');
                userMenuContainer.style.display = 'none';
            }
        }
        
        // Actualizar atributos ARIA para accesibilidad
        if (userMenuButton) {
            userMenuButton.setAttribute('aria-expanded', 'false');
            userMenuButton.setAttribute('aria-haspopup', 'true');
            userMenuButton.setAttribute('aria-label', isAuthenticated 
                ? `Menú de ${user?.name || 'usuario'}` 
                : 'Menú de usuario');
        }
        
        // Actualizar clases basadas en autenticación
        document.querySelectorAll('[data-auth-show]').forEach(el => {
            el.classList.toggle('hidden', !isAuthenticated);
        });
        
        document.querySelectorAll('[data-auth-hide]').forEach(el => {
            el.classList.toggle('hidden', isAuthenticated);
        });
        
        console.log('UI de autenticación actualizada correctamente');
        
    } catch (error) {
        console.error('Error al actualizar la UI de autenticación:', error);
    }
}

/**
 * Configurar botones de agregar al carrito
 */
function setupCartButtons() {
    document.querySelectorAll('[data-add-to-cart]').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const productId = this.dataset.productId || this.dataset.addToCart;
            const productName = this.dataset.productName || 'Producto';
            const productPrice = parseFloat(this.dataset.productPrice || 0);
            const productImage = this.dataset.productImage || '';
            const quantity = parseInt(this.dataset.quantity || 1);
            
            const product = {
                id: productId,
                name: productName,
                price: productPrice,
                image: productImage
            };
            
            if (window.cart) {
                window.cart.addProduct(product, quantity);
            }
        });
    });
}

/**
 * Configurar botones de cerrar sesión
 */
function setupLogoutButtons() {
    try {
        console.log('Configurando botones de cierre de sesión...');
        
        const logoutButtons = document.querySelectorAll('#logoutBtn, [data-logout]');
        
        if (logoutButtons.length === 0) {
            console.log('No se encontraron botones de cierre de sesión');
            return;
        }
        
        const handleLogout = async (e) => {
            if (e) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            try {
                console.log('Iniciando cierre de sesión...');
                
                // Mostrar confirmación al usuario
                const confirmLogout = window.confirm('¿Estás seguro de que deseas cerrar sesión?');
                if (!confirmLogout) {
                    console.log('Cierre de sesión cancelado por el usuario');
                    return;
                }
                
                // Mostrar indicador de carga
                const button = e?.target?.closest('button, a') || e?.target;
                let originalContent = '';
                
                if (button) {
                    originalContent = button.innerHTML;
                    button.disabled = true;
                    button.innerHTML = `
                        <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white inline-block" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Cerrando sesión...
                    `;
                }
                
                // Cerrar sesión
                if (window.auth && typeof window.auth.logout === 'function') {
                    await window.auth.logout();
                } else {
                    console.warn('Sistema de autenticación no disponible, redirigiendo a login');
                    window.location.href = '/login.html';
                    return;
                }
                
                // Limpiar carrito si existe
                if (window.cart && typeof window.cart.clear === 'function') {
                    window.cart.clear();
                }
                
                // Redirigir a la página de inicio o login
                const redirectUrl = window.location.pathname.includes('admin') ? '/login.html' : '/';
                
                // Mostrar notificación de éxito
                if (window.notify) {
                    window.notify.success('Has cerrado sesión correctamente');
                }
                
                // Pequeño retraso para mostrar la notificación
                setTimeout(() => {
                    window.location.href = redirectUrl;
                }, 500);
                
            } catch (error) {
                console.error('Error al cerrar sesión:', error);
                
                // Restaurar botón si existe
                const button = e?.target?.closest('button, a') || e?.target;
                if (button) {
                    button.disabled = false;
                    button.innerHTML = originalContent;
                }
                
                // Mostrar mensaje de error
                if (window.notify) {
                    window.notify.error('Error al cerrar sesión. Por favor, inténtalo de nuevo.');
                } else {
                    alert('Error al cerrar sesión. Por favor, inténtalo de nuevo.');
                }
            }
        };
        
        // Agregar event listeners a todos los botones de cierre de sesión
        logoutButtons.forEach(button => {
            // Remover event listeners existentes para evitar duplicados
            const newButton = button.cloneNode(true);
            button.parentNode.replaceChild(newButton, button);
            newButton.addEventListener('click', handleLogout);
        });
        
        console.log('Botones de cierre de sesión configurados correctamente');
        
    } catch (error) {
        console.error('Error al configurar botones de cierre de sesión:', error);
    }
}

/**
 * Helper: Formatear precio en pesos uruguayos
 */
function formatPrice(price) {
    return new Intl.NumberFormat('es-UY', {
        style: 'currency',
        currency: 'UYU'
    }).format(price);
}

/**
 * Helper: Hacer petición autenticada
 */
async function fetchAuth(url, options = {}) {
    if (window.auth) {
        return await window.auth.fetchAuth(url, options);
    }
    throw new Error('Sistema de autenticación no disponible');
}

// Exportar helpers globalmente
window.formatPrice = formatPrice;
window.fetchAuth = fetchAuth;
