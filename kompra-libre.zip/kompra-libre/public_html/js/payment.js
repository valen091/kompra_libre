// Configuración de Mercado Pago para Uruguay
const MERCADO_PAGO_PUBLIC_KEY = process.env.MP_PUBLIC_KEY || 'TEST-12345678-1234-1234-1234-123456789012';
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:3000';

// Función para inicializar el botón de pago de Mercado Pago
async function initializeMercadoPago() {
    try {
        // Cargar el SDK de Mercado Pago
        const script = document.createElement('script');
        script.src = 'https://sdk.mercadopago.com/js/v2';
        script.async = true;
        script.onload = async () => {
            try {
                // Inicializar SDK de Mercado Pago
                const mp = new MercadoPago(MERCADO_PAGO_PUBLIC_KEY, {
                    locale: 'es-UY', // Configurar para Uruguay
                    advancedFraudPrevention: true,
                    trackingDisabled: false
                });
                
                // Inicializar el botón de pago
                const checkout = mp.checkout({
                    preference: {
                        id: '' // Se establecerá más adelante
                    },
                    autoOpen: false, // No abrir automáticamente
                    theme: {
                        elementsColor: '#4F46E5',
                        headerColor: '#4F46E5',
                        textColor: '#1F2937'
                    },
                    render: {
                        container: '.mercado-pago-button', // Clase del contenedor del botón
                        label: 'Pagar con Mercado Pago',
                        type: 'pay',
                        value: 'Pagar con Mercado Pago'
                    },
                    customization: {
                        paymentMethods: {
                            atm: 'all',
                            ticket: 'all',
                            bankTransfer: 'all',
                            creditCard: 'all',
                            debitCard: 'all',
                            mercadoPago: 'all',
                            maxInstallments: 12 // Máximo de cuotas para Uruguay
                        }
                    }
                });
                
                // Almacenar la instancia del checkout para usarla más tarde
                window.mercadoPagoCheckout = checkout;
                
                // Mostrar el botón de Mercado Pago
                const mpButtonContainer = document.querySelector('.mercado-pago-button');
                if (mpButtonContainer) {
                    mpButtonContainer.style.display = 'block';
                }
                
                // Ocultar el botón genérico de pago
                const genericPayButton = document.getElementById('place-order-btn');
                if (genericPayButton) {
                    genericPayButton.style.display = 'none';
                }
                
            } catch (error) {
                console.error('Error al inicializar Mercado Pago:', error);
                showNotification('Error al cargar el sistema de pagos. Por favor, recarga la página.', 'error');
            }
        };
        
        script.onerror = () => {
            console.error('Error al cargar el SDK de Mercado Pago');
            showNotification('Error al cargar el sistema de pagos. Por favor, inténtalo de nuevo más tarde.', 'error');
        };
        
        document.body.appendChild(script);
    } catch (error) {
        console.error('Error al inicializar Mercado Pago:', error);
        showNotification('Error al inicializar el sistema de pagos. Por favor, recarga la página e intenta nuevamente.', 'error');
    }
}

// Función para crear una preferencia de pago
export async function createPaymentPreference(cartItems, userData) {
    try {
        const response = await fetch('/api/payments/create-preference', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`
            },
            body: JSON.stringify({
                items: cartItems,
                payer: userData
            })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Error al crear la preferencia de pago');
        }

        return await response.json();
    } catch (error) {
        console.error('Error al crear preferencia de pago:', error);
        throw error;
    }
}

// Función para manejar el proceso de pago
export async function handlePayment(buttonId, cartItems, userData) {
    try {
        // Mostrar indicador de carga
        const button = document.getElementById(buttonId);
        const buttonText = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';

        // Crear preferencia de pago
        const preference = await createPaymentPreference(cartItems, userData);
        
        // Inicializar el botón de pago
        window.mercadoPagoCheckout.preference.id = preference.id;
        window.mercadoPagoCheckout.open();
        
    } catch (error) {
        console.error('Error en el proceso de pago:', error);
        alert(`Error: ${error.message}`);
        
        // Restaurar el botón
        const button = document.getElementById(buttonId);
        button.disabled = false;
        button.innerHTML = buttonText;
    }
}

// Función para verificar el estado de un pago
export async function checkPaymentStatus(paymentId) {
    try {
        const response = await fetch(`/api/payments/status/${paymentId}`, {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('authToken')}`
            }
        });

        if (!response.ok) {
            throw new Error('Error al verificar el estado del pago');
        }

        return await response.json();
    } catch (error) {
        console.error('Error al verificar estado del pago:', error);
        throw error;
    }
}

// Función para manejar la respuesta de pago
export function handlePaymentResponse(status) {
    switch(status) {
        case 'approved':
            // Redirigir a página de éxito
            window.location.href = '/pago-exitoso';
            break;
        case 'pending':
            // Mostrar mensaje de pago pendiente
            window.location.href = '/pago-pendiente';
            break;
        case 'rejected':
            // Mostrar mensaje de pago rechazado
            window.location.href = '/pago-rechazado';
            break;
        default:
            console.error('Estado de pago desconocido:', status);
    }
}

// Verificar parámetros de URL después de un pago
export function checkUrlForPaymentResponse() {
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('status');
    const paymentId = urlParams.get('payment_id');
    
    if (status && paymentId) {
        handlePaymentResponse(status);
    }
}

// Inicializar el módulo de pagos
document.addEventListener('DOMContentLoaded', () => {
    // Verificar si hay una respuesta de pago en la URL
    checkUrlForPaymentResponse();
    
    // Verificar si estamos en la página de checkout
    if (window.location.pathname.includes('checkout.html')) {
        initializeMercadoPago();
    }
});

// Verificar si hay una respuesta de pago en la URL
function checkForPaymentResponse() {
    const urlParams = new URLSearchParams(window.location.search);
    const paymentStatus = urlParams.get('payment_status');
    const paymentId = urlParams.get('payment_id');
    const externalReference = urlParams.get('external_reference');
    
    if (paymentId && paymentStatus) {
        // Mostrar mensaje al usuario según el estado del pago
        const statusMessages = {
            'approved': '¡Pago aprobado! Tu pedido ha sido procesado con éxito.',
            'pending': 'Tu pago está siendo procesado. Te notificaremos cuando sea aprobado.',
            'in_process': 'Estamos procesando tu pago. Esto puede tardar hasta 2 días hábiles.',
            'rejected': 'Lo sentimos, tu pago fue rechazado. Por favor, intenta con otro método de pago.',
            'cancelled': 'El pago fue cancelado. Si lo deseas, puedes intentar nuevamente.',
            'refunded': 'Tu pago ha sido reembolsado.',
            'chargedback': 'Se ha realizado un contracargo en tu tarjeta.',
            'in_mediation': 'El pago está en proceso de mediación.',
            'pending_waiting_payment': 'Esperando el pago del comprador.',
            'pending_waiting_transfer': 'Esperando la transferencia del dinero.'
        };
        
        const message = statusMessages[paymentStatus] || 'El estado de tu pago es: ' + paymentStatus;
        showNotification(message, paymentStatus === 'approved' ? 'success' : 'info');
        
        // Limpiar la URL después de mostrar el mensaje
        const cleanUrl = window.location.pathname;
        window.history.replaceState({}, document.title, cleanUrl);
    }
}
