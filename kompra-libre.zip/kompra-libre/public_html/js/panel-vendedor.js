import { api, apiPost, apiDel } from './utils.js';

// Estado de la aplicación
let currentUser = null;
let currentProductId = null;

// Funciones de utilidad
function showNotification(message, type = 'success') {
    alert(message); // Por simplicidad, usar alert por ahora
}

// Cargar información del vendedor
async function loadUserInfo() {
    try {
        const userData = localStorage.getItem('user');
        const token = localStorage.getItem('auth_token');

        if (!token) {
            window.location.href = 'login.html';
            return;
        }

        if (userData) {
            currentUser = JSON.parse(userData);
        } else {
            const response = await fetch('api/auth/me', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                currentUser = await response.json();
                localStorage.setItem('user', JSON.stringify(currentUser));
            }
        }

        // Actualizar información del vendedor
        document.getElementById('products-count').textContent = '0';
        document.getElementById('monthly-sales').textContent = '$0';
        document.getElementById('total-views').textContent = '0';
        document.getElementById('pending-orders').textContent = '0';

    } catch (error) {
        console.error('Error al cargar información del vendedor:', error);
        showNotification('Error al cargar la información del vendedor', 'error');
    }
}

// Cargar productos del vendedor
async function loadProducts() {
    try {
        const productsList = document.getElementById('products-list');

        // TODO: Implementar API de productos del vendedor
        // Por ahora mostrar estado vacío
        productsList.innerHTML = `
            <tr>
                <td colspan="5" class="px-6 py-4 text-center text-sm text-gray-500">
                    No has agregado ningún producto aún.
                </td>
            </tr>
        `;

    } catch (error) {
        console.error('Error al cargar productos:', error);
        showNotification('Error al cargar productos', 'error');
    }
}

// Cargar categorías
async function loadCategories() {
    try {
        const categories = await api('api/categories');
        const categorySelect = document.getElementById('category_id');
        if (categorySelect) {
            categorySelect.innerHTML = '<option value="">Seleccionar categoría</option>';
            categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category.id;
                option.textContent = category.name;
                categorySelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error al cargar categorías:', error);
    }
}

// Abrir modal para agregar producto
function openAddProductModal() {
    currentProductId = null;
    document.getElementById('modal-title').textContent = 'Agregar Nuevo Producto';
    document.getElementById('product-form').reset();
    document.getElementById('image-preview').innerHTML = '';
    document.getElementById('product-modal').classList.remove('hidden');
}

// Cerrar modal
function closeModal() {
    document.getElementById('product-modal').classList.add('hidden');
}

// Guardar producto
async function saveProduct() {
    try {
        const form = document.getElementById('product-form');
        const formData = new FormData(form);

        const productData = {
            title: formData.get('title'),
            description: formData.get('description'),
            price: parseFloat(formData.get('price')),
            stock: parseInt(formData.get('quantity')),
            condition: formData.get('condition'),
            category_id: parseInt(formData.get('category_id')),
            visible: 1
        };

        // TODO: Implementar API de creación de productos
        showNotification('Funcionalidad de agregar productos próximamente', 'info');
        closeModal();
        loadProducts();

    } catch (error) {
        console.error('Error al guardar producto:', error);
        showNotification('Error al guardar el producto', 'error');
    }
}

// Cerrar sesión
function logout() {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Cargar información del vendedor
    loadUserInfo();
    loadCategories();
    loadProducts();

    // Event listeners
    document.getElementById('add-product-btn').addEventListener('click', openAddProductModal);
    document.getElementById('cancel-product').addEventListener('click', closeModal);
    document.getElementById('product-form').addEventListener('submit', function(e) {
        e.preventDefault();
        saveProduct();
    });

    // Cerrar modal al hacer clic fuera
    document.getElementById('product-modal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
});
