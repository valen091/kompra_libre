class UploadManager {
    constructor(options = {}) {
        this.dropZone = options.dropZone || document.body;
        this.previewContainer = options.previewContainer || document.createElement('div');
        this.maxFiles = options.maxFiles || 5;
        this.maxSize = options.maxSize || 5 * 1024 * 1024; // 5MB
        this.allowedTypes = options.allowedTypes || ['image/jpeg', 'image/png', 'image/webp'];
        this.uploadUrl = options.uploadUrl || '/api/upload/single';
        this.uploadMultipleUrl = options.uploadMultipleUrl || '/api/upload/multiple';
        this.token = options.token || '';
        this.images = [];
        this.onUploadComplete = options.onUploadComplete || (() => {});
        this.onError = options.onError || console.error;
        
        this.initialize();
    }

    initialize() {
        this.setupDropZone();
        this.setupFileInput();
        this.renderPreview();
    }

    setupDropZone() {
        // Prevenir comportamientos por defecto
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            this.dropZone.addEventListener(eventName, this.preventDefaults, false);
        });

        // Resaltar la zona de drop
        ['dragenter', 'dragover'].forEach(eventName => {
            this.dropZone.addEventListener(eventName, this.highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            this.dropZone.addEventListener(eventName, this.unhighlight, false);
        });

        // Manejar el drop
        this.dropZone.addEventListener('drop', this.handleDrop.bind(this), false);
    }

    setupFileInput() {
        this.fileInput = document.createElement('input');
        this.fileInput.type = 'file';
        this.fileInput.multiple = true;
        this.fileInput.accept = this.allowedTypes.join(',');
        this.fileInput.style.display = 'none';
        
        this.fileInput.addEventListener('change', (e) => {
            this.handleFiles(e.target.files);
            this.fileInput.value = ''; // Resetear el input
        });

        this.dropZone.appendChild(this.fileInput);
        
        // Hacer que el dropZone sea clickeable
        this.dropZone.style.cursor = 'pointer';
        this.dropZone.addEventListener('click', () => this.fileInput.click());
    }

    preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    highlight() {
        this.classList.add('border-blue-500', 'bg-blue-50');
    }

    unhighlight() {
        this.classList.remove('border-blue-500', 'bg-blue-50');
    }

    handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        this.handleFiles(files);
    }

    async handleFiles(files) {
        const validFiles = Array.from(files).filter(file => {
            if (!this.allowedTypes.includes(file.type)) {
                this.onError(`Tipo de archivo no soportado: ${file.name}`);
                return false;
            }
            if (file.size > this.maxSize) {
                this.onError(`El archivo es demasiado grande: ${file.name} (máx. ${this.maxSize / (1024 * 1024)}MB)`);
                return false;
            }
            return true;
        });

        if (validFiles.length === 0) return;

        try {
            const formData = new FormData();
            
            if (validFiles.length === 1) {
                formData.append('image', validFiles[0]);
                const response = await this.uploadFile(formData, this.uploadUrl);
                this.addImage(response);
            } else {
                validFiles.forEach((file, index) => {
                    formData.append('images', file);
                });
                const response = await this.uploadFile(formData, this.uploadMultipleUrl);
                response.images.forEach(img => this.addImage(img));
            }
        } catch (error) {
            this.onError('Error al subir los archivos', error);
        }
    }

    async uploadFile(formData, url) {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${this.token}`
            },
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Error al subir el archivo');
        }

        return await response.json();
    }

    addImage(imageData) {
        if (this.images.length >= this.maxFiles) {
            this.onError(`Solo se permiten ${this.maxFiles} imágenes como máximo`);
            return;
        }

        this.images.push({
            original: imageData.image || imageData.original,
            thumbnail: imageData.thumbnail || imageData.original,
            id: Date.now() + Math.random().toString(36).substr(2, 9)
        });

        this.renderPreview();
        this.onUploadComplete(this.images);
    }

    removeImage(id) {
        this.images = this.images.filter(img => img.id !== id);
        this.renderPreview();
        this.onUploadComplete(this.images);
    }

    renderPreview() {
        this.previewContainer.innerHTML = '';
        
        if (this.images.length === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.className = 'text-gray-500 text-center py-4';
            emptyMessage.textContent = 'Arrastra imágenes aquí o haz clic para seleccionar';
            this.previewContainer.appendChild(emptyMessage);
            return;
        }

        const grid = document.createElement('div');
        grid.className = 'grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4';

        this.images.forEach((img, index) => {
            const container = document.createElement('div');
            container.className = 'relative group';
            
            const imgElement = document.createElement('img');
            imgElement.src = img.thumbnail;
            imgElement.alt = `Imagen ${index + 1}`;
            imgElement.className = 'w-full h-32 object-cover rounded-lg border';
            
            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity';
            removeBtn.innerHTML = '&times;';
            removeBtn.addEventListener('click', () => this.removeImage(img.id));
            
            container.appendChild(imgElement);
            container.appendChild(removeBtn);
            grid.appendChild(container);
        });

        this.previewContainer.innerHTML = '';
        this.previewContainer.appendChild(grid);
    }

    getImages() {
        return [...this.images];
    }

    clear() {
        this.images = [];
        this.renderPreview();
    }
}

// Exportar para usar con módulos
export default UploadManager;

// Inicialización automática si se usa sin módulos
if (typeof window !== 'undefined') {
    window.UploadManager = UploadManager;
}

// Inicialización automática para elementos con data-upload
if (typeof document !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('[data-upload]').forEach(container => {
            const dropZone = container.querySelector('[data-drop-zone]') || container;
            const preview = container.querySelector('[data-preview]') || container;
            
            // Obtener el token de autenticación si está disponible
            let token = '';
            const metaToken = document.querySelector('meta[name="csrf-token"]');
            if (metaToken) {
                token = metaToken.getAttribute('content');
            }

            new UploadManager({
                dropZone,
                previewContainer: preview,
                token,
                onUploadComplete: (images) => {
                    // Actualizar campos ocultos con las URLs de las imágenes
                    const input = container.querySelector('input[type="hidden"][name="images"]');
                    if (input) {
                        input.value = JSON.stringify(images.map(img => ({
                            original: img.original,
                            thumbnail: img.thumbnail
                        })));
                    }
                }
            });
        });
    });
}
