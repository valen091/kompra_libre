document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('product-form');
    const specsList = document.getElementById('specs-list');
    const addSpecBtn = document.getElementById('add-spec');
    const cancelBtn = document.getElementById('cancel-btn');
    
    // Contador para IDs únicos de especificaciones
    let specCounter = 0;
    
    // Agregar una nueva especificación
    function addSpec(key = '', value = '') {
        const id = `spec-${specCounter++}`;
        
        const specElement = document.createElement('div');
        specElement.className = 'grid grid-cols-1 md:grid-cols-5 gap-4 items-end';
        specElement.id = id;
        
        specElement.innerHTML = `
            <div class="md:col-span-2">
                <label class="block text-gray-700 text-sm font-bold mb-1">Nombre</label>
                <input type="text" name="specs[${id}][key]" value="${key}" 
                       class="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div class="md:col-span-2">
                <label class="block text-gray-700 text-sm font-bold mb-1">Valor</label>
                <input type="text" name="specs[${id}][value]" value="${value}"
                       class="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
            <div>
                <button type="button" onclick="removeSpec('${id}')" 
                        class="w-full md:w-auto px-3 py-2 bg-red-500 text-white rounded hover:bg-red-600">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        specsList.appendChild(specElement);
    }
    
    // Eliminar una especificación
    window.removeSpec = (id) => {
        const element = document.getElementById(id);
        if (element) {
            element.remove();
        }
    };
    
    // Manejar el envío del formulario
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(form);
        const productData = {
            name: formData.get('name'),
            price: parseFloat(formData.get('price')),
            category: formData.get('category'),
            stock: parseInt(formData.get('stock'), 10),
            description: formData.get('description'),
            images: JSON.parse(formData.get('images') || '[]'),
            specs: {}
        };
        
        // Recopilar especificaciones
        const specElements = specsList.querySelectorAll('[id^="spec-"]');
        specElements.forEach(specEl => {
            const key = specEl.querySelector('input[name$="[key]"]').value.trim();
            const value = specEl.querySelector('input[name$="[value]"]').value.trim();
            if (key && value) {
                productData.specs[key] = value;
            }
        });
        
        try {
            const token = localStorage.getItem('token');
            
            const response = await fetch('/api/products', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(productData)
            });
            
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message || 'Error al guardar el producto');
            }
            
            const result = await response.json();
            alert('Producto guardado correctamente');
            window.location.href = '/productos.html'; // Redirigir a la lista de productos
            
        } catch (error) {
            console.error('Error:', error);
            alert(`Error: ${error.message}`);
        }
    });
    
    // Manejar el botón de cancelar
    cancelBtn.addEventListener('click', () => {
        if (confirm('¿Estás seguro de que deseas cancelar? Los cambios no guardados se perderán.')) {
            window.location.href = '/productos.html';
        }
    });
    
    // Manejar el botón de agregar especificación
    addSpecBtn.addEventListener('click', () => {
        addSpec();
    });
    
    // Agregar una especificación vacía al cargar
    addSpec();
});