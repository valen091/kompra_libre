<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: /auth/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

$pageTitle = 'Mi Perfil';
$success = '';
$error = '';

// Obtener información del usuario actual
$user_id = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // Si el usuario no existe, cerrar sesión
    session_destroy();
    header('Location: /auth/login.php');
    exit();
}

// Procesar actualización de perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $ciudad = trim($_POST['ciudad'] ?? '');
    $pais = trim($_POST['pais'] ?? 'Uruguay');
    $codigo_postal = trim($_POST['codigo_postal'] ?? '');
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? null;
    $genero = $_POST['genero'] ?? null;
    $biografia = trim($_POST['biografia'] ?? '');
    $sitio_web = trim($_POST['sitio_web'] ?? '');
    
    // Validaciones
    if (empty($nombre) || empty($email)) {
        $error = 'El nombre y el correo electrónico son obligatorios';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'El formato del correo electrónico no es válido';
    } else {
        // Verificar si el correo ya está en uso por otro usuario
        $stmt = $db->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
        $stmt->execute([$email, $user_id]);
        if ($stmt->fetch()) {
            $error = 'El correo electrónico ya está en uso por otra cuenta';
        } else {
            // Actualizar los datos del usuario
            $sql = "UPDATE usuarios SET 
                    nombre = ?, email = ?, telefono = ?, direccion = ?, 
                    ciudad = ?, pais = ?, codigo_postal = ?, fecha_nacimiento = ?, 
                    genero = ?, biografia = ?, sitio_web = ?, 
                    fecha_actualizacion = CURRENT_TIMESTAMP 
                    WHERE id = ?";
            
            $stmt = $db->prepare($sql);
            $result = $stmt->execute([
                $nombre, $email, $telefono, $direccion,
                $ciudad, $pais, $codigo_postal, $fecha_nacimiento,
                $genero, $biografia, $sitio_web,
                $user_id
            ]);
            
            if ($result) {
                // Actualizar datos en la sesión
                $_SESSION['user_name'] = $nombre;
                $_SESSION['user_email'] = $email;
                
                if (isset($_SESSION['user'])) {
                    $_SESSION['user']['name'] = $nombre;
                    $_SESSION['user']['email'] = $email;
                }
                
                $success = 'Perfil actualizado correctamente';
                
                // Recargar los datos del usuario
                $stmt = $db->prepare("SELECT * FROM usuarios WHERE id = ?");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                $error = 'Error al actualizar el perfil. Por favor, inténtalo de nuevo.';
            }
        }
    }
}

// Procesar cambio de contraseña
if (isset($_POST['cambiar_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = 'Todos los campos de contraseña son obligatorios';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Las contraseñas no coinciden';
    } elseif (strlen($new_password) < 8) {
        $error = 'La nueva contraseña debe tener al menos 8 caracteres';
    } else {
        // Verificar la contraseña actual
        if (password_verify($current_password, $user['password'])) {
            // Actualizar la contraseña
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE usuarios SET password = ? WHERE id = ?");
            if ($stmt->execute([$hashed_password, $user_id])) {
                $success = 'Contraseña actualizada correctamente';
            } else {
                $error = 'Error al actualizar la contraseña. Por favor, inténtalo de nuevo.';
            }
        } else {
            $error = 'La contraseña actual es incorrecta';
        }
    }
}

// Incluir el encabezado
include_once __DIR__ . '/../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <?php if ($success): ?>
            <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?php echo htmlspecialchars($success); ?></span>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>
        
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                <h1 class="text-2xl font-semibold text-gray-800 dark:text-white">Mi Perfil</h1>
                <p class="text-gray-600 dark:text-gray-300">Administra tu información personal y preferencias</p>
            </div>
            
            <div class="md:flex">
                <!-- Menú lateral -->
                <div class="md:w-1/4 border-r border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
                    <div class="p-4">
                        <div class="flex items-center space-x-4 mb-6">
                            <div class="relative">
                                <img src="/img/usuarios/<?php echo !empty($user['foto_perfil']) ? htmlspecialchars($user['foto_perfil']) : 'default.jpg'; ?>" 
                                     alt="Foto de perfil" 
                                     class="w-16 h-16 rounded-full object-cover border-2 border-white dark:border-gray-600">
                                <button class="absolute bottom-0 right-0 bg-blue-500 text-white rounded-full p-1.5 hover:bg-blue-600 transition-colors">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                </button>
                            </div>
                            <div>
                                <h2 class="text-lg font-semibold text-gray-800 dark:text-white"><?php echo htmlspecialchars($user['nombre']); ?></h2>
                                <p class="text-sm text-gray-600 dark:text-gray-300"><?php echo htmlspecialchars($user['email']); ?></p>
                            </div>
                        </div>
                        
                        <nav class="space-y-1">
                            <a href="#informacion-personal" class="flex items-center px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-md dark:bg-gray-800 dark:text-blue-400 group">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                </svg>
                                Información Personal
                            </a>
                            <a href="#seguridad" class="flex items-center px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 rounded-md dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                </svg>
                                Seguridad
                            </a>
                            <?php if ($user['rol'] === 'admin' || $user['rol'] === 'vendedor'): ?>
                            <a href="/dashboard/" class="flex items-center px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 rounded-md dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                                </svg>
                                Panel de Control
                            </a>
                            <?php endif; ?>
                            <a href="/pedidos/" class="flex items-center px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 rounded-md dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                                </svg>
                                Mis Pedidos
                            </a>
                            <a href="/favoritos/" class="flex items-center px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 rounded-md dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                                </svg>
                                Favoritos
                            </a>
                            <a href="/auth/logout.php" class="flex items-center px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 hover:text-red-700 rounded-md dark:text-red-400 dark:hover:bg-gray-700">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                </svg>
                                Cerrar Sesión
                            </a>
                        </nav>
                    </div>
                </div>
                
                <!-- Contenido principal -->
                <div class="md:w-3/4 p-6">
                    <!-- Sección de Información Personal -->
                    <section id="informacion-personal" class="mb-10">
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Información Personal</h2>
                        </div>
                        
                        <form method="POST" action="">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="col-span-2 md:col-span-1">
                                    <label for="nombre" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Nombre Completo *</label>
                                    <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($user['nombre']); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white" required>
                                </div>
                                
                                <div class="col-span-2 md:col-span-1">
                                    <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Correo Electrónico *</label>
                                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white" required>
                                </div>
                                
                                <div class="col-span-2 md:col-span-1">
                                    <label for="telefono" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Teléfono</label>
                                    <input type="tel" id="telefono" name="telefono" value="<?php echo htmlspecialchars($user['telefono'] ?? ''); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                </div>
                                
                                <div class="col-span-2 md:col-span-1">
                                    <label for="fecha_nacimiento" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Fecha de Nacimiento</label>
                                    <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" 
                                           value="<?php echo !empty($user['fecha_nacimiento']) ? $user['fecha_nacimiento'] : ''; ?>"
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                </div>
                                
                                <div class="col-span-2">
                                    <label for="direccion" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Dirección</label>
                                    <input type="text" id="direccion" name="direccion" value="<?php echo htmlspecialchars($user['direccion'] ?? ''); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                </div>
                                
                                <div class="col-span-2 md:col-span-1">
                                    <label for="ciudad" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Ciudad</label>
                                    <input type="text" id="ciudad" name="ciudad" value="<?php echo htmlspecialchars($user['ciudad'] ?? ''); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                </div>
                                
                                <div class="col-span-2 md:col-span-1">
                                    <label for="pais" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">País</label>
                                    <select id="pais" name="pais" class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                        <option value="Uruguay" <?php echo (isset($user['pais']) && $user['pais'] === 'Uruguay') ? 'selected' : ''; ?>>Uruguay</option>
                                        <option value="Argentina" <?php echo (isset($user['pais']) && $user['pais'] === 'Argentina') ? 'selected' : ''; ?>>Argentina</option>
                                        <option value="Brasil" <?php echo (isset($user['pais']) && $user['pais'] === 'Brasil') ? 'selected' : ''; ?>>Brasil</option>
                                        <option value="Paraguay" <?php echo (isset($user['pais']) && $user['pais'] === 'Paraguay') ? 'selected' : ''; ?>>Paraguay</option>
                                        <option value="Chile" <?php echo (isset($user['pais']) && $user['pais'] === 'Chile') ? 'selected' : ''; ?>>Chile</option>
                                        <option value="Otro" <?php echo (isset($user['pais']) && $user['pais'] === 'Otro') ? 'selected' : ''; ?>>Otro</option>
                                    </select>
                                </div>
                                
                                <div class="col-span-2 md:col-span-1">
                                    <label for="codigo_postal" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Código Postal</label>
                                    <input type="text" id="codigo_postal" name="codigo_postal" value="<?php echo htmlspecialchars($user['codigo_postal'] ?? ''); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                </div>
                                
                                <div class="col-span-2 md:col-span-1">
                                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Género</label>
                                    <div class="mt-1">
                                        <div class="flex items-center space-x-4">
                                            <div class="flex items-center">
                                                <input id="genero_masculino" name="genero" type="radio" value="masculino" 
                                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:bg-gray-700 dark:border-gray-600" 
                                                       <?php echo (isset($user['genero']) && $user['genero'] === 'masculino') ? 'checked' : ''; ?>>
                                                <label for="genero_masculino" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">Masculino</label>
                                            </div>
                                            <div class="flex items-center">
                                                <input id="genero_femenino" name="genero" type="radio" value="femenino" 
                                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:bg-gray-700 dark:border-gray-600" 
                                                       <?php echo (isset($user['genero']) && $user['genero'] === 'femenino') ? 'checked' : ''; ?>>
                                                <label for="genero_femenino" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">Femenino</label>
                                            </div>
                                            <div class="flex items-center">
                                                <input id="genero_otro" name="genero" type="radio" value="otro" 
                                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:bg-gray-700 dark:border-gray-600" 
                                                       <?php echo (isset($user['genero']) && $user['genero'] === 'otro') ? 'checked' : ''; ?>>
                                                <label for="genero_otro" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">Otro</label>
                                            </div>
                                            <div class="flex items-center">
                                                <input id="genero_no_decir" name="genero" type="radio" value="prefiero_no_decir" 
                                                       class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:bg-gray-700 dark:border-gray-600" 
                                                       <?php echo (isset($user['genero']) && $user['genero'] === 'prefiero_no_decir') ? 'checked' : ''; ?>>
                                                <label for="genero_no_decir" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">Prefiero no decirlo</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-span-2">
                                    <label for="biografia" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Biografía</label>
                                    <textarea id="biografia" name="biografia" rows="3" 
                                              class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"><?php echo htmlspecialchars($user['biografia'] ?? ''); ?></textarea>
                                </div>
                                
                                <div class="col-span-2">
                                    <label for="sitio_web" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Sitio Web</label>
                                    <input type="url" id="sitio_web" name="sitio_web" value="<?php echo htmlspecialchars($user['sitio_web'] ?? ''); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white" 
                                           placeholder="https://">
                                </div>
                            </div>
                            
                            <div class="mt-6 flex justify-end">
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Guardar Cambios
                                </button>
                            </div>
                        </form>
                    </section>
                    
                    <!-- Sección de Seguridad -->
                    <section id="seguridad" class="border-t border-gray-200 dark:border-gray-700 pt-8">
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Seguridad</h2>
                        </div>
                        
                        <form method="POST" action="">
                            <div class="space-y-4">
                                <div>
                                    <label for="current_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Contraseña Actual *</label>
                                    <input type="password" id="current_password" name="current_password" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white" required>
                                </div>
                                
                                <div>
                                    <label for="new_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Nueva Contraseña *</label>
                                    <input type="password" id="new_password" name="new_password" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white" required>
                                    <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">La contraseña debe tener al menos 8 caracteres</p>
                                </div>
                                
                                <div>
                                    <label for="confirm_password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Confirmar Nueva Contraseña *</label>
                                    <input type="password" id="confirm_password" name="confirm_password" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white" required>
                                </div>
                            </div>
                            
                            <div class="mt-6">
                                <button type="submit" name="cambiar_password" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Cambiar Contraseña
                                </button>
                            </div>
                        </form>
                    </section>
                    
                    <!-- Sección de Preferencias -->
                    <section id="preferencias" class="border-t border-gray-200 dark:border-gray-700 pt-8 mt-8">
                        <div class="flex justify-between items-center mb-6">
                            <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Preferencias</h2>
                        </div>
                        
                        <form method="POST" action="">
                            <div class="space-y-4">
                                <div class="flex items-center">
                                    <input type="checkbox" id="notificaciones" name="notificaciones" 
                                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded dark:bg-gray-700 dark:border-gray-600" 
                                           <?php echo (isset($user['notificaciones']) && $user['notificaciones']) ? 'checked' : ''; ?>>
                                    <label for="notificaciones" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                                        Recibir notificaciones por correo electrónico
                                    </label>
                                </div>
                                
                                <div class="flex items-center">
                                    <input type="checkbox" id="suscripcion_newsletter" name="suscripcion_newsletter" 
                                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded dark:bg-gray-700 dark:border-gray-600" 
                                           <?php echo (isset($user['suscripcion_newsletter']) && $user['suscripcion_newsletter']) ? 'checked' : ''; ?>>
                                    <label for="suscripcion_newsletter" class="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                                        Suscribirse al boletín de noticias
                                    </label>
                                </div>
                                
                                <div class="mt-4">
                                    <label for="tema" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Tema de la Aplicación</label>
                                    <select id="tema" name="tema" class="w-full md:w-1/3 px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                        <option value="sistema" <?php echo (isset($user['tema']) && $user['tema'] === 'sistema') ? 'selected' : ''; ?>>Sistema (predeterminado)</option>
                                        <option value="claro" <?php echo (isset($user['tema']) && $user['tema'] === 'claro') ? 'selected' : ''; ?>>Claro</option>
                                        <option value="oscuro" <?php echo (isset($user['tema']) && $user['tema'] === 'oscuro') ? 'selected' : ''; ?>>Oscuro</option>
                                    </select>
                                </div>
                                
                                <div class="mt-4">
                                    <label for="idioma" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Idioma</label>
                                    <select id="idioma" name="idioma" class="w-full md:w-1/3 px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                                        <option value="es" <?php echo (isset($user['idioma']) && $user['idioma'] === 'es') ? 'selected' : ''; ?>>Español</option>
                                        <option value="pt" <?php echo (isset($user['idioma']) && $user['idioma'] === 'pt') ? 'selected' : ''; ?>>Portugués</option>
                                        <option value="en" <?php echo (isset($user['idioma']) && $user['idioma'] === 'en') ? 'selected' : ''; ?>>Inglés</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mt-6">
                                <button type="submit" name="guardar_preferencias" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Guardar Preferencias
                                </button>
                            </div>
                        </form>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
