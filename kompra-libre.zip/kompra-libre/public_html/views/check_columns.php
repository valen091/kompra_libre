<?php
$dbConfig = [
    'host' => 'localhost',
    'dbname' => 'u472738607_kompra_libre',
    'username' => 'u472738607_kompralibre',
    'password' => 'Kompralibre1'
];

try {
    $pdo = new PDO(
        "mysql:host={$dbConfig['host']};dbname={$dbConfig['dbname']};charset=utf8",
        $dbConfig['username'],
        $dbConfig['password'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    // Get column names
    $stmt = $pdo->query("SHOW COLUMNS FROM usuarios");
    $columns = $stmt->fetchAll();
    
    echo "<h2>Columns in 'usuarios' table:</h2>";
    echo "<ul>";
    foreach ($columns as $column) {
        echo "<li>" . htmlspecialchars($column['Field']) . " (" . htmlspecialchars($column['Type']) . ")</li>";
    }
    echo "</ul>";

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>