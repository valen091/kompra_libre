<!-- Sidebar -->
<aside class="bg-gray-800 text-white w-64 min-h-screen p-4">
    <div class="flex items-center justify-between mb-8">
        <h1 class="text-xl font-bold">Panel Vendedor</h1>
    </div>
    
    <nav class="space-y-2">
        <a href="/panel-vendedor/" 
           class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-md transition-colors <?= $_SERVER['REQUEST_URI'] === '/panel-vendedor/' ? 'bg-gray-700' : '' ?>">
            <i class="fas fa-tachometer-alt mr-3"></i>
            Dashboard
        </a>
        
        <a href="/panel-vendedor/productos" 
           class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-md transition-colors">
            <i class="fas fa-boxes mr-3"></i>
            Productos
        </a>
        
        <a href="/panel-vendedor/ventas" 
           class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-md transition-colors">
            <i class="fas fa-shopping-cart mr-3"></i>
            Ventas
        </a>
        
        <a href="/panel-vendedor/clientes" 
           class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-md transition-colors">
            <i class="fas fa-users mr-3"></i>
            Clientes
        </a>
        
        <a href="/panel-vendedor/ajustes" 
           class="flex items-center px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-md transition-colors">
            <i class="fas fa-cog mr-3"></i>
            Ajustes
        </a>
        
        <div class="border-t border-gray-700 my-4"></div>
        
        <a href="/auth/logout.php" 
           class="flex items-center px-4 py-2 text-red-400 hover:bg-gray-700 rounded-md transition-colors">
            <i class="fas fa-sign-out-alt mr-3"></i>
            Cerrar Sesión
        </a>
    </nav>
    
    <div class="absolute bottom-0 left-0 right-0 p-4 text-center text-gray-500 text-sm">
        <p>Kompra Libre v1.0</p>
    </div>
</aside>
