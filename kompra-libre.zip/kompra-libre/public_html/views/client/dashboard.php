<?php include __DIR__ . '/../layouts/header.php'; ?>

<div class="bg-gray-50 min-h-screen">
    <!-- Header with User Info -->
    <div class="bg-white shadow">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center">
                <div class="flex items-center">
                    <div class="h-16 w-16 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-2xl font-bold">
                        <?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?>
                    </div>
                    <div class="ml-4">
                        <h1 class="text-2xl font-bold text-gray-900">Hola, <?= htmlspecialchars(explode(' ', $user['name'] ?? 'Usuario')[0]) ?>!</h1>
                        <p class="text-gray-600">Bienvenido a tu panel de cliente</p>
                    </div>
                </div>
                <div class="mt-4 md:mt-0
                flex space-x-3">
                    <button onclick="openModal('editProfileModal')" class="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <i class="fas fa-user-edit mr-2"></i> Editar Perfil
                    </button>
                    <a href="/client/orders" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <i class="fas fa-shopping-bag mr-2"></i> Mis Compras
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Left Sidebar -->
            <div class="lg:col-span-1">
                <div class="bg-white shadow rounded-lg overflow-hidden">
                    <div class="p-6">
                        <div class="text-center">
                            <div class="mx-auto h-24 w-24 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-3xl font-bold mb-4">
                                <?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?>
                            </div>
                            <h3 class="text-lg font-medium text-gray-900"><?= htmlspecialchars($user['name'] ?? 'Usuario') ?></h3>
                            <p class="text-sm text-gray-500"><?= htmlspecialchars($user['email'] ?? '') ?></p>
                            <p class="mt-1 text-sm text-gray-500">Miembro desde <?= date('M Y', strtotime($user['created_at'] ?? 'now')) ?></p>
                            
                            <div class="mt-6 flex justify-center space-x-4">
                                <button type="button" class="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <i class="fas fa-envelope mr-1"></i> Mensajes
                                </button>
                                <button type="button" class="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    <i class="fas fa-cog mr-1"></i> Configuración
                                </button>
                            </div>
                        </div>
                        
                        <div class="mt-6 pt-6 border-t border-gray-200">
                            <h4 class="text-xs font-medium text-gray-500 uppercase tracking-wider">Información de Contacto</h4>
                            <dl class="mt-2 space-y-2">
                                <div class="flex items-start">
                                    <dt class="w-1/3 text-sm font-medium text-gray-500">Email:</dt>
                                    <dd class="text-sm text-gray-900"><?= htmlspecialchars($user['email'] ?? 'No especificado') ?></dd>
                                </div>
                                <div class="flex items-start">
                                    <dt class="w-1/3 text-sm font-medium text-gray-500">Teléfono:</dt>
                                    <dd class="text-sm text-gray-900"><?= $user['phone'] ?? 'No especificado' ?></dd>
                                </div>
                                <div class="flex items-start">
                                    <dt class="w-1/3 text-sm font-medium text-gray-500">Dirección:</dt>
                                    <dd class="text-sm text-gray-900">
                                        <?= $user['address'] ?? 'No especificada' ?><br>
                                        <?= $user['city'] ?? '' ?> <?= $user['postal_code'] ?? '' ?>
                                    </dd>
                                </div>
                            </dl>
                            <button type="button" class="mt-3 text-sm font-medium text-blue-600 hover:text-blue-500">
                                Actualizar información de contacto
                            </button>
                        </div>
                        
                        <div class="mt-6 pt-6 border-t border-gray-200">
                            <h4 class="text-xs font-medium text-gray-500 uppercase tracking-wider">Preferencias</h4>
                            <div class="mt-2 space-y-2">
                                <div class="flex items-center">
                                    <input id="newsletter" name="newsletter" type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" checked>
                                    <label for="newsletter" class="ml-2 block text-sm text-gray-700">
                                        Recibir ofertas por email
                                    </label>
                                </div>
                                <div class="flex items-center">
                                    <input id="sms_notifications" name="sms_notifications" type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                    <label for="sms_notifications" class="ml-2 block text-sm text-gray-700">
                                        Recibir notificaciones por SMS
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div class="mt-6 bg-white shadow rounded-lg overflow-hidden">
                    <div class="p-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Acceso Rápido</h3>
                        <nav class="space-y-2">
                            <a href="/client/orders" class="group flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900">
                                <i class="fas fa-shopping-bag text-gray-400 group-hover:text-gray-500 mr-3"></i>
                                Mis Pedidos
                            </a>
                            <a href="/client/wishlist" class="group flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900">
                                <i class="fas fa-heart text-gray-400 group-hover:text-gray-500 mr-3"></i>
                                Lista de Deseos
                                <span class="ml-auto inline-block py-0.5 px-2.5 text-xs font-medium bg-gray-100 text-gray-600 rounded-full">12</span>
                            </a>
                            <a href="/client/addresses" class="group flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900">
                                <i class="fas fa-map-marker-alt text-gray-400 group-hover:text-gray-500 mr-3"></i>
                                Direcciones
                            </a>
                            <a href="/client/payment-methods" class="group flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900">
                                <i class="far fa-credit-card text-gray-400 group-hover:text-gray-500 mr-3"></i>
                                Métodos de Pago
                            </a>
                            <a href="/client/reviews" class="group flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900">
                                <i class="far fa-star text-gray-400 group-hover:text-gray-500 mr-3"></i>
                                Mis Reseñas
                            </a>
                            <a href="/client/returns" class="group flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900">
                                <i class="fas fa-undo-alt text-gray-400 group-hover:text-gray-500 mr-3"></i>
                                Devoluciones
                            </a>
                        </nav>
                    </div>
                </div>
            </div>
            
            <!-- Right Content -->
            <div class="lg:col-span-2 space-y-6">
                <!-- Order Status -->
                <div class="bg-white shadow rounded-lg overflow-hidden">
                    <div class="px-6 py-5 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900">Estado de tus pedidos</h3>
                    </div>
                    <div class="px-6 py-5">
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                            <div class="p-4 border rounded-lg">
                                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 text-blue-600 mb-2">
                                    <i class="fas fa-shopping-bag"></i>
                                </div>
                                <p class="text-sm font-medium text-gray-500">Pendientes</p>
                                <p class="text-2xl font-semibold text-gray-900">2</p>
                            </div>
                            <div class="p-4 border rounded-lg">
                                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-yellow-100 text-yellow-600 mb-2">
                                    <i class="fas fa-truck"></i>
                                </div>
                                <p class="text-sm font-medium text-gray-500">En Camino</p>
                                <p class="text-2xl font-semibold text-gray-900">1</p>
                            </div>
                            <div class="p-4 border rounded-lg">
                                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 text-green-600 mb-2">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                                <p class="text-sm font-medium text-gray-500">Entregados</p>
                                <p class="text-2xl font-semibold text-gray-900">7</p>
                            </div>
                            <div class="p-4 border rounded-lg">
                                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 text-red-600 mb-2">
                                    <i class="fas fa-times-circle"></i>
                                </div>
                                <p class="text-sm font-medium text-gray-500">Cancelados</p>
                                <p class="text-2xl font-semibold text-gray-900">0</p>
                            </div>
                        </div>
                        <div class="mt-6 text-center">
                            <a href="/client/orders" class="text-sm font-medium text-blue-600 hover:text-blue-500">Ver todos los pedidos <span aria-hidden="true">&rarr;</span></a>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Orders -->
                <div class="bg-white shadow rounded-lg overflow-hidden">
                    <div class="px-6 py-5 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900">Pedidos Recientes</h3>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pedido #</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Productos</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                    <th scope="col" class="relative px-6 py-3">
                                        <span class="sr-only">Acciones</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php 
                                $orders = [
                                    ['id' => 1001, 'date' => '15 Oct 2023', 'products' => 2, 'total' => 149.99, 'status' => 'En camino', 'status_class' => 'bg-yellow-100 text-yellow-800'],
                                    ['id' => 1000, 'date' => '10 Oct 2023', 'products' => 1, 'total' => 89.99, 'status' => 'Entregado', 'status_class' => 'bg-green-100 text-green-800'],
                                    ['id' => 999, 'date' => '5 Oct 2023', 'products' => 3, 'total' => 210.50, 'status' => 'Entregado', 'status_class' => 'bg-green-100 text-green-800'],
                                ];
                                foreach($orders as $order): 
                                ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#<?= $order['id'] ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= $order['date'] ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= $order['products'] ?> producto<?= $order['products'] > 1 ? 's' : '' ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$<?= number_format($order['total'], 2) ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= $order['status_class'] ?>">
                                            <?= $order['status'] ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <a href="/client/orders/<?= $order['id'] ?>" class="text-blue-600 hover:text-blue-900 mr-3">Ver</a>
                                        <?php if($order['status'] === 'Entregado'): ?>
                                        <a href="#" class="text-green-600 hover:text-green-900">Devolver</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Recently Viewed -->
                <div class="bg-white shadow rounded-lg overflow-hidden">
                    <div class="px-6 py-5 border-b border-gray-200">
                        <h3 class="text-lg font-medium text-gray-900">Vistos Recientemente</h3>
                    </div>
                    <div class="p-6">
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <?php 
                            $products = [
                                ['name' => 'Zapatos Deportivos', 'price' => 79.99, 'image' => 'https://via.placeholder.com/150'],
                                ['name' => 'Camiseta Básica', 'price' => 19.99, 'image' => 'https://via.placeholder.com/150'],
                                ['name' => 'Reloj Inteligente', 'price' => 199.99, 'image' => 'https://via.placeholder.com/150'],
                                ['name' => 'Audífonos Inalámbricos', 'price' => 129.99, 'image' => 'https://via.placeholder.com/150'],
                            ];
                            foreach($products as $product): 
                            ?>
                            <div class="group relative">
                                <div class="w-full aspect-w-1 aspect-h-1 bg-gray-200 rounded-md overflow-hidden group-hover:opacity-75">
                                    <img src="<?= $product['image'] ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-full object-center object-cover">
                                </div>
                                <h4 class="mt-2 text-sm font-medium text-gray-900">
                                    <a href="/products/<?= strtolower(str_replace(' ', '-', $product['name'])) ?>">
                                        <span aria-hidden="true" class="absolute inset-0"></span>
                                        <?= $product['name'] ?>
                                    </a>
                                </h4>
                                <p class="mt-1 text-sm text-gray-700">$<?= number_format($product['price'], 2) ?></p>
                                <div class="mt-2 flex items-center">
                                    <div class="flex items-center">
                                        <?php for($i = 0; $i < 5; $i++): ?>
                                            <i class="fas fa-star text-yellow-400"></i>
                                        <?php endfor; ?>
                                        <span class="ml-1 text-xs text-gray-500">(24)</span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Loyalty Program -->
                <div class="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg shadow-lg overflow-hidden">
                    <div class="p-6 text-white">
                        <div class="flex flex-col md:flex-row justify-between items-start md:items-center">
                            <div class="mb-4 md:mb-0">
                                <h3 class="text-lg font-medium">Programa de Fidelidad</h3>
                                <p class="mt-1 text-purple-100">¡Gana puntos con cada compra y canjéalos por descuentos!</p>
                            </div>
                            <div class="bg-white bg-opacity-20 backdrop-filter backdrop-blur-lg rounded-lg p-4 text-center">
                                <p class="text-sm font-medium">Tus Puntos</p>
                                <p class="text-2xl font-bold">1,250</p>
                                <p class="text-xs mt-1">Equivalen a $12.50 de descuento</p>
                            </div>
                        </div>
                        <div class="mt-6">
                            <div class="w-full bg-white bg-opacity-20 rounded-full h-2.5">
                                <div class="bg-yellow-400 h-2.5 rounded-full" style="width: 25%"></div>
                            </div>
                            <div class="flex justify-between mt-2 text-xs text-purple-100">
                                <span>Nivel Plata</span>
                                <span>250 puntos hasta Oro</span>
                            </div>
                        </div>
                        <div class="mt-6">
                            <a href="/client/loyalty" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-purple-700 bg-white hover:bg-purple-50">
                                Ver detalles del programa
                                <i class="fas fa-arrow-right ml-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Edit Profile Modal -->
<div id="editProfileModal" class="hidden fixed inset-0 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
    <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" onclick="closeModal('editProfileModal')"></div>
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div class="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
            <div class="absolute top-0 right-0 pt-4 pr-4">
                <button type="button" class="bg-white rounded-md text-gray-400 hover:text-gray-500 focus:outline-none" onclick="closeModal('editProfileModal')">
                    <span class="sr-only">Cerrar</span>
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div>
                <div class="mt-3 text-center sm:mt-0 sm:text-left">
                    <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                        Editar Perfil
                    </h3>
                    <div class="mt-2">
                        <form class="space-y-6">
                            <div class="mt-1">
                                <label for="name" class="block text-sm font-medium text-gray-700">Nombre Completo</label>
                                <input type="text" name="name" id="name" value="<?= htmlspecialchars($user['name'] ?? '') ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                            </div>
                            <div class="mt-1">
                                <label for="email" class="block text-sm font-medium text-gray-700">Correo Electrónico</label>
                                <input type="email" name="email" id="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                            </div>
                            <div class="mt-1">
                                <label for="phone" class="block text-sm font-medium text-gray-700">Teléfono</label>
                                <input type="tel" name="phone" id="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                            </div>
                            <div class="mt-1">
                                <label for="birthdate" class="block text-sm font-medium text-gray-700">Fecha de Nacimiento</label>
                                <input type="date" name="birthdate" id="birthdate" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                            </div>
                            <div class="mt-1">
                                <label for="gender" class="block text-sm font-medium text-gray-700">Género</label>
                                <select id="gender" name="gender" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                                    <option value="">Seleccionar...</option>
                                    <option value="male">Masculino</option>
                                    <option value="female">Femenino</option>
                                    <option value="other">Otro</option>
                                    <option value="prefer_not_to_say">Prefiero no decirlo</option>
                                </select>
                            </div>
                            <div class="mt-5 sm:mt-6 sm:grid sm:grid-cols-2 sm:gap-3 sm:grid-flow-row-dense">
                                <button type="submit" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:col-start-2 sm:text-sm">
                                    Guardar Cambios
                                </button>
                                <button type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:col-start-1 sm:text-sm" onclick="closeModal('editProfileModal')">
                                    Cancelar
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>

<script>
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('bg-gray-500')) {
        event.target.classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
}
</script>
