<?php include __DIR__ . '/../layouts/header.php'; ?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include __DIR__ . '/../components/admin/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-hidden">
        <!-- Top Navigation -->
        <?php include __DIR__ . '/../components/admin/header.php'; ?>
        
        <!-- Main Content -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                            <i class="fas fa-users text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-gray-500 text-sm font-medium">Total Usuarios</h3>
                            <p class="text-2xl font-semibold text-gray-700">1,254</p>
                            <p class="text-sm text-green-500">+12% desde ayer</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-green-100 text-green-600">
                            <i class="fas fa-shopping-cart text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-gray-500 text-sm font-medium">Órdenes Hoy</h3>
                            <p class="text-2xl font-semibold text-gray-700">245</p>
                            <p class="text-sm text-green-500">+5% desde ayer</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                            <i class="fas fa-store text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-gray-500 text-sm font-medium">Vendedores Activos</h3>
                            <p class="text-2xl font-semibold text-gray-700">187</p>
                            <p class="text-sm text-green-500">+3% desde ayer</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow p-6">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                            <i class="fas fa-dollar-sign text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <h3 class="text-gray-500 text-sm font-medium">Ingresos Hoy</h3>
                            <p class="text-2xl font-semibold text-gray-700">$12,540</p>
                            <p class="text-sm text-green-500">+8% desde ayer</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity & Quick Actions -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                <!-- Recent Activity -->
                <div class="lg:col-span-2 bg-white rounded-lg shadow p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-lg font-semibold text-gray-800">Actividad Reciente</h2>
                        <button class="text-blue-600 hover:text-blue-800 text-sm font-medium">Ver todo</button>
                    </div>
                    <div class="space-y-4">
                        <?php for($i = 0; $i < 5; $i++): ?>
                        <div class="flex items-start pb-4 border-b border-gray-100">
                            <div class="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                <i class="fas fa-user text-blue-600"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-gray-900">Nuevo usuario registrado</p>
                                <p class="text-sm text-gray-500">Juan Pérez se ha registrado como vendedor</p>
                                <p class="text-xs text-gray-400">Hace 10 minutos</p>
                            </div>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-lg font-semibold text-gray-800 mb-4">Acciones Rápidas</h2>
                    <div class="space-y-3">
                        <button onclick="openModal('newProductModal')" class="w-full flex items-center justify-between px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                            <span>Nuevo Producto</span>
                            <i class="fas fa-plus"></i>
                        </button>
                        <button onclick="openModal('newUserModal')" class="w-full flex items-center justify-between px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                            <span>Nuevo Usuario</span>
                            <i class="fas fa-user-plus"></i>
                        </button>
                        <button onclick="openModal('promotionModal')" class="w-full flex items-center justify-between px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                            <span>Crear Promoción</span>
                            <i class="fas fa-tag"></i>
                        </button>
                        <button onclick="openModal('reportModal')" class="w-full flex items-center justify-between px-4 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors">
                            <span>Generar Reporte</span>
                            <i class="fas fa-file-export"></i>
                        </button>
                        <button onclick="openModal('settingsModal')" class="w-full flex items-center justify-between px-4 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                            <span>Configuración</span>
                            <i class="fas fa-cog"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Recent Orders -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200">
                    <div class="flex justify-between items-center">
                        <h2 class="text-lg font-semibold text-gray-800">Órdenes Recientes</h2>
                        <a href="/admin/orders" class="text-sm text-blue-600 hover:text-blue-800 font-medium">Ver todas</a>
                    </div>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"># Orden</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendedor</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php for($i = 0; $i < 5; $i++): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#<?= 1000 + $i ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Cliente <?= $i + 1 ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Vendedor <?= $i + 1 ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$<?= number_format(rand(100, 1000), 2) ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                        Completado
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <a href="#" class="text-blue-600 hover:text-blue-900 mr-3">Ver</a>
                                    <a href="#" class="text-green-600 hover:text-green-900">Imprimir</a>
                                </td>
                            </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Modals -->
<?php include __DIR__ . '/../components/modals/new_product.php'; ?>
<?php include __DIR__ . '/../components/modals/new_user.php'; ?>

<?php include __DIR__ . '/../layouts/footer.php'; ?>

<script>
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
}

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.classList.contains('modal-overlay')) {
        event.target.classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
}
</script>
