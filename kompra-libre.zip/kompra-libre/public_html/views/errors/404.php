<?php
// Set the response code to 404
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página no encontrada - Kompra Libre</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex flex-col items-center justify-center p-4">
        <div class="bg-white p-8 rounded-lg shadow-lg max-w-md w-full text-center">
            <div class="text-6xl text-red-500 mb-6">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-800 mb-4">404 - Página no encontrada</h1>
            <p class="text-gray-600 mb-6">Lo sentimos, la página que estás buscando no existe o ha sido movida.</p>
            <a href="/" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-lg transition-colors">
                <i class="fas fa-home mr-2"></i> Volver al inicio
            </a>
        </div>
    </div>
</body>
</html>
