<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include authentication middleware
$user = require __DIR__ . '/../../middleware/seller_auth.php';

// Include header
include __DIR__ . '/../layouts/header.php'; 
?>

<div class="flex h-screen bg-gray-100">
    <!-- Sidebar -->
    <?php include __DIR__ . '/../components/seller/sidebar.php'; ?>
    
    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-hidden">
        <!-- Top Navigation -->
        <header class="bg-white shadow">
            <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
                    <div class="flex items-center space-x-4">
                        <span class="text-gray-600"><?= htmlspecialchars($user['name'] ?? 'Vendedor') ?></span>
                        <div class="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center">
                            <i class="fas fa-user text-gray-600"></i>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Main content -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Stats Cards -->
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                            <i class="fas fa-boxes text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Productos</p>
                            <p class="text-2xl font-semibold text-gray-900">0</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-green-100 text-green-600">
                            <i class="fas fa-shopping-cart text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Ventas Hoy</p>
                            <p class="text-2xl font-semibold text-gray-900">0</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                            <i class="fas fa-dollar-sign text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-500">Ingresos Hoy</p>
                            <p class="text-2xl font-semibold text-gray-900">$0.00</p>
                        </div>
                    </div>
                </div>
                            <p class="text-sm text-gray-500 mt-1">Basado en 128 reseñas</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions & Recent Orders -->
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
                <!-- Quick Actions -->
                <div class="lg:col-span-1">
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4">Acciones Rápidas</h2>
                        <div class="space-y-3">
                            <button onclick="openModal('addProductModal')" class="w-full flex items-center justify-between px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                <span>Agregar Producto</span>
                                <i class="fas fa-plus"></i>
                            </button>
                            <button onclick="openModal('inventoryModal')" class="w-full flex items-center justify-between px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                                <span>Gestionar Inventario</span>
                                <i class="fas fa-boxes"></i>
                            </button>
                            <button onclick="openModal('discountModal')" class="w-full flex items-center justify-between px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                                <span>Crear Descuento</span>
                                <i class="fas fa-tag"></i>
                            </button>
                            <button onclick="openModal('reportModal')" class="w-full flex items-center justify-between px-4 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors">
                                <span>Generar Reporte</span>
                                <i class="fas fa-chart-bar"></i>
                            </button>
                        </div>
                        
                        <div class="mt-6">
                            <h3 class="text-md font-medium text-gray-700 mb-2">Objetivos del Mes</h3>
                            <div class="space-y-2">
                                <div>
                                    <div class="flex justify-between text-sm mb-1">
                                        <span>Ventas</span>
                                        <span>75%</span>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-full h-2">
                                        <div class="bg-blue-600 h-2 rounded-full" style="width: 75%"></div>
                                    </div>
                                </div>
                                <div>
                                    <div class="flex justify-between text-sm mb-1">
                                        <span>Ingresos</span>
                                        <span>60%</span>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-full h-2">
                                        <div class="bg-green-600 h-2 rounded-full" style="width: 60%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Orders -->
                <div class="lg:col-span-2">
                    <div class="bg-white rounded-lg shadow overflow-hidden">
                        <div class="px-6 py-4 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h2 class="text-lg font-semibold text-gray-800">Órdenes Recientes</h2>
                                <a href="/seller/orders" class="text-sm text-blue-600 hover:text-blue-800 font-medium">Ver todas</a>
                            </div>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"># Orden</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Productos</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php for($i = 0; $i < 5; $i++): 
                                        $statuses = ['Completado', 'En Proceso', 'Pendiente', 'Cancelado'];
                                        $status = $statuses[array_rand($statuses)];
                                        $statusClass = [
                                            'Completado' => 'bg-green-100 text-green-800',
                                            'En Proceso' => 'bg-blue-100 text-blue-800',
                                            'Pendiente' => 'bg-yellow-100 text-yellow-800',
                                            'Cancelado' => 'bg-red-100 text-red-800'
                                        ][$status];
                                    ?>
                                    <tr class="hover:bg-gray-50 cursor-pointer" onclick="window.location.href='/seller/orders/<?= 1000 + $i ?>'">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#<?= 1000 + $i ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Cliente <?= $i + 1 ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= rand(1, 5) ?> productos</td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$<?= number_format(rand(50, 500), 2) ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= $statusClass ?>">
                                                <?= $status ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Low Stock Products -->
                    <div class="bg-white rounded-lg shadow overflow-hidden mt-6">
                        <div class="px-6 py-4 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h2 class="text-lg font-semibold text-gray-800">Productos Bajos en Stock</h2>
                                <a href="/seller/inventory" class="text-sm text-blue-600 hover:text-blue-800 font-medium">Ver inventario</a>
                            </div>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Producto</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoría</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acción</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php 
                                    $products = [
                                        ['name' => 'Zapatos Deportivos X1', 'category' => 'Calzado', 'stock' => 2],
                                        ['name' => 'Camiseta Manga Larga', 'category' => 'Ropa', 'stock' => 3],
                                        ['name' => 'Bolso de Cuero', 'category' => 'Accesorios', 'stock' => 1],
                                        ['name' => 'Reloj Inteligente', 'category' => 'Electrónicos', 'stock' => 0],
                                    ];
                                    foreach($products as $product): 
                                    ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="flex items-center">
                                                <div class="flex-shrink-0 h-10 w-10 bg-gray-200 rounded-md flex items-center justify-center">
                                                    <i class="fas fa-box text-gray-500"></i>
                                                </div>
                                                <div class="ml-4">
                                                    <div class="text-sm font-medium text-gray-900"><?= $product['name'] ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?= $product['category'] ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= $product['stock'] == 0 ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800' ?>">
                                                <?= $product['stock'] == 0 ? 'Agotado' : $product['stock'] . ' restantes' ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                            <button onclick="openModal('restockModal')" class="text-blue-600 hover:text-blue-900">Reabastecer</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Modals -->
<?php include __DIR__ . '/../components/modals/quick_sale.php'; ?>
<?php include __DIR__ . '/../components/modals/add_product.php'; ?>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
