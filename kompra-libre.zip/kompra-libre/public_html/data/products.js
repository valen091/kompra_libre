// Productos de prueba para Kompra Libre Uruguay
// Precios en pesos uruguayos (UYU) con IVA incluido

const products = {
    // Categoría: Electrónica
    'electronica': [
        {
            id: 'elec-001',
            name: 'Smartphone Samsung Galaxy S22',
            description: 'Pantalla 6.1" Dynamic AMOLED, 128GB, 8GB RAM, Cámara Triple 50MP+12MP+10MP',
            price: 45990,
            image: 'https://via.placeholder.com/300x300?text=Galaxy+S22',
            category: 'electronica',
            stock: 15,
            rating: 4.8,
            specs: {
                marca: 'Samsung',
                modelo: 'Galaxy S22',
                almacenamiento: '128GB',
                ram: '8GB',
                pantalla: '6.1" Dynamic AMOLED',
                bateria: '3700 mAh',
                sistema: 'Android 12'
            }
        },
        {
            id: 'elec-002',
            name: 'Notebook HP 15-dw3010la',
            description: '15.6" Full HD, Intel Core i5, 8GB RAM, 512GB SSD, Windows 11',
            price: 52990,
            image: 'https://via.placeholder.com/300x300?text=HP+15-dw3010la',
            category: 'electronica',
            stock: 8,
            rating: 4.6,
            specs: {
                marca: 'HP',
                modelo: '15-dw3010la',
                procesador: 'Intel Core i5-1135G7',
                ram: '8GB',
                almacenamiento: '512GB SSD',
                pantalla: '15.6" Full HD',
                sistema: 'Windows 11'
            }
        },
        {
            id: 'elec-003',
            name: 'Smart TV LG 50" 4K UHD',
            description: '50 pulgadas, 4K UHD, Smart TV con webOS, HDR10, 3 HDMI, 2 USB',
            price: 42990,
            image: 'https://via.placeholder.com/300x300?text=LG+50+4K',
            category: 'electronica',
            stock: 12,
            rating: 4.7,
            specs: {
                marca: 'LG',
                pulgadas: '50"',
                resolucion: '4K UHD',
                sistema: 'webOS',
                hdmi: 3,
                usb: 2,
                wifi: 'Sí',
                smart: 'Sí'
            }
        },
        {
            id: 'elec-004',
            name: 'Tablet Samsung Galaxy Tab A8',
            description: '10.5", 64GB, 4GB RAM, WiFi, Plata, Cámara 8MP',
            price: 22990,
            image: 'https://via.placeholder.com/300x300?text=Galaxy+Tab+A8',
            category: 'electronica',
            stock: 20,
            rating: 4.5,
            specs: {
                marca: 'Samsung',
                modelo: 'Galaxy Tab A8',
                pantalla: '10.5"',
                almacenamiento: '64GB',
                ram: '4GB',
                camara: '8MP',
                bateria: '7040 mAh',
                sistema: 'Android 11'
            }
        },
        {
            id: 'elec-005',
            name: 'Auriculares Inalámbricos Sony WH-CH510',
            description: 'Bluetooth, 30hs de batería, control táctil, manos libres',
            price: 4590,
            image: 'https://via.placeholder.com/300x300?text=Sony+WH-CH510',
            category: 'electronica',
            stock: 30,
            rating: 4.4,
            specs: {
                marca: 'Sony',
                modelo: 'WH-CH510',
                conexion: 'Bluetooth',
                bateria: '30 horas',
                control: 'Táctil',
                microfono: 'Sí',
                color: 'Negro'
            }
        },
        {
            id: 'elec-006',
            name: 'Cámara Mirrorless Canon EOS M50 Mark II',
            'description': '24.1MP, 4K, Pantalla Táctil Abatible, WiFi, Bluetooth, Negro',
            price: 68990,
            image: 'https://via.placeholder.com/300x300?text=Canon+M50+Mark+II',
            category: 'electronica',
            stock: 6,
            rating: 4.9,
            specs: {
                marca: 'Canon',
                modelo: 'EOS M50 Mark II',
                resolucion: '24.1 MP',
                video: '4K',
                pantalla: 'Táctil abatible',
                wifi: 'Sí',
                bluetooth: 'Sí',
                tipo: 'Mirrorless'
            }
        },
        {
            id: 'elec-007',
            name: 'Parlante Bluetooth JBL Flip 5',
            description: 'Resistente al agua IPX7, 12 horas de duración, sonido potente',
            price: 8990,
            image: 'https://via.placeholder.com/300x300?text=JBL+Flip+5',
            category: 'electronica',
            stock: 18,
            rating: 4.7,
            specs: {
                marca: 'JBL',
                modelo: 'Flip 5',
                potencia: '20W',
                bateria: '12 horas',
                resistencia: 'IPX7 (resistente al agua)',
                bluetooth: '4.2',
                colores: 'Varios disponibles'
            }
        },
        {
            id: 'elec-008',
            name: 'Smartwatch Xiaomi Mi Band 7',
            description: 'Monitoreo de sueño, oxígeno en sangre, 120 modos deportivos',
            price: 5990,
            image: 'https://via.placeholder.com/300x300?text=Xiaomi+Mi+Band+7',
            category: 'electronica',
            stock: 25,
            rating: 4.6,
            specs: {
                marca: 'Xiaomi',
                modelo: 'Mi Band 7',
                pantalla: 'AMOLED 1.62"',
                bateria: 'Hasta 14 días',
                resistencia: '5 ATM',
                monitoreo: 'Sueño, oxígeno, frecuencia cardíaca',
                deportes: '120 modos',
                compatibilidad: 'Android/iOS'
            }
        },
        {
            id: 'elec-009',
            name: 'Impresora Multifunción HP DeskJet 2776',
            description: 'Imprime, escanea y copia, WiFi, móvil, compatible con Alexa',
            price: 8990,
            image: 'https://via.placeholder.com/300x300?text=HP+DeskJet+2776',
            category: 'electronica',
            stock: 10,
            rating: 4.3,
            specs: {
                marca: 'HP',
                modelo: 'DeskJet 2776',
                funciones: 'Imprimir, escanear, copiar',
                conexion: 'WiFi, USB',
                movil: 'HP Smart App',
                compatibilidad: 'Windows, Mac, Android, iOS',
                alexa: 'Sí',
                tipo: 'Inyección de tinta'
            }
        },
        {
            id: 'elec-010',
            name: 'Router WiFi 6 TP-Link Archer AX10',
            'description': 'Doble Banda, 1.5 Gbps, 4 Antenas, MU-MIMO, Compatible con Alexa',
            price: 7590,
            image: 'https://via.placeholder.com/300x300?text=TP-Link+AX10',
            category: 'electronica',
            stock: 14,
            rating: 4.5,
            specs: {
                marca: 'TP-Link',
                modelo: 'Archer AX10',
                velocidad: 'Hasta 1.5 Gbps',
                bandas: 'Doble banda (2.4GHz y 5GHz)',
                estandar: 'WiFi 6 (802.11ax)',
                puertos: '4 LAN + 1 WAN',
                antenas: '4 externas',
                alexa: 'Sí'
            }
        }
    ],
    
    // Categoría: Ropa
    'ropa': [
        {
            id: 'ropa-001',
            name: 'Camisa Manga Larga Hombre',
            description: 'Camisa de algodón 100%, disponible en varios colores, talles S a XXL',
            price: 1490,
            image: 'https://via.placeholder.com/300x300?text=Camisa+Hombre',
            category: 'ropa',
            stock: 50,
            rating: 4.3,
            specs: {
                genero: 'Hombre',
                tipo: 'Camisa manga larga',
                material: 'Algodón 100%',
                colores: ['Blanco', 'Azul', 'Negro', 'Gris'],
                talles: ['S', 'M', 'L', 'XL', 'XXL'],
                cuidados: 'Lavado a máquina 30°C, no usar secadora'
            }
        },
        {
            id: 'ropa-002',
            name: 'Jeans Skinny Mujer',
            description: 'Jeans ajustados, tiro medio, disponible en varios lavados',
            price: 2290,
            image: 'https://via.placeholder.com/300x300?text=Jeans+Mujer',
            category: 'ropa',
            stock: 35,
            rating: 4.5,
            specs: {
                genero: 'Mujer',
                tipo: 'Jeans skinny',
                material: 'Algodón 98%, Elastano 2%',
                colores: ['Azul oscuro', 'Azul claro', 'Negro'],
                talles: ['XS', 'S', 'M', 'L', 'XL'],
                cuidados: 'Lavar al revés, no usar blanqueador'
            }
        },
        {
            id: 'ropa-003',
            name: 'Buzo con Capucha Unisex',
            description: 'Buzo de algodón con capucha, bolsillo canguro, disponible en varios colores',
            price: 2890,
            image: 'https://via.placeholder.com/300x300?text=Buzo+Capucha',
            category: 'ropa',
            stock: 42,
            rating: 4.6,
            specs: {
                genero: 'Unisex',
                tipo: 'Buzo con capucha',
                material: 'Algodón 80%, Poliéster 20%',
                colores: ['Negro', 'Gris', 'Azul marino', 'Rojo'],
                talles: ['S', 'M', 'L', 'XL'],
                caracteristicas: 'Bolsillo canguro, cordón ajustable'
            }
        },
        {
            id: 'ropa-004',
            name: 'Zapatillas Deportivas Running',
            description: 'Zapatillas ligeras para running, suela de goma con amortiguación',
            price: 4590,
            image: 'https://via.placeholder.com/300x300?text=Zapatillas+Running',
            category: 'ropa',
            stock: 28,
            rating: 4.7,
            specs: {
                tipo: 'Zapatillas running',
                material: 'Malla transpirable, suela de goma',
                colores: ['Negro/Rojo', 'Blanco/Azul', 'Gris/Verde'],
                talles: ['36', '37', '38', '39', '40', '41', '42', '43', '44'],
                caracteristicas: 'Amortiguación, soporte arco plantar, peso ligero'
            }
        },
        {
            id: 'ropa-005',
            name: 'Vestido Floral Verano',
            description: 'Vestido estampado floral, ajuste entallado, perfecto para el verano',
            price: 3290,
            image: 'https://via.placeholder.com/300x300?text=Vestido+Floral',
            category: 'ropa',
            stock: 22,
            rating: 4.4,
            specs: {
                genero: 'Mujer',
                tipo: 'Vestido',
                material: 'Viscosa 100%',
                estampado: 'Floral',
                colores: ['Multicolor', 'Azul/Blanco', 'Rosa/Verde'],
                talles: ['XS', 'S', 'M', 'L'],
                largo: 'Por la rodilla'
            }
        },
        {
            id: 'ropa-006',
            name: 'Campera Impermeable Hombre',
            description: 'Campera cortaviento e impermeable, ideal para días lluviosos',
            price: 5890,
            image: 'https://via.placeholder.com/300x300?text=Campera+Impermeable',
            category: 'ropa',
            stock: 18,
            rating: 4.8,
            specs: {
                genero: 'Hombre',
                tipo: 'Campera',
                material: 'Poliéster 100% con membrana impermeable',
                colores: ['Negro', 'Azul marino', 'Verde militar'],
                talles: ['S', 'M', 'L', 'XL', 'XXL'],
                caracteristicas: 'Impermeable, cortaviento, capucha desmontable'
            }
        },
        {
            id: 'ropa-007',
            name: 'Conjunto Deportivo Mujer',
            description: 'Top deportivo y calza de entrenamiento, conjunto a juego',
            price: 3890,
            image: 'https://via.placeholder.com/300x300?text=Conjunto+Deportivo',
            category: 'ropa',
            stock: 30,
            rating: 4.6,
            specs: {
                genero: 'Mujer',
                tipo: 'Conjunto deportivo',
                material: 'Poliéster 88%, Elastano 12%',
                colores: ['Negro', 'Gris', 'Azul marino', 'Verde menta'],
                talles: ['XS', 'S', 'M', 'L'],
                caracteristicas: 'Transpirable, secado rápido, protección UV'
            }
        },
        {
            id: 'ropa-008',
            name: 'Camisa Formal Hombre',
            description: 'Camisa de vestir 100% algodón, cuello italiano, planchado permanente',
            price: 2490,
            image: 'https://via.placeholder.com/300x300?text=Camisa+Formal',
            category: 'ropa',
            stock: 27,
            rating: 4.5,
            specs: {
                genero: 'Hombre',
                tipo: 'Camisa formal',
                material: 'Algodón 100%',
                colores: ['Blanco', 'Azul claro', 'Celeste', 'Rosa palo'],
                talles: ['S', 'M', 'L', 'XL'],
                caracteristicas: 'Cuello italiano, planchado permanente, doble botón en puños'
            }
        },
        {
            id: 'ropa-009',
            name: 'Falda Plisada Escolar',
            description: 'Falda plisada estilo escolar, cintura elástica, largo hasta la rodilla',
            price: 1890,
            image: 'https://via.placeholder.com/300x300?text=Falda+Escolar',
            category: 'ropa',
            stock: 33,
            rating: 4.2,
            specs: {
                genero: 'Mujer',
                tipo: 'Falda plisada',
                material: 'Poliéster 65%, Viscosa 35%',
                colores: ['Azul marino', 'Negro', 'Gris'],
                talles: ['XS', 'S', 'M', 'L'],
                caracteristicas: 'Cintura elástica, forrada, pliegues fijos'
            }
        },
        {
            id: 'ropa-010',
            name: 'Chaleco de Lana Hombre',
            description: 'Chaleco tejido de lana merino, diseño clásico, ideal para capas',
            price: 4290,
            image: 'https://via.placeholder.com/300x300?text=Chaleco+Lana',
            category: 'ropa',
            stock: 15,
            rating: 4.7,
            specs: {
                genero: 'Hombre',
                tipo: 'Chaleco',
                material: 'Lana merino 100%',
                colores: ['Beige', 'Gris', 'Azul marino'],
                talles: ['S', 'M', 'L', 'XL'],
                caracteristicas: 'Abrigo medio, corte clásico, 4 botones'
            }
        }
    ],
    
    // Categoría: Hogar
    'hogar': [
        {
            id: 'hogar-001',
            name: 'Juego de Sábanas Algodón Egipcio',
            description: 'Juego de sábanas 4 piezas, 600 hilos, algodón egipcio 100%',
            price: 5890,
            image: 'https://via.placeholder.com/300x300?text=Sabanas+Algodon',
            category: 'hogar',
            stock: 25,
            rating: 4.8,
            specs: {
                tipo: 'Juego de sábanas',
                piezas: 4,
                material: 'Algodón egipcio 100%',
                hilos: '600 hilos',
                colores: ['Blanco', 'Hueso', 'Gris perla', 'Azul celeste'],
                tamaños: ['1 plaza', '1 1/2 plaza', '2 plazas', 'Queen', 'King']
            }
        },
        {
            id: 'hogar-002',
            name: 'Set de Ollas Acero Inoxidable',
            'description': 'Set de 5 piezas de acero inoxidable 18/10, con tapa de vidrio templado',
            price: 12990,
            image: 'https://via.placeholder.com/300x300?text=Set+Ollas',
            category: 'hogar',
            stock: 12,
            rating: 4.9,
            specs: {
                tipo: 'Set de ollas',
                piezas: 5,
                material: 'Acero inoxidable 18/10',
                incluye: ['Olla 16cm', 'Olla 18cm', 'Olla 20cm', 'Sartén 24cm', 'Cacerola 24cm'],
                caracteristicas: 'Fondos difusores, asas ergonómicas, tapas de vidrio templado',
                induccion: 'Sí'
            }
        },
        {
            id: 'hogar-003',
            name: 'Aspiradora Robot Inteligente',
            'description': 'Aspiradora robot con navegación láser, app control, programación y mapeo',
            price: 24990,
            image: 'https://via.placeholder.com/300x300?text=Aspiradora+Robot',
            category: 'hogar',
            stock: 8,
            rating: 4.7,
            specs: {
                marca: 'Xiaomi',
                modelo: 'Mi Robot Vacuum',
                navegacion: 'Láser LDS',
                conectividad: 'WiFi, App Mi Home',
                bateria: '5200mAh',
                autonomia: 'Hasta 150m²',
                aspiracion: '2000Pa',
                caracteristicas: 'Mapeo LIDAR, programación, control por voz con Alexa/Google'
            }
        },
        {
            id: 'hogar-004',
            name: 'Juego de Toallas de Baño',
            'description': 'Juego de 6 toallas de baño, algodón egipcio, extra suaves y absorbentes',
            price: 4290,
            image: 'https://via.placeholder.com/300x300?text=Toallas+Baño',
            category: 'hogar',
            stock: 30,
            rating: 4.6,
            specs: {
                tipo: 'Juego de toallas',
                piezas: 6,
                material: 'Algodón egipcio 100%',
                incluye: ['2 toallas de baño', '2 toallas de mano', '2 toallones'],
                colores: ['Blanco', 'Gris', 'Azul marino', 'Verde agua'],
                peso: '600 g/m²'
            }
        },
        {
            id: 'hogar-005',
            name: 'Cafetera Express',
            'description': 'Cafetera espresso automática con molinillo integrado, 19 bares de presión',
            price: 28990,
            image: 'https://via.placeholder.com/300x300?text=Cafetera+Express',
            category: 'hogar',
            stock: 6,
            rating: 4.9,
            specs: {
                marca: 'DeLonghi',
                modelo: 'ECAM22.110',
                tipo: 'Automática',
                presion: '15 bares',
                capacidadAgua: '1.8L',
                capacidadGranos: '250g',
                caracteristicas: 'Molinillo integrado, espumador de leche, pantalla LCD, 3 perfiles de usuario'
            }
        },
        {
            id: 'hogar-006',
            name: 'Sofá Esquinero 3-2-1',
            'description': 'Sofá modular esquinero, tela anti-manchas, estructura de madera de pino',
            price: 45990,
            image: 'https://via.placeholder.com/300x300?text=Sofa+Esquinero',
            category: 'hogar',
            stock: 4,
            rating: 4.8,
            specs: {
                tipo: 'Sofá esquinero',
                material: 'Tela poliéster anti-manchas',
                estructura: 'Madera de pino',
                relleno: 'Espuma de alta densidad',
                medidas: '280x160x85cm',
                colores: ['Gris', 'Beige', 'Azul petróleo'],
                caracteristicas: 'Modular, asientos reclinables, reposabrazos con almacenamiento'
            }
        },
        {
            id: 'hogar-007',
            name: 'Juego de Vajilla 48 Piezas',
            'description': 'Vajilla completa para 6 personas, porcelana blanca brillante, diseño clásico',
            price: 7890,
            image: 'https://via.placeholder.com/300x300?text=Vajilla+48+Piezas',
            category: 'hogar',
            stock: 15,
            rating: 4.7,
            specs: {
                tipo: 'Juego de vajilla',
                piezas: 48,
                material: 'Porcelana',
                servicio: '6 personas',
                incluye: '6 platos planos, 6 platos hondos, 6 platos postre, 6 tazas, 6 platos pequeños, 6 tazones, 6 juegos de cubiertos',
                caracteristicas: 'Apta microondas, lavavajillas y horno',
                diseño: 'Blanco brillante con filete dorado'
            }
        },
        {
            id: 'hogar-008',
            name: 'Colchón Memory Foam',
            'description': 'Colchón ortopédico de espuma viscoelástica, alta densidad, 20cm de grosor',
            price: 32990,
            image: 'https://via.placeholder.com/300x300?text=Colchon+Memory+Foam',
            category: 'hogar',
            stock: 7,
            rating: 4.9,
            specs: {
                tipo: 'Colchón',
                material: 'Espuma viscoelástica',
                densidad: '55 kg/m³',
                grosor: '20 cm',
                firmeza: 'Media-alta',
                tamaños: ['1 plaza', '1 1/2 plaza', '2 plazas', 'Queen', 'King'],
                garantia: '10 años'
            }
        },
        {
            id: 'hogar-009',
            name: 'Purificador de Aire con HEPA',
            'description': 'Purificador de aire con filtro HEPA True HEPA, para habitaciones hasta 40m²',
            price: 15990,
            image: 'https://via.placeholder.com/300x300?text=Purificador+Aire',
            category: 'hogar',
            stock: 10,
            rating: 4.8,
            specs: {
                marca: 'Philips',
                modelo: 'AC2887/10',
                cobertura: 'Hasta 40m²',
                filtros: 'Prefiltro, HEPA, Carbón activado',
                niveles: '4 niveles de purificación',
                ruido: 'Hasta 61 dB',
                caracteristicas: 'Sensor de calidad del aire, modo noche, control por app',
                consumo: '50W'
            }
        },
        {
            id: 'hogar-010',
            name: 'Juego de Cuchillos Profesional',
            'description': 'Juego de 6 cuchillos de acero inoxidable alemán, con soporte magnético',
            price: 11290,
            image: 'https://via.placeholder.com/300x300?text=Juego+Cuchillos',
            category: 'hogar',
            stock: 14,
            rating: 4.9,
            specs: {
                marca: 'WMF',
                material: 'Acero inoxidable alemán Cromargan',
                piezas: 6,
                incluye: 'Cuchillo de chef 20cm, cuchillo para pan 20cm, cuchillo para filete 15cm, cuchillo de uso general 13cm, cuchillo para pelar 8cm, tijeras de cocina',
                caracteristicas: 'Filo láser, ergonómico, soporte magnético incluido',
                garantia: 'Vitalicia'
            }
        }
    ]
};

// Función para obtener todos los productos
export const getAllProducts = () => {
    return Object.values(products).flat();
};

// Función para obtener productos por categoría
export const getProductsByCategory = (category) => {
    return products[category] || [];
};

// Función para buscar productos por término
export const searchProducts = (term) => {
    const searchTerm = term.toLowerCase();
    return getAllProducts().filter(product => 
        product.name.toLowerCase().includes(searchTerm) || 
        product.description.toLowerCase().includes(searchTerm)
    );
};

// Función para obtener un producto por ID
export const getProductById = (id) => {
    return getAllProducts().find(product => product.id === id);
};

export default products;
