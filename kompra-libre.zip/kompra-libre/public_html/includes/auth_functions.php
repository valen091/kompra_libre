<?php
function generateJWT($payload) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    if (!isset($payload['exp'])) $payload['exp'] = time() + (86400 * 30);
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($payload)));
    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

function verifyJWT($token) {
    $tokenParts = explode('.', $token);
    if (count($tokenParts) !== 3) return false;
    
    list($base64UrlHeader, $base64UrlPayload, $signature) = $tokenParts;
    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64UrlPayload)), true);
    if (isset($payload['exp']) && $payload['exp'] < time()) return false;
    $base64UrlHeaderToSign = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode(['typ' => 'JWT', 'alg' => 'HS256'])));
    $signatureToVerify = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlSignatureToVerify = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signatureToVerify));
    return hash_equals($base64UrlSignatureToVerify, $signature) ? $payload : false;
}

function isAuthenticated() {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';
    if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        $payload = verifyJWT($matches[1]);
        if ($payload && isset($payload['user_id'])) return $payload;
    }
    
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (isset($_SESSION['user_id'])) {
        return [
            'user_id' => $_SESSION['user_id'],
            'email' => $_SESSION['email'] ?? null,
            'role' => $_SESSION['role'] ?? 'user'
        ];
    }
    
    if (isset($_COOKIE['remember_token'])) {
        $payload = verifyJWT($_COOKIE['remember_token']);
        if ($payload && isset($payload['user_id'])) {
            $_SESSION['user_id'] = $payload['user_id'];
            $_SESSION['email'] = $payload['email'] ?? null;
            $_SESSION['role'] = $payload['role'] ?? 'user';
            setcookie('remember_token', $_COOKIE['remember_token'], time() + (86400 * 30), '/');
            return [
                'user_id' => $payload['user_id'],
                'email' => $payload['email'] ?? null,
                'role' => $payload['role'] ?? 'user'
            ];
        }
    }
    return false;
}

function requireAuth($role = null) {
    $user = isAuthenticated();
    if (!$user) {
        http_response_code(401);
        throw new Exception('Acceso no autorizado. Debes iniciar sesión.');
    }
    if ($role && (!isset($user['role']) || $user['role'] !== $role)) {
        http_response_code(403);
        throw new Exception('No tienes permisos para acceder a este recurso.');
    }
    return $user;
}

function createSlug($text) {
    $text = str_replace(
        ['á', 'é', 'í', 'ó', 'ú', 'ñ', 'ü', 'Á', 'É', 'Í', 'Ó', 'Ú', 'Ñ', 'Ü'],
        ['a', 'e', 'i', 'o', 'u', 'n', 'u', 'A', 'E', 'I', 'O', 'U', 'N', 'U'],
        $text
    );
    $text = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $text), '-'));
    return preg_replace('/-+/', '-', $text);
}

function sanitize($input) {
    if (is_array($input)) return array_map('sanitize', $input);
    return htmlspecialchars(trim($input), ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

function generateSecurePassword($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?';
    $password = '';
    $max = strlen($chars) - 1;
    
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[random_int(0, $max)];
    }
    
    return $password;
}
