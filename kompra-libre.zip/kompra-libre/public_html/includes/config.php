<?php
/**
 * Configuración principal de la aplicación Kompra Libre
 * 
 * @version 2.0
 */

// =============================================
// Configuración del entorno
// =============================================
define('APP_NAME', 'Kompra Libre');
define('APP_VERSION', '2.0.0');

// Detectar entorno (producción, desarrollo, pruebas)
$environment = getenv('APP_ENV') ?: 'development';
$isProduction = ($environment === 'production' || $_SERVER['HTTP_HOST'] === 'kompralibre.shop');
$isDevelopment = ($environment === 'development');

// Configuración de URLs
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$host = $isProduction ? 'kompralibre.shop' : ($_SERVER['HTTP_HOST'] ?? 'localhost');
$port = $_SERVER['SERVER_PORT'] ?? ($isProduction ? '' : ':3000');

// Configuración de la aplicación
define('APP_ENV', $environment);
define('APP_DEBUG', $isDevelopment);
define('APP_URL', $protocol . $host . $port);
define('APP_ROOT', dirname(__DIR__));

// =============================================
// Configuración de la base de datos
// =============================================
// Cargar configuración desde variables de entorno o usar valores por defecto
define('DB_HOST', getenv('DB_HOST') ?: 'srv1311.hstgr.io');
define('DB_NAME', getenv('DB_NAME') ?: 'u472738607_kompra_libre');
define('DB_USER', getenv('DB_USER') ?: 'u472738607_kompra_libre');
define('DB_PASS', getenv('DB_PASS') ?: 'Kompralibre1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');

// Configuración de PDO
$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::ATTR_PERSISTENT         => true
];

// =============================================
// Configuración de seguridad
// =============================================
// Configuración de sesión segura
$isSecure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
$domain = str_replace('www.', '', $host);

// Configuración de cookies seguras
$cookieParams = [
    'lifetime' => 86400, // 24 horas
    'path' => '/',
    'domain' => $isProduction ? '.kompralibre.shop' : $domain,
    'secure' => $isProduction,
    'httponly' => true,
    'samesite' => $isProduction ? 'None' : 'Lax'
];

// Configuración de sesión segura
ini_set('session.cookie_httponly', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_secure', $isSecure ? '1' : '0');
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_lifetime', '86400');
ini_set('session.gc_maxlifetime', '86400');

// Configuración de seguridad adicional
if (!defined('PASSWORD_BCRYPT_DEFAULT_COST')) {
    define('PASSWORD_BCRYPT_DEFAULT_COST', 12);
}

// Configuración de zona horaria
date_default_timezone_set('America/Argentina/Buenos_Aires');

// Iniciar sesión segura
if (session_status() === PHP_SESSION_NONE) {
    session_start($cookieParams);
}

// =============================================
// Configuración de rutas
// =============================================
// Directorios principales
define('UPLOADS_DIR', APP_ROOT . '/public_html/uploads');
define('ASSETS_DIR', APP_ROOT . '/public_html/assets');

// URLs públicas
define('UPLOADS_URL', APP_URL . '/uploads');
define('ASSETS_URL', APP_URL . '/assets');

// =============================================
// Manejo de errores
// =============================================
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);
    ini_set('error_log', APP_ROOT . '/logs/error.log');
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', APP_ROOT . '/logs/error.log');
}

// Función para manejar errores no capturados
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    $error = [
        'type' => $errno,
        'message' => $errstr,
        'file' => $errfile,
        'line' => $errline,
        'time' => date('Y-m-d H:i:s')
    ];
    
    // Registrar error
    error_log(json_encode($error));
    
    // Mostrar error en desarrollo
    if (APP_DEBUG) {
        echo "<pre>";
        print_r($error);
        echo "</pre>";
    }
    
    return true; // No ejecutar el gestor de errores interno de PHP
});

// Función para manejar excepciones no capturadas
set_exception_handler(function($exception) {
    $error = [
        'type' => get_class($exception),
        'message' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'trace' => $exception->getTraceAsString(),
        'time' => date('Y-m-d H:i:s')
    ];
    
    // Registrar error
    error_log(json_encode($error));
    
    // Mostrar error en desarrollo
    if (APP_DEBUG) {
        echo "<h1>Error</h1>";
        echo "<pre>";
        print_r($error);
        echo "</pre>";
    } else {
        // Página de error personalizada en producción
        http_response_code(500);
        include_once __DIR__ . '/error/500.php';
    }
});

// Función para manejar errores fatales
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
        $error = [
            'type' => 'Fatal Error',
            'message' => $error['message'],
            'file' => $error['file'],
            'line' => $error['line'],
            'time' => date('Y-m-d H:i:s')
        ];
        
        // Registrar error
        error_log(json_encode($error));
        
        // Mostrar error en desarrollo
        if (APP_DEBUG) {
            echo "<h1>Fatal Error</h1>";
            echo "<pre>";
            print_r($error);
            echo "</pre>";
        } else {
            // Página de error personalizada en producción
            http_response_code(500);
            include_once __DIR__ . '/error/500.php';
        }
    }
});
session_name('kompra_libre_session');
session_set_cookie_params($cookieParams);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configuración de JWT
define('JWT_SECRET', 'Kompralibre1');
define('JWT_EXPIRE', 86400);

// Configuración de subida de archivos
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// Configuración de zona horaria
date_default_timezone_set('America/Montevideo');

// Mostrar errores en desarrollo
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}