<?php
// Configuración de la aplicación
define('APP_NAME', 'Kompra Libre');
define('APP_URL', 'https://kompralibre.shop/');
define('APP_DEBUG', false);

// Configuración fija de la base de datos (para Hostinger)
define('DB_HOST', 'localhost');  // Hostinger usa localhost para la DB
define('DB_NAME', 'u472738607_kompra_libre');
define('DB_USER', 'u472738607_kompra_libre');
define('DB_PASS', 'Kompralibre1');

// Configuración de sesión
define('SESSION_NAME', 'kompra_libre_session');
define('SESSION_LIFETIME', 86400); // 24 horas

// Configuración de JWT
define('JWT_SECRET', 'tu_clave_secreta_muy_segura');
define('JWT_EXPIRE', 86400); // 24 horas

// Configuración de subida de archivos
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif']);

// Configuración de errores - Desactivada completamente
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 0);

// Configuración de zona horaria
date_default_timezone_set('America/Uruguay/Montevideo');

// Iniciar sesión de forma silenciosa
@session_name(SESSION_NAME);
@session_set_cookie_params([
    'lifetime' => SESSION_LIFETIME,
    'path' => '/',
    'domain' => '',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);
@session_start();