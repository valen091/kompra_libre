<?php
/**
 * Configuración principal de la aplicación Kompra Libre
 * 
 * @version 2.1.0
 */

// =============================================
// Configuración del entorno
// =============================================

// Nombre y versión de la aplicación
define('APP_NAME', 'Kompra Libre');
define('APP_VERSION', '2.1.0');

// Cargar variables de entorno desde el archivo .env
// Ruta para Hostinger (el archivo .env debe estar en public_html/)
$dotenvPath = __DIR__ . '/../.env';  // Apunta a public_html/.env

// Verificar si el archivo existe y es legible
if (!file_exists($dotenvPath)) {
    die('Error: No se encontró el archivo .env en: ' . $dotenvPath . 
        '\nPor favor, asegúrate de que el archivo .env esté en la carpeta public_html/ de tu hosting.');
}

if (!is_readable($dotenvPath)) {
    die('Error: No se puede leer el archivo .env. Verifica los permisos del archivo.');
}

// Leer el contenido del archivo para depuración
$envContent = file_get_contents($dotenvPath);
if ($envContent === false) {
    die('Error: No se pudo leer el contenido del archivo .env');
}

// Mostrar el contenido para depuración (solo en desarrollo)
echo '<pre>Contenido de .env (primeras 500 caracteres):\n' . htmlspecialchars(substr($envContent, 0, 500)) . '</pre>';

// Verificar si hay caracteres BOM
if (substr($envContent, 0, 3) === "\xEF\xBB\xBF") {
    $envContent = substr($envContent, 3);
    echo '<div style="color:orange">Se detectó y eliminó BOM del archivo .env</div>';
}

// Procesar el archivo .env manualmente
$dotenv = [];
$lines = explode("\n", $envContent);
foreach ($lines as $line) {
    $line = trim($line);
    // Saltar líneas vacías o comentarios
    if (empty($line) || $line[0] === '#' || $line[0] === ';') {
        continue;
    }
    
    // Dividir en clave y valor
    $parts = explode('=', $line, 2);
    if (count($parts) === 2) {
        $key = trim($parts[0]);
        $value = trim($parts[1]);
        
        // Eliminar comillas si existen
        if ((str_starts_with($value, '"') && str_ends_with($value, '"')) || 
            (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
            $value = substr($value, 1, -1);
        }
        
        $dotenv[$key] = $value;
    }
}

// Verificar si se cargaron variables
if (empty($dotenv)) {
    die('Error: No se pudieron cargar variables desde el archivo .env. Verifica el formato.');
}

// Configuración del entorno
define('APP_ENV', getenv('APP_ENV') ?: ($dotenv['APP_ENV'] ?? 'development'));
$isProduction = (APP_ENV === 'production');
$isDevelopment = !$isProduction;

// Configuración de URLs
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
             (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)) ? 'https://' : 'http://';
             
$host = $isProduction ? ($dotenv['APP_DOMAIN'] ?? 'kompralibre.shop') : 
                       ($_SERVER['HTTP_HOST'] ?? 'localhost');
                       
$port = !in_array($_SERVER['SERVER_PORT'] ?? '', ['80', '443', '']) ? 
        (':'.$_SERVER['SERVER_PORT']) : '';

// Configuración de la aplicación
define('APP_DEBUG', $isDevelopment);
define('APP_URL', rtrim($protocol . $host . $port, '/'));
define('APP_ROOT', dirname(__DIR__));

// =============================================
// Configuración de la base de datos
// =============================================
// Cargar configuración desde variables de entorno o archivo .env
define('DB_HOST', getenv('DB_HOST') ?: ($dotenv['DB_HOST'] ?? 'localhost'));
define('DB_NAME', getenv('DB_DATABASE') ?: ($dotenv['DB_NAME'] ?? 'u472738607_kompra_libre'));
define('DB_USER', getenv('DB_USERNAME') ?: ($dotenv['DB_USER'] ?? 'u472738607_kompra_libre'));
define('DB_PASS', getenv('DB_PASSWORD') ?: ($dotenv['DB_PASS'] ?? 'Kompralibre1'));
define('DB_PORT', getenv('DB_PORT') ?: ($dotenv['DB_PORT'] ?? '3306'));

// Configuración de PDO para MySQL (Hostinger usa MySQL)
try {
    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_PERSISTENT         => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
    ]);
    
    // Establecer la conexión como variable global
    $GLOBALS['pdo'] = $pdo;
    
} catch (PDOException $e) {
    // Mostrar mensaje de error detallado en desarrollo
    if (APP_DEBUG) {
        die('Error de conexión a la base de datos: ' . $e->getMessage() . 
            '<br>Configuración usada: ' . 
            'Host: ' . DB_HOST . 
            ', DB: ' . DB_NAME . 
            ', Usuario: ' . DB_USER);
    } else {
        // Mensaje genérico en producción
        error_log('Error de conexión a la base de datos: ' . $e->getMessage());
        die('Error de conexión con la base de datos. Por favor, intente nuevamente más tarde.');
    }
}

// =============================================
// Configuración de seguridad
// =============================================

// Configuración de sesión segura
if (session_status() === PHP_SESSION_NONE) {
    // Configuración de cookies de sesión seguras
    $cookieParams = [
        'lifetime' => 86400, // 24 horas
        'path' => '/',
        'domain' => $isProduction ? '.kompralibre.shop' : '',
        'secure' => $isProduction,
        'httponly' => true,
        'samesite' => 'Lax'
    ];

    // Aplicar configuración de cookies
    @session_set_cookie_params($cookieParams);
    
    // Establecer el nombre de la sesión
    @session_name('KLSESSID');
    
    // Configurar directorio de sesión personalizado si es necesario
    $sessionPath = __DIR__ . '/../tmp/sessions';
    if (!is_dir($sessionPath)) {
        @mkdir($sessionPath, 0755, true);
    }
    @ini_set('session.save_path', $sessionPath);
    @ini_set('session.gc_maxlifetime', 86400);
    @ini_set('session.cookie_lifetime', 86400);
    
    // Iniciar la sesión con manejo de errores
    @session_start();

    // Regenerar ID de sesión periódicamente para prevenir fijación de sesión
    if (!isset($_SESSION['last_regeneration'])) {
        @session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    } elseif (time() - $_SESSION['last_regeneration'] > 1800) { // 30 minutos
        @session_regenerate_id(true);
        $_SESSION['last_regeneration'] = time();
    }
}

// Configuración de encabezados de seguridad
header_remove('X-Powered-By');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

// Configuración de HSTS en producción
if ($isProduction) {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
    
    // Content Security Policy (CSP)
    $csp = [
        "default-src 'self'",
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.google-analytics.com https://www.googletagmanager.com https://js.stripe.com https://sdk.mercadopago.com",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        "img-src 'self' data: https: http:",
        "font-src 'self' https://fonts.gstatic.com data:",
        "connect-src 'self' https://api.mercadopago.com https://api.paypal.com https://www.paypal.com https://www.google-analytics.com",
        "frame-src 'self' https://www.youtube.com https://www.google.com https://www.paypal.com https://js.stripe.com https://www.mercadopago.com",
        "object-src 'none'",
        "base-uri 'self'",
        "form-action 'self' https://www.paypal.com https://www.mercadopago.com",
        "frame-ancestors 'self'",
        "upgrade-insecure-requests"
    ];
    
    header("Content-Security-Policy: " . implode('; ', $csp));
}

// Clave secreta para CSRF
define('CSRF_TOKEN_SECRET', $dotenv['CSRF_TOKEN_SECRET'] ?? hash('sha256', uniqid(mt_rand(), true)));

// Configuración de CORS
header('Access-Control-Allow-Origin: ' . ($isProduction ? 'https://kompralibre.shop' : '*'));
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-TOKEN');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 3600');

// Prevenir MIME type sniffing
header('X-Content-Type-Options: nosniff');

// Configuración de seguridad adicional
if (!defined('PASSWORD_BCRYPT_DEFAULT_COST')) {
    define('PASSWORD_BCRYPT_DEFAULT_COST', 12);
}

// Iniciar sesión segura
if (session_status() === PHP_SESSION_NONE) {
    session_start($cookieParams);
}

// =============================================
// Configuración de rutas
// =============================================
// Directorios principales
define('UPLOADS_DIR', APP_ROOT . '/public_html/uploads');
define('ASSETS_DIR', APP_ROOT . '/public_html/assets');

// URLs públicas
define('UPLOADS_URL', APP_URL . '/uploads');
define('ASSETS_URL', APP_URL . '/assets');

// =============================================
// Manejo de errores
// =============================================
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);
    ini_set('error_log', APP_ROOT . '/logs/error.log');
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', APP_ROOT . '/logs/error.log');
}

// Función para manejar errores no capturados
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    $error = [
        'type' => $errno,
        'message' => $errstr,
        'file' => $errfile,
        'line' => $errline,
        'time' => date('Y-m-d H:i:s')
    ];
    
    // Registrar error
    error_log(json_encode($error));
    
    // Mostrar error en desarrollo
    if (APP_DEBUG) {
        echo "<pre>";
        print_r($error);
        echo "</pre>";
    }
    
    return true; // No ejecutar el gestor de errores interno de PHP
});

// Función para manejar excepciones no capturadas
set_exception_handler(function($exception) {
    $error = [
        'type' => get_class($exception),
        'message' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'trace' => $exception->getTraceAsString(),
        'time' => date('Y-m-d H:i:s')
    ];
    
    // Registrar error
    error_log(json_encode($error));
    
    // Mostrar error en desarrollo
    if (APP_DEBUG) {
        echo "<h1>Error</h1>";
        echo "<pre>";
        print_r($error);
        echo "</pre>";
    } else {
        // Página de error personalizada en producción
        http_response_code(500);
        include_once __DIR__ . '/error/500.php';
    }
});

// Función para manejar errores fatales
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR])) {
        $error = [
            'type' => 'Fatal Error',
            'message' => $error['message'],
            'file' => $error['file'],
            'line' => $error['line'],
            'time' => date('Y-m-d H:i:s')
        ];
        
        // Registrar error
        error_log(json_encode($error));
        
        // Mostrar error en desarrollo
        if (APP_DEBUG) {
            echo "<h1>Fatal Error</h1>";
            echo "<pre>";
            print_r($error);
            echo "</pre>";
        } else {
            // Página de error personalizada en producción
            http_response_code(500);
            include_once __DIR__ . '/error/500.php';
        }
    }
});
// La sesión ya fue iniciada anteriormente con la configuración adecuada

// Configuración de JWT
define('JWT_SECRET', 'Kompralibre1');
define('JWT_EXPIRE', 86400);

// Configuración de subida de archivos
define('UPLOAD_DIR', __DIR__ . '/../assets/uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// Usar la zona horaria del sistema
date_default_timezone_set(date_default_timezone_get());
error_log('Using system timezone: ' . date_default_timezone_get());

// Mostrar errores en desarrollo
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}