<?php
/**
 * Archivo de funciones auxiliares para Kompra Libre
 * 
 * @package KompraLibre
 * @version 2.0
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/Database.php';

/**
 * Sanitiza los datos de entrada para prevenir inyección XSS
 * 
 * @param mixed $data Datos a sanitizar (string o array)
 * @return mixed Datos sanitizados
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    
    // Eliminar espacios en blanco al inicio y final
    $data = trim($data);
    
    // Convertir caracteres especiales a entidades HTML
    return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8', false);
}

/**
 * Redirige a una URL específica
 * 
 * @param string $url URL a la que se redirigirá
 * @param int $statusCode Código de estado HTTP (por defecto: 302)
 * @return void
 */
function redirect($url, $statusCode = 302) {
    // Asegurarse de que la URL sea absoluta si no lo es
    if (!preg_match('~^(?:f|ht)tps?://~i', $url)) {
        $url = rtrim(APP_URL, '/') . '/' . ltrim($url, '/');
    }
    
    // Limpiar el búfer de salida
    if (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // Redirigir
    header('Location: ' . $url, true, $statusCode);
    exit();
}

/**
 * Genera un token CSRF si no existe
 * 
 * @return string Token CSRF
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Valida un token CSRF
 * 
 * @param string $token Token a validar
 * @return bool true si el token es válido, false en caso contrario
 */
function validateCSRFToken($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Sube un archivo al servidor de manera segura
 * 
 * @param array $file Array $_FILES del archivo a subir
 * @param string $directory Directorio de destino dentro de la carpeta de uploads
 * @param array $allowedTypes Tipos MIME permitidos (opcional)
 * @param int $maxSize Tamaño máximo en bytes (opcional, por defecto 5MB)
 * @return array Array con información sobre el archivo subido o error
 */
function uploadFile($file, $directory = '', $allowedTypes = null, $maxSize = 5242880) {
    // Directorio de destino
    $targetDir = rtrim(UPLOADS_DIR, '/') . '/' . trim($directory, '/');
    
    // Crear directorio si no existe
    if (!file_exists($targetDir)) {
        if (!mkdir($targetDir, 0755, true)) {
            throw new Exception('No se pudo crear el directorio de destino.');
        }
    }
    
    // Validar errores de subida
    if (!isset($file['error']) || is_array($file['error'])) {
        throw new Exception('Parámetros inválidos.');
    }
    
    // Verificar errores de subida
    switch ($file['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            throw new Exception('No se ha enviado ningún archivo.');
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            throw new Exception('El archivo excede el tamaño máximo permitido.');
        default:
            throw new Exception('Error al subir el archivo.');
    }
    
    // Validar tamaño del archivo
    if ($file['size'] > $maxSize) {
        throw new Exception('El archivo es demasiado grande. Tamaño máximo: ' . formatBytes($maxSize));
    }
    
    // Obtener información del archivo
    $fileInfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $fileInfo->file($file['tmp_name']);
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    // Tipos MIME permitidos por defecto
    if ($allowedTypes === null) {
        $allowedTypes = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'zip' => 'application/zip'
        ];
    }
    
    // Validar tipo de archivo
    if (!in_array($mimeType, $allowedTypes) || !in_array($extension, array_keys($allowedTypes))) {
        throw new Exception('Tipo de archivo no permitido.');
    }
    
    // Generar nombre de archivo único
    $fileName = uniqid('', true) . '_' . preg_replace('/[^a-zA-Z0-9\-\._]/', '_', $file['name']);
    $targetPath = rtrim($targetDir, '/') . '/' . $fileName;
    
    // Mover el archivo subido al directorio de destino
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        throw new Exception('Error al guardar el archivo.');
    }
    
    // Cambiar permisos del archivo (solo lectura y ejecución para otros)
    chmod($targetPath, 0644);
    
    // Retornar información del archivo subido
    return [
        'name' => $file['name'],
        'type' => $mimeType,
        'size' => $file['size'],
        'path' => str_replace('\\', '/', $targetPath),
        'url' => rtrim(UPLOADS_URL, '/') . '/' . trim($directory, '/') . '/' . $fileName,
        'extension' => $extension
    ];
}

/**
 * Formatea un número como moneda
 * 
 * @param float $price Precio a formatear
 * @param string $currency Símbolo de moneda (por defecto: '$')
 * @param int $decimals Número de decimales (por defecto: 2)
 * @param string $decimalSeparator Separador decimal (por defecto: ',')
 * @param string $thousandsSeparator Separador de miles (por defecto: '.')
 * @return string Precio formateado
 */
function formatPrice($price, $currency = '$', $decimals = 2, $decimalSeparator = ',', $thousandsSeparator = '.') {
    $price = (float) $price;
    return $currency . ' ' . number_format($price, $decimals, $decimalSeparator, $thousandsSeparator);
}

/**
 * Genera un slug a partir de un texto
 * 
 * @param string $string Texto a convertir en slug
 * @param string $separator Separador (por defecto: '-')
 * @return string Slug generado
 */
function generateSlug($string, $separator = '-') {
    // Convertir a minúsculas
    $string = mb_strtolower(trim($string), 'UTF-8');
    
    // Reemplazar caracteres especiales
    $string = preg_replace('/[^a-z0-9\s\-]/u', '', $string);
    
    // Reemplazar espacios y guiones por el separador
    $string = preg_replace('/[\s\-]+/', $separator, $string);
    
    // Eliminar separadores al inicio y final
    return trim($string, $separator);
}

/**
 * Verifica si el usuario está autenticado
 * 
 * @return bool true si el usuario está autenticado, false en caso contrario
 */
function isAuthenticated() {
    return !empty($_SESSION['user_id']) && !empty($_SESSION['user_role']);
}

/**
 * Verifica si el usuario es administrador
 * 
 * @return bool true si el usuario es administrador, false en caso contrario
 */
function isAdmin() {
    return isAuthenticated() && $_SESSION['user_role'] === 'admin';
}

/**
 * Verifica si el usuario es vendedor o administrador
 * 
 * @return bool true si el usuario es vendedor o administrador, false en caso contrario
 */
function isSeller() {
    return isAuthenticated() && in_array($_SESSION['user_role'], ['seller', 'admin']);
}

/**
 * Obtiene el ID del usuario actual
 * 
 * @return int|null ID del usuario o null si no está autenticado
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Obtiene el rol del usuario actual
 * 
 * @return string|null Rol del usuario o null si no está autenticado
 */
function getCurrentUserRole() {
    return $_SESSION['user_role'] ?? null;
}

/**
 * Genera un token JWT
 * 
 * @param array $payload Datos a incluir en el token
 * @param int $expire Tiempo de expiración en segundos (por defecto: 24 horas)
 * @return string Token JWT generado
 */
function generateJWT($payload, $expire = 86400) {
    // Cabecera del token
    $header = [
        'typ' => 'JWT', 
        'alg' => 'HS256'
    ];
    
    // Tiempo actual
    $now = time();
    
    // Datos del token
    $tokenPayload = [
        'iat' => $now,                          // Tiempo de emisión
        'exp' => $now + $expire,                // Tiempo de expiración
        'jti' => bin2hex(random_bytes(16)),     // ID único del token
        'iss' => APP_URL,                       // Emisor
        'aud' => APP_URL                        // Audiencia
    ];
    
    // Combinar con los datos adicionales
    $tokenPayload = array_merge($tokenPayload, $payload);
    
    // Codificar cabecera y payload en base64url
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($header)));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($tokenPayload)));
    
    // Crear la firma
    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    
    // Retornar el token completo
    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

/**
 * Valida un token JWT
 * 
 * @param string $token Token JWT a validar
 * @return array|false Datos del token si es válido, false en caso contrario
 */
function validateJWT($token) {
    // Verificar formato del token
    $tokenParts = explode('.', $token);
    if (count($tokenParts) !== 3) {
        return false;
    }
    
    list($base64UrlHeader, $base64UrlPayload, $signature) = $tokenParts;
    
    // Decodificar cabecera y payload
    $header = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64UrlHeader)), true);
    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64UrlPayload)), true);
    
    // Verificar cabecera y algoritmo
    if (!$header || !isset($header['alg']) || $header['alg'] !== 'HS256') {
        return false;
    }
    
    // Verificar firma
    $validSignature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlValidSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($validSignature));
    
    if (!hash_equals($signature, $base64UrlValidSignature)) {
        return false;
    }
    
    // Verificar tiempo de expiración
    if (!isset($payload['exp']) || $payload['exp'] < time()) {
        return false;
    }
    
    // Verificar emisor (issuer) si está definido
    if (isset($payload['iss']) && $payload['iss'] !== APP_URL) {
        return false;
    }
    
    // Verificar audiencia (audience) si está definida
    if (isset($payload['aud']) && $payload['aud'] !== APP_URL) {
        return false;
    }
    
    return $payload;
}

/**
 * Formatea bytes en un formato legible
 * 
 * @param int $bytes Número de bytes
 * @param int $precision Precisión decimal (por defecto: 2)
 * @return string Bytes formateados (ej: "1.5 MB")
 */
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    
    return round($bytes, $precision) . ' ' . $units[$pow];
}

/**
 * Obtiene la URL base de la aplicación
 * 
 * @return string URL base
 */
function baseUrl($path = '') {
    return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
}

/**
 * Obtiene la URL de un recurso de assets
 * 
 * @param string $path Ruta del recurso
 * @return string URL completa del recurso
 */
function asset($path) {
    return rtrim(ASSETS_URL, '/') . '/' . ltrim($path, '/');
}

/**
 * Obtiene la URL de un archivo subido
 * 
 * @param string $path Ruta del archivo
 * @return string URL completa del archivo
 */
function uploadUrl($path) {
    return rtrim(UPLOADS_URL, '/') . '/' . ltrim($path, '/');
}

/**
 * Incluye una vista con variables
 * 
 * @param string $view Nombre de la vista (sin extensión)
 * @param array $data Datos a pasar a la vista
 * @return void
 */
function view($view, $data = []) {
    $viewFile = APP_ROOT . '/views/' . trim($view, '/') . '.php';
    
    if (!file_exists($viewFile)) {
        throw new Exception("La vista '{$view}' no existe.");
    }
    
    // Extraer las variables a un ámbito local
    extract($data, EXTR_SKIP);
    
    // Iniciar el buffer de salida
    ob_start();
    
    // Incluir la vista
    include $viewFile;
    
    // Obtener y limpiar el contenido del buffer
    return ob_get_clean();
}

/**
 * Muestra una vista
 * 
 * @param string $view Nombre de la vista (sin extensión)
 * @param array $data Datos a pasar a la vista
 * @param int $statusCode Código de estado HTTP
 * @return void
 */
function render($view, $data = [], $statusCode = 200) {
    http_response_code($statusCode);
    echo view($view, $data);
    exit;
}

/**
 * Devuelve una respuesta JSON
 * 
 * @param mixed $data Datos a devolver
 * @param int $statusCode Código de estado HTTP
 * @param array $headers Encabezados adicionales
 * @return void
 */
function json($data, $statusCode = 200, $headers = []) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    
    // Establecer encabezados adicionales
    foreach ($headers as $header => $value) {
        header("{$header}: {$value}");
    }
    
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Obtiene el valor de un parámetro de la solicitud
 * 
 * @param string $key Clave del parámetro
 * @param mixed $default Valor por defecto si no existe
 * @param string $type Tipo de dato (string, int, float, bool, array)
 * @return mixed Valor del parámetro
 */
function request($key, $default = null, $type = 'string') {
    $value = $_REQUEST[$key] ?? $default;
    
    // Filtrar según el tipo
    switch (strtolower($type)) {
        case 'int':
        case 'integer':
            return (int) $value;
        case 'float':
        case 'double':
            return (float) $value;
        case 'bool':
        case 'boolean':
            return (bool) $value;
        case 'array':
            return is_array($value) ? $value : [];
        case 'string':
        default:
            return is_scalar($value) ? (string) $value : $default;
    }
}

/**
 * Verifica si la solicitud es de tipo AJAX
 * 
 * @return bool true si es una petición AJAX, false en caso contrario
 */
function isAjax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Verifica si la solicitud es de tipo POST
 * 
 * @return bool true si es una petición POST, false en caso contrario
 */
function isPost() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Verifica si la solicitud es de tipo GET
 * 
 * @return bool true si es una petición GET, false en caso contrario
 */
function isGet() {
    return $_SERVER['REQUEST_METHOD'] === 'GET';
}

/**
 * Genera una contraseña segura
 * 
 * @param int $length Longitud de la contraseña (por defecto: 12)
 * @return string Contraseña generada
 */
function generatePassword($length = 12) {
    $uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $lowercase = 'abcdefghijklmnopqrstuvwxyz';
    $numbers = '0123456789';
    $special = '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    $all = $uppercase . $lowercase . $numbers . $special;
    $password = '';
    
    // Asegurar al menos un carácter de cada tipo
    $password .= $uppercase[random_int(0, strlen($uppercase) - 1)];
    $password .= $lowercase[random_int(0, strlen($lowercase) - 1)];
    $password .= $numbers[random_int(0, strlen($numbers) - 1)];
    $password .= $special[random_int(0, strlen($special) - 1)];
    
    // Completar la longitud restante
    for ($i = strlen($password); $i < $length; $i++) {
        $password .= $all[random_int(0, strlen($all) - 1)];
    }
    
    // Mezclar los caracteres
    return str_shuffle($password);
}

/**
 * Genera un hash seguro de contraseña
 * 
 * @param string $password Contraseña en texto plano
 * @return string Hash de la contraseña
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, [
        'cost' => PASSWORD_BCRYPT_DEFAULT_COST
    ]);
}

/**
 * Verifica una contraseña con su hash
 * 
 * @param string $password Contraseña en texto plano
 * @param string $hash Hash de la contraseña
 * @return bool true si la contraseña es válida, false en caso contrario
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Obtiene la dirección IP del cliente
 * 
 * @return string Dirección IP
 */
function getClientIp() {
    $ip = '';
    
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }
    
    // En caso de múltiples IPs (proxies), tomar la primera
    if (strpos($ip, ',') !== false) {
        $ips = explode(',', $ip);
        $ip = trim($ips[0]);
    }
    
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '127.0.0.1';
}

/**
 * Registra un mensaje flash en la sesión
 * 
 * @param string $type Tipo de mensaje (success, error, warning, info)
 * @param string $message Mensaje a mostrar
 * @return void
 */
function setFlash($type, $message) {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    
    $_SESSION['flash_messages'][] = [
        'type' => $type,
        'message' => $message,
        'time' => time()
    ];
}

/**
 * Obtiene y elimina los mensajes flash de la sesión
 * 
 * @return array Array de mensajes flash
 */
function getFlashMessages() {
    $messages = $_SESSION['flash_messages'] ?? [];
    unset($_SESSION['flash_messages']);
    return $messages;
}

/**
 * Muestra los mensajes flash
 * 
 * @param string $type Tipo de mensaje a mostrar (opcional, muestra todos si es null)
 * @return string HTML con los mensajes
 */
function displayFlashMessages($type = null) {
    $messages = getFlashMessages();
    $output = '';
    
    foreach ($messages as $message) {
        if ($type === null || $message['type'] === $type) {
            $output .= sprintf(
                '<div class="alert alert-%s">%s</div>',
                htmlspecialchars($message['type'], ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($message['message'], ENT_QUOTES, 'UTF-8')
            );
        }
    }
    
    return $output;
}

/**
 * Verifica si hay mensajes flash de un tipo específico
 * 
 * @param string $type Tipo de mensaje a verificar
 * @return bool true si hay mensajes, false en caso contrario
 */
function hasFlash($type) {
    if (empty($_SESSION['flash_messages'])) {
        return false;
    }
    
    foreach ($_SESSION['flash_messages'] as $message) {
        if ($message['type'] === $type) {
            return true;
        }
    }
    
    return false;
}

/**
 * Registra un mensaje en el log de la aplicación
 * 
 * @param string $message Mensaje a registrar
 * @param string $level Nivel de log (info, warning, error, etc.)
 * @param array $context Datos adicionales
 * @return void
 */
function logger($message, $level = 'info', $context = []) {
    $logFile = APP_ROOT . '/logs/app.log';
    $logDir = dirname($logFile);
    
    // Crear directorio de logs si no existe
    if (!file_exists($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    // Formato del mensaje: [fecha] nivel: mensaje {contexto}
    $logMessage = sprintf(
        '[%s] %s: %s %s' . PHP_EOL,
        date('Y-m-d H:i:s'),
        strtoupper($level),
        $message,
        !empty($context) ? json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : ''
    );
    
    // Escribir en el archivo de log
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

/**
 * Obtiene la ruta completa de un archivo de idioma
 * 
 * @param string $file Nombre del archivo (sin extensión)
 * @param string $lang Código de idioma (opcional, por defecto: 'es')
 * @return string Ruta completa del archivo de idioma
 */
function langPath($file, $lang = 'es') {
    return APP_ROOT . "/lang/{$lang}/{$file}.php";
}

/**
 * Obtiene una cadena de idioma
 * 
 * @param string $key Clave de la cadena
 * @param array $params Parámetros para reemplazar en la cadena
 * @param string $lang Código de idioma (opcional)
 * @return string Cadena de idioma
 */
function __($key, $params = [], $lang = null) {
    static $translations = [];
    
    // Determinar el idioma
    $lang = $lang ?? ($_SESSION['lang'] ?? 'es');
    
    // Cargar traducciones si no están cargadas
    if (!isset($translations[$lang])) {
        $langFile = langPath('common', $lang);
        
        if (file_exists($langFile)) {
            $translations[$lang] = include $langFile;
        } else {
            // Cargar idioma por defecto si el solicitado no existe
            $defaultLangFile = langPath('common', 'es');
            $translations[$lang] = file_exists($defaultLangFile) ? include $defaultLangFile : [];
        }
    }
    
    // Obtener la traducción
    $translation = $translations[$lang][$key] ?? $key;
    
    // Reemplazar parámetros si los hay
    if (!empty($params)) {
        foreach ($params as $param => $value) {
            $translation = str_replace(':' . $param, $value, $translation);
        }
    }
    
    return $translation;
}

// Inicializar la sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Cargar configuración de idioma si existe
if (file_exists(APP_ROOT . '/config/locale.php')) {
    require_once APP_ROOT . '/config/locale.php';
}

// Cargar funciones personalizadas si existen
if (file_exists(APP_ROOT . '/app/helpers.php')) {
    require_once APP_ROOT . '/app/helpers.php';
}
