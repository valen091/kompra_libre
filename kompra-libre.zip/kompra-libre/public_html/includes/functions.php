<?php
require_once __DIR__ . '/config.php';

// Sanitizar entrada de datos
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Redireccionar a una URL
function redirect($url) {
    header("Location: " . APP_URL . $url);
    exit;
}

// Generar token CSRF
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Validar token CSRF
function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Subir archivo
function uploadFile($file, $directory = '') {
    $targetDir = UPLOAD_DIR . $directory;
    
    // Crear directorio si no existe
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    $fileName = uniqid() . '_' . basename($file['name']);
    $targetPath = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
    
    // Validar tipo de archivo
    if (!in_array($fileType, ALLOWED_EXTENSIONS)) {
        throw new Exception('Tipo de archivo no permitido.');
    }
    
    // Validar tamaño
    if ($file['size'] > MAX_UPLOAD_SIZE) {
        throw new Exception('El archivo es demasiado grande. El tamaño máximo permitido es ' . (MAX_UPLOAD_SIZE / 1024 / 1024) . 'MB');
    }
    
    // Mover archivo
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return '/uploads/' . $directory . $fileName;
    }
    
    throw new Exception('Error al subir el archivo.');
}

// Formatear precio
function formatPrice($price) {
    return '$' . number_format($price, 2, ',', '.');
}

// Generar slug
function generateSlug($string) {
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $string)));
    $slug = preg_replace('/-+/', '-', $slug);
    return trim($slug, '-');
}

// Verificar si el usuario está autenticado
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

// Verificar si el usuario es administrador
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

// Verificar si el usuario es vendedor
function isSeller() {
    return isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['seller', 'admin']);
}

// Obtener ID de usuario actual
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

// Generar token JWT
function generateJWT($payload) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload['iat'] = time();
    $payload['exp'] = time() + JWT_EXPIRE;
    
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($payload)));
    
    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    
    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

// Validar token JWT
function validateJWT($token) {
    $tokenParts = explode('.', $token);
    
    if (count($tokenParts) !== 3) {
        return false;
    }
    
    list($base64UrlHeader, $base64UrlPayload, $signature) = $tokenParts;
    
    $header = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64UrlHeader)), true);
    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64UrlPayload)), true);
    
    $signatureToVerify = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlSignatureToVerify = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signatureToVerify));
    
    if (!hash_equals($signature, $base64UrlSignatureToVerify)) {
        return false;
    }
    
    if (isset($payload['exp']) && $payload['exp'] < time()) {
        return false;
    }
    
    return $payload;
}