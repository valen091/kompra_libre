<?php
// includes/Router.php
class Router {
    private $routes = [];
    private $notFound;

    public function addRoute($method, $path, $handler) {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler
        ];
    }

    public function setNotFound($handler) {
        $this->notFound = $handler;
    }

    public function dispatch() {
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $method = $_SERVER['REQUEST_METHOD'];

        foreach ($this->routes as $route) {
            if ($route['method'] === $method && $route['path'] === $uri) {
                return call_user_func($route['handler']);
            }
        }

        if ($this->notFound) {
            return call_user_func($this->notFound);
        }

        http_response_code(404);
        echo '404 Not Found';
    }
}