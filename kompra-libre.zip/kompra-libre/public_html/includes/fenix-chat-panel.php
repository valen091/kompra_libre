<?php
// This file should be included in your layout/header to show the chat panel on all pages
?>
<!-- Fenix Chat Panel -->
<link rel="stylesheet" href="/css/fenix-chat.css">

<div id="fenix-chat-container" class="fixed bottom-6 right-6 z-50">
    <!-- Chat header (minimized state) -->
    <div id="fenix-chat-header" class="bg-yellow-500 text-white p-3 rounded-full shadow-lg cursor-pointer hover:bg-yellow-600 transition-colors duration-200 flex items-center">
        <div class="w-10 h-10 bg-yellow-600 rounded-full flex items-center justify-center flex-shrink-0">
            <i class="fas fa-robot text-xl"></i>
        </div>
        <span class="ml-3 font-medium hidden md:inline">Fénix Asistente</span>
        <div id="fenix-notification" class="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white hidden"></div>
    </div>

    <!-- Chat content (expanded state) -->
    <div id="fenix-chat-content" class="hidden absolute bottom-full right-0 mb-3 w-80 bg-white rounded-lg shadow-xl overflow-hidden flex flex-col" style="height: 500px;">
        <!-- Chat header -->
        <div class="bg-yellow-500 text-white p-3 flex items-center justify-between">
            <div class="flex items-center space-x-2">
                <div class="w-8 h-8 bg-yellow-600 rounded-full flex items-center justify-center">
                    <i class="fas fa-robot"></i>
                </div>
                <span class="font-semibold">Fénix Asistente</span>
            </div>
            <div class="flex space-x-2">
                <button id="minimize-chat" class="text-white hover:text-gray-200">
                    <i class="fas fa-window-minimize"></i>
                </button>
                <button id="close-chat" class="text-white hover:text-gray-200">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <!-- Chat messages -->
        <div class="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50" id="chat-messages">
            <!-- Welcome message -->
            <div class="flex items-start space-x-2">
                <div class="w-8 h-8 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-robot text-sm"></i>
                </div>
                <div class="bg-white p-3 rounded-lg shadow-sm max-w-[80%]">
                    <p class="text-sm text-gray-800">¡Hola! Soy Fénix, tu asistente de Kompra Libre. ¿En qué puedo ayudarte hoy?</p>
                    <p class="text-xs text-gray-400 mt-1">Ahora</p>
                </div>
            </div>
        </div>

        <!-- Chat input -->
        <div class="border-t border-gray-200 p-3 bg-white">
            <div class="flex items-center space-x-2">
                <input type="text" id="user-input" 
                    class="flex-1 border border-gray-300 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                    placeholder="Escribe tu pregunta...">
                <button id="send-message" class="bg-yellow-500 hover:bg-yellow-600 text-white rounded-full w-10 h-10 flex items-center justify-center">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
            <p class="text-xs text-gray-500 mt-2 text-center">Fénix puede cometer errores. Verifica la información importante.</p>
        </div>
    </div>
</div>

<!-- Include the chat functionality -->
<script src="/js/fenix-chat.js"></script>
