<?php
// Configuración para entorno de producción en EC2 AWS
define('APP_NAME', 'Kompra Libre');
define('APP_URL', 'https://kompralibre.shop');
define('APP_DEBUG', false);  // Desactivar en producción

// Configuración de la base de datos para EC2
define('DB_HOST', 'localhost');
define('DB_NAME', 'u472738607_kompra_libre');
define('DB_USER', 'u472738607_kompra_libre');
define('DB_PASS', 'Kompralibre1');  // Cambiar por una contraseña segura

// Configuración de sesión segura
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 1);  // Solo HTTPS
ini_set('session.cookie_samesite', 'Strict');
session_name('kompra_libre_session');
session_set_cookie_params([
    'lifetime' => 86400,
    'path' => '/',
    'domain' => '.kompralibre.shop',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);
session_start();

define('SESSION_NAME', 'kompra_libre_session');
define('SESSION_LIFETIME', 86400);

// Clave secreta para JWT - ¡Cambiar por una clave segura!
define('JWT_SECRET', 'Kompralibre1');
define('JWT_EXPIRE', 86400);

// Configuración de subida de archivos
define('UPLOAD_DIR', '/var/www/kompra-libre/public_html/uploads/');
define('MAX_UPLOAD_SIZE', 20 * 1024 * 1024);  // 20MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// Configuración de errores (desactivar en producción)
error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT & ~E_NOTICE);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/php/kompra-libre-error.log');

// Usar la zona horaria del sistema
date_default_timezone_set(date_default_timezone_get());
error_log('Using system timezone in production: ' . date_default_timezone_get());

// Configuración de CORS
header('Access-Control-Allow-Origin: https://kompralibre.shop/');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Forzar HTTPS en producción
if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], true, 301);
    exit();
}
