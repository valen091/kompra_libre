<?php
/**
 * Clase Database - Gestiona la conexión a la base de datos
 * Implementa el patrón Singleton para una única instancia de conexión
 * 
 * @package KompraLibre
 * @version 2.0
 */
class Database {
    /**
     * @var PDO Instancia de PDO para la conexión a la base de datos
     */
    private static $instance = null;
    
    /**
     * @var PDO Instancia de PDO para transacciones
     */
    private $connection = null;
    
    /**
     * @var int Contador de transacciones anidadas
     */
    private $transactionCounter = 0;
    
    /**
     * Constructor privado para evitar instanciación directa
     */
    private function __construct() {
        try {
            // Configuración de la conexión PDO
            $dsn = "mysql:host=" . DB_HOST . 
                  ";dbname=" . DB_NAME . 
                  ";port=" . DB_PORT . 
                  ";charset=utf8mb4";
            
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_PERSISTENT         => true,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
                PDO::ATTR_STATEMENT_CLASS    => ['CustomPDOStatement', []]
            ];
            
            // Crear la conexión PDO
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
            
            // Configurar atributos adicionales
            $this->connection->setAttribute(PDO::ATTR_STRINGIFY_FETCHES, false);
            
        } catch (PDOException $e) {
            // Registrar el error
            error_log("Error de conexión a la base de datos: " . $e->getMessage());
            
            // Mostrar mensaje amigable en producción
            if (!APP_DEBUG) {
                http_response_code(503);
                include_once __DIR__ . '/error/503.php';
                exit;
            }
            
            throw new PDOException("Error al conectar con la base de datos: " . $e->getMessage(), (int)$e->getCode());
        }
    }
    
    /**
     * Obtener la instancia única de la base de datos
     * 
     * @return Database Instancia única de la clase Database
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Obtener la conexión PDO
     * 
     * @return PDO Instancia de PDO
     */
    public function getConnection() {
        return $this->connection;
    }
    
    /**
     * Prevenir la clonación del objeto
     */
    private function __clone() {}
    
    /**
     * Prevenir la deserialización del objeto
     */
    public function __wakeup() {
        throw new Exception("No se puede deserializar una instancia de " . get_class($this) . ".");
    }
    
    /**
     * Ejecutar una consulta SQL con parámetros
     * 
     * @param string $sql Consulta SQL
     * @param array $params Parámetros para la consulta preparada
     * @return PDOStatement|false Retorna el statement ejecutado o false en caso de error
     */
    public function query($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            
            if ($stmt === false) {
                throw new PDOException("Error al preparar la consulta: " . implode(" ", $this->connection->errorInfo()));
            }
            
            // Ejecutar la consulta con los parámetros
            $result = $stmt->execute($params);
            
            if ($result === false) {
                throw new PDOException("Error al ejecutar la consulta: " . implode(" ", $stmt->errorInfo()));
            }
            
            return $stmt;
            
        } catch (PDOException $e) {
            error_log("Error en la consulta SQL: " . $e->getMessage());
            error_log("Consulta: " . $sql);
            error_log("Parámetros: " . print_r($params, true));
            
            if (APP_DEBUG) {
                throw $e;
            }
            
            return false;
        }
    }
    
    /**
     * Obtener una fila de resultados
     * 
     * @param string $sql Consulta SQL
     * @param array $params Parámetros para la consulta preparada
     * @return array|false Retorna un array asociativo con la fila o false si no hay resultados
     */
    public function fetch($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt ? $stmt->fetch() : false;
    }
    
    /**
     * Obtener todas las filas de resultados
     * 
     * @param string $sql Consulta SQL
     * @param array $params Parámetros para la consulta preparada
     * @return array Retorna un array con todas las filas
     */
    public function fetchAll($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt ? $stmt->fetchAll() : [];
    }
    
    /**
     * Obtener un valor único (primera columna de la primera fila)
     * 
     * @param string $sql Consulta SQL
     * @param array $params Parámetros para la consulta preparada
     * @return mixed Retorna el valor o false si no hay resultados
     */
    public function fetchColumn($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt ? $stmt->fetchColumn() : false;
    }
    
    /**
     * Insertar un registro y retornar el ID
     * 
     * @param string $table Nombre de la tabla
     * @param array $data Datos a insertar (array asociativo columna => valor)
     * @return int|false Retorna el ID del registro insertado o false en caso de error
     */
    public function insert($table, $data) {
        if (empty($data)) {
            return false;
        }
        
        $columns = array_keys($data);
        $placeholders = array_map(function($col) { 
            return ":$col"; 
        }, $columns);
        
        $sql = "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) 
                VALUES (" . implode(', ', $placeholders) . ")";
        
        $stmt = $this->query($sql, $data);
        
        if ($stmt) {
            return $this->connection->lastInsertId();
        }
        
        return false;
    }
    
    /**
     * Actualizar registros
     * 
     * @param string $table Nombre de la tabla
     * @param array $data Datos a actualizar (array asociativo columna => valor)
     * @param string $where Condición WHERE (sin la palabra WHERE)
     * @param array $params Parámetros adicionales para la condición WHERE
     * @return int Número de filas afectadas
     */
    public function update($table, $data, $where, $params = []) {
        if (empty($data)) {
            return 0;
        }
        
        $set = [];
        $values = [];
        
        foreach ($data as $column => $value) {
            $set[] = "`$column` = :set_$column";
            $values["set_$column"] = $value;
        }
        
        $sql = "UPDATE `$table` SET " . implode(', ', $set) . " WHERE $where";
        
        // Combinar los valores de actualización con los parámetros adicionales
        $values = array_merge($values, $params);
        
        $stmt = $this->query($sql, $values);
        
        return $stmt ? $stmt->rowCount() : 0;
    }
    
    /**
     * Eliminar registros
     * 
     * @param string $table Nombre de la tabla
     * @param string $where Condición WHERE (sin la palabra WHERE)
     * @param array $params Parámetros para la condición WHERE
     * @return int Número de filas afectadas
     */
    public function delete($table, $where, $params = []) {
        $sql = "DELETE FROM `$table` WHERE $where";
        $stmt = $this->query($sql, $params);
        return $stmt ? $stmt->rowCount() : 0;
    }
    
    /**
     * Iniciar una transacción
     * 
     * @return bool true si la transacción se inició correctamente
     */
    public function beginTransaction() {
        if ($this->transactionCounter === 0) {
            $this->transactionCounter++;
            return $this->connection->beginTransaction();
        }
        
        $this->transactionCounter++;
        return $this->connection->exec('SAVEPOINT trans' . $this->transactionCounter) !== false;
    }
    
    /**
     * Confirmar una transacción
     * 
     * @return bool true si la transacción se confirmó correctamente
     */
    public function commit() {
        if ($this->transactionCounter === 0) {
            return false;
        }
        
        $result = true;
        
        if ($this->transactionCounter === 1) {
            $result = $this->connection->commit();
        }
        
        $this->transactionCounter--;
        return $result;
    }
    
    /**
     * Revertir una transacción
     * 
     * @return bool true si la transacción se revirtió correctamente
     */
    public function rollback() {
        if ($this->transactionCounter === 0) {
            return false;
        }
        
        $result = true;
        
        if ($this->transactionCounter === 1) {
            $result = $this->connection->rollBack();
        } else {
            $this->connection->exec('ROLLBACK TO trans' . $this->transactionCounter);
        }
        
        $this->transactionCounter--;
        return $result;
    }
    
    /**
     * Escapar un valor para usarlo en una consulta SQL
     * 
     * @param mixed $value Valor a escapar
     * @return string Valor escapado
     */
    public function quote($value) {
        return $this->connection->quote($value);
    }
    
    /**
     * Obtener el ID del último registro insertado
     * 
     * @param string $name Nombre de la secuencia (opcional)
     * @return string ID del último registro insertado
     */
    public function lastInsertId($name = null) {
        return $this->connection->lastInsertId($name);
    }
}

/**
 * Clase CustomPDOStatement para extender la funcionalidad de PDOStatement
 */
class CustomPDOStatement extends PDOStatement {
    protected function __construct() {}
    
    /**
     * Ejecutar una sentencia preparada con parámetros
     * 
     * @param array $params Parámetros para la consulta
     * @return bool true en caso de éxito, false en caso de error
     */
    public function execute($params = []) {
        try {
            return parent::execute($params);
        } catch (PDOException $e) {
            error_log("Error en la ejecución de la consulta: " . $e->getMessage());
            error_log("Consulta: " . $this->queryString);
            error_log("Parámetros: " . print_r($params, true));
            
            if (APP_DEBUG) {
                throw $e;
            }
            
            return false;
        }
    }
}
?>