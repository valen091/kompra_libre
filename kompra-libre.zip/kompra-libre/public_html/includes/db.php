<?php
// Check if database credentials are defined
if (!defined('DB_HOST') || !defined('DB_NAME') || !defined('DB_USER') || !defined('DB_PASS')) {
    die('Database configuration is incomplete');
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Global PDO connection
$db = null;
$connectionAttempts = 0;
$maxAttempts = 2;
$lastError = null;

// Try multiple connection methods
$connectionConfigs = [
    [
        'dsn' => 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        'user' => DB_USER,
        'pass' => DB_PASS,
        'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            PDO::ATTR_TIMEOUT => 5,
            PDO::ATTR_PERSISTENT => false
        ]
    ],
    // Alternative connection for Hostinger
    [
        'dsn' => 'mysql:host=localhost;dbname=' . DB_NAME . ';charset=utf8mb4',
        'user' => DB_USER,
        'pass' => DB_PASS,
        'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]
    ]
];

foreach ($connectionConfigs as $config) {
    try {
        $db = new PDO(
            $config['dsn'],
            $config['user'],
            $config['pass'],
            $config['options']
        );
        
        // Set additional session variables
        $db->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
        $db->exec("SET SESSION time_zone='America/Montevideo'");
        
        // If we get here, connection was successful
        break;
        
    } catch (PDOException $e) {
        $lastError = $e->getMessage();
        error_log('Database connection attempt failed: ' . $lastError);
        
        // If this was the last attempt, throw the exception
        if (++$connectionAttempts >= $maxAttempts) {
            // Log detailed error but show generic message to user
            error_log('All database connection attempts failed. Last error: ' . $lastError);
            
            // Return JSON response for API requests
            if (strpos($_SERVER['REQUEST_URI'], '/api/') !== false) {
                header('Content-Type: application/json');
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'message' => 'Error de conexión con la base de datos. Por favor, intente nuevamente.'
                ]);
                exit();
            } else {
                // For regular page loads
                die('Error de conexión con la base de datos. Por favor, intente nuevamente.');
            }
        }
    }
}

// If we get here and $db is still null, no connection was successful
if ($db === null) {
    throw new RuntimeException('No se pudo establecer conexión con la base de datos. Por favor, verifique la configuración.');
}

class DB {
    private static $i=null;private $c=null;private const O=[
        3=>2,2=>2,1000=>0,1002=>"SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
        1001=>1];private function __construct(){$this->c();}
    private function c(){
        try{$this->c=new PDO(sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4',DB_HOST,DB_NAME),DB_USER,DB_PASS,self::O);
            $this->c->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
            $this->c->exec("SET SESSION time_zone='America/Montevideo'");
        }catch(PDOException$e){throw new RuntimeException('Error de conexión a la base de datos',500);}
    }
    public static function gI(){return self::$i??=new self();}
    public function gC(){return $this->c??$this->c();}
    private function __clone(){}
    public function __wakeup(){throw new RuntimeException('No se puede deserializar');}
}
/**
 * Get database connection instance (singleton)
 * 
 * @return PDO
 */
function getDB() {
    global $db;
    if ($db === null) {
        throw new RuntimeException('Database connection not initialized');
    }
    return $db;
}

/**
 * Alias for getDB() for backward compatibility
 * 
 * @return PDO
 */
function getDBConnection() {
    return getDB();
}
