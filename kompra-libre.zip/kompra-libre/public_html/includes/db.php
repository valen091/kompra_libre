<?php
// Check if database credentials are defined
if (!defined('DB_HOST') || !defined('DB_NAME') || !defined('DB_USER') || !defined('DB_PASS')) {
    // Try to load from .env file if exists
    $envFile = __DIR__ . '/../.env';
    if (file_exists($envFile)) {
        $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos(trim($line), '#') === 0) continue;
            
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);
            
            // Remove quotes if present
            if (($value[0] === '"' && $value[strlen($value) - 1] === '"') || 
                ($value[0] === "'" && $value[strlen($value) - 1] === "'")) {
                $value = substr($value, 1, -1);
            }
            
            define($name, $value);
        }
    } else {
        // Set default values if .env doesn't exist
        define('DB_HOST', 'localhost');
        define('DB_NAME', 'u472738607_kompra_libre');
        define('DB_USER', 'u472738607_kompra_libre');
        define('DB_PASS', 'Kompralibre1');
        define('DB_PORT', '3306');
        define('APP_DEBUG', true);
    }
}

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Global PDO connection
$db = null;

// Database configuration for Hostinger
$dsn = 'mysql:host=' . DB_HOST . ';port=' . (defined('DB_PORT') ? DB_PORT : '3306') . ';dbname=' . DB_NAME . ';charset=utf8mb4';
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::ATTR_TIMEOUT => 5,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
];

try {
    $db = new PDO($dsn, DB_USER, DB_PASS, $options);
    // Set SQL mode only - no timezone setting
    $db->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
} catch (PDOException $e) {
    // Log the error
    error_log('Database connection failed: ' . $e->getMessage());
    
    // Show user-friendly error in production
    if (defined('APP_DEBUG') && APP_DEBUG) {
        // Show detailed error in development
        die('<h2 style="color: red;">Error de conexión a la base de datos</h2>' .
            '<p><strong>Mensaje:</strong> ' . $e->getMessage() . '</p>' .
            '<h3>Detalles de la conexión:</h3>' .
            '<pre>Host: ' . DB_HOST . 
            '\nBase de datos: ' . DB_NAME . 
            '\nUsuario: ' . DB_USER . 
            '\nDSN: ' . $dsn . '</pre>');
    } else {
        die('Error de conexión con la base de datos. Por favor, intente nuevamente más tarde.');
    }
    throw new RuntimeException('No se pudo conectar a la base de datos: ' . $e->getMessage());
}

/**
 * DB Class - Singleton pattern for database connection
 */
class DB {
    private static $instance = null;
    private $connection = null;
    
    // Private constructor to prevent creating multiple instances
    private function __construct() {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . (defined('DB_PORT') ? DB_PORT : '3306') . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ]);
            
            // Set SQL mode only - no timezone setting
            $this->connection->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
            
            // Log that we're not setting a timezone
            error_log('Database connection established without setting timezone');
            
        } catch (PDOException $e) {
            error_log('DB Connection Error: ' . $e->getMessage());
            if (defined('APP_DEBUG') && APP_DEBUG) {
                throw new RuntimeException('Error de conexión a la base de datos: ' . $e->getMessage());
            } else {
                throw new RuntimeException('No se pudo conectar a la base de datos. Por favor, intente más tarde.');
            }
        }
    }
    
    /**
     * Get the DB instance
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Get the database connection
     */
    public function getConnection() {
        return $this->connection;
    }
    
    // Prevent cloning of the instance
    private function __clone() {}
    
    // Prevent unserializing of the instance
    public function __wakeup() {
        throw new RuntimeException('No se puede deserializar la instancia de DB');
    }
}
/**
 * Get database connection instance (singleton)
 * 
 * @return PDO
 */
function getDB() {
    global $db;
    global $dsn, $options;
    
    if ($db === null) {
        // Try to reconnect once
        try {
            $db = new PDO($dsn, DB_USER, DB_PASS, $options);
            // Set SQL mode only - no timezone setting
            $db->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
        } catch (PDOException $e) {
            // Log the error
            error_log('Database connection error: ' . $e->getMessage());
            
            // Show user-friendly error in production
            if (!defined('APP_DEBUG') || !APP_DEBUG) {
                die('Error de conexión con la base de datos. Por favor, intente nuevamente más tarde.');
            }
            
            // Show detailed error in development
            throw new Exception('No se pudo establecer conexión con la base de datos: ' . $e->getMessage());
        }
    }
    
    return $db;
}

/**
 * Alias for getDB() for backward compatibility
 * 
 * @return PDO
 */
function getDBConnection() {
    return getDB();
}
