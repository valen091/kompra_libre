<?php
// Database connection - simplified
class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];

            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Log del error para debugging pero no mostrar HTML
            error_log("Database connection error: " . $e->getMessage());
            throw new Exception("Error de conexión a la base de datos", 500);
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }

    // Evitar la clonación del objeto
    private function __clone() {}

    // Evitar la deserialización del objeto
    private function __wakeup() {}
}

// Función helper para obtener la conexión
function getDB() {
    try {
        return Database::getInstance()->getConnection();
    } catch (Exception $e) {
        // Re-lanzar la excepción para que sea manejada por el endpoint
        throw $e;
    }
}