<?php
// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'u472738607_kompra_libre');
define('DB_USER', 'u472738607_kompra_libre');
define('DB_PASS', 'Kompralibre1');

// Función simple para conectar a la base de datos
function conectarDB() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        
        // Configuraciones adicionales
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->exec("SET NAMES utf8mb4");
        
        return $pdo;
    } catch (PDOException $e) {
        // Mostrar error detallado
        die('Error de conexión: ' . $e->getMessage() . 
            '<br>Host: ' . DB_HOST . 
            '<br>Base de datos: ' . DB_NAME . 
            '<br>Usuario: ' . DB_USER);
    }
}

// Crear conexión global
$db = conectarDB();
