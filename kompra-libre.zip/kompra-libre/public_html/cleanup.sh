#!/bin/bash
# Script de limpieza final - Kompra Libre
echo "🧹 Limpiando archivos temporales..."

# Archivos a eliminar
temp_files=(
    "backup-and-revert.ps1"
    "complete-reorganize.ps1"
    "reorganize-files-simple.ps1"
    "reorganize-files.ps1"
    "reorganize-files.sh"
    "REORGANIZAR-LEEME.md"
)

for file in "${temp_files[@]}"; do
    if [ -f "$file" ]; then
        rm "$file"
        echo "✅ Eliminado: $file"
    fi
done

echo ""
echo "🎉 Limpieza completada!"
echo ""
echo "📋 Estructura final limpia:"
echo "📂 config/  - Archivos de configuración"
echo "📂 docs/    - Documentación completa"
echo "📂 setup/   - Scripts de instalación"
echo "📂 pages/   - Páginas HTML"
echo "📂 tests/   - Scripts de prueba"
echo "📂 scripts/ - API y utilitarios"
echo ""
echo "🚀 ¡Proyecto listo para usar!"
