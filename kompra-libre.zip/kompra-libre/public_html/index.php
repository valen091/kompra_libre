<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Start session with proper configuration
$sessionParams = [
    'cookie_httponly' => true,
    'cookie_secure' => isset($_SERVER['HTTPS']),
    'use_strict_mode' => true,
    'cookie_lifetime' => 86400, // 24 horas
    'gc_maxlifetime' => 86400,  // 24 horas
    'cookie_samesite' => 'Lax'  // Protección CSRF
];

if (session_status() === PHP_SESSION_NONE) {
    session_start($sessionParams);
}

// Verificar si hay una sesión de usuario antigua y migrarla al nuevo formato
if (isset($_SESSION['user_id']) && !isset($_SESSION['user'])) {
    $_SESSION['user'] = [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'] ?? 'Usuario',
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'client'
    ];
}

// Include database connection
require_once __DIR__ . '/includes/simple-db.php';

// Function to get featured products
function getFeaturedProducts($limit = 8) {
    global $db;
    try {
        $stmt = $db->prepare("
            SELECT p.*, c.nombre as categoria 
            FROM productos p
            LEFT JOIN categorias c ON p.categoria_id = c.id
            WHERE p.estado = 'activo'
            ORDER BY p.fecha_creacion DESC
            LIMIT :limit
        ");
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting featured products: " . $e->getMessage());
        return [];
    }
}

// Function to get categories
function getCategories() {
    global $db;
    try {
        $stmt = $db->query("
            SELECT * FROM categorias 
            WHERE estado = 'activo'
            ORDER BY nombre ASC
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting categories: " . $e->getMessage());
        return [];
    }
}

// Get data
$featuredProducts = getFeaturedProducts(8);
$categories = getCategories();

// Define main categories
$mainCategories = [
    'Moda y Accesorios' => [
        'icon' => '👕',
        'subcategories' => [
            'Ropa Hombre' => '👔 Ropa para hombre',
            'Ropa Mujer' => '👗 Ropa para mujer',
            'Ropa Niños' => '👶 Ropa para niños',
            'Calzado' => '👟 Calzado',
            'Bolsos y Mochilas' => '🎒 Bolsos y mochilas',
            'Joyería y Relojes' => '⌚ Joyería y relojes',
            'Accesorios' => '👓 Accesorios varios'
        ]
    ],
    'Electrónica y Tecnología' => [
        'icon' => '📱',
        'subcategories' => [
            'Smartphones y Tablets' => '📱 Smartphones y tablets',
            'Computación' => '💻 Computadoras y laptops',
            'TV y Audio' => '📺 Televisores y audio',
            'Wearables' => '⌚ Wearables',
            'Accesorios' => '🎧 Accesorios tecnológicos',
            'Gaming' => '🎮 Videojuegos'
        ]
    ],
    // Add other categories similarly
];

// If no categories from DB, use default ones
if (empty($categories) && !empty($mainCategories)) {
    $categories = array_map(function($name, $data) {
        return [
            'id' => strtolower(str_replace(' ', '-', $name)),
            'nombre' => $name,
            'icono' => $data['icon'],
            'subcategorias' => $data['subcategories']
        ];
    }, array_keys($mainCategories), $mainCategories);
}
?>
<!DOCTYPE html>
<html lang="es" class="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kompra Libre - Marketplace Educativo</title>
    <meta name="description" content="Compra y vende productos en Kompra Libre. Encuentra ofertas en moda, tecnología, hogar y más.">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/assets/img/favicon.png">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Custom Tailwind Config -->
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FFD700',    // Gold
                        secondary: '#FF69B4',  // Fuchsia Pink
                        accent: '#87CEEB',     // Light Blue
                    }
                }
            }
        }
    </script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom Styles -->
    <style>
        /* Dark mode overrides */
        .dark {
            --tw-bg-opacity: 1;
            background-color: #1a202c;
            color: #e2e8f0;
        }
        
        .dark .bg-white {
            background-color: #2d3748 !important;
        }
        
        .dark .text-gray-900 {
            color: #e2e8f0 !important;
        }
        
        .dark .text-gray-700 {
            color: #cbd5e0 !important;
        }
        
        .dark .border-gray-200 {
            border-color: #4a5568 !important;
        }
        
        /* Smooth transitions */
        .transition-all {
            transition-property: all;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
            transition-duration: 150ms;
        }
        
        /* Ensure text is readable in dark mode */
        .dark .category-item {
            color: #e2e8f0 !important;
            background-color: #2d3748 !important;
            border-color: #4a5568 !important;
        }
        
        .dark .category-item:hover {
            background-color: #4a5568 !important;
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        .dark ::-webkit-scrollbar-track {
            background: #2d3748;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #cbd5e0;
            border-radius: 4px;
        }
        
        .dark ::-webkit-scrollbar-thumb {
            background: #4a5568;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #a0aec0;
        }
        
        .dark ::-webkit-scrollbar-thumb:hover {
            background: #718096;
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 min-h-screen flex flex-col">
    <!-- Header -->
    <header class="bg-gradient-to-r from-yellow-400 to-yellow-500 dark:from-yellow-600 dark:to-yellow-700 shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <!-- Logo -->
                <div class="flex items-center space-x-8">
                    <a href="/" class="flex items-center">
                        <img src="/assets/img/logo.png" alt="Kompra Libre" class="h-12">
                    </a>
                    
                    <!-- Navigation -->
                    <nav class="hidden md:flex items-center space-x-6">
                        <a href="/" class="text-gray-900 dark:text-white hover:text-yellow-100 px-3 py-2 rounded-md text-sm font-medium">Inicio</a>
                        <a href="/categorias" class="text-gray-900 dark:text-white hover:text-yellow-100 px-3 py-2 rounded-md text-sm font-medium">Categorías</a>
                        <a href="/ofertas" class="text-gray-900 dark:text-white hover:text-yellow-100 px-3 py-2 rounded-md text-sm font-medium">Ofertas</a>
                        <a href="/nuevo" class="text-gray-900 dark:text-white hover:text-yellow-100 px-3 py-2 rounded-md text-sm font-medium">Nuevo</a>
                    </nav>
                </div>

                <!-- Search -->
                <div class="flex-1 max-w-xl mx-4">
                    <div class="relative">
                        <input type="text" placeholder="Buscar productos..." class="w-full pl-10 pr-4 py-2 rounded-full border-0 text-gray-900 focus:ring-2 focus:ring-yellow-500 focus:ring-offset-2">
                        <div class="absolute left-3 top-2.5 text-gray-400">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>
                </div>

                <!-- User Menu -->
                <div class="flex items-center space-x-4">
                    <?php 
                    $isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['user']);
                    $userName = '';
                    $userRole = '';
                    $userInitial = '';
                    
                    if (isset($_SESSION['user'])) {
                        $userName = $_SESSION['user']['name'] ?? '';
                        $userRole = $_SESSION['user']['role'] ?? '';
                        $userInitial = !empty($userName) ? strtoupper(substr($userName, 0, 1)) : 'U';
                    } elseif (isset($_SESSION['user_name'])) {
                        $userName = $_SESSION['user_name'];
                        $userRole = $_SESSION['user_role'] ?? '';
                        $userInitial = !empty($userName) ? strtoupper(substr($userName, 0, 1)) : 'U';
                    }
                    
                    // Determine dashboard URL based on user role
                    $dashboardUrl = '/';
                    $dashboardText = 'Panel de Usuario';
                    
                    if ($userRole === 'admin') {
                        $dashboardUrl = '/views/admin/dashboard.php';
                        $dashboardText = 'Panel de Administración';
                    } elseif ($userRole === 'seller' || $userRole === 'vendedor') {
                        $dashboardUrl = '/views/seller/dashboard.php';
                        $dashboardText = 'Panel de Vendedor';
                    } elseif ($userRole === 'client' || $userRole === 'cliente') {
                        $dashboardUrl = '/views/client/dashboard.php';
                        $dashboardText = 'Mi Cuenta';
                    }
                    ?>
                    
                    <?php if ($isLoggedIn): ?>
                        <!-- User Dropdown with Gear Icon -->
                        <div class="relative group" id="user-menu">
                            <button type="button" 
                                    class="flex items-center justify-center w-10 h-10 rounded-full bg-yellow-100 dark:bg-yellow-800 text-yellow-600 dark:text-yellow-200 hover:bg-yellow-200 dark:hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 transition-colors"
                                    aria-expanded="false"
                                    aria-haspopup="true">
                                <i class="fas fa-cog text-lg"></i>
                            </button>
                            
                            <!-- Dropdown menu -->
                            <div class="hidden group-hover:block absolute right-0 mt-2 w-56 origin-top-right bg-white dark:bg-gray-800 rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none z-50">
                                <div class="py-1" role="none">
                                    <!-- User Info -->
                                    <div class="px-4 py-2 border-b border-gray-100 dark:border-gray-700">
                                        <p class="text-sm font-medium text-gray-900 dark:text-white truncate">
                                            <?= htmlspecialchars($userName) ?: 'Usuario' ?>
                                        </p>
                                        <p class="text-xs text-gray-500 truncate">
                                            <?= htmlspecialchars($userRole) ? ucfirst($userRole) : 'Usuario' ?>
                                        </p>
                                    </div>
                                    
                                    <!-- Dashboard Link -->
                                    <a href="<?= $dashboardUrl ?>" 
                                       class="flex items-center px-4 py-2.5 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                                       role="menuitem">
                                        <i class="fas fa-tachometer-alt w-5 mr-3 text-gray-500"></i>
                                        <?= $dashboardText ?>
                                    </a>
                                    
                                    <!-- Logout Button -->
                                    <form action="/auth/logout.php" method="POST" class="w-full">
                                        <button type="submit" 
                                                class="w-full text-left flex items-center px-4 py-2.5 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                                                role="menuitem">
                                            <i class="fas fa-sign-out-alt w-5 mr-3"></i>
                                            Cerrar Sesión
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <!-- Login Button -->
                        <a href="/login" 
                           class="flex items-center px-3 py-1.5 text-sm rounded-md bg-yellow-100 dark:bg-yellow-800 text-yellow-700 dark:text-yellow-200 hover:bg-yellow-200 dark:hover:bg-yellow-700 transition-colors">
                            <i class="fas fa-user mr-2"></i>
                            <span class="hidden md:inline">Iniciar Sesión</span>
                        </a>
                    <?php endif; ?>
                </div>
                
                <!-- Cart -->
                <a href="/carrito" class="p-2 text-gray-900 dark:text-white hover:text-yellow-100 relative">
                    <i class="fas fa-shopping-cart text-xl"></i>
                    <span class="absolute -top-1 -right-1 bg-pink-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">0</span>
                </a>
                    
                    <!-- Social Media -->
                    <div class="hidden md:flex items-center space-x-3 ml-2">
                        <a href="https://facebook.com" target="_blank" class="text-gray-900 dark:text-white hover:text-yellow-100">
                            <i class="fab fa-facebook text-xl"></i>
                        </a>
                        <a href="https://instagram.com" target="_blank" class="text-gray-900 dark:text-white hover:text-yellow-100">
                            <i class="fab fa-instagram text-xl"></i>
                        </a>
                        <a href="https://x.com" target="_blank" class="text-gray-900 dark:text-white hover:text-yellow-100">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path d="M13.6823 10.6218L20.239 3H18.6854L12.9921 9.61788L8.44486 3H3.2002L10.0765 13.0074L3.2002 21H4.75404L10.7663 14.0113L15.5685 21H20.8131L13.6819 10.6218H13.6823ZM11.5541 13.0956L10.8574 12.0991L5.31391 4.16971H7.70053L12.1742 10.5689L12.8709 11.5655L18.6861 19.8835H16.2995L11.5541 13.096V13.0956Z"></path>
                            </svg>
                        </a>
                    </div>
                    
                    <!-- Mobile menu button -->
                    <button id="mobile-menu-button" class="md:hidden p-2 text-gray-900 dark:text-white hover:text-yellow-100 focus:outline-none">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile menu -->
        <div id="mobile-menu" class="md:hidden hidden bg-yellow-400 dark:bg-yellow-700">
            <div class="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                <a href="/" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 dark:text-white hover:bg-yellow-500 dark:hover:bg-yellow-600">
                    <i class="fas fa-home mr-2"></i> Inicio
                </a>
                <a href="/categorias" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 dark:text-white hover:bg-yellow-500 dark:hover:bg-yellow-600">
                    <i class="fas fa-th-large mr-2"></i> Categorías
                </a>
                <a href="/ofertas" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 dark:text-white hover:bg-yellow-500 dark:hover:bg-yellow-600">
                    <i class="fas fa-tag mr-2"></i> Ofertas
                </a>
                <a href="/nuevo" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 dark:text-white hover:bg-yellow-500 dark:hover:bg-yellow-600">
                    <i class="fas fa-star mr-2"></i> Nuevo
                </a>
                <a href="/views/seller/dashboard.php" class="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-gray-100 bg-yellow-50">
                    <i class="fas fa-store mr-2"></i>Panel Vendedor
                </a>
                
                <div class="border-t border-yellow-500 dark:border-yellow-600 my-2"></div>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="/mi-cuenta" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 dark:text-white hover:bg-yellow-500 dark:hover:bg-yellow-600">
                        <i class="fas fa-user-circle mr-2"></i> Mi Cuenta
                    </a>
                    <a href="/mis-compras" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 dark:text-white hover:bg-yellow-500 dark:hover:bg-yellow-600">
                        <i class="fas fa-shopping-bag mr-2"></i> Mis Compras
                    </a>
                    <a href="/cerrar-sesion" class="block px-3 py-2 rounded-md text-base font-medium text-red-700 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-900/20">
                        <i class="fas fa-sign-out-alt mr-2"></i> Cerrar Sesión
                    </a>
                <?php else: ?>
                    <a href="/iniciar-sesion" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 dark:text-white hover:bg-yellow-500 dark:hover:bg-yellow-600">
                        <i class="fas fa-sign-in-alt mr-2"></i> Iniciar Sesión
                    </a>
                    <a href="/registro" class="block px-3 py-2 rounded-md text-base font-medium text-gray-900 dark:text-white hover:bg-yellow-500 dark:hover:bg-yellow-600">
                        <i class="fas fa-user-plus mr-2"></i> Registrarse
                    </a>
                <?php endif; ?>
                
                <!-- Mobile Social Media -->
                <div class="flex space-x-4 pt-2">
                    <a href="https://facebook.com" target="_blank" class="text-gray-900 dark:text-white hover:text-yellow-100">
                        <i class="fab fa-facebook text-2xl"></i>
                    </a>
                    <a href="https://instagram.com" target="_blank" class="text-gray-900 dark:text-white hover:text-yellow-100">
                        <i class="fab fa-instagram text-2xl"></i>
                    </a>
                    <a href="https://x.com" target="_blank" class="text-gray-900 dark:text-white hover:text-yellow-100">
                        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M13.6823 10.6218L20.239 3H18.6854L12.9921 9.61788L8.44486 3H3.2002L10.0765 13.0074L3.2002 21H4.75404L10.7663 14.0113L15.5685 21H20.8131L13.6819 10.6218H13.6823ZM11.5541 13.0956L10.8574 12.0991L5.31391 4.16971H7.70053L12.1742 10.5689L12.8709 11.5655L18.6861 19.8835H16.2995L11.5541 13.096V13.0956Z"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-yellow-400 via-pink-500 to-blue-300 dark:from-yellow-600 dark:via-pink-600 dark:to-blue-500 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">Bienvenido a Kompra Libre</h1>
            <p class="text-xl md:text-2xl mb-8">Encuentra todo lo que necesitas al mejor precio</p>
            <div class="max-w-2xl mx-auto">
                <form action="/buscar" method="GET" class="flex shadow-lg rounded-full overflow-hidden">
                    <input type="text" name="q" placeholder="¿Qué estás buscando?" 
                           class="flex-1 px-6 py-4 text-gray-900 focus:outline-none">
                    <a href="/views/seller/dashboard.php" class="ml-2 hidden md:block px-4 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600 transition-colors text-sm font-medium">
                        <i class="fas fa-store mr-1"></i> Panel Vendedor
                    </a>
                </form>
            </div>
            <div class="mt-8 flex flex-wrap justify-center gap-4">
                <span class="text-sm bg-white/20 px-4 py-2 rounded-full">Envíos a todo el país</span>
                <span class="text-sm bg-white/20 px-4 py-2 rounded-full">Pagos seguros</span>
                <span class="text-sm bg-white/20 px-4 py-2 rounded-full">Garantía de devolución</span>
            </div>
        </div>
    </section>

    <!-- Main Categories -->
    <section class="py-12 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 class="text-2xl font-bold mb-8 text-center">Explorar por Categorías</h2>
            
            <?php foreach ($mainCategories as $categoryName => $categoryData): ?>
                <div class="mb-12">
                    <h3 class="text-xl font-semibold mb-4 flex items-center">
                        <span class="mr-2"><?= $categoryData['icon'] ?></span> <?= $categoryName ?>
                    </h3>
                    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                        <?php foreach ($categoryData['subcategories'] as $subKey => $subCategory): ?>
                            <a href="/categoria/<?= strtolower(str_replace(' ', '-', $subKey)) ?>" 
                               class="bg-gray-50 p-4 rounded-lg hover:shadow-md transition-shadow flex items-center">
                                <span class="text-2xl mr-2"><?= explode(' ', $subCategory)[0] ?></span>
                                <div>
                                    <h4 class="font-medium"><?= $subCategory ?></h4>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Featured Products -->
    <main class="flex-grow">
    <!-- Featured Products -->
    <section class="py-12 bg-white dark:bg-gray-900">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
                <h2 class="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-4 md:mb-0">Productos Destacados</h2>
                <div class="flex items-center space-x-4 w-full md:w-auto">
                    <a href="/productos" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-pink-500 hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 dark:bg-pink-600 dark:hover:bg-pink-700">
                        Ver todos los productos
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                    <!-- Dark mode toggle -->
                    <button id="darkModeToggle" class="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-yellow-300 hover:bg-gray-300 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500">
                        <i class="fas fa-moon dark:hidden"></i>
                        <i class="fas fa-sun hidden dark:inline"></i>
                    </button>
                </div>
            </div>
            
            <!-- Categories -->
            <?php if (!empty($categories)): ?>
            <div class="mb-8">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-3">Explorar categorías</h3>
                <div class="flex flex-wrap gap-2">
                    <?php foreach ($categories as $category): ?>
                        <a href="/categoria/<?= htmlspecialchars($category['id']) ?>" 
                           class="inline-flex items-center px-3 py-2 rounded-full text-sm font-medium category-item">
                            <i class="fas fa-<?= $category['icono'] ?? 'tag' ?> mr-2"></i>
                            <?= htmlspecialchars($category['nombre']) ?>
                            <?php if (isset($category['count'])): ?>
                                <span class="ml-2 bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 text-xs font-medium px-2 py-0.5 rounded-full">
                                    <?= $category['count'] ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Products Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <?php if (!empty($featuredProducts)): ?>
                    <?php foreach ($featuredProducts as $product): ?>
                        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 border border-gray-100 dark:border-gray-700">
                            <!-- Product Image -->
                            <div class="h-48 bg-gray-100 dark:bg-gray-700 flex items-center justify-center p-4 relative">
                                <span class="bg-pink-500 text-white text-xs font-semibold px-2.5 py-0.5 rounded-full">
                                    Oferta
                                </span>
                            </div>
                            
                            <!-- Product Image -->
                            <div class="h-48 bg-gray-100 dark:bg-gray-600 flex items-center justify-center p-4">
                                <img src="<?= !empty($product['imagen']) ? '/uploads/productos/' . $product['imagen'] : '/assets/img/placeholder-product.jpg' ?>" 
                                     alt="<?= htmlspecialchars($product['nombre']) ?>" 
                                     class="h-full w-full object-contain">
                            </div>
                            
                            <!-- Product Info -->
                            <div class="p-4">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <h3 class="text-sm font-medium text-gray-900 dark:text-white line-clamp-2 h-10">
                                            <?= htmlspecialchars($product['nombre']) ?>
                                        </h3>
                                        <p class="mt-1 text-sm text-gray-500 dark:text-gray-300">
                                            <?= htmlspecialchars($product['categoria'] ?? 'Sin categoría') ?>
                                        <span class="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                                            -<?= $product['descuento'] ?>%
                                        </span>
                                    </div>
                                </div>
                                <div class="p-4">
                                    <h3 class="font-medium text-gray-900 mb-1"><?= htmlspecialchars($product['nombre']) ?></h3>
                                    <div class="flex items-center mb-2">
                                        <div class="text-yellow-400">
                                            <?php
                                            $rating = $product['valoracion_promedio'] ?? 0;
                                            $fullStars = floor($rating);
                                            $hasHalfStar = $rating - $fullStars >= 0.5;
                                            
                                            for ($i = 1; $i <= 5; $i++): 
                                                if ($i <= $fullStars): ?>
                                                    <i class="fas fa-star"></i>
                                                <?php elseif ($i == $fullStars + 1 && $hasHalfStar): ?>
                                                    <i class="fas fa-star-half-alt"></i>
                                                <?php else: ?>
                                                    <i class="far fa-star"></i>
                                                <?php endif; 
                                            endfor; ?>
                                        </div>
                                        <span class="text-xs text-gray-500 ml-1">(<?= $product['num_valoraciones'] ?? 0 ?>)</span>
                                    </div>
                                    <div class="flex items-center">
                                        <p class="text-lg font-bold text-gray-900">
                                            $<?= number_format($product['precio'] * (1 - (($product['descuento'] ?? 0) / 100)), 2) ?>
                                        </p>
                                        <?php if (isset($product['descuento']) && $product['descuento'] > 0): ?>
                                            <p class="ml-2 text-sm text-gray-500 line-through">$<?= number_format($product['precio'], 2) ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mt-2 text-sm text-green-600">
                                        <?= ($product['stock'] ?? 0) > 0 ? 'Envío gratis' : 'Agotado' ?>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-span-full text-center py-8">
                        <p class="text-gray-500">No hay productos destacados disponibles en este momento.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    </main>
    
    <!-- Footer -->
    <footer class="bg-gray-800 dark:bg-gray-900 text-white pt-12 pb-6">
        <!-- Newsletter -->
        <section class="bg-gradient-to-r from-yellow-400 to-pink-500 dark:from-yellow-600 dark:to-pink-600 py-12">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 class="text-2xl font-bold mb-4">¡Suscríbete a nuestro boletín!</h2>
            <p class="mb-6">Recibe ofertas exclusivas y descuentos en tu correo</p>
            <form class="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
                <input type="email" placeholder="Tu correo electrónico" class="flex-1 px-4 py-3 rounded-lg focus:outline-none text-gray-900">
                <button type="submit" class="bg-gray-900 hover:bg-black text-white font-medium px-6 py-3 rounded-lg transition-colors">
                    Suscribirse
                </button>
            </form>
        </div>
    </section>
    
    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Main Footer -->
            <div class="grid grid-cols-1 md:grid-cols-5 gap-8 mb-8">
                <!-- Logo and Description -->
                <div class="md:col-span-2">
                    <div class="flex items-center mb-4">
                        <img src="/assets/img/logo-white.png" alt="Kompra Libre" class="h-10">
                    </div>
                    <p class="text-gray-300 mb-4">Tu plataforma de compra y venta de productos nuevos y usados.</p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-300 hover:text-white"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-gray-300 hover:text-white"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-gray-300 hover:text-white"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-gray-300 hover:text-white"><i class="fab fa-tiktok"></i></a>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div>
                    <h3 class="text-lg font-semibold mb-4">Enlaces Rápidos</h3>
                    <p class="text-gray-400">Tu marketplace de confianza para comprar y vender productos de calidad.</p>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Categorías</h4>
                    <ul class="space-y-2">
                        <li><a href="/categoria/moda" class="text-gray-400 hover:text-white">Moda</a></li>
                        <li><a href="/categoria/electronica" class="text-gray-400 hover:text-white">Electrónica</a></li>
                        <li><a href="/categoria/hogar" class="text-gray-400 hover:text-white">Hogar</a></li>
                        <li><a href="/categoria/deportes" class="text-gray-400 hover:text-white">Deportes</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Mi Cuenta</h4>
                    <ul class="space-y-2">
                        <li><a href="/login" class="text-gray-400 hover:text-white">Iniciar sesión</a></li>
                        <li><a href="/registro" class="text-gray-400 hover:text-white">Registrarse</a></li>
                        <li><a href="/mi-cuenta" class="text-gray-400 hover:text-white">Mi perfil</a></li>
                        <li><a href="/mis-pedidos" class="text-gray-400 hover:text-white">Mis pedidos</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Contacto</h4>
                    <ul class="space-y-2">
                        <li class="flex items-center"><i class="fas fa-envelope mr-2"></i> ayuda@kompralibre.com</li>
                        <li class="flex items-center"><i class="fas fa-phone-alt mr-2"></i> +598 XX XXX XXX</li>
                        <li class="flex items-center"><i class="fas fa-map-marker-alt mr-2"></i> Montevideo, Uruguay</li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400 text-sm">
                <p>&copy; <?= date('Y') ?> Kompra Libre. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script>
        // Show user menu on hover/focus
        function showUserMenu() {
            const dropdown = document.getElementById('user-dropdown');
            if (dropdown) {
                dropdown.classList.remove('hidden');
                const button = document.getElementById('user-menu-button');
                if (button) {
                    button.setAttribute('aria-expanded', 'true');
                }
            }
        }
        
        // Hide user menu when mouse leaves
        function hideUserMenu() {
            const dropdown = document.getElementById('user-dropdown');
            if (dropdown) {
                dropdown.classList.add('hidden');
                const button = document.getElementById('user-menu-button');
                if (button) {
                    button.setAttribute('aria-expanded', 'false');
                }
            }
        }
        
        // Toggle user dropdown (for keyboard navigation)
        function toggleUserDropdown(event) {
            if (event) {
                event.preventDefault();
                event.stopPropagation();
            }
            const dropdown = document.getElementById('user-dropdown');
            const button = document.getElementById('user-menu-button');
            
            if (dropdown && button) {
                const isExpanded = dropdown.classList.toggle('hidden');
                button.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
                
                // If opening, focus the first link in the dropdown
                if (isExpanded) {
                    const firstLink = dropdown.querySelector('a, button');
                    if (firstLink) {
                        setTimeout(() => firstLink.focus(), 10);
                    }
                }
                
                return false; // Prevent default action
            }
        }
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('user-dropdown');
            const container = document.getElementById('user-dropdown-container');
            
            if (!container.contains(event.target) && dropdown && !dropdown.classList.contains('hidden')) {
                dropdown.classList.add('hidden');
                const button = document.getElementById('user-menu-button');
                if (button) {
                    button.setAttribute('aria-expanded', 'false');
                }
            }
        });
        
        // Close dropdown when pressing Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                const dropdown = document.getElementById('user-dropdown');
                const button = document.getElementById('user-menu-button');
                if (dropdown && !dropdown.classList.contains('hidden')) {
                    dropdown.classList.add('hidden');
                    if (button) {
                        button.setAttribute('aria-expanded', 'false');
                        button.focus();
                    }
                }
            }
        });
        
        // Handle logout
        async function logout() {
            try {
                const response = await fetch('/api/auth/logout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    credentials: 'include'
                });
                
                if (response.ok) {
                    window.location.href = '/';
                } else {
                    console.error('Error al cerrar sesión');
                    window.location.href = '/';
                }
            } catch (error) {
                console.error('Error:', error);
                window.location.href = '/';
            }
        }
        
        // Dark mode toggle functionality
        document.addEventListener('DOMContentLoaded', function() {
            const darkModeToggle = document.getElementById('darkModeToggle');
            const html = document.documentElement;
            
            // Function to set dark mode
            function setDarkMode(isDark) {
                if (isDark) {
                    html.classList.add('dark');
                    localStorage.theme = 'dark';
                } else {
                    html.classList.remove('dark');
                    localStorage.theme = 'light';
                }
                updateDarkModeIcon();
            }
            
            // Function to update dark mode icon
            function updateDarkModeIcon() {
                const icon = darkModeToggle?.querySelector('i');
                if (!icon) return;
                
                const isDark = html.classList.contains('dark');
                if (isDark) {
                    icon.classList.remove('fa-moon');
                    icon.classList.add('fa-sun');
                } else {
                    icon.classList.remove('fa-sun');
                    icon.classList.add('fa-moon');
                }
            }

            // Initialize dark mode based on preference
            if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                setDarkMode(true);
            } else {
                setDarkMode(false);
            }

            // Toggle dark mode when button is clicked
            if (darkModeToggle) {
                darkModeToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    setDarkMode(!html.classList.contains('dark'));
                });
            }

            // Mobile menu toggle
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            
            if (mobileMenuButton && mobileMenu) {
                mobileMenuButton.addEventListener('click', (e) => {
                    e.stopPropagation();
                    mobileMenu.classList.toggle('hidden');
                });
            }
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                const dropdowns = document.querySelectorAll('.dropdown');
                dropdowns.forEach(dropdown => {
                    if (!dropdown.contains(e.target)) {
                        const menu = dropdown.querySelector('.dropdown-menu');
                        if (menu) menu.classList.add('hidden');
                    }
                });
            });
            
            // Toggle dropdown menus
            const dropdownToggles = document.querySelectorAll('[data-dropdown-toggle]');
            dropdownToggles.forEach(toggle => {
                toggle.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const targetId = this.getAttribute('data-dropdown-toggle');
                    const target = document.getElementById(targetId);
                    if (target) {
                        target.classList.toggle('hidden');
                    }
                });
            });

            // Cart functionality
            const cartButtons = document.querySelectorAll('.add-to-cart');
            cartButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const productId = this.dataset.productId;
                    
                    // Show success message
                    const notification = document.createElement('div');
                    notification.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center';
                    notification.innerHTML = `
                        <i class="fas fa-check-circle mr-2"></i>
                        <span>Producto añadido al carrito</span>
                    `;
                    document.body.appendChild(notification);
                    
                    // Remove notification after 3 seconds
                    setTimeout(() => {
                        notification.remove();
                    }, 3000);
                });
            });
        });
    </script>
    <script>
        // Mostrar el menú desplegable
        function showUserMenu() {
            const dropdown = document.getElementById('user-dropdown');
            if (dropdown) {
                dropdown.classList.remove('hidden');
                dropdown.classList.add('block');
            }
        }

        // Ocultar el menú desplegable
        function hideUserMenu() {
            const dropdown = document.getElementById('user-dropdown');
            if (dropdown) {
                dropdown.classList.remove('block');
                dropdown.classList.add('hidden');
            }
        }

        // Alternar la visibilidad del menú desplegable
        function toggleUserMenu() {
            const dropdown = document.getElementById('user-dropdown');
            if (dropdown) {
                if (dropdown.classList.contains('hidden')) {
                    showUserMenu();
                } else {
                    hideUserMenu();
                }
            }
        }

        // Cerrar el menú al hacer clic fuera de él
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('user-dropdown');
            const button = document.getElementById('user-menu-button');
            
            if (dropdown && button && !dropdown.contains(event.target) && !button.contains(event.target)) {
                hideUserMenu();
            }
        });
    </script>

    <!-- Floating Action Button (Mobile) -->
    <div class="md:hidden fixed bottom-6 right-6">
        <a href="/publicar" class="bg-pink-500 hover:bg-pink-600 text-white w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all">
            <i class="fas fa-plus text-xl"></i>
        </a>
    </div>
    
    <!-- Back to Top Button -->
    <button onclick="window.scrollTo({top: 0, behavior: 'smooth'})" class="fixed bottom-6 right-6 bg-yellow-400 hover:bg-yellow-500 text-gray-900 w-12 h-12 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all hidden md:flex">
        <i class="fas fa-arrow-up"></i>
    </button>
    
    <script>
        // Show/hide back to top button
        window.addEventListener('scroll', function() {
            const backToTopButton = document.querySelector('button[onclick*="scrollTo"]');
            if (window.pageYOffset > 300) {
                backToTopButton.classList.remove('hidden');
            } else {
                backToTopButton.classList.add('hidden');
            }
        });
        
        // Mobile menu toggle
        function toggleMobileMenu() {
            const mobileMenu = document.getElementById('mobile-menu');
            mobileMenu.classList.toggle('hidden');
        }
    </script>
</body>
</html>

<?php
// Configuración básica
define('BASE_PATH', __DIR__);
define('VIEWS_PATH', BASE_PATH . '/views');

// Obtener la URL solicitada
$request = $_SERVER['REQUEST_URI'];
$url = parse_url($request, PHP_URL_PATH);
$url = trim($url, '/');

// Rutas definidas
$routes = [
    '' => 'home',
    'login' => 'auth/login',
    'registro' => 'auth/registro',
    'carrito' => 'carrito',
    'favoritos' => 'favoritos',
    // Añade más rutas según sea necesario
];

// Manejar la ruta solicitada
if (array_key_exists($url, $routes)) {
    $view = $routes[$url];
    $file = VIEWS_PATH . '/' . $view . '.php';
    
    if (file_exists($file)) {
        require $file;
    } else {
        // Vista no encontrada
        http_response_code(404);
        require VIEWS_PATH . '/errors/404.php';
    }
} else {
    // Ruta no encontrada
    http_response_code(404);
    require VIEWS_PATH . '/errors/404.php';
}