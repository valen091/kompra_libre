<?php
// Start session
session_start();

// Load environment variables
require_once __DIR__ . '/../vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Load configuration
require_once __DIR__ . '/includes/config.php';

// Autoload classes
spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    $base_dir = __DIR__ . '/app/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

// Initialize session
$session = new App\Core\Session();

// Get the current URL path
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$base_path = str_replace('index.php', '', $_SERVER['SCRIPT_NAME']);
$path = '/' . ltrim(str_replace($base_path, '', $request_uri), '/');

// Define routes
$routes = [
    // Auth routes
    'GET /login' => ['AuthController', 'showLoginForm'],
    'POST /login' => ['AuthController', 'login'],
    'GET /register' => ['AuthController', 'showRegisterForm'],
    'POST /register' => ['AuthController', 'register'],
    'GET /logout' => ['AuthController', 'logout'],
    
    // Protected routes
    'GET /dashboard' => ['DashboardController', 'index', ['auth']],
    'GET /admin/dashboard' => ['Admin\DashboardController', 'index', ['auth', 'role:admin']],
    'GET /seller/dashboard' => ['Seller\DashboardController', 'index', ['auth', 'role:seller']],
    'GET /client/dashboard' => ['Client\DashboardController', 'index', ['auth', 'role:client']],
    
    // Public routes
    'GET /' => ['HomeController', 'index'],
    'GET /unauthorized' => ['ErrorController', 'unauthorized'],
];

// Route matching
$matched = false;

foreach ($routes as $route => $handler) {
    list($method, $routePath) = explode(' ', $route, 2);
    
    // Convert route parameters to regex
    $pattern = '#^' . preg_replace('/\{([^\}]+)\}/', '([^/]+)', $routePath) . '$#';
    
    if ($_SERVER['REQUEST_METHOD'] === $method && preg_match($pattern, $path, $matches)) {
        $matched = true;
        
        // Remove the full match from matches
        array_shift($matches);
        
        // Get controller and method
        $controllerName = 'App\\Controllers\\' . $handler[0];
        $methodName = $handler[1];
        $middleware = $handler[2] ?? [];
        
        // Apply middleware
        foreach ($middleware as $middlewareName) {
            if (strpos($middlewareName, 'role:') === 0) {
                $role = substr($middlewareName, 5);
                $middlewareInstance = new App\Middleware\CheckRole($role);
            } else {
                $middlewareClass = 'App\\Middleware\\' . ucfirst($middlewareName);
                $middlewareInstance = new $middlewareClass();
            }
            
            $middlewareInstance->handle($_REQUEST, function() {});
        }
        
        // Create controller instance and call method
        $controller = new $controllerName();
        call_user_func_array([$controller, $methodName], $matches);
        
        break;
    }
}

// 404 Not Found
if (!$matched) {
    header("HTTP/1.0 404 Not Found");
    echo '404 Not Found';
    exit();
}
