<?php
// Start session and include configuration
session_start();
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

// Function to get featured products
function getFeaturedProducts($limit = 8) {
    try {
        $db = getDB();
        $stmt = $db->prepare("
            SELECT p.*, c.nombre as categoria 
            FROM productos p
            LEFT JOIN categorias c ON p.categoria_id = c.id
            WHERE p.estado = 'activo'
            ORDER BY p.fecha_creacion DESC
            LIMIT :limit
        ");
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting featured products: " . $e->getMessage());
        return [];
    }
}

// Function to get categories
function getCategories() {
    try {
        $db = getDB();
        $stmt = $db->query("
            SELECT * FROM categorias 
            WHERE estado = 'activo'
            ORDER BY nombre ASC
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error getting categories: " . $e->getMessage());
        return [];
    }
}

// Get data
$featuredProducts = getFeaturedProducts(8);
$categories = getCategories();

// Define main categories
$mainCategories = [
    'Moda y Accesorios' => [
        'icon' => '👕',
        'subcategories' => [
            'Ropa Hombre' => '👔 Ropa para hombre',
            'Ropa Mujer' => '👗 Ropa para mujer',
            'Ropa Niños' => '👶 Ropa para niños',
            'Calzado' => '👟 Calzado',
            'Bolsos y Mochilas' => '🎒 Bolsos y mochilas',
            'Joyería y Relojes' => '⌚ Joyería y relojes',
            'Accesorios' => '👓 Accesorios varios'
        ]
    ],
    'Electrónica y Tecnología' => [
        'icon' => '📱',
        'subcategories' => [
            'Smartphones y Tablets' => '📱 Smartphones y tablets',
            'Computación' => '💻 Computadoras y laptops',
            'TV y Audio' => '📺 Televisores y audio',
            'Wearables' => '⌚ Wearables',
            'Accesorios' => '🎧 Accesorios tecnológicos',
            'Gaming' => '🎮 Videojuegos'
        ]
    ],
    // Add other categories similarly
];

// If no categories from DB, use default ones
if (empty($categories) && !empty($mainCategories)) {
    $categories = array_map(function($name, $data) {
        return [
            'id' => strtolower(str_replace(' ', '-', $name)),
            'nombre' => $name,
            'icono' => $data['icon'],
            'subcategorias' => $data['subcategories']
        ];
    }, array_keys($mainCategories), $mainCategories);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kompra Libre - Marketplace Educativo</title>
    <meta name="description" content="Compra y vende productos en Kompra Libre. Encuentra ofertas en moda, tecnología, hogar y más.">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/assets/css/custom.css">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#F59E0B',
                        accent: '#10B981'
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-yellow-400 shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <a href="/" class="flex items-center">
                        <img src="/assets/img/logo.png" alt="Kompra Libre" class="h-10">
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/login" class="bg-blue-400 hover:bg-blue-500 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                        Iniciar sesión
                    </a>
                    <a href="/registro" class="bg-white hover:bg-gray-100 text-blue-600 px-4 py-2 rounded-lg font-medium border-2 border-blue-400 transition-colors">
                        Registrarse
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-blue-500 to-blue-600 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl font-bold mb-4">Bienvenido a Kompra Libre</h1>
            <p class="text-xl mb-8">Encuentra todo lo que necesitas al mejor precio</p>
            <div class="max-w-2xl mx-auto">
                <form action="/buscar" method="GET" class="flex">
                    <input type="text" name="q" placeholder="Buscar productos..." 
                           class="flex-1 px-4 py-3 rounded-l-lg text-gray-900 focus:outline-none">
                    <button type="submit" class="bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-bold px-6 py-3 rounded-r-lg transition-colors">
                        <i class="fas fa-search"></i> Buscar
                    </button>
                </form>
            </div>
        </div>
    </section>

    <!-- Main Categories -->
    <section class="py-12 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 class="text-2xl font-bold mb-8 text-center">Explorar por Categorías</h2>
            
            <?php foreach ($mainCategories as $categoryName => $categoryData): ?>
                <div class="mb-12">
                    <h3 class="text-xl font-semibold mb-4 flex items-center">
                        <span class="mr-2"><?= $categoryData['icon'] ?></span> <?= $categoryName ?>
                    </h3>
                    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                        <?php foreach ($categoryData['subcategories'] as $subKey => $subCategory): ?>
                            <a href="/categoria/<?= strtolower(str_replace(' ', '-', $subKey)) ?>" 
                               class="bg-gray-50 p-4 rounded-lg hover:shadow-md transition-shadow flex items-center">
                                <span class="text-2xl mr-2"><?= explode(' ', $subCategory)[0] ?></span>
                                <div>
                                    <h4 class="font-medium"><?= $subCategory ?></h4>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Featured Products -->
    <section class="py-12 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center mb-8">
                <h2 class="text-2xl font-bold">Productos Destacados</h2>
                <a href="/productos" class="text-blue-600 hover:underline">Ver todos los productos</a>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <?php if (!empty($featuredProducts)): ?>
                    <?php foreach ($featuredProducts as $product): ?>
                        <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                            <a href="/producto/<?= $product['id'] ?>" class="block">
                                <div class="relative pb-[75%] bg-gray-100">
                                    <img src="<?= htmlspecialchars($product['imagen_url'] ?? '/assets/img/placeholder-product.jpg') ?>" 
                                         alt="<?= htmlspecialchars($product['nombre']) ?>" 
                                         class="absolute h-full w-full object-cover">
                                    <?php if (isset($product['descuento']) && $product['descuento'] > 0): ?>
                                        <span class="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                                            -<?= $product['descuento'] ?>%
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="p-4">
                                    <h3 class="font-medium text-gray-900 mb-1"><?= htmlspecialchars($product['nombre']) ?></h3>
                                    <div class="flex items-center mb-2">
                                        <div class="text-yellow-400">
                                            <?php
                                            $rating = $product['valoracion_promedio'] ?? 0;
                                            $fullStars = floor($rating);
                                            $hasHalfStar = $rating - $fullStars >= 0.5;
                                            
                                            for ($i = 1; $i <= 5; $i++): 
                                                if ($i <= $fullStars): ?>
                                                    <i class="fas fa-star"></i>
                                                <?php elseif ($i == $fullStars + 1 && $hasHalfStar): ?>
                                                    <i class="fas fa-star-half-alt"></i>
                                                <?php else: ?>
                                                    <i class="far fa-star"></i>
                                                <?php endif; 
                                            endfor; ?>
                                        </div>
                                        <span class="text-xs text-gray-500 ml-1">(<?= $product['num_valoraciones'] ?? 0 ?>)</span>
                                    </div>
                                    <div class="flex items-center">
                                        <p class="text-lg font-bold text-gray-900">
                                            $<?= number_format($product['precio'] * (1 - (($product['descuento'] ?? 0) / 100)), 2) ?>
                                        </p>
                                        <?php if (isset($product['descuento']) && $product['descuento'] > 0): ?>
                                            <p class="ml-2 text-sm text-gray-500 line-through">$<?= number_format($product['precio'], 2) ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="mt-2 text-sm text-green-600">
                                        <?= ($product['stock'] ?? 0) > 0 ? 'Envío gratis' : 'Agotado' ?>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-span-full text-center py-8">
                        <p class="text-gray-500">No hay productos destacados disponibles en este momento.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-lg font-semibold mb-4">Kompra Libre</h3>
                    <p class="text-gray-400">Tu marketplace de confianza para comprar y vender productos de calidad.</p>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Categorías</h4>
                    <ul class="space-y-2">
                        <li><a href="/categoria/moda" class="text-gray-400 hover:text-white">Moda</a></li>
                        <li><a href="/categoria/electronica" class="text-gray-400 hover:text-white">Electrónica</a></li>
                        <li><a href="/categoria/hogar" class="text-gray-400 hover:text-white">Hogar</a></li>
                        <li><a href="/categoria/deportes" class="text-gray-400 hover:text-white">Deportes</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Mi Cuenta</h4>
                    <ul class="space-y-2">
                        <li><a href="/login" class="text-gray-400 hover:text-white">Iniciar sesión</a></li>
                        <li><a href="/registro" class="text-gray-400 hover:text-white">Registrarse</a></li>
                        <li><a href="/mi-cuenta" class="text-gray-400 hover:text-white">Mi perfil</a></li>
                        <li><a href="/mis-pedidos" class="text-gray-400 hover:text-white">Mis pedidos</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold mb-4">Contacto</h4>
                    <ul class="space-y-2">
                        <li class="flex items-center"><i class="fas fa-envelope mr-2"></i> ayuda@kompralibre.com</li>
                        <li class="flex items-center"><i class="fas fa-phone-alt mr-2"></i> +598 XX XXX XXX</li>
                        <li class="flex items-center"><i class="fas fa-map-marker-alt mr-2"></i> Montevideo, Uruguay</li>
                    </ul>
                </div>
            </div>
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400 text-sm">
                <p>&copy; <?= date('Y') ?> Kompra Libre. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            // Cart functionality
            const cartButtons = document.querySelectorAll('.add-to-cart');
            cartButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const productId = this.dataset.productId;
                    
                    // Show success message
                    const notification = document.createElement('div');
                    notification.className = 'fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center';
                    notification.innerHTML = `
                        <i class="fas fa-check-circle mr-2"></i>
                        <span>Producto añadido al carrito</span>
                    `;
                    document.body.appendChild(notification);
                    
                    // Remove notification after 3 seconds
                    setTimeout(() => {
                        notification.remove();
                    }, 3000);
                });
            });
        });
    </script>
</body>
</html>