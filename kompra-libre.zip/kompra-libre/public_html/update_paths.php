<?php
/**
 * Script para actualizar rutas en el proyecto después de moverlo a Hostinger
 */

class PathUpdater {
    private $baseDir;
    private $fileTypes = ['php', 'html', 'js', 'css', 'json'];
    private $pathMappings = [];
    
    public function __construct($baseDir) {
        $this->baseDir = rtrim($baseDir, '/\\');
    }
    
    public function run() {
        echo "Iniciando actualización de rutas...\n";
        $this->scanDirectory($this->baseDir);
        echo "Proceso completado.\n";
    }
    
    private function scanDirectory($dir) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($files as $file) {
            if ($file->isFile() && in_array($file->getExtension(), $this->fileTypes)) {
                $this->updateFilePaths($file->getPathname());
            }
        }
    }
    
    private function updateFilePaths($filePath) {
        $content = file_get_contents($filePath);
        $originalContent = $content;
        
        // Actualizar rutas de inclusión PHP
        $content = preg_replace(
            "/(require|include|require_once|include_once)[\s(]+['\"]([^'\"]+[.](?:php|inc))['\"]/i",
            function($matches) use ($filePath) {
                $includePath = $this->resolvePath($matches[2], $filePath);
                return $matches[1] . ' \'' . $includePath . '\'';
            },
            $content
        );
        
        // Actualizar rutas en HTML (src, href, etc.)
        $content = preg_replace_callback(
            '/(src|href|data-src|data-href)=["\']([^"\']+)["\']/i',
            function($matches) use ($filePath) {
                $url = $matches[2];
                // No modificar URLs absolutas que comiencen con http o //
                if (preg_match('#^(https?:|//)#i', $url)) {
                    return $matches[0];
                }
                $newUrl = $this->resolvePath($url, $filePath);
                return $matches[1] . '="' . $newUrl . '"';
            },
            $content
        );
        
        // Actualizar rutas en CSS (url())
        $content = preg_replace_callback(
            '/url\([\'" ]*([^\s\'"\)]+)[\'" ]*\)/i',
            function($matches) use ($filePath) {
                $url = $matches[1];
                // No modificar data URLs o URLs absolutas
                if (strpos($url, 'data:') === 0 || preg_match('#^(https?:|//)#i', $url)) {
                    return $matches[0];
                }
                $newUrl = $this->resolvePath($url, $filePath);
                return 'url(' . $newUrl . ')';
            },
            $content
        );
        
        // Actualizar rutas en JavaScript (import/export)
        $content = preg_replace_callback(
            '/(?:import|export|from)\s+["\']([^"\'\s]+)["\']/',
            function($matches) use ($filePath) {
                $modulePath = $matches[1];
                // No modificar módulos de node_modules o URLs
                if (strpos($modulePath, 'node_modules/') === 0 || 
                    strpos($modulePath, './node_modules/') === 0 ||
                    strpos($modulePath, '../node_modules/') === 0 ||
                    preg_match('#^(https?:|//)#i', $modulePath)) {
                    return $matches[0];
                }
                $newPath = $this->resolvePath($modulePath, $filePath, true);
                return str_replace($modulePath, $newPath, $matches[0]);
            },
            $content
        );
        
        // Guardar cambios si hubo modificaciones
        if ($content !== $originalContent) {
            file_put_contents($filePath, $content);
            echo "Actualizado: " . str_replace($this->baseDir, '', $filePath) . "\n";
        }
    }
    
    private function resolvePath($path, $currentFilePath, $isModule = false) {
        $currentDir = dirname($currentFilePath);
        
        // Si es una ruta absoluta (comienza con /)
        if (strpos($path, '/') === 0) {
            // Para rutas absolutas, hacemos que sean relativas a la raíz del proyecto
            $relativePath = ltrim($path, '/');
            $newPath = $this->makeRelative($currentDir, $this->baseDir . '/' . $relativePath);
            return $newPath;
        }
        
        // Para rutas relativas
        $absolutePath = realpath($currentDir . '/' . $path);
        if ($absolutePath === false) {
            // Si el archivo no existe, lo dejamos como está
            return $path;
        }
        
        // Si el archivo está dentro del directorio base
        if (strpos($absolutePath, $this->baseDir) === 0) {
            $relativePath = substr($absolutePath, strlen($this->baseDir) + 1);
            
            // Para módulos JS, mantener la ruta relativa al directorio actual
            if ($isModule) {
                return $this->makeRelative($currentDir, $absolutePath);
            }
            
            // Para otros archivos, hacer la ruta relativa a la raíz del proyecto
            return '/' . str_replace('\', '/', $relativePath);
        }
        
        return $path;
    }
    
    private function makeRelative($from, $to) {
        $from = str_replace('\', '/', $from);
        $to = str_replace('\', '/', $to);
        
        $fromParts = explode('/', $from);
        $toParts = explode('/', $to);
        
        // Encontrar el directorio común más largo
        $i = 0;
        $len = min(count($fromParts), count($toParts));
        while ($i < $len && $fromParts[$i] === $toParts[$i]) {
            $i++;
        }
        
        // Construir la ruta relativa
        $relativePath = [];
        $dirsToGoUp = count($fromParts) - $i - 1;
        
        if ($dirsToGoUp > 0) {
            $relativePath = array_fill(0, $dirsToGoUp, '..');
        } else if ($i === count($fromParts)) {
            $relativePath[] = '.';
        }
        
        $relativePath = array_merge($relativePath, array_slice($toParts, $i));
        
        return implode('/', $relativePath);
    }
}

// Ejecutar el script
if (php_sapi_name() === 'cli') {
    $baseDir = __DIR__;
    $updater = new PathUpdater($baseDir);
    $updater->run();
} else {
    echo "Este script debe ejecutarse desde la línea de comandos.";
    exit(1);
}
