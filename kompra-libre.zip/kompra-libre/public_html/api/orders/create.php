<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Solo permitir método POST para crear órdenes
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido. Use POST para crear órdenes.', 405);
    }

    // Verificar autenticación
    if (!isAuthenticated()) {
        throw new Exception('Debe iniciar sesión para crear una orden.', 401);
    }

    $userId = getCurrentUserId();

    // Obtener datos del request
    $data = json_decode(file_get_contents('php://input'), true);

    // Validar datos requeridos
    $requiredFields = ['shipping_method_id', 'shipping_address'];
    foreach ($requiredFields as $field) {
        if (empty($data[$field])) {
            throw new Exception("Campo requerido faltante: {$field}.", 400);
        }
    }

    // Validar y sanitizar datos
    $shippingMethodId = (int)$data['shipping_method_id'];
    $shippingAddress = sanitize($data['shipping_address']);

    if ($shippingMethodId <= 0) {
        throw new Exception('Método de envío inválido.', 400);
    }

    if (strlen($shippingAddress) < 10) {
        throw new Exception('La dirección de envío debe tener al menos 10 caracteres.', 400);
    }

    // Obtener el carrito del usuario
    $cartId = getUserCartId($userId);

    if (!$cartId) {
        throw new Exception('No se encontró un carrito activo.', 404);
    }

    // Obtener items del carrito con detalles de productos
    $cartItems = getCartItemsWithDetails($cartId);

    if (empty($cartItems)) {
        throw new Exception('El carrito está vacío.', 400);
    }

    // Verificar stock para cada producto
    $totalAmount = 0;
    $validatedItems = [];

    foreach ($cartItems as $item) {
        // Verificar stock actual
        if ($item['stock'] < $item['quantity']) {
            throw new Exception("Stock insuficiente para '{$item['title']}'. Disponible: {$item['stock']}, Solicitado: {$item['quantity']}.", 400);
        }

        // Verificar que el producto sigue activo
        if (!$item['is_active']) {
            throw new Exception("El producto '{$item['title']}' ya no está disponible.", 400);
        }

        $itemTotal = $item['price'] * $item['quantity'];
        $totalAmount += $itemTotal;

        $validatedItems[] = [
            'product_id' => $item['product_id'],
            'quantity' => $item['quantity'],
            'price_unit' => $item['price'],
            'total' => $itemTotal,
            'seller_id' => $item['seller_id'],
            'title' => $item['title']
        ];
    }

    // Obtener costo de envío
    $shippingCost = getShippingCost($shippingMethodId);

    if ($shippingCost === false) {
        throw new Exception('Método de envío no encontrado.', 404);
    }

    $finalTotal = $totalAmount + $shippingCost;

    // Iniciar transacción
    $db->beginTransaction();

    try {
        // Crear la orden
        $stmt = $db->prepare("
            INSERT INTO orders (user_id, total, status, shipping_method_id, shipping_cost, created_at, updated_at)
            VALUES (?, ?, 'pendiente', ?, ?, NOW(), NOW())
        ");

        $stmt->execute([$userId, $finalTotal, $shippingMethodId, $shippingCost]);
        $orderId = $db->lastInsertId();

        // Crear los items de la orden
        $stmt = $db->prepare("
            INSERT INTO order_items (order_id, product_id, price_unit, quantity)
            VALUES (?, ?, ?, ?)
        ");

        foreach ($validatedItems as $item) {
            $stmt->execute([
                $orderId,
                $item['product_id'],
                $item['price_unit'],
                $item['quantity']
            ]);
        }

        // Reducir stock de productos
        $stmt = $db->prepare("
            UPDATE products
            SET stock = stock - ?
            WHERE id = ?
        ");

        foreach ($validatedItems as $item) {
            $stmt->execute([$item['quantity'], $item['product_id']]);
        }

        // Vaciar el carrito
        $stmt = $db->prepare("DELETE FROM cart_items WHERE cart_id = ?");
        $stmt->execute([$cartId]);

        // Eliminar el carrito
        $stmt = $db->prepare("DELETE FROM carts WHERE id = ?");
        $stmt->execute([$cartId]);

        // Limpiar carrito de la sesión
        if (isset($_SESSION['cart_id'])) {
            unset($_SESSION['cart_id']);
        }

        // Confirmar transacción
        $db->commit();

        // Crear notificaciones para los vendedores
        createOrderNotifications($orderId, $validatedItems);

        // Respuesta exitosa
        $response = [
            'success' => true,
            'message' => 'Orden creada exitosamente.',
            'data' => [
                'order_id' => $orderId,
                'total' => $finalTotal,
                'subtotal' => $totalAmount,
                'shipping_cost' => $shippingCost,
                'item_count' => count($validatedItems),
                'status' => 'pendiente',
                'items' => array_map(function($item) {
                    return [
                        'product_id' => $item['product_id'],
                        'title' => $item['title'],
                        'quantity' => $item['quantity'],
                        'price_unit' => $item['price_unit'],
                        'total' => $item['total']
                    ];
                }, $validatedItems),
                'shipping_method' => getShippingMethodName($shippingMethodId),
                'created_at' => date('Y-m-d H:i:s')
            ]
        ];

    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $db->rollback();
        throw $e;
    }

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener el ID del carrito del usuario
function getUserCartId($userId) {
    global $db;

    $stmt = $db->prepare("
        SELECT id FROM carts
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 1
    ");

    $stmt->execute([$userId]);
    $cart = $stmt->fetch();

    return $cart ? $cart['id'] : null;
}

// Función auxiliar para obtener items del carrito con detalles
function getCartItemsWithDetails($cartId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            ci.*,
            p.title,
            p.price,
            p.stock,
            p.status as product_status,
            p.seller_id,
            (SELECT name FROM users WHERE id = p.seller_id) as seller_name
        FROM cart_items ci
        JOIN products p ON ci.product_id = p.id
        WHERE ci.cart_id = ? AND p.status = 'active'
    ");

    $stmt->execute([$cartId]);
    $items = $stmt->fetchAll();

    // Agregar flag de activo
    foreach ($items as &$item) {
        $item['is_active'] = $item['product_status'] === 'active';
    }

    return $items;
}

// Función auxiliar para obtener costo de envío
function getShippingCost($shippingMethodId) {
    global $db;

    $stmt = $db->prepare("SELECT price FROM shipping_methods WHERE id = ?");
    $stmt->execute([$shippingMethodId]);
    $method = $stmt->fetch();

    return $method ? (float)$method['price'] : false;
}

// Función auxiliar para obtener nombre del método de envío
function getShippingMethodName($shippingMethodId) {
    global $db;

    $stmt = $db->prepare("SELECT name FROM shipping_methods WHERE id = ?");
    $stmt->execute([$shippingMethodId]);
    $method = $stmt->fetch();

    return $method ? $method['name'] : 'Método desconocido';
}

// Función auxiliar para crear notificaciones de orden
function createOrderNotifications($orderId, $items) {
    global $db;

    // Crear notificación para el comprador
    $stmt = $db->prepare("
        INSERT INTO notifications (user_id, kind, payload, created_at)
        VALUES (?, 'order_created', ?, NOW())
    ");

    $payload = json_encode(['order_id' => $orderId, 'type' => 'buyer']);
    $stmt->execute([getCurrentUserId(), $payload]);

    // Crear notificaciones para cada vendedor
    $sellerIds = array_unique(array_column($items, 'seller_id'));

    foreach ($sellerIds as $sellerId) {
        $sellerItems = array_filter($items, function($item) use ($sellerId) {
            return $item['seller_id'] == $sellerId;
        });

        $stmt = $db->prepare("
            INSERT INTO notifications (user_id, kind, payload, created_at)
            VALUES (?, 'order_received', ?, NOW())
        ");

        $payload = json_encode([
            'order_id' => $orderId,
            'item_count' => count($sellerItems),
            'type' => 'seller'
        ]);

        $stmt->execute([$sellerId, $payload]);
    }
}
?>