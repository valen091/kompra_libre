# 📦 API de Órdenes - Kompra Libre

Este directorio contiene los endpoints de la API para la gestión completa de órdenes de compra.

## 📋 Endpoints Disponibles

### 🆕 **Crear Orden** - `create.php`
**POST** `/api/orders/create.php`

Crea una nueva orden desde el carrito de compras del usuario autenticado.

#### **Parámetros (JSON):**
```json
{
  "shipping_method_id": 1,
  "shipping_address": "Dirección completa de envío, mínimo 10 caracteres"
}
```

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Orden creada exitosamente.",
  "data": {
    "order_id": 123,
    "total": 2599.98,
    "subtotal": 2499.99,
    "shipping_cost": 99.99,
    "item_count": 2,
    "status": "pendiente",
    "items": [
      {
        "product_id": 456,
        "title": "iPhone 15 Pro Max",
        "quantity": 1,
        "price_unit": 1299.99,
        "total": 1299.99
      }
    ],
    "shipping_method": "Envío Express",
    "created_at": "2025-01-15 14:30:00"
  }
}
```

#### **Funcionalidades:**
- ✅ **Validación completa** de carrito y productos
- ✅ **Verificación de stock** antes de crear orden
- ✅ **Cálculo automático** de totales y envío
- ✅ **Transacciones seguras** con rollback en errores
- ✅ **Reducción de stock** automática
- ✅ **Notificaciones** automáticas a vendedores
- ✅ **Limpieza del carrito** después de la compra

### 📜 **Historial de Órdenes** - `history.php`
**GET** `/api/orders/history.php`

Obtiene el historial completo de órdenes del usuario autenticado con paginación y filtros.

#### **Parámetros GET (opcionales):**
```bash
/api/orders/history.php?status=pendiente&limit=10&offset=0
```

| Parámetro | Descripción | Valor por defecto |
|-----------|-------------|-------------------|
| `status` | Filtrar por estado | null (todos) |
| `limit` | Número de resultados | 20 (máx. 100) |
| `offset` | Desplazamiento para paginación | 0 |

#### **Estados válidos:**
- `pendiente` - Orden creada, esperando procesamiento
- `procesando` - En preparación por vendedores
- `enviado` - Producto enviado al comprador
- `entregado` - Orden completada exitosamente
- `cancelado` - Orden cancelada

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Historial de órdenes obtenido exitosamente.",
  "data": {
    "orders": [
      {
        "id": 123,
        "total": 2599.98,
        "status": "pendiente",
        "shipping_method": "Envío Express",
        "shipping_cost": 99.99,
        "item_count": 2,
        "notification_count": 1,
        "created_at": "2025-01-15 14:30:00",
        "updated_at": "2025-01-15 14:35:00",
        "items": [
          {
            "id": 456,
            "product_id": 789,
            "title": "iPhone 15 Pro Max",
            "price_unit": 1299.99,
            "quantity": 1,
            "total": 1299.99,
            "image": "/img/products/iphone-15-pro-max.jpg",
            "url": "/producto/iphone-15-pro-max",
            "seller": "Tienda Apple"
          }
        ],
        "summary": {
          "subtotal": 2499.99,
          "shipping": 99.99,
          "total": 2599.98
        }
      }
    ],
    "pagination": {
      "total": 25,
      "limit": 20,
      "offset": 0,
      "has_more": true
    },
    "filters": {
      "status": "pendiente",
      "valid_statuses": ["pendiente", "procesando", "enviado", "entregado", "cancelado"]
    }
  }
}
```

### 🔍 **Detalles de Orden** - `details.php`
**GET** `/api/orders/details.php?order_id=123`

Obtiene detalles completos de una orden específica con verificación de permisos.

#### **Parámetros GET:**
| Parámetro | Descripción | Requerido |
|-----------|-------------|-----------|
| `order_id` | ID de la orden a consultar | ✅ |

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Detalles de orden obtenidos exitosamente.",
  "data": {
    "order": {
      "id": 123,
      "total": 2599.98,
      "status": "procesando",
      "shipping_method": "Envío Express",
      "shipping_cost": 99.99,
      "item_count": 2,
      "notification_count": 3,
      "created_at": "2025-01-15 14:30:00",
      "updated_at": "2025-01-15 16:45:00"
    },
    "items": [
      {
        "id": 456,
        "product_id": 789,
        "title": "iPhone 15 Pro Max",
        "description": "Smartphone de última generación...",
        "price_unit": 1299.99,
        "quantity": 1,
        "total": 1299.99,
        "image": "/img/products/iphone-15-pro-max.jpg",
        "url": "/producto/iphone-15-pro-max",
        "seller": {
          "name": "Tienda Apple",
          "email": "contacto@tiendaapple.com"
        }
      }
    ],
    "updates": [
      {
        "id": 1,
        "kind": "order_updated",
        "type": "seller",
        "message": "Tu orden ha sido procesada y enviada",
        "old_status": "procesando",
        "new_status": "enviado",
        "read_flag": false,
        "created_at": "2025-01-15 16:45:00"
      }
    ],
    "summary": {
      "subtotal": 2499.99,
      "shipping": 99.99,
      "total": 2599.98,
      "item_count": 2
    }
  }
}
```

### 🔄 **Actualizar Estado** - `update.php`
**PUT** `/api/orders/update.php`

Actualiza el estado de una orden con validación de permisos y reglas de transición.

#### **Parámetros (JSON):**
```json
{
  "order_id": 123,
  "status": "enviado",
  "message": "Tu orden ha sido enviada y está en camino" // opcional
}
```

#### **Estados válidos:**
- `pendiente` → `procesando`, `cancelado`
- `procesando` → `enviado`, `cancelado`
- `enviado` → `entregado`
- `entregado`, `cancelado` → Estado final (sin cambios)

#### **Permisos por Rol:**
- **Comprador**: Solo puede cancelar órdenes pendientes/procesando
- **Vendedor**: Puede procesar y enviar órdenes de sus productos
- **Admin**: Puede cambiar cualquier orden a cualquier estado

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Estado de orden actualizado exitosamente.",
  "data": {
    "order_id": 123,
    "old_status": "procesando",
    "new_status": "enviado",
    "updated_by": {
      "user_id": 456,
      "role": "seller"
    },
    "order": {
      "id": 123,
      "total": 2599.98,
      "status": "enviado",
      "shipping_method": "Envío Express",
      "created_at": "2025-01-15 14:30:00",
      "updated_at": "2025-01-15 16:45:00"
    },
    "allowed_next_statuses": ["entregado"]
  }
}
```

## 🔧 **Códigos de Respuesta HTTP**

| Código | Descripción | Endpoint |
|--------|-------------|----------|
| `200` | Operación exitosa | Todos |
| `201` | Orden creada exitosamente | create.php |
| `400` | Datos inválidos / Stock insuficiente | Todos |
| `401` | No autenticado | Todos |
| `403` | Sin permisos para la operación | update.php / details.php |
| `404` | Orden no encontrada | details.php / update.php |
| `405` | Método HTTP no permitido | Todos |
| `500` | Error interno del servidor | Todos |

## 📝 **Ejemplos de Uso (JavaScript)**

### **Crear Orden desde el Carrito:**
```javascript
// Crear orden con método de envío
fetch('/api/orders/create.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        shipping_method_id: 1,
        shipping_address: "Av. Corrientes 1234, CABA, Argentina"
    })
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        console.log('Orden creada:', data.data.order_id);
        // Redirigir a página de confirmación
        window.location.href = `/pages/order-confirmation.html?order_id=${data.data.order_id}`;
    } else {
        console.error('Error:', data.message);
        // Mostrar error al usuario
        showError(data.message);
    }
});
```

### **Obtener Detalles de Orden:**
```javascript
// Obtener detalles completos de una orden
fetch(`/api/orders/details.php?order_id=${orderId}`)
.then(response => response.json())
.then(data => {
    if (data.success) {
        renderOrderDetails(data.data);
        renderOrderItems(data.data.items);
        renderOrderUpdates(data.data.updates);
    }
});
```

### **Actualizar Estado (Vendedores):**
```javascript
// Vendedor actualiza estado a "enviado"
fetch('/api/orders/update.php', {
    method: 'PUT',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        order_id: 123,
        status: 'enviado',
        message: 'Tu orden ha sido enviada. Tracking: ABC123'
    })
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        console.log('Estado actualizado:', data.data.new_status);
        updateOrderUI(data.data);
    }
});
```

### **Historial con Paginación:**
```javascript
// Obtener órdenes con filtros y paginación
async function loadOrders(status = null, page = 1) {
    const limit = 10;
    const offset = (page - 1) * limit;

    const response = await fetch(
        `/api/orders/history.php?status=${status}&limit=${limit}&offset=${offset}`
    );
    const data = await response.json();

    if (data.success) {
        renderOrdersList(data.data.orders);
        updatePagination(data.data.pagination);
    }
}
```

## ⚠️ **Validaciones y Seguridad**

### **Validaciones Implementadas:**

#### **Autenticación y Autorización:**
- ✅ **Sesión requerida** - Solo usuarios autenticados
- ✅ **Permisos por rol** - Compradores, vendedores, admins
- ✅ **Propiedad de órdenes** - Solo puede ver/modificar órdenes propias
- ✅ **Transiciones válidas** - Estados permitidos según rol

#### **Datos del Carrito:**
- ✅ **Carrito no vacío** - Al menos un producto
- ✅ **Stock disponible** - Verificación antes de crear orden
- ✅ **Productos activos** - Solo productos disponibles
- ✅ **Precios válidos** - Sin productos con precio 0 o negativo

#### **Gestión de Estados:**
- ✅ **Transiciones controladas** - No todos los cambios son permitidos
- ✅ **Restauración de stock** - Al cancelar órdenes
- ✅ **Auditoría completa** - Logs de todos los cambios

### **Transacciones de Base de Datos:**
- ✅ **Atomicidad** - Todo o nada (commit/rollback)
- ✅ **Consistencia** - Stock actualizado correctamente
- ✅ **Aislamiento** - Sin interferencias entre operaciones
- ✅ **Durabilidad** - Cambios persistentes

## 📊 **Estados de Orden y Permisos**

| Estado | Comprador | Vendedor | Admin | Descripción |
|--------|-----------|----------|-------|-------------|
| `pendiente` | ✅ Cancelar | ✅ Procesar | ✅ Todo | Orden creada, esperando |
| `procesando` | ✅ Cancelar | ✅ Enviar | ✅ Todo | En preparación |
| `enviado` | ❌ | ✅ Entregar | ✅ Todo | En camino |
| `entregado` | ❌ | ❌ | ✅ Reabrir | Completada |
| `cancelado` | ❌ | ❌ | ✅ Reabrir | Cancelada |

## 🚀 **Mejores Prácticas**

### **Para Frontend:**
- **Validar datos** antes de enviar al backend
- **Mostrar progreso** durante operaciones
- **Manejar errores** apropiadamente
- **Actualizar UI** en tiempo real
- **Confirmación** antes de acciones importantes

### **Para Backend:**
- **Validaciones estrictas** - Nunca confiar en el frontend
- **Logs detallados** - Para debugging y auditoría
- **Rate limiting** - Prevenir spam
- **Monitoring** - Alertas automáticas
- **Backups** - Antes de operaciones críticas

## 📞 **Solución de Problemas**

### **Errores Comunes:**

#### **"No tiene permisos" (403):**
- Verificar que el usuario sea el comprador o vendedor de la orden
- Confirmar que el usuario tenga el rol correcto
- Revisar permisos de administrador si es necesario

#### **"Transición no permitida" (400):**
- Verificar que el cambio de estado sea válido
- Confirmar que el usuario tenga permisos para ese cambio
- Revisar la tabla de transiciones permitidas

#### **"Stock restaurado" (al cancelar):**
- El stock se restaura automáticamente al cancelar
- Los productos vuelven a estar disponibles
- Los vendedores reciben notificación

### **Debugging:**
- Revisa logs del servidor
- Usa herramientas como Postman
- Verifica permisos en la base de datos
- Consulta el historial de notificaciones

## 🔗 **Integración con Otros Módulos**

- **🛒 Carrito** → `api/cart/` para gestión del carrito
- **👤 Usuarios** → `api/auth/` para autenticación
- **📢 Notificaciones** → `api/notifications/` para notificaciones automáticas
- **📦 Productos** → `api/products/` para detalles de productos
- **🛍️ Frontend** → `pages/` para interfaces de usuario
- **🗄️ Base de Datos** → `sql/fix-schema-carts-orders.sql` para correcciones

## 📈 **Performance y Escalabilidad**

### **Optimizaciones Implementadas:**
- ✅ **Consultas eficientes** con JOINs apropiados
- ✅ **Índices de BD** en campos críticos (user_id, status, session_id)
- ✅ **Transacciones** para consistencia de datos
- ✅ **Validación temprana** para evitar operaciones innecesarias
- ✅ **Paginación** para grandes volúmenes de datos
- ✅ **Caching** de métodos de envío frecuentes

### **Recomendaciones Adicionales:**
- **Queue system** para notificaciones masivas
- **Async processing** para operaciones pesadas
- **Monitoring** de performance de consultas
- **CDN** para imágenes de productos

---
**¡La API de órdenes está completa y lista para producción!** 🛒✨
