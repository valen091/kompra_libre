<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Solo permitir método PUT para actualizar órdenes
    if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
        throw new Exception('Método no permitido. Use PUT para actualizar órdenes.', 405);
    }

    // Verificar autenticación
    if (!isAuthenticated()) {
        throw new Exception('Debe iniciar sesión para actualizar órdenes.', 401);
    }

    $userId = getCurrentUserId();

    // Obtener datos del request
    $data = json_decode(file_get_contents('php://input'), true);

    // Validar datos requeridos
    if (empty($data['order_id']) || empty($data['status'])) {
        throw new Exception('Faltan datos requeridos: order_id y status son obligatorios.', 400);
    }

    $orderId = (int)$data['order_id'];
    $newStatus = trim($data['status']);
    $statusMessage = isset($data['message']) ? sanitize($data['message']) : '';

    // Validar order_id
    if ($orderId <= 0) {
        throw new Exception('ID de orden inválido.', 400);
    }

    // Validar estado
    $validStatuses = ['pendiente', 'procesando', 'enviado', 'entregado', 'cancelado'];
    if (!in_array($newStatus, $validStatuses)) {
        throw new Exception('Estado de orden inválido.', 400);
    }

    // Obtener detalles de la orden y verificar permisos
    $order = getOrderWithPermissions($orderId, $userId);

    if (!$order) {
        throw new Exception('Orden no encontrada o no tiene permisos para modificarla.', 404);
    }

    $currentStatus = $order['status'];
    $isBuyer = $order['user_id'] == $userId;
    $isSeller = isProductSeller($orderId, $userId);
    $isAdmin = isAdmin();

    // Validar permisos según el estado actual y el nuevo estado
    if (!$isAdmin && !$isBuyer && !$isSeller) {
        throw new Exception('No tiene permisos para modificar esta orden.', 403);
    }

    // Validar transiciones de estado permitidas
    $allowedTransitions = getAllowedStatusTransitions($currentStatus, $isBuyer, $isSeller, $isAdmin);

    if (!in_array($newStatus, $allowedTransitions)) {
        throw new Exception("No se permite cambiar de '{$currentStatus}' a '{$newStatus}'.", 400);
    }

    // Si es cancelación, solo el comprador puede cancelar en estados iniciales
    if ($newStatus === 'cancelado') {
        if (!$isBuyer) {
            throw new Exception('Solo el comprador puede cancelar la orden.', 403);
        }

        if (!in_array($currentStatus, ['pendiente', 'procesando'])) {
            throw new Exception('Solo se pueden cancelar órdenes pendientes o en procesamiento.', 400);
        }
    }

    // Iniciar transacción
    $db->beginTransaction();

    try {
        // Actualizar estado de la orden
        $stmt = $db->prepare("
            UPDATE orders
            SET status = ?, updated_at = NOW()
            WHERE id = ?
        ");

        $stmt->execute([$newStatus, $orderId]);

        if ($stmt->rowCount() === 0) {
            throw new Exception('No se pudo actualizar la orden.', 500);
        }

        // Si la orden se entrega o cancela, restaurar stock si es necesario
        if (in_array($newStatus, ['cancelado'])) {
            restoreProductStock($orderId);
        }

        // Crear notificación del cambio
        createOrderStatusNotification($orderId, $currentStatus, $newStatus, $statusMessage, $userId);

        // Confirmar transacción
        $db->commit();

        // Obtener detalles actualizados de la orden
        $updatedOrder = getOrderWithPermissions($orderId, $userId);

        $response = [
            'success' => true,
            'message' => 'Estado de orden actualizado exitosamente.',
            'data' => [
                'order_id' => $orderId,
                'old_status' => $currentStatus,
                'new_status' => $newStatus,
                'updated_by' => [
                    'user_id' => $userId,
                    'role' => $isAdmin ? 'admin' : ($isSeller ? 'seller' : 'buyer')
                ],
                'order' => [
                    'id' => (int)$updatedOrder['id'],
                    'total' => (float)$updatedOrder['total'],
                    'status' => $newStatus,
                    'shipping_method' => $updatedOrder['shipping_method_name'],
                    'created_at' => $updatedOrder['created_at'],
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'allowed_next_statuses' => getAllowedStatusTransitions($newStatus, $isBuyer, $isSeller, $isAdmin)
            ]
        ];

    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $db->rollback();
        throw $e;
    }

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener orden con verificación de permisos
function getOrderWithPermissions($orderId, $userId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            o.*,
            sm.name as shipping_method_name,
            (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count
        FROM orders o
        LEFT JOIN shipping_methods sm ON o.shipping_method_id = sm.id
        WHERE o.id = ?
        LIMIT 1
    ");

    $stmt->execute([$orderId]);
    $order = $stmt->fetch();

    if (!$order) {
        return null;
    }

    // Verificar si el usuario puede ver/modificar esta orden
    $isBuyer = $order['user_id'] == $userId;
    $isSeller = isProductSeller($orderId, $userId);
    $isAdmin = isAdmin();

    return ($isBuyer || $isSeller || $isAdmin) ? $order : null;
}

// Función auxiliar para verificar si el usuario es vendedor de productos en la orden
function isProductSeller($orderId, $userId) {
    global $db;

    $stmt = $db->prepare("
        SELECT COUNT(*) as is_seller
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        JOIN sellers s ON p.seller_id = s.id
        WHERE oi.order_id = ? AND s.user_id = ?
    ");

    $stmt->execute([$orderId, $userId]);
    $result = $stmt->fetch();

    return $result['is_seller'] > 0;
}

// Función auxiliar para obtener transiciones de estado permitidas
function getAllowedStatusTransitions($currentStatus, $isBuyer, $isSeller, $isAdmin) {
    $transitions = [
        'pendiente' => ['procesando', 'cancelado'],
        'procesando' => ['enviado', 'cancelado'],
        'enviado' => ['entregado'],
        'entregado' => [], // Estado final
        'cancelado' => []  // Estado final
    ];

    // Si es admin, puede cambiar a cualquier estado válido
    if ($isAdmin) {
        $allStatuses = ['pendiente', 'procesando', 'enviado', 'entregado', 'cancelado'];
        return array_filter($allStatuses, function($status) use ($currentStatus) {
            return $status !== $currentStatus;
        });
    }

    // Si es comprador, solo puede cancelar en estados iniciales
    if ($isBuyer) {
        return array_filter($transitions[$currentStatus] ?? [], function($status) {
            return $status === 'cancelado';
        });
    }

    // Si es vendedor, puede hacer todas las transiciones normales excepto cancelar
    if ($isSeller) {
        return array_filter($transitions[$currentStatus] ?? [], function($status) {
            return $status !== 'cancelado';
        });
    }

    return [];
}

// Función auxiliar para restaurar stock de productos
function restoreProductStock($orderId) {
    global $db;

    $stmt = $db->prepare("
        UPDATE products p
        JOIN order_items oi ON p.id = oi.product_id
        SET p.stock = p.stock + oi.quantity
        WHERE oi.order_id = ?
    ");

    $stmt->execute([$orderId]);
}

// Función auxiliar para crear notificación de cambio de estado
function createOrderStatusNotification($orderId, $oldStatus, $newStatus, $message, $updatedByUserId) {
    global $db;

    // Obtener detalles de la orden
    $stmt = $db->prepare("SELECT user_id FROM orders WHERE id = ?");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch();

    if (!$order) {
        return;
    }

    $buyerId = $order['user_id'];

    // Crear notificación para el comprador
    $stmt = $db->prepare("
        INSERT INTO notifications (user_id, kind, payload, created_at)
        VALUES (?, 'order_updated', ?, NOW())
    ");

    $payload = json_encode([
        'order_id' => $orderId,
        'type' => 'buyer',
        'old_status' => $oldStatus,
        'new_status' => $newStatus,
        'message' => $message,
        'updated_by' => $updatedByUserId
    ]);

    $stmt->execute([$buyerId, $payload]);

    // Si el que actualiza no es el comprador, también notificar al comprador
    if ($updatedByUserId !== $buyerId) {
        // Crear notificación para el vendedor/admin que actualizó
        $stmt = $db->prepare("
            INSERT INTO notifications (user_id, kind, payload, created_at)
            VALUES (?, 'order_updated', ?, NOW())
        ");

        $payload = json_encode([
            'order_id' => $orderId,
            'type' => 'seller',
            'old_status' => $oldStatus,
            'new_status' => $newStatus,
            'message' => $message,
            'updated_by' => $updatedByUserId
        ]);

        $stmt->execute([$updatedByUserId, $payload]);
    }
}
?>
