<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Solo permitir método GET para obtener detalles de orden
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception('Método no permitido. Use GET para obtener detalles de orden.', 405);
    }

    // Verificar autenticación
    if (!isAuthenticated()) {
        throw new Exception('Debe iniciar sesión para ver detalles de órdenes.', 401);
    }

    $userId = getCurrentUserId();

    // Obtener ID de orden desde parámetros GET
    $orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : null;

    if (!$orderId || $orderId <= 0) {
        throw new Exception('ID de orden inválido.', 400);
    }

    // Obtener detalles completos de la orden
    $order = getOrderDetails($orderId, $userId);

    if (!$order) {
        throw new Exception('Orden no encontrada o no tiene permisos para verla.', 404);
    }

    // Obtener items de la orden
    $orderItems = getOrderItems($orderId);

    // Obtener historial de actualizaciones de la orden
    $orderUpdates = getOrderUpdates($orderId, $userId);

    // Marcar notificaciones como leídas si las hay
    markOrderNotificationsAsRead($orderId, $userId);

    $response = [
        'success' => true,
        'message' => 'Detalles de orden obtenidos exitosamente.',
        'data' => [
            'order' => $order,
            'items' => $orderItems,
            'updates' => $orderUpdates,
            'summary' => [
                'subtotal' => (float)$order['total'] - (float)$order['shipping_cost'],
                'shipping' => (float)$order['shipping_cost'],
                'total' => (float)$order['total'],
                'item_count' => count($orderItems)
            ]
        ]
    ];

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener detalles completos de una orden
function getOrderDetails($orderId, $userId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            o.*,
            sm.name as shipping_method_name,
            sm.price as shipping_method_price,
            u.name as buyer_name,
            u.email as buyer_email,
            (SELECT COUNT(*) FROM notifications n WHERE n.user_id = ? AND n.payload LIKE CONCAT('%\"order_id\":', o.id, '%')) as notification_count
        FROM orders o
        LEFT JOIN shipping_methods sm ON o.shipping_method_id = sm.id
        LEFT JOIN users u ON o.user_id = u.id
        WHERE o.id = ? AND o.user_id = ?
        LIMIT 1
    ");

    $stmt->execute([$userId, $orderId, $userId]);
    return $stmt->fetch();
}

// Función auxiliar para obtener items de una orden
function getOrderItems($orderId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            oi.*,
            p.title,
            p.slug,
            p.description,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image_url,
            (SELECT name FROM users WHERE id = p.seller_id) as seller_name,
            (SELECT email FROM users WHERE id = p.seller_id) as seller_email
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?
        ORDER BY oi.id
    ");

    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll();

    // Formatear items
    return array_map(function($item) {
        return [
            'id' => (int)$item['id'],
            'product_id' => (int)$item['product_id'],
            'title' => $item['title'],
            'description' => $item['description'],
            'price_unit' => (float)$item['price_unit'],
            'quantity' => (int)$item['quantity'],
            'total' => (float)$item['price_unit'] * (int)$item['quantity'],
            'image' => $item['image_url'] ?: '/img/placeholder-product.jpg',
            'url' => '/producto/' . $item['slug'],
            'seller' => [
                'name' => $item['seller_name'],
                'email' => $item['seller_email']
            ]
        ];
    }, $items);
}

// Función auxiliar para obtener historial de actualizaciones
function getOrderUpdates($orderId, $userId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            n.*,
            JSON_UNQUOTE(JSON_EXTRACT(n.payload, '$.type')) as update_type,
            JSON_UNQUOTE(JSON_EXTRACT(n.payload, '$.message')) as update_message,
            JSON_UNQUOTE(JSON_EXTRACT(n.payload, '$.old_status')) as old_status,
            JSON_UNQUOTE(JSON_EXTRACT(n.payload, '$.new_status')) as new_status
        FROM notifications n
        WHERE n.user_id = ? AND n.payload LIKE CONCAT('%\"order_id\":', ?, '%')
        ORDER BY n.created_at DESC
        LIMIT 20
    ");

    $stmt->execute([$userId, $orderId]);
    $updates = $stmt->fetchAll();

    return array_map(function($update) {
        return [
            'id' => (int)$update['id'],
            'kind' => $update['kind'],
            'type' => $update['update_type'],
            'message' => $update['update_message'],
            'old_status' => $update['old_status'],
            'new_status' => $update['new_status'],
            'read_flag' => (bool)$update['read_flag'],
            'created_at' => $update['created_at']
        ];
    }, $updates);
}

// Función auxiliar para marcar notificaciones como leídas
function markOrderNotificationsAsRead($orderId, $userId) {
    global $db;

    $stmt = $db->prepare("
        UPDATE notifications
        SET read_flag = 1
        WHERE user_id = ? AND payload LIKE CONCAT('%\"order_id\":', ?, '%') AND read_flag = 0
    ");

    $stmt->execute([$userId, $orderId]);
}
?>
