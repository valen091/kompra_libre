<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Permitir GET para obtener historial de órdenes
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception('Método no permitido. Use GET para obtener historial de órdenes.', 405);
    }

    // Verificar autenticación
    if (!isAuthenticated()) {
        throw new Exception('Debe iniciar sesión para ver el historial de órdenes.', 401);
    }

    $userId = getCurrentUserId();

    // Obtener parámetros opcionales
    $status = isset($_GET['status']) ? sanitize($_GET['status']) : null;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;

    // Validar parámetros
    if ($limit < 1 || $limit > 100) {
        $limit = 20;
    }

    if ($offset < 0) {
        $offset = 0;
    }

    // Validar status si se proporciona
    $validStatuses = ['pendiente', 'procesando', 'enviado', 'entregado', 'cancelado'];
    if ($status && !in_array($status, $validStatuses)) {
        throw new Exception('Estado de orden inválido.', 400);
    }

    // Construir consulta base
    $whereConditions = ["o.user_id = ?"];
    $params = [$userId];

    if ($status) {
        $whereConditions[] = "o.status = ?";
        $params[] = $status;
    }

    $whereClause = implode(' AND ', $whereConditions);

    // Obtener total de órdenes para paginación
    $stmt = $db->prepare("
        SELECT COUNT(*) as total
        FROM orders o
        WHERE {$whereClause}
    ");

    $stmt->execute($params);
    $totalResult = $stmt->fetch();
    $totalOrders = (int)$totalResult['total'];

    // Obtener órdenes con detalles
    $stmt = $db->prepare("
        SELECT
            o.*,
            sm.name as shipping_method_name,
            sm.price as shipping_cost,
            COUNT(oi.id) as item_count,
            (SELECT COUNT(*) FROM notifications n WHERE n.user_id = ? AND n.kind = 'order_updated' AND n.payload LIKE CONCAT('%\"order_id\":', o.id, '%')) as notification_count
        FROM orders o
        LEFT JOIN shipping_methods sm ON o.shipping_method_id = sm.id
        LEFT JOIN order_items oi ON o.id = oi.order_id
        WHERE {$whereClause}
        GROUP BY o.id
        ORDER BY o.created_at DESC
        LIMIT ? OFFSET ?
    ");

    $params[] = $limit;
    $params[] = $offset;
    $stmt->execute($params);
    $orders = $stmt->fetchAll();

    // Obtener detalles de items para cada orden
    $ordersWithItems = [];
    foreach ($orders as $order) {
        $orderItems = getOrderItems($order['id']);

        $ordersWithItems[] = [
            'id' => (int)$order['id'],
            'total' => (float)$order['total'],
            'status' => $order['status'],
            'shipping_method' => $order['shipping_method_name'] ?: 'No especificado',
            'shipping_cost' => (float)$order['shipping_cost'],
            'item_count' => (int)$order['item_count'],
            'notification_count' => (int)$order['notification_count'],
            'created_at' => $order['created_at'],
            'updated_at' => $order['updated_at'] ?: $order['created_at'],
            'items' => $orderItems,
            'summary' => [
                'subtotal' => (float)$order['total'] - (float)$order['shipping_cost'],
                'shipping' => (float)$order['shipping_cost'],
                'total' => (float)$order['total']
            ]
        ];
    }

    $response = [
        'success' => true,
        'data' => [
            'orders' => $ordersWithItems,
            'pagination' => [
                'total' => $totalOrders,
                'limit' => $limit,
                'offset' => $offset,
                'has_more' => ($offset + $limit) < $totalOrders
            ],
            'filters' => [
                'status' => $status,
                'valid_statuses' => $validStatuses
            ]
        ],
        'message' => count($ordersWithItems) > 0 ? 'Historial de órdenes obtenido exitosamente.' : 'No se encontraron órdenes.'
    ];

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener items de una orden
function getOrderItems($orderId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            oi.*,
            p.title,
            p.slug,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image_url,
            (SELECT name FROM users WHERE id = p.seller_id) as seller_name
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?
        ORDER BY oi.id
    ");

    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll();

    // Formatear items
    return array_map(function($item) {
        return [
            'id' => (int)$item['id'],
            'product_id' => (int)$item['product_id'],
            'title' => $item['title'],
            'price_unit' => (float)$item['price_unit'],
            'quantity' => (int)$item['quantity'],
            'total' => (float)$item['price_unit'] * (int)$item['quantity'],
            'image' => $item['image_url'] ?: '/img/placeholder-product.jpg',
            'url' => '/producto/' . $item['slug'],
            'seller' => $item['seller_name']
        ];
    }, $items);
}
?>