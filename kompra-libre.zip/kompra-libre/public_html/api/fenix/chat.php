<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

// Verificar autenticación
$usuario = verificarAutenticacion();
if (!$usuario) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

// Obtener el mensaje del usuario
$input = json_decode(file_get_contents('php://input'), true);
$mensaje = trim($input['message'] ?? '');

if (empty($mensaje)) {
    http_response_code(400);
    echo json_encode(['error' => 'El mensaje no puede estar vacío']);
    exit;
}

try {
    $db = getDBConnection();
    
    // Registrar la pregunta en la base de datos
    $stmt = $db->prepare("
        INSERT INTO fenix_chat (usuario_id, mensaje, tipo, fecha_creacion)
        VALUES (:usuario_id, :mensaje, 'pregunta', NOW())
    ");
    $stmt->execute([
        ':usuario_id' => $usuario['id'],
        ':mensaje' => $mensaje
    ]);
    
    // Procesar la pregunta y generar una respuesta
    $respuesta = $this->procesarPregunta($mensaje, $usuario['id']);
    
    // Registrar la respuesta en la base de datos
    $stmt = $db->prepare("
        INSERT INTO fenix_chat (usuario_id, mensaje, tipo, fecha_creacion)
        VALUES (:usuario_id, :mensaje, 'respuesta', NOW())
    ");
    $stmt->execute([
        ':usuario_id' => $usuario['id'],
        ':mensaje' => $respuesta['respuesta']
    ]);
    
    // Devolver la respuesta
    echo json_encode([
        'success' => true,
        'response' => $respuesta['respuesta'],
        'suggestedQuestions' => $respuesta['preguntas_sugeridas'] ?? []
    ]);
    
} catch (Exception $e) {
    error_log('Error en el chat de Fénix: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error al procesar la solicitud'
    ]);
}

/**
 * Procesa la pregunta del usuario y genera una respuesta
 */
private function procesarPregunta($pregunta, $usuarioId) {
    $pregunta = strtolower(trim($pregunta));
    $db = $this->getDBConnection();
    $respuesta = '';
    $preguntasSugeridas = [];
    
    // Patrones de preguntas comunes
    $patrones = [
        '/hola|buenos|buenas|saludos|qué tal|que tal/' => function() {
            $saludos = ['¡Hola!', '¡Buen día!', '¡Hola! ¿En qué puedo ayudarte hoy?', '¡Hola! Soy Fénix, tu asistente de Kompra Libre.'];
            return $saludos[array_rand($saludos)];
        },
        '/cómo estás|como estas|qué tal estás|que tal estas/' => '¡Estoy aquí para ayudarte! ¿En qué puedo asistirte hoy?',
        '/gracias|muchas gracias|te lo agradezco/' => '¡De nada! Estoy aquí para ayudarte. ¿Hay algo más en lo que pueda asistirte?',
        '/adiós|chau|hasta luego|nos vemos/' => '¡Hasta luego! No dudes en volver si necesitas más ayuda. ¡Que tengas un excelente día!',
    ];
    
    // Buscar coincidencia con patrones
    foreach ($patrones as $patron => $respuestaPatron) {
        if (preg_match($patron, $pregunta)) {
            if (is_callable($respuestaPatron)) {
                $respuesta = $respuestaPatron();
            } else {
                $respuesta = $respuestaPatron;
            }
            break;
        }
    }
    
    // Si no hay coincidencia con patrones, buscar en la base de conocimiento
    if (empty($respuesta)) {
        // Buscar productos
        if (preg_match('/(buscar|encontrar|ver|mostrar|quiero|necesito|dónde está|donde esta|precio de|cuánto cuesta|cuanto cuesta)/', $pregunta)) {
            $terminosBusqueda = preg_replace('/(buscar|encontrar|ver|mostrar|quiero|necesito|dónde está|donde esta|precio de|cuánto cuesta|cuanto cuesta|\?|\.|,|\/)/', '', $pregunta);
            $terminosBusqueda = trim($terminosBusqueda);
            
            $stmt = $db->prepare("
                SELECT id, nombre, descripcion, precio 
                FROM productos 
                WHERE nombre LIKE :busqueda 
                   OR descripcion LIKE :busqueda 
                LIMIT 3
            ");
            $stmt->execute([':busqueda' => "%$terminosBusqueda%"]);
            $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (!empty($productos)) {
                $respuesta = "He encontrado estos productos que podrían interesarte:\n\n";
                foreach ($productos as $producto) {
                    $precioFormateado = number_format($producto['precio'], 0, ',', '.');
                    $respuesta .= "• {$producto['nombre']} - $ {$precioFormateado}\n";
                    $respuesta .= "  {$producto['descripcion']}\n\n";
                }
                $respuesta .= "¿Te gustaría ver más detalles de alguno de estos productos?";
                
                $preguntasSugeridas = array_map(function($p) {
                    return "¿Qué me puedes decir sobre {$p['nombre']}?";
                }, $productos);
            } else {
                $respuesta = "No encontré productos que coincidan con tu búsqueda. ¿Podrías ser más específico o intentar con otras palabras clave?";
            }
        }
        // Consultar estado de pedido
        elseif (preg_match('/(estado de mi pedido|dónde está mi pedido|donde esta mi pedido|cuándo llega|cuando llega|seguimiento)/', $pregunta)) {
            $stmt = $db->prepare("
                SELECT p.id, p.estado, p.fecha_creacion, 
                       pr.nombre as producto, pr.imagen_principal
                FROM pedidos p
                JOIN productos pr ON p.producto_id = pr.id
                WHERE p.usuario_id = :usuario_id
                ORDER BY p.fecha_creacion DESC
                LIMIT 1
            ");
            $stmt->execute([':usuario_id' => $usuarioId]);
            $pedido = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($pedido) {
                $fecha = new DateTime($pedido['fecha_creacion']);
                $respuesta = "Tu pedido #{$pedido['id']} de {$pedido['producto']} está actualmente en estado: " . 
                            "**{$this->formatearEstadoPedido($pedido['estado'])}**\n\n";
                $respuesta .= "Fecha del pedido: " . $fecha->format('d/m/Y H:i') . "\n";
                
                // Agregar información adicional según el estado
                switch ($pedido['estado']) {
                    case 'pendiente':
                        $respuesta .= "\nEstamos procesando tu pedido. Te notificaremos cuando sea enviado.";
                        break;
                    case 'enviado':
                        $respuesta .= "\n¡Tu pedido ha sido enviado! Debería llegar en los próximos días.";
                        break;
                    case 'entregado':
                        $respuesta .= "\n¡Tu pedido ha sido entregado! Esperamos que lo disfrutes.";
                        break;
                }
                
                $preguntasSugeridas = [
                    "¿Cómo hago un seguimiento de mi pedido?",
                    "¿Puedo cancelar mi pedido?",
                    "¿Cuánto tarda el envío?"
                ];
            } else {
                $respuesta = "No encontré pedidos recientes en tu cuenta. ¿Te gustaría ver nuestros productos disponibles?";
                $preguntasSugeridas = [
                    "¿Qué productos tienen envío gratis?",
                    "¿Cuáles son las ofertas del día?",
                    "¿Cómo realizo una compra?"
                ];
            }
        }
        // Consultar política de devoluciones
        elseif (preg_match('/(devolver|devolución|arrepentimiento|reembolso|cancelar pedido)/', $pregunta)) {
            $respuesta = "**Política de Devoluciones:**\n\n";
            $respuesta .= "• Tienes 10 días corridos desde la recepción del producto para solicitar la devolución.\n";
            $respuesta .= "• El producto debe estar en su estado original, sin uso y con su empaque original.\n";
            $respuesta .= "• El reembolso se realizará utilizando el mismo método de pago original.\n\n";
            $respuesta .= "Para iniciar una devolución, por favor ve a 'Mis Pedidos' en tu cuenta y selecciona la opción 'Solicitar Devolución'.";
            
            $preguntasSugeridas = [
                "¿Cuánto tarda el reembolso?",
                "¿Puedo cambiar un producto por otro?",
                "¿Qué hago si el producto llegó dañado?"
            ];
        }
        // Consultar métodos de pago
        elseif (preg_match('/(métodos de pago|formas de pago|aceptan tarjeta|pagar con|transferencia|efectivo)/', $pregunta)) {
            $respuesta = "**Métodos de Pago Aceptados:**\n\n";
            $respuesta .= "• 💳 Tarjetas de crédito (Visa, Mastercard, American Express)\n";
            $respuesta .= "• 🏦 Transferencia bancaria\n";
            $respuesta .= "• 📱 Pagos móviles (RedPagos, EBROU, etc.)\n";
            $respuesta .= "• 💵 Efectivo en puntos de pago (RedPagos, Abitab, etc.)\n\n";
            $respuesta .= "¿Neitas más información sobre algún método de pago en particular?";
            
            $preguntasSugeridas = [
                "¿Puedo pagar en cuotas?",
                "¿Hay recargo por pagar con tarjeta?",
                "¿Aceptan MercadoPago?"
            ];
        }
        // Consultar tiempos de envío
        elseif (preg_match('/(tiempo de envío|cuándo llega|cuando llega|demora del envío|envío gratis|envío gratuito)/', $pregunta)) {
            $respuesta = "**Tiempos de Envío Aproximados:**\n\n";
            $respuesta .= "• **Montevideo:** 24 a 48 horas hábiles\n";
            $respuesta .= "• **Interior del país:** 2 a 5 días hábiles\n\n";
            $respuesta .= "Los envíos son gratuitos para compras superiores a $2.500.\n\n";
            $respuesta .= "Una vez que tu pedido sea despachado, recibirás un correo con el número de seguimiento para que puedas monitorear su estado.";
            
            $preguntasSugeridas = [
                "¿Hacen envíos a todo el país?",
                "¿Puedo retirar en algún local?",
                "¿Cómo hago el seguimiento de mi envío?"
            ];
        }
        // Si no se reconoce la pregunta
        else {
            $respuesta = "Disculpa, no estoy seguro de entender tu pregunta. Estoy aquí para ayudarte con:\n\n";
            $respuesta .= "• Búsqueda de productos\n";
            $respuesta .= "• Estado de tus pedidos\n";
            $respuesta .= "• Políticas de devolución\n";
            $respuesta .= "• Métodos de pago\n";
            $respuesta .= "• Tiempos de envío\n\n";
            $respuesta .= "¿En qué más puedo ayudarte?";
            
            $preguntasSugeridas = [
                "¿Qué métodos de pago aceptan?",
                "¿Cuál es la política de devoluciones?",
                "¿Cómo hago un seguimiento de mi pedido?"
            ];
        }
    }
    
    return [
        'respuesta' => $respuesta,
        'preguntas_sugeridas' => $preguntasSugeridas
    ];
}

/**
 * Formatea el estado del pedido para mostrarlo al usuario
 */
private function formatearEstadoPedido($estado) {
    $estados = [
        'pendiente' => 'Pendiente de procesar',
        'procesando' => 'En proceso',
        'enviado' => 'Enviado',
        'entregado' => 'Entregado',
        'cancelado' => 'Cancelado'
    ];
    
    return $estados[$estado] ?? ucfirst($estado);
}
