<?php
// Configuración de cabeceras para API REST
header('Content-Type: application/json; charset=utf-8');

// Configurar CORS - Orígenes permitidos
$allowedOrigins = [
    'https://kompralibre.shop',
    'https://www.kompralibre.shop',
    'http://localhost',
    'http://127.0.0.1'
];

// Obtener el origen de la solicitud
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

// Validar el origen
if (!empty($origin)) {
    foreach ($allowedOrigins as $allowedOrigin) {
        if (strpos($origin, $allowedOrigin) !== false) {
            $origin = $allowedOrigin;
            break;
        }
    }
} else {
    $origin = '*'; // Solo para desarrollo
}

header('Access-Control-Allow-Origin: ' . $origin);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, Authorization');
header('Access-Control-Allow-Credentials: true');
header('Cache-Control: no-cache, must-revalidate');

// Cargar configuración primero
$configPath = __DIR__ . '/../../includes/config.php';
if (!file_exists($configPath)) {
    throw new Exception('El archivo de configuración no existe: ' . $configPath);
}
require_once $configPath;

// Inicializar la conexión a la base de datos
try {
    $dbPath = __DIR__ . '/../../includes/db.php';
    if (!file_exists($dbPath)) {
        throw new Exception('El archivo de base de datos no existe: ' . $dbPath);
    }
    
    // Incluir el archivo de base de datos
    require_once $dbPath;
    
    // Verificar que la conexión a la base de datos se estableció correctamente
    if (!isset($db) || !($db instanceof PDO)) {
        throw new Exception('La conexión a la base de datos no se pudo establecer');
    }
    
    // Verificar si la tabla de usuarios existe
    $tableCheck = $db->query("SHOW TABLES LIKE 'users'");
    if ($tableCheck->rowCount() === 0) {
        // Crear la tabla si no existe
        $createTableSQL = "CREATE TABLE IF NOT EXISTS `users` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `name` varchar(100) NOT NULL,
            `email` varchar(100) NOT NULL,
            `password` varchar(255) NOT NULL,
            `role` enum('user','seller','admin') NOT NULL DEFAULT 'user',
            `phone` varchar(20) DEFAULT NULL,
            `address` text DEFAULT NULL,
            `city` varchar(100) DEFAULT NULL,
            `postal_code` varchar(20) DEFAULT NULL,
            `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
            `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
            PRIMARY KEY (`id`),
            UNIQUE KEY `email` (`email`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        
        $db->exec($createTableSQL);
    }
    
} catch (Exception $e) {
    // Registrar el error
    error_log('Database error in register.php: ' . $e->getMessage());
    
    // Enviar respuesta de error
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error de conexión con la base de datos. Por favor, intente nuevamente.'
    ]);
    exit();
}

// Manejar solicitudes OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Iniciar búfer de salida
ob_start();

// Archivos ya incluidos al inicio
$functionsPath = __DIR__ . '/../../includes/functions.php';
if (!file_exists($functionsPath)) {
    throw new Exception('El archivo de funciones no existe: ' . $functionsPath);
}
require_once $functionsPath;

// Manejar errores de inicialización
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
});

// Manejar excepciones no capturadas
set_exception_handler(function($e) {
    error_log('Uncaught Exception: ' . $e->getMessage() . ' in ' . $e->getFile() . ' on line ' . $e->getLine());
    
    if (!headers_sent()) {
        header('Content-Type: application/json');
        http_response_code(500);
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'Error en el servidor',
        'error' => APP_DEBUG ? [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => APP_DEBUG ? $e->getTrace() : null
        ] : null
    ]);
    exit();
});

// Función para limpiar el búfer y enviar la respuesta
function sendJsonResponse($data, $statusCode = 200) {
    ob_end_clean();
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

try {
    // Obtener y validar el método de la solicitud
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Obtener datos de la solicitud
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Si no hay datos JSON, intentar con POST
    if (json_last_error() !== JSON_ERROR_NONE || !$data) {
        $data = $_POST;
    }
    
    // Validar datos requeridos
    $required = ['email', 'password', 'name'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new Exception("El campo $field es obligatorio", 400);
        }
    }
    
    // Sanitizar y validar datos
    $email = filter_var(trim($data['email']), FILTER_SANITIZE_EMAIL);
    $password = $data['password'];
    $name = sanitize(trim($data['name']));
    $role = in_array($data['role'] ?? 'buyer', ['buyer', 'seller']) ? $data['role'] : 'buyer';
    $phone = !empty($data['phone']) ? preg_replace('/[^0-9+]/', '', $data['phone']) : null;
    
    // Validaciones adicionales
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('El correo electrónico no es válido', 400);
    }
    
    if (strlen($password) < 8) {
        throw new Exception('La contraseña debe tener al menos 8 caracteres', 400);
    }
    
    if (strlen($name) < 2) {
        throw new Exception('El nombre debe tener al menos 2 caracteres', 400);
    }
    // Validar que tengamos datos
    if (!$data) {
        throw new Exception('Datos de registro requeridos', 400);
    }

    // Verificar si el correo ya existe
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        throw new Exception('Este correo electrónico ya está registrado', 409);
    }
    
    // Hashear la contraseña
    $password_hash = password_hash($password, PASSWORD_DEFAULT, ['cost' => 12]);
    
    // Iniciar transacción
    $db->beginTransaction();
    
    try {
        // Insertar usuario
        $stmt = $db->prepare("
            INSERT INTO users (name, email, password_hash, user_role, phone, email_verified)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $email_verified = 1; // O 0 si implementas verificación por correo
        
        $stmt->execute([
            $name,
            $email,
            $password_hash,
            $role,
            $phone,
            $email_verified
        ]);
        
        $user_id = $db->lastInsertId();
        
        // Si es vendedor, crear registro en la tabla sellers
        if ($role === 'seller') {
            $shop_name = substr("Tienda de " . $name, 0, 100);
            $shop_slug = createSlug($shop_name);
            
            $stmt = $db->prepare("
                INSERT INTO sellers (user_id, shop_name, shop_slug, status)
                VALUES (?, ?, ?, 'active')
            ");
            $stmt->execute([$user_id, $shop_name, $shop_slug]);
        }
        
        // Confirmar transacción
        $db->commit();
        
        // Iniciar sesión automáticamente
        $_SESSION['user_id'] = $user_id;
        $_SESSION['user_role'] = $role;
        $_SESSION['email'] = $email;
        $_SESSION['name'] = $name;
        
        if ($role === 'seller') {
            $_SESSION['is_seller'] = true;
            $_SESSION['shop_name'] = $shop_name;
        }
        
        // Generar token JWT
        $token = generateJWT([
            'user_id' => $user_id,
            'email' => $email,
            'role' => $role
        ]);
        
        // Enviar respuesta exitosa
        sendJsonResponse([
            'success' => true,
            'message' => 'Registro exitoso. ¡Bienvenido a ' . APP_NAME . '!',
            'token' => $token,
            'user' => [
                'id' => $user_id,
                'name' => $name,
                'email' => $email,
                'role' => $role,
                'is_seller' => ($role === 'seller'),
                'shop_name' => $shop_name ?? null
            ]
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
        // Generar token JWT
        $token = generateJWT([
            'user_id' => $user_id,
            'email' => $email,
            'role' => $role
        ]);
        
        // Enviar respuesta exitosa
        sendJsonResponse([
            'success' => true,
            'message' => 'Registro exitoso. ¡Bienvenido a ' . APP_NAME . '!',
            'token' => $token,
            'user' => [
                'id' => $user_id,
                'name' => $name,
                'email' => $email,
                'role' => $role,
                'is_seller' => ($role === 'seller'),
                'shop_name' => $shop_name ?? null
            ]
        ]);

} catch (Exception $e) {
    // Solo hacer rollback si hay una transacción activa
    if (isset($db) && $db->inTransaction()) {
        try {
            $db->rollBack();
        } catch (Exception $rollbackException) {
            // Registrar el error de rollback pero continuar con el manejo del error original
            error_log('Error al hacer rollback: ' . $rollbackException->getMessage());
        }
    }

    // Limpiar cualquier salida antes de enviar la respuesta de error
    if (ob_get_level() > 0) {
        ob_end_clean();
    }

    // Registrar el error
    error_log("Error en registro: " . $e->getMessage());

    // Determinar el código de estado HTTP
    $statusCode = $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500;

    // Mensaje de error amigable
    $errorMessage = $e->getMessage();

    // Si es un error de base de datos y estamos en producción, ocultar detalles
    if ($statusCode === 500 && !APP_DEBUG) {
        $errorMessage = 'Ocurrió un error al procesar el registro. Por favor, intente nuevamente.';
    }

    // Enviar respuesta de error
    $response = [
        'success' => false,
        'message' => $errorMessage
    ];

    // Agregar información de depuración si está habilitada
    if (APP_DEBUG) {
        $response['debug'] = [
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ];

        if (isset($e->errorInfo) && is_array($e->errorInfo)) {
            $response['debug']['error_info'] = $e->errorInfo;
        }
    }

    http_response_code($statusCode);
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}
