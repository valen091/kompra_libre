<?php
// Asegurar que siempre devolvamos JSON válido
ob_clean();
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'message' => '', 'data' => []];

try {
    // Solo permitir método POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Obtener datos del cuerpo de la petición
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Si no se pudo decodificar el JSON, intentar desde POST
    if (json_last_error() !== JSON_ERROR_NONE && !empty($_POST)) {
        $data = $_POST;
    }

    // Validar que tengamos datos
    if (!$data) {
        throw new Exception('Datos de registro requeridos', 400);
    }

    // Validar datos básicos
    if (empty($data['email']) || empty($data['password'])) {
        throw new Exception('Correo electrónico y contraseña son obligatorios', 400);
    }

    // Sanitizar datos
    $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
    $password = $data['password'];
    $name = sanitize($data['name'] ?? '');
    $role = in_array($data['role'] ?? '', ['buyer', 'seller']) ? $data['role'] : 'buyer';

    // Validar email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('El correo electrónico no es válido', 400);
    }

    // Validar contraseña
    if (strlen($password) < 8) {
        throw new Exception('La contraseña debe tener al menos 8 caracteres', 400);
    }

    // Si no hay nombre, usar parte del email
    if (empty($name) && !empty($email)) {
        $name = explode('@', $email)[0];
    }

    // Conectar a la base de datos usando el sistema unificado
    $db = getDB();

    // Generar username a partir del email si no se proporciona
    $username = $data['username'] ?? explode('@', $email)[0];

    // Verificar si el usuario ya existe
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
    $stmt->execute([$email, $username]);

    if ($stmt->rowCount() > 0) {
        throw new Exception('El correo electrónico o nombre de usuario ya está en uso', 409);
    }

    // Insertar nuevo usuario
    $stmt = $db->prepare("INSERT INTO users (username, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$username, $name, $email, $hashedPassword, $role]);
    $userId = $db->lastInsertId();

    // Si es vendedor, crear perfil de vendedor
    if ($role === 'seller') {
        $storeName = $data['store_name'] ?? $name . ' Store';
        $stmt = $db->prepare("INSERT INTO sellers (user_id, shop_alias) VALUES (?, ?)");
        $stmt->execute([$userId, $storeName]);
    }

    // Iniciar sesión automáticamente después del registro
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_role'] = $role;
    $_SESSION['username'] = $username;

    // Generar token JWT
    $token = generateJWT([
        'user_id' => $userId,
        'username' => $username,
        'role' => $role
    ]);

    // Respuesta exitosa
    $response = [
        'success' => true,
        'message' => 'Registro exitoso',
        'data' => [
            'user' => [
                'id' => $userId,
                'username' => $username,
                'name' => $name,
                'email' => $email,
                'role' => $role
            ],
            'token' => $token
        ]
    ];

} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'data' => []
    ];
}

// Limpiar cualquier output previo y asegurar JSON válido
ob_clean();
http_response_code(isset($response['code']) ? $response['code'] : 200);
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
exit;
?>