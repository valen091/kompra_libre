<?php
// Configuración de cabeceras para API REST
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . APP_URL);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Access-Control-Allow-Credentials: true');
header('Cache-Control: no-cache, must-revalidate');

// Manejar solicitudes OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

// Función para limpiar el búfer y enviar la respuesta
function sendJsonResponse($data, $statusCode = 200) {
    if (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

try {
    // Solo permitir método POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Obtener datos del cuerpo de la petición
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Si no hay datos JSON, intentar con POST
    if (json_last_error() !== JSON_ERROR_NONE || !$data) {
        $data = $_POST;
    }
    
    // Validar datos requeridos
    if (empty($data['email']) || empty($data['password'])) {
        throw new Exception('Correo electrónico y contraseña son obligatorios', 400);
    }
    
    // Sanitizar datos
    $email = filter_var(trim($data['email']), FILTER_SANITIZE_EMAIL);
    $password = $data['password'];
    
    // Validar email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('El correo electrónico no es válido', 400);
    }
    
    // Obtener conexión a la base de datos
    $db = getDB();
    
    // Buscar usuario por email
    $stmt = $db->prepare("
        SELECT u.*, s.id as seller_id, s.shop_name, s.shop_slug
        FROM users u
        LEFT JOIN sellers s ON u.id = s.user_id
        WHERE u.email = ?
        LIMIT 1
    
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Verificar si el usuario existe
    if (!$user) {
        // Registrar intento fallido (puedes implementar esto)
        error_log("Intento de inicio de sesión fallido para el email: $email - Usuario no encontrado");
        throw new Exception('Credenciales incorrectas', 401);
    }
    
    // Verificar la contraseña
    if (!password_verify($password, $user['password_hash'])) {
        // Registrar intento fallido
        error_log("Intento de inicio de sesión fallido para el usuario: {$user['email']} - Contraseña incorrecta");
        throw new Exception('Credenciales incorrectas', 401);
    }
    
    // Verificar si el correo está verificado
    if (!$user['email_verified']) {
        error_log("Intento de inicio de sesión fallido para el usuario: {$user['email']} - Correo no verificado");
        throw new Exception('Por favor, verifica tu correo electrónico antes de iniciar sesión', 403);
    }
    
    // Iniciar sesión
    session_regenerate_id(true);
    $_SESSION = [];
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_role'] = $user['user_role'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['name'] = $user['name'];
    
    // Si es vendedor, agregar datos adicionales
    if (!empty($user['seller_id'])) {
        $_SESSION['is_seller'] = true;
        $_SESSION['shop_name'] = $user['shop_name'];
        $_SESSION['shop_slug'] = $user['shop_slug'];
    }
    
    // Generar token JWT
    $tokenPayload = [
        'user_id' => $user['id'],
        'email' => $user['email'],
        'role' => $user['user_role'],
        'exp' => time() + (86400 * 30) // 30 días
    ];
    
    $token = generateJWT($tokenPayload);
    
    // Preparar datos del usuario para la respuesta
    $userData = [
        'id' => $user['id'],
        'name' => $user['name'],
        'email' => $user['email'],
        'role' => $user['user_role'],
        'is_seller' => !empty($user['seller_id']),
        'shop_name' => $user['shop_name'] ?? null,
        'shop_slug' => $user['shop_slug'] ?? null
    ];
    
    // Registrar inicio de sesión exitoso
    error_log("Inicio de sesión exitoso para el usuario: {$user['email']}");
    
    // Enviar respuesta exitosa
    sendJsonResponse([
        'success' => true,
        'message' => 'Inicio de sesión exitoso',
        'token' => $token,
        'user' => $userData
    ]);
    
} catch (Exception $e) {
    // Limpiar cualquier salida antes de enviar la respuesta de error
    if (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    // Registrar el error
    error_log("Error en login: " . $e->getMessage());
    
    // Determinar el código de estado HTTP
    $statusCode = $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500;
    
    // Mensaje de error amigable
    $errorMessage = $e->getMessage();
    
    // Si es un error de base de datos y estamos en producción, ocultar detalles
    if ($statusCode === 500 && !APP_DEBUG) {
        $errorMessage = 'Ocurrió un error al procesar el inicio de sesión. Por favor, intente nuevamente.';
    }
    
    // Enviar respuesta de error
    $response = [
        'success' => false,
        'message' => $errorMessage
    ];
    
    // Agregar información de depuración si está habilitada
    if (APP_DEBUG) {
        $response['debug'] = [
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ];
    }
    
    http_response_code($statusCode);
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}
