<?php
// Endpoint simplificado para testing
ob_clean();
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// Desactivar errores PHP
error_reporting(0);
ini_set('display_errors', 0);

$response = ['success' => false, 'message' => 'Test response'];

try {
    // Verificar método
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Verificar datos
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!$data || !isset($data['email']) || !isset($data['password'])) {
        throw new Exception('Datos de email y password requeridos', 400);
    }

    // Verificar conexión BD
    try {
        require_once __DIR__ . '/../../includes/config.php';
        require_once __DIR__ . '/../../includes/db.php';
        $db = getDB();
    } catch (Exception $e) {
        throw new Exception('Error de conexión BD: ' . $e->getMessage(), 500);
    }

    // Verificar si email ya existe
    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$data['email']]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        throw new Exception('Email ya registrado', 409);
    }

    // Insertar usuario
    $stmt = $db->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)");
    $name = $data['name'] ?? explode('@', $data['email'])[0];
    $role = $data['role'] ?? 'buyer';
    $passwordHash = password_hash($data['password'], PASSWORD_DEFAULT);

    $stmt->execute([$name, $data['email'], $passwordHash, $role]);
    $userId = $db->lastInsertId();

    $response = [
        'success' => true,
        'message' => 'Usuario registrado exitosamente',
        'data' => [
            'user_id' => $userId,
            'email' => $data['email'],
            'name' => $name,
            'role' => $role
        ]
    ];

} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500
    ];
}

// Asegurar respuesta JSON
ob_clean();
http_response_code(isset($response['code']) ? $response['code'] : 200);
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;
?>
