<?php
// Endpoint ultra-simple para testing
ob_clean();
header('Content-Type: application/json');
error_reporting(0);
ini_set('display_errors', 0);

echo json_encode([
    'success' => false,
    'message' => 'Endpoint funcionando correctamente',
    'timestamp' => time(),
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
    'data' => $_POST ?? []
]);
?>
