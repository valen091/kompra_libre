<?php
// Remove any previous headers to prevent duplicates
header_remove();

// Allow from any origin
if (isset($_SERVER['HTTP_ORIGIN'])) {
    $http_origin = $_SERVER['HTTP_ORIGIN'];
    
    // You can add more origins here if needed
    $allowed_origins = [
        'http://localhost:3001',
        'http://kompralibre.shop',
        'https://kompralibre.shop'
    ];
    
    if (in_array($http_origin, $allowed_origins)) {
        header("Access-Control-Allow-Origin: $http_origin");
    }
}

header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Iniciar búfer de salida
ob_start();

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

// Función para enviar respuesta JSON
function sendJsonResponse($data, $statusCode = 200) {
    if (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

try {
    // Validar método
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Si no hay JSON, intentar POST
    if (json_last_error() !== JSON_ERROR_NONE || !$data) {
        $data = $_POST;
    }
    
    // Mapeo de campos: Combinar first_name y last_name en name si no existe
    if (!isset($data['name']) && isset($data['first_name']) && isset($data['last_name'])) {
        $data['name'] = trim($data['first_name'] . ' ' . $data['last_name']);
    }
    
    // Validar campos requeridos
    $required = ['email', 'password', 'name'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new Exception("El campo $field es obligatorio", 400);
        }
    }
    
    // Sanitizar y validar
    $email = filter_var(trim($data['email']), FILTER_SANITIZE_EMAIL);
    $password = $data['password'];
    $name = sanitize(trim($data['name']));
    $role = in_array($data['role'] ?? 'buyer', ['buyer', 'seller']) ? $data['role'] : 'buyer';
    $phone = !empty($data['phone']) ? preg_replace('/[^0-9+]/', '', $data['phone']) : null;
    
    // Validaciones adicionales
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('El correo electrónico no es válido', 400);
    }
    
    if (strlen($password) < 8) {
        throw new Exception('La contraseña debe tener al menos 8 caracteres', 400);
    }
    
    if (strlen($name) < 2) {
        throw new Exception('El nombre debe tener al menos 2 caracteres', 400);
    }
    
    // Verificar email duplicado
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        throw new Exception('Este correo electrónico ya está registrado', 409);
    }
    
    $password_hash = password_hash($password, PASSWORD_DEFAULT, ['cost' => 12]);

    // Iniciar transacción
    $db->beginTransaction();

    try {
        // Insertar usuario
        $stmt = $db->prepare("
            INSERT INTO users (name, email, password_hash, user_role, phone, email_verified, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 1, NOW(), NOW())
        ");
        
        $stmt->execute([
            $name,
            $email,
            $password_hash,
            $role,
            $phone
        ]);
        
        $user_id = $db->lastInsertId();
        $shop_slug = null;
        
        // Si es vendedor, crear registro de seller
        if ($role === 'seller') {
            $shop_name = substr("Tienda de " . $name, 0, 100);
            $shop_slug = createSlug($shop_name);
            
            $stmt = $db->prepare("
                INSERT INTO sellers (user_id, shop_name, shop_slug, status, created_at, updated_at)
                VALUES (?, ?, ?, 'active', NOW(), NOW())
            ");
            
            $stmt->execute([$user_id, $shop_name, $shop_slug]);
        }
        
        // Commit
        $db->commit();
        
        // Generar JWT
        $token = generateJWT([
            'user_id' => $user_id,
            'email' => $email,
            'role' => $role
        ]);
        
        // Respuesta de éxito (agregado 'redirect')
        $response = [
            'success' => true,
            'message' => 'Registro exitoso',
            'redirect' => '/views/login.html',  // Ajusta según tu ruta
            'data' => [
                'user_id' => $user_id,
                'email' => $email,
                'role' => $role,
                'token' => $token
            ]
        ];
        
        if ($role === 'seller') {
            $response['data']['shop_name'] = $shop_name;
            $response['data']['shop_slug'] = $shop_slug;
        }
        
        sendJsonResponse($response);
        
    } catch (PDOException $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log("Database error: " . $e->getMessage());
        throw new Exception('Error en la base de datos. Intente nuevamente.', 500);
    }
    
} catch (Exception $e) {
    $statusCode = $e->getCode() ?: 400;
    $response = [
        'success' => false,
        'message' => $e->getMessage()
    ];
    
    // Agregar debug si está habilitado
    if (defined('APP_DEBUG') && APP_DEBUG) {
        $response['debug'] = [
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ];
    }
    
    sendJsonResponse($response, $statusCode);
}