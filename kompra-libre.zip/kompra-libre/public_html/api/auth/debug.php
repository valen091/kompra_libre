<?php
// Endpoint ultra-simple para debugging
ob_clean();
header('Content-Type: application/json');
error_reporting(0);
ini_set('display_errors', 0);

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Solo POST permitido', 405);
    }

    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!$data) {
        throw new Exception('JSON inválido', 400);
    }

    if (empty($data['email']) || empty($data['password'])) {
        throw new Exception('Email y password requeridos', 400);
    }

    // Validación básica
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Email inválido', 400);
    }

    if (strlen($data['password']) < 8) {
        throw new Exception('Password muy corto', 400);
    }

    // Simular registro exitoso
    $response = [
        'success' => true,
        'message' => 'Registro exitoso',
        'data' => [
            'email' => $data['email'],
            'timestamp' => time()
        ]
    ];

} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500
    ];
}

ob_clean();
http_response_code(isset($response['code']) ? $response['code'] : 200);
echo json_encode($response);
exit;
?>
