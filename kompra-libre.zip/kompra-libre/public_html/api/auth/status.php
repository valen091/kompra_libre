<?php
// Script simple para verificar que PHP esté funcionando
header('Content-Type: text/plain');
echo "PHP Version: " . PHP_VERSION . "\n";
echo "Server Software: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'Unknown') . "\n";
echo "Document Root: " . ($_SERVER['DOCUMENT_ROOT'] ?? 'Unknown') . "\n";
echo "Script Name: " . ($_SERVER['SCRIPT_NAME'] ?? 'Unknown') . "\n";
echo "Request URI: " . ($_SERVER['REQUEST_URI'] ?? 'Unknown') . "\n";
echo "Current Time: " . date('Y-m-d H:i:s') . "\n";
echo "File exists: " . (file_exists(__DIR__ . '/login.php') ? 'YES' : 'NO') . "\n";
?>
