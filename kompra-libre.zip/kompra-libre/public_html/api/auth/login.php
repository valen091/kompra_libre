<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'message' => ''];

try {
    // Solo permitir método POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Obtener datos del cuerpo de la petición
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validar datos
    if (empty($data['username']) || empty($data['password'])) {
        throw new Exception('Usuario y contraseña son obligatorios');
    }
    
    // Sanitizar datos
    $username = sanitize($data['username']);
    $password = $data['password'];
    
    $db = getDB();
    
    // Buscar usuario por nombre de usuario o correo
    $stmt = $db->prepare("
        SELECT u.*,
               s.shop_alias as store_name, s.description as store_description
        FROM users u
        LEFT JOIN sellers s ON u.id = s.user_id
        WHERE u.email = ? OR u.username = ? OR u.name = ?
    ");
    
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch();
    
    // Verificar usuario y contraseña
    if (!$user || !password_verify($password, $user['password_hash'])) {
        throw new Exception('Usuario o contraseña incorrectos');
    }
    
    // Iniciar sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['username'] = $user['username'];

    // Generar token JWT
    $token = generateJWT([
        'user_id' => $user['id'],
        'username' => $user['username'],
        'role' => $user['role']
    ]);

    $userData = [
        'id' => $user['id'],
        'username' => $user['username'],
        'email' => $user['email'],
        'role' => $user['role'],
        'full_name' => $user['name'],
        'avatar' => $user['avatar']
    ];

    // Agregar datos adicionales si es vendedor
    if ($user['role'] === 'seller') {
        $userData['store'] = [
            'name' => $user['store_name'],
            'description' => $user['store_description'],
            'logo' => null
        ];
    }
    
    $response = [
        'success' => true,
        'message' => 'Inicio de sesión exitoso',
        'user' => $userData,
        'token' => $token
    ];
    
} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500
    ];
}

echo json_encode($response);