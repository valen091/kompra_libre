<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . APP_URL);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Access-Control-Allow-Credentials: true');

// Manejar solicitudes OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'message' => ''];

try {
    // Solo permitir método POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Obtener datos del cuerpo de la petición
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validar datos
    if (empty($data['username']) || empty($data['password'])) {
        throw new Exception('Usuario y contraseña son obligatorios');
    }
    
    // Sanitizar datos
    $username = sanitize($data['username']);
    $password = $data['password'];
    
    $db = getDB();
    
    // Buscar usuario por email (en Hostinger el email es único)
    $stmt = $db->prepare("
        SELECT u.*, s.id as seller_id, s.shop_name, s.shop_description
        FROM users u
        LEFT JOIN sellers s ON u.id = s.user_id
        WHERE u.email = ?
    ");
    
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Verificar usuario y contraseña
    if (!$user) {
        throw new Exception('Usuario no encontrado');
    }
    
    if (!password_verify($password, $user['password_hash'])) {
        error_log("Error de contraseña para el usuario: " . $username);
        throw new Exception('Contraseña incorrecta');
    }
    
    // Iniciar sesión
    $_SESSION = [];
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_role'] = $user['user_role'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['name'] = $user['name'];
    
    // Si es vendedor, agregar datos adicionales
    if ($user['seller_id']) {
        $_SESSION['is_seller'] = true;
        $_SESSION['shop_name'] = $user['shop_name'];
    }

    // Generar token JWT
    $token = generateJWT([
        'user_id' => $user['id'],
        'email' => $user['email'],
        'role' => $user['user_role']
    ]);
    
    $response = [
        'success' => true,
        'message' => 'Inicio de sesión exitoso',
        'token' => $token,
        'user' => [
            'id' => $user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['user_role'],
            'is_seller' => !empty($user['seller_id']),
            'shop_name' => $user['shop_name'] ?? null
        ]
    ];
    
    // Establecer cookie HTTP-only segura
    setcookie(
        'auth_token',
        $token,
        [
            'expires' => time() + (86400 * 30), // 30 días
            'path' => '/',
            'domain' => parse_url(APP_URL, PHP_URL_HOST),
            'secure' => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Lax'
        ]
    );
    
} catch (Exception $e) {
    error_log("Error en login: " . $e->getMessage());
    $response = [
        'success' => false,
        'message' => 'Error en el inicio de sesión. Por favor, intente nuevamente.'
    ];
    
    if (APP_DEBUG) {
        $response['debug'] = $e->getMessage();
    }
    
    http_response_code($e->getCode() && $e->getCode() >= 400 ? $e->getCode() : 500);
}

echo json_encode($response);
