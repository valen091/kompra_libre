<?php
// Remove any previously set CORS headers
header_remove('Access-Control-Allow-Origin');
header_remove('Access-Control-Allow-Credentials');
header_remove('Access-Control-Allow-Methods');
header_remove('Access-Control-Allow-Headers');
header_remove('Access-Control-Max-Age');

// Set the allowed origins
$allowed_origins = [
    'http://localhost:3001',
    'http://kompralibre.shop',
    'https://kompralibre.shop'
];

// Get the origin of the request
$http_origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

// Check if the origin is allowed
$origin = in_array($http_origin, $allowed_origins) ? $http_origin : '';

// Headers that will be sent for both preflight and actual requests
$cors_headers = [];

if ($origin) {
    $cors_headers['Access-Control-Allow-Origin'] = $origin;
    $cors_headers['Access-Control-Allow-Credentials'] = 'true';
}

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    if ($origin) {
        $cors_headers['Access-Control-Allow-Methods'] = 'POST, OPTIONS';
        $cors_headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With';
        $cors_headers['Access-Control-Max-Age'] = '86400'; // 24 hours
    }
    
    // Send CORS headers
    foreach ($cors_headers as $key => $value) {
        header("$key: $value");
    }
    
    http_response_code(204);
    exit();
}

// For actual requests, set CORS headers
foreach ($cors_headers as $key => $value) {
    header("$key: $value");
}

// Set content type for the response
header('Content-Type: application/json; charset=utf-8');

// Database configuration
$host = 'localhost';
$dbname = 'u472738607_kompra_libre'; // Updated database name
$username = 'root'; // Update with your database username
$password = '';     // Update with your database password

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    // If no JSON data, try form data
    if (empty($input)) {
        $input = $_POST;
    }

    // Validate required fields
    $required = ['business_name', 'rut', 'first_name', 'last_name', 'email', 'phone', 'password'];
    $missing = array_diff($required, array_keys($input));
    
    if (!empty($missing)) {
        throw new Exception('Faltan campos requeridos: ' . implode(', ', $missing), 400);
    }

    // Connect to database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT id FROM sellers WHERE email = ?");
    $stmt->execute([$input['email']]);
    if ($stmt->fetch()) {
        throw new Exception('Este correo electrónico ya está registrado', 400);
    }

    // Hash password
    $hashedPassword = password_hash($input['password'], PASSWORD_DEFAULT);

    // Insert seller directly into sellers table
    $stmt = $pdo->prepare("
        INSERT INTO sellers (
            business_name, 
            rut, 
            first_name, 
            last_name, 
            email, 
            password, 
            phone,
            business_type,
            created_at
        ) VALUES (
            :business_name, 
            :rut, 
            :first_name, 
            :last_name, 
            :email, 
            :password, 
            :phone,
            :business_type,
            NOW()
        )
    ");
    
    $stmt->execute([
        ':business_name' => $input['business_name'],
        ':rut' => $input['rut'],
        ':first_name' => $input['first_name'],
        ':last_name' => $input['last_name'],
        ':email' => $input['email'],
        ':password' => $hashedPassword,
        ':phone' => $input['phone'],
        ':business_type' => $input['business_type'] ?? 'other' // Default to 'other' if not provided
    ]);

    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Registro exitoso. Por favor inicia sesión.',
        'redirect' => '/views/login.html'  // Updated path to include /views/
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error en la base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}