<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

// Verificar autenticación
$usuario = verificarAutenticacion();
if (!$usuario) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

try {
    $db = getDBConnection();
    
    // Obtener actividades recientes del usuario
    $stmt = $db->prepare("
        SELECT 
            'compra' as tipo,
            'Compra realizada' as titulo,
            CONCAT('Has comprado el producto "', p.nombre, '" por $', FORMAT(pp.precio, 0)) as descripcion,
            c.fecha_compra as fecha
        FROM compras c
        JOIN productos p ON c.producto_id = p.id
        JOIN productos_precios pp ON c.producto_id = pp.producto_id
        WHERE c.usuario_id = :usuario_id
        
        UNION ALL
        
        SELECT 
            'venta' as tipo,
            'Venta realizada' as titulo,
            CONCAT('Has vendido "', p.nombre, '" a ', u.nombre) as descripcion,
            v.fecha_venta as fecha
        FROM ventas v
        JOIN productos p ON v.producto_id = p.id
        JOIN usuarios u ON v.comprador_id = u.id
        WHERE v.vendedor_id = :usuario_id
        
        UNION ALL
        
        SELECT 
            'oferta' as tipo,
            'Nueva oferta' as titulo,
            CONCAT('Tienes una nueva oferta por "', p.nombre, '" de $', FORMAT(o.monto, 0)) as descripcion,
            o.fecha_creacion as fecha
        FROM ofertas o
        JOIN productos p ON o.producto_id = p.id
        WHERE p.vendedor_id = :usuario_id AND o.estado = 'pendiente'
        
        ORDER BY fecha DESC
        LIMIT 10
    ");
    
    $stmt->bindParam(':usuario_id', $usuario['id'], PDO::PARAM_INT);
    $stmt->execute();
    $actividades = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatear fechas
    foreach ($actividades as &$actividad) {
        $fecha = new DateTime($actividad['fecha']);
        $actividad['fecha'] = $fecha->format('c'); // Formato ISO 8601
    }
    
    echo json_encode($actividades);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error en la base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
