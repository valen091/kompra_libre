<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

// Verificar autenticación
$usuario = verificarAutenticacion();
if (!$usuario) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

try {
    $db = getDBConnection();
    
    // Obtener datos básicos del usuario
    $stmt = $db->prepare("
        SELECT 
            u.id,
            u.nombre,
            u.email,
            u.foto_perfil,
            u.fecha_registro,
            u.rol,
            (SELECT COUNT(*) FROM compras WHERE usuario_id = u.id) as total_compras,
            (SELECT COUNT(*) FROM ventas WHERE vendedor_id = u.id) as total_ventas,
            (SELECT COUNT(*) FROM favoritos WHERE usuario_id = u.id) as total_favoritos
        FROM usuarios u
        WHERE u.id = :usuario_id
    ");
    
    $stmt->bindParam(':usuario_id', $usuario['id'], PDO::PARAM_INT);
    $stmt->execute();
    $datosUsuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$datosUsuario) {
        throw new Exception('Usuario no encontrado');
    }
    
    // Ocultar información sensible
    unset($datosUsuario['password_hash']);
    unset($datosUsuario['token_recuperacion']);
    unset($datosUsuario['token_expiracion']);
    
    // Formatear fechas
    $fechaRegistro = new DateTime($datosUsuario['fecha_registro']);
    $datosUsuario['fecha_registro_formateada'] = $fechaRegistro->format('d/m/Y');
    $datosUsuario['miembro_desde'] = $fechaRegistro->format('F Y');
    
    echo json_encode($datosUsuario);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error en la base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
