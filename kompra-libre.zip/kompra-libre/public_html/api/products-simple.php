<?php
// API de productos simplificada para testing en Hostinger
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Productos de ejemplo
$products = [
    [
        'id' => 1,
        'title' => 'iPhone 15 Pro',
        'slug' => 'iphone-15-pro',
        'description' => 'iPhone 15 Pro en excelente estado',
        'price' => 899.99,
        'stock' => 5,
        'condition' => 'nuevo',
        'cover' => '',
        'category_name' => 'Electrónica',
        'seller_username' => 'vendedor1',
        'created_at' => '2024-01-15 10:30:00'
    ],
    [
        'id' => 2,
        'title' => 'MacBook Air M2',
        'slug' => 'macbook-air-m2',
        'description' => 'MacBook Air con chip M2, 8GB RAM, 256GB SSD',
        'price' => 1099.99,
        'stock' => 3,
        'condition' => 'nuevo',
        'cover' => '',
        'category_name' => 'Electrónica',
        'seller_username' => 'vendedor2',
        'created_at' => '2024-01-14 15:45:00'
    ],
    [
        'id' => 3,
        'title' => 'Camiseta Nike',
        'slug' => 'camiseta-nike',
        'description' => 'Camiseta deportiva Nike original',
        'price' => 29.99,
        'stock' => 20,
        'condition' => 'nuevo',
        'cover' => '',
        'category_name' => 'Ropa',
        'seller_username' => 'vendedor3',
        'created_at' => '2024-01-13 09:15:00'
    ]
];

// Filtrar productos según parámetros
$page = max(1, intval($_GET['page'] ?? 1));
$limit = min(20, max(1, intval($_GET['limit'] ?? 9)));
$offset = ($page - 1) * $limit;

// Simular paginación
$filteredProducts = array_slice($products, $offset, $limit);

echo json_encode([
    'success' => true,
    'message' => 'Productos de prueba - API funcionando',
    'data' => [
        'products' => $filteredProducts,
        'pagination' => [
            'total' => count($products),
            'page' => $page,
            'limit' => $limit,
            'total_pages' => ceil(count($products) / $limit)
        ]
    ],
    'debug' => [
        'php_version' => phpversion(),
        'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'request_method' => $_SERVER['REQUEST_METHOD'],
        'script_name' => $_SERVER['SCRIPT_NAME'],
        'get_params' => $_GET
    ]
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
