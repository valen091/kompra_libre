<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'message' => ''];

try {
    // Verificar autenticación
    if (!isAuthenticated()) {
        throw new Exception('No autorizado', 401);
    }
    
    // Verificar rol de vendedor
    if (!isSeller()) {
        throw new Exception('No tienes permisos para realizar esta acción', 403);
    }
    
    // Solo permitir método POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }
    
    // Obtener datos del formulario
    $data = $_POST;
    $files = $_FILES;
    
    // Validar datos requeridos
    $required = ['title', 'description', 'price', 'category_id', 'quantity'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new Exception("El campo $field es obligatorio");
        }
    }
    
    // Sanitizar datos
    $title = sanitize($data['title']);
    $slug = generateSlug($title);
    $description = sanitize($data['description']);
    $price = floatval($data['price']);
    $comparePrice = !empty($data['compare_price']) ? floatval($data['compare_price']) : null;
    $categoryId = intval($data['category_id']);
    $quantity = intval($data['quantity']);
    $condition = in_array($data['condition'] ?? 'new', ['new', 'used', 'refurbished']) ? $data['condition'] : 'new';
    $isFeatured = isset($data['is_featured']) ? (bool)$data['is_featured'] : false;
    
    // Validar precio
    if ($price <= 0) {
        throw new Exception('El precio debe ser mayor a cero');
    }
    
    // Validar categoría
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM categories WHERE id = ?");
    $stmt->execute([$categoryId]);
    
    if ($stmt->rowCount() === 0) {
        throw new Exception('La categoría seleccionada no es válida');
    }
    
    // Iniciar transacción
    $db->beginTransaction();
    
    try {
        // Insertar producto
        $stmt = $db->prepare("
            INSERT INTO products (
                seller_id, category_id, title, slug, description, price, compare_price, 
                quantity, condition, is_featured, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
        ");
        
        $stmt->execute([
            getCurrentUserId(),
            $categoryId,
            $title,
            $slug,
            $description,
            $price,
            $comparePrice,
            $quantity,
            $condition,
            $isFeatured ? 1 : 0
        ]);
        
        $productId = $db->lastInsertId();
        
        // Procesar imágenes
        if (!empty($files['images'])) {
            $uploadedImages = [];
            
            // Asegurarse de que sea un array
            $images = is_array($files['images']['name']) ? 
                $files['images'] : 
                [
                    'name' => [$files['images']['name']],
                    'tmp_name' => [$files['images']['tmp_name']],
                    'error' => [$files['images']['error']]
                ];
            
            foreach ($images['name'] as $index => $name) {
                if ($images['error'][$index] === UPLOAD_ERR_OK) {
                    $file = [
                        'name' => $name,
                        'tmp_name' => $images['tmp_name'][$index],
                        'error' => $images['error'][$index]
                    ];
                    
                    $uploadPath = uploadFile($file, "products/$productId/");
                    $isPrimary = $index === 0; // Primera imagen como principal
                    
                    $stmt = $db->prepare("
                        INSERT INTO product_images (product_id, image_url, is_primary, sort_order)
                        VALUES (?, ?, ?, ?)
                    ");
                    
                    $stmt->execute([$productId, $uploadPath, $isPrimary ? 1 : 0, $index]);
                    
                    $uploadedImages[] = $uploadPath;
                }
            }
        }
        
        // Procesar opciones y variantes si existen
        if (!empty($data['options'])) {
            $options = json_decode($data['options'], true);
            
            foreach ($options as $option) {
                $optionName = sanitize($option['name']);
                $optionValues = array_map('sanitize', $option['values']);
                
                $stmt = $db->prepare("
                    INSERT INTO product_options (product_id, name, values_json, position)
                    VALUES (?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $productId,
                    $optionName,
                    json_encode($optionValues),
                    $option['position'] ?? 0
                ]);
                
                $optionId = $db->lastInsertId();
                
                // Si hay variantes, insertarlas
                if (!empty($option['variants'])) {
                    foreach ($option['variants'] as $variant) {
                        $stmt = $db->prepare("
                            INSERT INTO product_variants (
                                product_id, sku, option1, option2, option3, 
                                price, compare_price, quantity, barcode
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        
                        $stmt->execute([
                            $productId,
                            $variant['sku'] ?? null,
                            $variant['option1'] ?? null,
                            $variant['option2'] ?? null,
                            $variant['option3'] ?? null,
                            $variant['price'] ?? $price,
                            $variant['compare_price'] ?? $comparePrice,
                            $variant['quantity'] ?? 0,
                            $variant['barcode'] ?? null
                        ]);
                    }
                }
            }
        }
        
        $db->commit();
        
        $response = [
            'success' => true,
            'message' => 'Producto creado exitosamente',
            'product_id' => $productId
        ];
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500
    ];
}

echo json_encode($response);