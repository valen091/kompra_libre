<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Obtener parámetros de consulta
    $params = [
        'page' => max(1, intval($_GET['page'] ?? 1)),
        'limit' => min(20, max(1, intval($_GET['limit'] ?? 12))),
        'category' => $_GET['category'] ?? null,
        'seller' => $_GET['seller'] ?? null,
        'q' => $_GET['q'] ?? '',
        'min_price' => $_GET['min_price'] ?? null,
        'max_price' => $_GET['max_price'] ?? null,
        'condition' => $_GET['condition'] ?? null,
        'sort' => $_GET['sort'] ?? 'newest',
        'in_stock' => isset($_GET['in_stock']) ? (bool)$_GET['in_stock'] : null
    ];
    
    $offset = ($params['page'] - 1) * $params['limit'];
    
    // Construir consulta
    $where = ['p.status = "active"'];
    $queryParams = [];
    
    // Filtros
    if (!empty($params['q'])) {
        $where[] = '(p.title LIKE ? OR p.description LIKE ?)';
        $searchTerm = "%{$params['q']}%";
        $queryParams[] = $searchTerm;
        $queryParams[] = $searchTerm;
    }
    
    if (!empty($params['category'])) {
        $where[] = '(c.id = ? OR c.slug = ? OR c.parent_id = ?)';
        $queryParams[] = $params['category'];
        $queryParams[] = $params['category'];
        $queryParams[] = $params['category'];
    }
    
    if (!empty($params['seller'])) {
        $where[] = '(u.id = ? OR u.username = ?)';
        $queryParams[] = $params['seller'];
        $queryParams[] = $params['seller'];
    }
    
    if (!empty($params['min_price'])) {
        $where[] = 'p.price >= ?';
        $queryParams[] = floatval($params['min_price']);
    }
    
    if (!empty($params['max_price'])) {
        $where[] = 'p.price <= ?';
        $queryParams[] = floatval($params['max_price']);
    }
    
    if (!empty($params['condition'])) {
        $where[] = 'p.condition = ?';
        $queryParams[] = $params['condition'];
    }
    
    if ($params['in_stock'] !== null) {
        $where[] = $params['in_stock'] ? 'p.quantity > 0' : 'p.quantity <= 0';
    }
    
    // Ordenar
    $orderBy = 'p.created_at DESC';
    switch ($params['sort']) {
        case 'price_asc':
            $orderBy = 'p.price ASC';
            break;
        case 'price_desc':
            $orderBy = 'p.price DESC';
            break;
        case 'name_asc':
            $orderBy = 'p.title ASC';
            break;
        case 'name_desc':
            $orderBy = 'p.title DESC';
            break;
        case 'popular':
            $orderBy = 'p.views DESC, p.sold_quantity DESC';
            break;
    }
    
    // Consulta para contar el total de productos
    $countQuery = "
        SELECT COUNT(DISTINCT p.id) as total
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN users u ON p.seller_id = u.id
        WHERE " . implode(' AND ', $where);
    
    $stmt = $db->prepare($countQuery);
    $stmt->execute($queryParams);
    $total = $stmt->fetch()['total'];
    
    // Consulta para obtener los productos
    $query = "
        SELECT 
            p.*,
            u.username as seller_username,
            u.avatar as seller_avatar,
            c.name as category_name,
            c.slug as category_slug,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
            (SELECT COUNT(*) FROM product_reviews WHERE product_id = p.id) as review_count,
            (SELECT AVG(rating) FROM product_reviews WHERE product_id = p.id) as average_rating
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN users u ON p.seller_id = u.id
        WHERE " . implode(' AND ', $where) . "
        GROUP BY p.id
        ORDER BY $orderBy
        LIMIT ? OFFSET ?
    ";
    
    $queryParams[] = $params['limit'];
    $queryParams[] = $offset;
    
    $stmt = $db->prepare($query);
    $stmt->execute($queryParams);
    $products = $stmt->fetchAll();
    
    // Formatear respuesta
    $formattedProducts = array_map(function($product) {
        return [
            'id' => $product['id'],
            'title' => $product['title'],
            'slug' => $product['slug'],
            'description' => $product['description'],
            'price' => (float)$product['price'],
            'compare_price' => $product['compare_price'] ? (float)$product['compare_price'] : null,
            'quantity' => (int)$product['quantity'],
            'condition' => $product['condition'],
            'images' => [
                'primary' => $product['primary_image'] ?: '/img/placeholder-product.jpg'
            ],
            'category' => [
                'id' => $product['category_id'],
                'name' => $product['category_name'],
                'slug' => $product['category_slug']
            ],
            'seller' => [
                'id' => $product['seller_id'],
                'username' => $product['seller_username'],
                'avatar' => $product['seller_avatar'] ?: '/img/avatar-placeholder.png'
            ],
            'rating' => [
                'average' => (float)$product['average_rating'],
                'count' => (int)$product['review_count']
            ],
            'created_at' => $product['created_at'],
            'updated_at' => $product['updated_at']
        ];
    }, $products);
    
    $response = [
        'success' => true,
        'data' => [
            'products' => $formattedProducts,
            'pagination' => [
                'total' => (int)$total,
                'page' => $params['page'],
                'limit' => $params['limit'],
                'total_pages' => ceil($total / $params['limit'])
            ]
        ]
    ];
    
} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => 'Error al obtener productos: ' . $e->getMessage(),
        'code' => $e->getCode() ?: 500
    ];
}

echo json_encode($response);