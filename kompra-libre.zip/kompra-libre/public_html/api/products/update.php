<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Solo permitir método PUT para actualizar productos
    if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
        throw new Exception('Método no permitido. Use PUT para actualizar productos.', 405);
    }

    // Verificar autenticación
    if (!isAuthenticated()) {
        throw new Exception('Debe iniciar sesión para actualizar productos.', 401);
    }

    // Verificar rol de vendedor
    if (!isSeller()) {
        throw new Exception('No tienes permisos para actualizar productos.', 403);
    }

    // Obtener datos del request
    $data = json_decode(file_get_contents('php://input'), true);

    // Validar datos requeridos
    if (empty($data['product_id'])) {
        throw new Exception('ID de producto es requerido.', 400);
    }

    $productId = (int)$data['product_id'];

    if ($productId <= 0) {
        throw new Exception('ID de producto inválido.', 400);
    }

    $userId = getCurrentUserId();

    // Verificar que el producto existe y pertenece al usuario
    $stmt = $db->prepare("
        SELECT p.*, s.user_id as seller_user_id
        FROM products p
        JOIN sellers s ON p.seller_id = s.id
        WHERE p.id = ?
    ");

    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        throw new Exception('Producto no encontrado.', 404);
    }

    // Verificar que el usuario sea el dueño del producto o admin
    if ($product['seller_user_id'] !== $userId && !isAdmin()) {
        throw new Exception('No tienes permisos para modificar este producto.', 403);
    }

    // Validar y sanitizar datos a actualizar
    $updateFields = [];
    $updateValues = [];

    // Campos que se pueden actualizar
    $allowedFields = [
        'title' => 'string',
        'description' => 'string',
        'price' => 'float',
        'compare_price' => 'float',
        'category_id' => 'int',
        'quantity' => 'int',
        'condition' => 'string',
        'is_featured' => 'bool',
        'status' => 'string'
    ];

    foreach ($allowedFields as $field => $type) {
        if (isset($data[$field])) {
            $value = $data[$field];

            switch ($type) {
                case 'string':
                    if (empty($value)) {
                        throw new Exception("El campo {$field} no puede estar vacío.", 400);
                    }
                    $value = sanitize($value);
                    if ($field === 'title') {
                        $updateFields[] = 'slug = ?';
                        $updateValues[] = generateSlug($value);
                    }
                    break;

                case 'float':
                    $value = (float)$value;
                    if ($value < 0) {
                        throw new Exception("El campo {$field} debe ser mayor o igual a 0.", 400);
                    }
                    break;

                case 'int':
                    $value = (int)$value;
                    if ($value < 0) {
                        throw new Exception("El campo {$field} debe ser mayor o igual a 0.", 400);
                    }
                    // Validar categoría si se está actualizando
                    if ($field === 'category_id') {
                        $stmt = $db->prepare("SELECT id FROM categories WHERE id = ?");
                        $stmt->execute([$value]);
                        if ($stmt->rowCount() === 0) {
                            throw new Exception('La categoría seleccionada no es válida.', 400);
                        }
                    }
                    break;

                case 'bool':
                    $value = (bool)$value ? 1 : 0;
                    break;
            }

            $updateFields[] = "{$field} = ?";
            $updateValues[] = $value;
        }
    }

    // Validar que al menos un campo se esté actualizando
    if (empty($updateFields)) {
        throw new Exception('No se especificaron campos para actualizar.', 400);
    }

    // Validar condición si se está actualizando
    if (isset($data['condition'])) {
        $validConditions = ['nuevo', 'usado', 'refurbished'];
        if (!in_array($data['condition'], $validConditions)) {
            throw new Exception('Condición de producto inválida.', 400);
        }
    }

    // Validar estado si se está actualizando
    if (isset($data['status'])) {
        $validStatuses = ['active', 'inactive', 'draft'];
        if (!in_array($data['status'], $validStatuses)) {
            throw new Exception('Estado de producto inválido.', 400);
        }
    }

    // Validar precio si se está actualizando
    if (isset($data['price'])) {
        if ($data['price'] <= 0) {
            throw new Exception('El precio debe ser mayor a cero.', 400);
        }
    }

    // Iniciar transacción
    $db->beginTransaction();

    try {
        // Actualizar producto
        $updateFields[] = 'updated_at = NOW()';
        $sql = "UPDATE products SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $updateValues[] = $productId;

        $stmt = $db->prepare($sql);
        $stmt->execute($updateValues);

        if ($stmt->rowCount() === 0) {
            throw new Exception('No se pudo actualizar el producto.', 500);
        }

        // Si se está actualizando el stock, verificar que no sea menor que órdenes pendientes
        if (isset($data['quantity'])) {
            $pendingQuantity = getPendingOrderQuantity($productId);

            if ($data['quantity'] < $pendingQuantity) {
                throw new Exception("No se puede reducir el stock por debajo de {$pendingQuantity} unidades (órdenes pendientes).", 400);
            }
        }

        // Confirmar transacción
        $db->commit();

        // Obtener producto actualizado
        $updatedProduct = getProductWithDetails($productId);

        // Crear notificación si el producto se reactiva
        if (isset($data['status']) && $data['status'] === 'active' && $product['status'] !== 'active') {
            createProductStatusNotification($productId, $product['status'], 'active', $userId);
        }

        $response = [
            'success' => true,
            'message' => 'Producto actualizado exitosamente.',
            'data' => [
                'product_id' => $productId,
                'product' => $updatedProduct,
                'updated_fields' => array_keys(array_filter($allowedFields, function($field) use ($data) {
                    return isset($data[$field]);
                })),
                'updated_at' => date('Y-m-d H:i:s')
            ]
        ];

    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $db->rollback();
        throw $e;
    }

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener detalles completos de un producto
function getProductWithDetails($productId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            p.*,
            c.name as category_name,
            c.slug as category_slug,
            s.user_id as seller_user_id,
            u.name as seller_name,
            u.email as seller_email,
            (SELECT COUNT(*) FROM product_images WHERE product_id = p.id) as image_count,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
            (SELECT COUNT(*) FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE oi.product_id = p.id AND o.status NOT IN ('cancelado', 'entregado')) as pending_orders
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        JOIN sellers s ON p.seller_id = s.id
        LEFT JOIN users u ON s.user_id = u.id
        WHERE p.id = ?
    ");

    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        return null;
    }

    // Obtener imágenes del producto
    $stmt = $db->prepare("SELECT id, image_url, is_primary, sort_order FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC");
    $stmt->execute([$productId]);
    $images = $stmt->fetchAll();

    return [
        'id' => (int)$product['id'],
        'title' => $product['title'],
        'slug' => $product['slug'],
        'description' => $product['description'],
        'price' => (float)$product['price'],
        'compare_price' => $product['compare_price'] ? (float)$product['compare_price'] : null,
        'quantity' => (int)$product['quantity'],
        'condition' => $product['condition'],
        'is_featured' => (bool)$product['is_featured'],
        'status' => $product['status'],
        'category' => [
            'id' => (int)$product['category_id'],
            'name' => $product['category_name'],
            'slug' => $product['category_slug']
        ],
        'seller' => [
            'id' => (int)$product['seller_user_id'],
            'name' => $product['seller_name'],
            'email' => $product['seller_email']
        ],
        'images' => array_map(function($img) {
            return [
                'id' => (int)$img['id'],
                'image_url' => $img['image_url'],
                'is_primary' => (bool)$img['is_primary'],
                'sort_order' => (int)$img['sort_order']
            ];
        }, $images),
        'image_count' => (int)$product['image_count'],
        'primary_image' => $product['primary_image'],
        'pending_orders' => (int)$product['pending_orders'],
        'created_at' => $product['created_at'],
        'updated_at' => $product['updated_at']
    ];
}

// Función auxiliar para obtener cantidad pendiente en órdenes
function getPendingOrderQuantity($productId) {
    global $db;

    $stmt = $db->prepare("
        SELECT COALESCE(SUM(oi.quantity), 0) as pending_qty
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE oi.product_id = ? AND o.status IN ('pendiente', 'procesando', 'enviado')
    ");

    $stmt->execute([$productId]);
    $result = $stmt->fetch();

    return (int)$result['pending_qty'];
}

// Función auxiliar para crear notificación de cambio de estado
function createProductStatusNotification($productId, $oldStatus, $newStatus, $updatedByUserId) {
    global $db;

    // Crear notificación para el vendedor
    $stmt = $db->prepare("
        INSERT INTO notifications (user_id, kind, payload, created_at)
        VALUES (?, 'product_updated', ?, NOW())
    ");

    $payload = json_encode([
        'product_id' => $productId,
        'old_status' => $oldStatus,
        'new_status' => $newStatus,
        'updated_by' => $updatedByUserId,
        'type' => 'status_change'
    ]);

    $stmt->execute([$updatedByUserId, $payload]);
}
?>