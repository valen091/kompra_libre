<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Solo permitir método GET para obtener producto
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        throw new Exception('Método no permitido. Use GET para obtener detalles de producto.', 405);
    }

    // Obtener ID del producto desde parámetros GET
    $productId = isset($_GET['id']) ? (int)$_GET['id'] : null;
    $productSlug = isset($_GET['slug']) ? sanitize($_GET['slug']) : null;

    if (!$productId && !$productSlug) {
        throw new Exception('ID o slug de producto requerido.', 400);
    }

    // Obtener detalles completos del producto
    if ($productId) {
        $product = getProductWithDetails($productId);
    } else {
        $product = getProductBySlug($productSlug);
    }

    if (!$product) {
        throw new Exception('Producto no encontrado.', 404);
    }

    // Verificar que el producto esté activo (excepto para el vendedor)
    if ($product['status'] !== 'active') {
        $isOwner = isAuthenticated() && isProductOwner($product['id']);
        if (!$isOwner && !isAdmin()) {
            throw new Exception('Producto no disponible.', 404);
        }
    }

    // Incrementar contador de vistas (solo para productos activos)
    if ($product['status'] === 'active') {
        incrementProductViews($product['id']);
    }

    // Obtener productos relacionados de la misma categoría
    $relatedProducts = getRelatedProducts($product['id'], $product['category']['id'], 8);

    // Obtener productos del mismo vendedor
    $sellerProducts = getSellerProducts($product['seller']['id'], $product['id'], 6);

    // Obtener reseñas del producto
    $reviews = getProductReviews($product['id']);

    $response = [
        'success' => true,
        'message' => 'Detalles de producto obtenidos exitosamente.',
        'data' => [
            'product' => $product,
            'related_products' => $relatedProducts,
            'seller_products' => $sellerProducts,
            'reviews' => [
                'items' => $reviews,
                'summary' => calculateReviewSummary($reviews)
            ],
            'meta' => [
                'can_edit' => isAuthenticated() && isProductOwner($product['id']),
                'can_delete' => isAuthenticated() && isProductOwner($product['id']),
                'can_add_to_cart' => $product['status'] === 'active' && $product['quantity'] > 0,
                'is_featured' => (bool)$product['is_featured'],
                'is_in_stock' => $product['quantity'] > 0,
                'stock_status' => getStockStatus($product['quantity'])
            ]
        ]
    ];

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener detalles completos de un producto
function getProductWithDetails($productId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            p.*,
            c.name as category_name,
            c.slug as category_slug,
            s.user_id as seller_user_id,
            u.name as seller_name,
            u.email as seller_email,
            (SELECT COUNT(*) FROM product_images WHERE product_id = p.id) as image_count,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
            (SELECT COUNT(*) FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE oi.product_id = p.id AND o.status NOT IN ('cancelado', 'entregado')) as pending_orders,
            (SELECT COUNT(*) FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE oi.product_id = p.id AND o.status = 'entregado') as sold_quantity,
            (SELECT AVG(r.rating) FROM reviews r WHERE r.product_id = p.id) as average_rating,
            (SELECT COUNT(*) FROM reviews r WHERE r.product_id = p.id) as review_count
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        JOIN sellers s ON p.seller_id = s.id
        LEFT JOIN users u ON s.user_id = u.id
        WHERE p.id = ?
    ");

    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        return null;
    }

    // Obtener imágenes del producto
    $stmt = $db->prepare("SELECT id, image_url, is_primary, sort_order FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC");
    $stmt->execute([$productId]);
    $images = $stmt->fetchAll();

    return [
        'id' => (int)$product['id'],
        'title' => $product['title'],
        'slug' => $product['slug'],
        'description' => $product['description'],
        'price' => (float)$product['price'],
        'compare_price' => $product['compare_price'] ? (float)$product['compare_price'] : null,
        'quantity' => (int)$product['quantity'],
        'condition' => $product['condition'],
        'is_featured' => (bool)$product['is_featured'],
        'status' => $product['status'],
        'views' => (int)$product['views'],
        'sold_quantity' => (int)$product['sold_quantity'],
        'average_rating' => $product['average_rating'] ? (float)$product['average_rating'] : null,
        'review_count' => (int)$product['review_count'],
        'category' => [
            'id' => (int)$product['category_id'],
            'name' => $product['category_name'],
            'slug' => $product['category_slug']
        ],
        'seller' => [
            'id' => (int)$product['seller_user_id'],
            'name' => $product['seller_name'],
            'email' => $product['seller_email']
        ],
        'images' => array_map(function($img) {
            return [
                'id' => (int)$img['id'],
                'image_url' => $img['image_url'],
                'is_primary' => (bool)$img['is_primary'],
                'sort_order' => (int)$img['sort_order']
            ];
        }, $images),
        'image_count' => (int)$product['image_count'],
        'primary_image' => $product['primary_image'],
        'pending_orders' => (int)$product['pending_orders'],
        'created_at' => $product['created_at'],
        'updated_at' => $product['updated_at']
    ];
}

// Función auxiliar para obtener producto por slug
function getProductBySlug($slug) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            p.*,
            c.name as category_name,
            c.slug as category_slug,
            s.user_id as seller_user_id,
            u.name as seller_name,
            u.email as seller_email,
            (SELECT COUNT(*) FROM product_images WHERE product_id = p.id) as image_count,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
            (SELECT COUNT(*) FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE oi.product_id = p.id AND o.status NOT IN ('cancelado', 'entregado')) as pending_orders
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        JOIN sellers s ON p.seller_id = s.id
        LEFT JOIN users u ON s.user_id = u.id
        WHERE p.slug = ?
    ");

    $stmt->execute([$slug]);
    $product = $stmt->fetch();

    if (!$product) {
        return null;
    }

    // Agregar imágenes y formatear como en getProductWithDetails
    $stmt = $db->prepare("SELECT id, image_url, is_primary, sort_order FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC");
    $stmt->execute([$product['id']]);
    $images = $stmt->fetchAll();

    $product['images'] = array_map(function($img) {
        return [
            'id' => (int)$img['id'],
            'image_url' => $img['image_url'],
            'is_primary' => (bool)$img['is_primary'],
            'sort_order' => (int)$img['sort_order']
        ];
    }, $images);

    $product['image_count'] = (int)$product['image_count'];
    $product['primary_image'] = $product['primary_image'];
    $product['pending_orders'] = (int)$product['pending_orders'];

    return $product;
}

// Función auxiliar para verificar si el usuario es dueño del producto
function isProductOwner($productId) {
    if (!isAuthenticated()) {
        return false;
    }

    global $db;

    $stmt = $db->prepare("
        SELECT COUNT(*) as is_owner
        FROM products p
        JOIN sellers s ON p.seller_id = s.id
        WHERE p.id = ? AND s.user_id = ?
    ");

    $stmt->execute([$productId, getCurrentUserId()]);
    $result = $stmt->fetch();

    return $result['is_owner'] > 0;
}

// Función auxiliar para incrementar vistas del producto
function incrementProductViews($productId) {
    global $db;

    $stmt = $db->prepare("UPDATE products SET views = views + 1 WHERE id = ?");
    $stmt->execute([$productId]);
}

// Función auxiliar para obtener productos relacionados
function getRelatedProducts($productId, $categoryId, $limit = 8) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            p.id, p.title, p.slug, p.price, p.quantity,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image_url,
            (SELECT name FROM users u JOIN sellers s ON u.id = s.user_id WHERE s.id = p.seller_id) as seller_name
        FROM products p
        WHERE p.id != ? AND p.category_id = ? AND p.status = 'active' AND p.quantity > 0
        ORDER BY RAND()
        LIMIT ?
    ");

    $stmt->execute([$productId, $categoryId, $limit]);
    $products = $stmt->fetchAll();

    return array_map(function($product) {
        return [
            'id' => (int)$product['id'],
            'title' => $product['title'],
            'slug' => $product['slug'],
            'price' => (float)$product['price'],
            'image' => $product['image_url'] ?: '/img/placeholder-product.jpg',
            'seller' => $product['seller_name'],
            'url' => '/producto/' . $product['slug']
        ];
    }, $products);
}

// Función auxiliar para obtener productos del mismo vendedor
function getSellerProducts($sellerId, $excludeProductId, $limit = 6) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            p.id, p.title, p.slug, p.price, p.quantity,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as image_url
        FROM products p
        WHERE p.seller_id = (SELECT id FROM sellers WHERE user_id = ?) AND p.id != ? AND p.status = 'active' AND p.quantity > 0
        ORDER BY p.created_at DESC
        LIMIT ?
    ");

    $stmt->execute([$sellerId, $excludeProductId, $limit]);
    $products = $stmt->fetchAll();

    return array_map(function($product) {
        return [
            'id' => (int)$product['id'],
            'title' => $product['title'],
            'slug' => $product['slug'],
            'price' => (float)$product['price'],
            'image' => $product['image_url'] ?: '/img/placeholder-product.jpg',
            'url' => '/producto/' . $product['slug']
        ];
    }, $products);
}

// Función auxiliar para obtener reseñas del producto
function getProductReviews($productId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            r.*,
            u.name as user_name,
            u.email as user_email
        FROM reviews r
        JOIN users u ON r.user_id = u.id
        WHERE r.product_id = ?
        ORDER BY r.created_at DESC
        LIMIT 20
    ");

    $stmt->execute([$productId]);
    $reviews = $stmt->fetchAll();

    return array_map(function($review) {
        return [
            'id' => (int)$review['id'],
            'user' => [
                'name' => $review['user_name'],
                'email' => $review['user_email']
            ],
            'rating' => (int)$review['rating'],
            'comment' => $review['comment'],
            'created_at' => $review['created_at']
        ];
    }, $reviews);
}

// Función auxiliar para calcular resumen de reseñas
function calculateReviewSummary($reviews) {
    if (empty($reviews)) {
        return [
            'average_rating' => null,
            'total_reviews' => 0,
            'rating_distribution' => []
        ];
    }

    $totalReviews = count($reviews);
    $averageRating = array_sum(array_column($reviews, 'rating')) / $totalReviews;

    $distribution = [];
    for ($i = 1; $i <= 5; $i++) {
        $distribution[$i] = count(array_filter($reviews, function($review) use ($i) {
            return $review['rating'] === $i;
        }));
    }

    return [
        'average_rating' => round($averageRating, 1),
        'total_reviews' => $totalReviews,
        'rating_distribution' => $distribution
    ];
}

// Función auxiliar para obtener estado de stock
function getStockStatus($quantity) {
    if ($quantity <= 0) {
        return 'out_of_stock';
    } elseif ($quantity <= 5) {
        return 'low_stock';
    } elseif ($quantity <= 20) {
        return 'medium_stock';
    } else {
        return 'in_stock';
    }
}
?>
