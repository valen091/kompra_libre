# 📦 API de Productos - Kompra Libre

Este directorio contiene los endpoints de la API para la gestión completa de productos por parte de los vendedores.

## 📋 Endpoints Disponibles

### 🆕 **Crear Producto** - `create.php`
**POST** `/api/products/create.php`

Permite a los vendedores crear nuevos productos con imágenes y validación completa.

#### **Parámetros (Form Data):**
```php
$_POST = [
    'title' => 'iPhone 15 Pro Max',
    'description' => 'Smartphone de última generación...',
    'price' => 1299.99,
    'compare_price' => 1499.99,  // opcional
    'category_id' => 1,
    'quantity' => 50,
    'condition' => 'nuevo',  // nuevo, usado, refurbished
    'is_featured' => true,   // opcional
];

$_FILES = [
    'images' => [
        'name' => ['image1.jpg', 'image2.jpg'],
        'tmp_name' => ['/tmp/php123', '/tmp/php456'],
        'error' => [0, 0]
    ]
];
```

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Producto creado exitosamente.",
  "data": {
    "product_id": 123,
    "product": {
      "id": 123,
      "title": "iPhone 15 Pro Max",
      "slug": "iphone-15-pro-max",
      "price": 1299.99,
      "quantity": 50,
      "status": "active",
      "images": [
        {
          "id": 1,
          "image_url": "/uploads/products/123/image1.jpg",
          "is_primary": true,
          "sort_order": 0
        }
      ]
    }
  }
}
```

#### **Funcionalidades:**
- ✅ **Validación completa** de datos requeridos
- ✅ **Subida de múltiples imágenes** con gestión de orden
- ✅ **Generación automática** de slug amigable
- ✅ **Categorías validadas** contra la base de datos
- ✅ **Precios y cantidades** validadas

### 🔍 **Detalles de Producto** - `details.php`
**GET** `/api/products/details.php?id=123` o `/api/products/details.php?slug=iphone-15-pro-max`

Obtiene detalles completos de un producto específico con información adicional para la página del producto.

#### **Parámetros GET:**
| Parámetro | Descripción | Ejemplo |
|-----------|-------------|---------|
| `id` | ID numérico del producto | `123` |
| `slug` | Slug amigable del producto | `iphone-15-pro-max` |

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Detalles de producto obtenidos exitosamente.",
  "data": {
    "product": {
      "id": 123,
      "title": "iPhone 15 Pro Max",
      "slug": "iphone-15-pro-max",
      "description": "Smartphone de última generación...",
      "price": 1299.99,
      "compare_price": 1499.99,
      "quantity": 25,
      "condition": "nuevo",
      "is_featured": true,
      "status": "active",
      "views": 156,
      "sold_quantity": 8,
      "average_rating": 4.8,
      "review_count": 5,
      "category": {
        "id": 1,
        "name": "Electrónica",
        "slug": "electronica"
      },
      "seller": {
        "id": 456,
        "name": "Tienda Apple",
        "email": "contacto@tiendaapple.com"
      },
      "images": [
        {
          "id": 1,
          "image_url": "/img/products/123_1.jpg",
          "is_primary": true,
          "sort_order": 0
        }
      ],
      "primary_image": "/img/products/123_1.jpg",
      "pending_orders": 2,
      "created_at": "2025-01-15 10:30:00",
      "updated_at": "2025-01-15 14:30:00"
    },
    "related_products": [
      {
        "id": 124,
        "title": "iPhone 15 Pro",
        "slug": "iphone-15-pro",
        "price": 1099.99,
        "image": "/img/products/124_1.jpg",
        "seller": "Tienda Apple",
        "url": "/producto/iphone-15-pro"
      }
    ],
    "seller_products": [
      {
        "id": 125,
        "title": "MacBook Air M3",
        "slug": "macbook-air-m3",
        "price": 1299.99,
        "image": "/img/products/125_1.jpg",
        "url": "/producto/macbook-air-m3"
      }
    ],
    "reviews": {
      "items": [
        {
          "id": 1,
          "user": {
            "name": "María García",
            "email": "maria@example.com"
          },
          "rating": 5,
          "comment": "Excelente producto, llegó rápido",
          "created_at": "2025-01-14 16:20:00"
        }
      ],
      "summary": {
        "average_rating": 4.8,
        "total_reviews": 5,
        "rating_distribution": {
          "1": 0,
          "2": 0,
          "3": 0,
          "4": 1,
          "5": 4
        }
      }
    },
    "meta": {
      "can_edit": true,
      "can_delete": true,
      "can_add_to_cart": true,
      "is_featured": true,
      "is_in_stock": true,
      "stock_status": "in_stock"
    }
  }
}
```

#### **Funcionalidades:**
- ✅ **Información completa** del producto con imágenes
- ✅ **Productos relacionados** de la misma categoría
- ✅ **Otros productos** del mismo vendedor
- ✅ **Sistema de reseñas** con estadísticas
- ✅ **Contador de vistas** automático
- ✅ **Permisos de edición** para el vendedor
- ✅ **Estado de stock** y disponibilidad

### 🔄 **Actualizar Producto** - `update.php`
**PUT** `/api/products/update.php`

Permite a los vendedores actualizar sus productos existentes.

#### **Parámetros (JSON):**
```json
{
  "product_id": 123,
  "title": "iPhone 15 Pro Max 512GB",
  "description": "Descripción actualizada...",
  "price": 1399.99,
  "quantity": 25,
  "condition": "nuevo",
  "is_featured": true,
  "status": "active"
}
```

#### **Campos Actualizables:**
| Campo | Tipo | Descripción | Requerido |
|-------|------|-------------|-----------|
| `title` | string | Título del producto | ⚠️ Al actualizar se regenera el slug |
| `description` | string | Descripción detallada | ⚠️ |
| `price` | float | Precio actual | ⚠️ Debe ser > 0 |
| `compare_price` | float | Precio anterior | ➖ Opcional |
| `category_id` | int | ID de categoría | ⚠️ |
| `quantity` | int | Stock disponible | ⚠️ Debe ser >= órdenes pendientes |
| `condition` | string | Condición | ➖ nuevo, usado, refurbished |
| `is_featured` | bool | Producto destacado | ➖ |
| `status` | string | Estado del producto | ➖ active, inactive, draft |

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Producto actualizado exitosamente.",
  "data": {
    "product_id": 123,
    "product": {
      "id": 123,
      "title": "iPhone 15 Pro Max 512GB",
      "slug": "iphone-15-pro-max-512gb",
      "price": 1399.99,
      "quantity": 25,
      "status": "active",
      "updated_at": "2025-01-15 14:30:00"
    },
    "updated_fields": ["title", "price", "quantity"],
    "updated_at": "2025-01-15 14:30:00"
  }
}
```

#### **Validaciones Especiales:**
- ✅ **Permisos de propietario** - Solo el vendedor puede actualizar
- ✅ **Stock mínimo** - No se puede reducir por debajo de órdenes pendientes
- ✅ **Categorías válidas** - Verificación contra la base de datos
- ✅ **Precios positivos** - Validación de precios mayores a 0

### 🗑️ **Eliminar Producto** - `delete.php`
**DELETE** `/api/products/delete.php`

Elimina productos del catálogo con validaciones de seguridad.

#### **Parámetros (GET o JSON):**
```bash
# Desde URL
DELETE /api/products/delete.php?product_id=123

# Desde JSON
{
  "product_id": 123
}
```

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Producto eliminado exitosamente.",
  "data": {
    "product_id": 123,
    "product_info": {
      "title": "iPhone 15 Pro Max",
      "category": "Electrónica",
      "price": 1299.99,
      "quantity": 50
    },
    "images_deleted": 3,
    "deleted_at": "2025-01-15 14:30:00",
    "deleted_by": {
      "user_id": 456,
      "role": "seller"
    }
  }
}
```

#### **Validaciones de Seguridad:**
- ✅ **Permisos de propietario** - Solo el vendedor o admin
- ✅ **Sin órdenes pendientes** - No se puede eliminar con compras activas
- ✅ **Eliminación en cascada** - Limpia imágenes y referencias
- ✅ **Transacción segura** - Rollback en caso de error

## 🔧 **Códigos de Respuesta HTTP**

| Código | Descripción | Endpoint |
|--------|-------------|----------|
| `200` | Operación exitosa | Todos |
| `201` | Producto creado exitosamente | create.php |
| `400` | Datos inválidos / Validación fallida | Todos |
| `401` | No autenticado | Todos |
| `403` | Sin permisos (no es el vendedor) | update.php / delete.php |
| `404` | Producto no encontrado | update.php / delete.php |
| `405` | Método HTTP no permitido | Todos |
| `500` | Error interno del servidor | Todos |

## 📝 **Ejemplos de Uso (JavaScript)**

### **Crear Producto con Imágenes:**
```javascript
const formData = new FormData();
formData.append('title', 'iPhone 15 Pro Max');
formData.append('description', 'Smartphone de última generación...');
formData.append('price', 1299.99);
formData.append('category_id', 1);
formData.append('quantity', 50);
formData.append('condition', 'nuevo');

// Agregar imágenes
formData.append('images[]', file1);
formData.append('images[]', file2);

fetch('/api/products/create.php', {
    method: 'POST',
    body: formData
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        console.log('Producto creado:', data.data.product_id);
        window.location.href = `/producto/${data.data.product.slug}`;
    }
});
```

### **Obtener Detalles de Producto:**
```javascript
// Obtener detalles por ID
fetch('/api/products/details.php?id=123')
.then(response => response.json())
.then(data => {
    if (data.success) {
        renderProductPage(data.data.product);
        renderRelatedProducts(data.data.related_products);
        renderSellerProducts(data.data.seller_products);
        renderReviews(data.data.reviews);

        // Actualizar meta información
        updateProductMeta(data.data.meta);
    }
});

// Obtener detalles por slug (URL amigable)
fetch('/api/products/details.php?slug=iphone-15-pro-max')
.then(response => response.json())
.then(data => {
    if (data.success) {
        // Incrementa automáticamente el contador de vistas
        console.log('Vistas actuales:', data.data.product.views);
    }
});
```

### **Renderizar Página de Producto:**
```javascript
function renderProductPage(product) {
    document.title = `${product.title} - Kompra Libre`;
    
    // Renderizar imágenes principales
    const imageGallery = document.querySelector('.product-images');
    imageGallery.innerHTML = product.images.map((img, index) => `
        <div class="product-image ${img.is_primary ? 'primary' : ''}" data-index="${index}">
            <img src="${img.image_url}" alt="${product.title}">
        </div>
    `).join('');

    // Renderizar información principal
    document.querySelector('.product-title').textContent = product.title;
    document.querySelector('.product-price').innerHTML = `
        <span class="current-price">$${product.price.toFixed(2)}</span>
        ${product.compare_price ? `<span class="compare-price">$${product.compare_price.toFixed(2)}</span>` : ''}
    `;
    document.querySelector('.product-description').innerHTML = product.description;
    
    // Estado de stock
    const stockElement = document.querySelector('.stock-status');
    stockElement.className = `stock-status ${product.quantity > 0 ? 'in-stock' : 'out-of-stock'}`;
    stockElement.textContent = product.quantity > 0 ? `${product.quantity} disponibles` : 'Agotado';
    
    // Botón de agregar al carrito
    const addToCartBtn = document.querySelector('.add-to-cart-btn');
    addToCartBtn.disabled = product.quantity <= 0;
    addToCartBtn.dataset.productId = product.id;
}

function renderRelatedProducts(products) {
    const container = document.querySelector('.related-products');
    container.innerHTML = products.map(product => `
        <div class="related-product">
            <img src="${product.image}" alt="${product.title}">
            <h4>${product.title}</h4>
            <p class="price">$${product.price.toFixed(2)}</p>
            <a href="${product.url}" class="view-product">Ver producto</a>
        </div>
    `).join('');
}

function updateProductMeta(meta) {
    // Actualizar botones de acción
    const editBtn = document.querySelector('.edit-product-btn');
    const deleteBtn = document.querySelector('.delete-product-btn');
    
    editBtn.style.display = meta.can_edit ? 'inline-block' : 'none';
    deleteBtn.style.display = meta.can_delete ? 'inline-block' : 'none';
    
    // Actualizar estado
    const featuredBadge = document.querySelector('.featured-badge');
    featuredBadge.style.display = meta.is_featured ? 'inline-block' : 'none';
}
```

### **Eliminar Producto:**
```javascript
fetch(`/api/products/delete.php?product_id=${productId}`, {
    method: 'DELETE'
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        console.log('Eliminado:', data.data.product_info.title);
        removeProductFromList(productId);
    }
});
```

### **Listar con Filtros:**
```javascript
async function searchProducts(query, category, priceRange) {
    const params = new URLSearchParams({
        q: query,
        category: category,
        min_price: priceRange.min,
        max_price: priceRange.max,
        sort: 'price_asc',
        limit: 20
    });

    const response = await fetch(`/api/products/index.php?${params}`);
    const data = await response.json();

    if (data.success) {
        renderProductGrid(data.data.products);
        updatePagination(data.data.pagination);
    }
}
```

## ⚠️ **Validaciones y Seguridad**

### **Autenticación y Autorización:**
- ✅ **Sesión requerida** - Solo usuarios autenticados
- ✅ **Rol de vendedor** - Solo vendedores y admins pueden gestionar
- ✅ **Propiedad de productos** - Solo el vendedor puede modificar sus productos
- ✅ **Validación de admin** - Los admins pueden gestionar cualquier producto

### **Validaciones de Datos:**
- ✅ **Campos requeridos** - Título, descripción, precio, categoría, cantidad
- ✅ **Precios válidos** - Mayores a 0, con hasta 2 decimales
- ✅ **Categorías existentes** - Validación contra la base de datos
- ✅ **Stock no negativo** - Cantidades válidas
- ✅ **Condiciones válidas** - Solo valores permitidos

### **Validaciones de Seguridad:**
- ✅ **Stock vs Órdenes** - No reducir stock por debajo de órdenes pendientes
- ✅ **Eliminación segura** - Solo productos sin órdenes activas
- ✅ **Sanitización completa** - Prevención de XSS y inyección SQL
- ✅ **Transacciones** - Consistencia de datos con rollback

## 🖼️ **Gestión de Imágenes**

### **Subida de Imágenes (create.php):**
- ✅ **Múltiples imágenes** - Hasta 10 imágenes por producto
- ✅ **Imagen principal** - Primera imagen como principal automáticamente
- ✅ **Validación de tipos** - Solo JPG, PNG, WebP
- ✅ **Tamaño limitado** - Máximo 5MB por imagen
- ✅ **Reorganización** - Drag & drop para cambiar orden

### **Eliminación de Imágenes (delete.php):**
- ✅ **Eliminación en cascada** - Se eliminan todas las imágenes del producto
- ✅ **Limpieza de archivos** - Elimina archivos físicos del servidor
- ✅ **Reorganización automática** - Nueva primera imagen como principal

## 📊 **Estados de Producto**

| Estado | Descripción | Visible en Catálogo | Editable |
|--------|-------------|-------------------|----------|
| `active` | Producto activo y visible | ✅ Sí | ✅ Sí |
| `inactive` | Producto oculto temporalmente | ❌ No | ✅ Sí |
| `draft` | Borrador, no publicado | ❌ No | ✅ Sí |

## 🚀 **Mejores Prácticas**

### **Para Vendedores:**
- **Imágenes de calidad** - Usa fotos claras y múltiples ángulos
- **Descripciones detalladas** - Incluye características, dimensiones, garantía
- **Precios competitivos** - Considera precio de comparación para mostrar descuento
- **Stock actualizado** - Mantén el inventario sincronizado
- **Categorización correcta** - Usa la categoría más específica posible

### **Para Desarrolladores:**
- **Validación en frontend** - Previene errores antes de enviar
- **Progreso visual** - Muestra progreso durante subida de imágenes
- **Confirmaciones** - Pide confirmación antes de eliminar
- **Feedback inmediato** - Actualiza UI después de operaciones
- **Manejo de errores** - Muestra mensajes claros al usuario

## 📞 **Solución de Problemas**

### **Errores Comunes:**

#### **"No tienes permisos" (403):**
- Verificar que el usuario sea el vendedor del producto
- Confirmar que la sesión no haya expirado
- Revisar permisos de administrador si es necesario

#### **"Stock insuficiente" (400):**
- No se puede reducir stock por debajo de órdenes pendientes
- Esperar a que se completen las órdenes existentes
- Contactar al admin para ajustes manuales

#### **"Categoría no válida" (400):**
- Verificar que el category_id existe en la base de datos
- Usar IDs válidos de la tabla categories
- Consultar categorías disponibles desde el frontend

#### **"Producto no encontrado" (404):**
- Verificar que el product_id sea correcto
- Confirmar que el producto no haya sido eliminado
- Revisar permisos de acceso al producto

### **Debugging:**
- Revisa logs del servidor
- Usa herramientas como Postman para testing
- Verifica la base de datos directamente
- Consulta el historial de notificaciones

## 🔗 **Integración con Otros Módulos**

- **📸 Imágenes** - Gestión completa de imágenes de productos
- **🛒 Carrito** - Validación de stock antes de agregar al carrito
- **📋 Órdenes** - Verificación de stock antes de crear órdenes
- **👤 Usuarios** - Autenticación y roles de vendedor
- **📢 Notificaciones** - Alertas automáticas de cambios
- **📊 Analytics** - Seguimiento de vistas y ventas

## 📈 **Performance y Escalabilidad**

### **Optimizaciones Implementadas:**
- ✅ **Consultas eficientes** con JOINs optimizados
- ✅ **Índices de BD** en campos críticos (title, category_id, seller_id)
- ✅ **Paginación** para grandes catálogos
- ✅ **Validación temprana** para evitar operaciones innecesarias
- ✅ **Transacciones** para consistencia de datos
- ✅ **Caching** de categorías frecuentes

### **Recomendaciones Adicionales:**
- **CDN** para imágenes de productos
- **Compresión de imágenes** automática
- **Queue system** para procesamiento de imágenes
- **Monitoring** de performance de consultas
- **Analytics** para productos más populares

---
**¡La API de productos está completa y lista para producción!** 📦✨
