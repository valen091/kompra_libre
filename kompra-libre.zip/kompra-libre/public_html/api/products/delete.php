<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Solo permitir método DELETE para eliminar productos
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        throw new Exception('Método no permitido. Use DELETE para eliminar productos.', 405);
    }

    // Verificar autenticación
    if (!isAuthenticated()) {
        throw new Exception('Debe iniciar sesión para eliminar productos.', 401);
    }

    // Verificar rol de vendedor
    if (!isSeller()) {
        throw new Exception('No tienes permisos para eliminar productos.', 403);
    }

    // Obtener ID del producto desde parámetros GET o JSON
    $productId = null;

    // Intentar obtener desde parámetros GET
    if (isset($_GET['product_id'])) {
        $productId = (int)$_GET['product_id'];
    } else {
        // Intentar obtener desde JSON body
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['product_id'])) {
            $productId = (int)$data['product_id'];
        }
    }

    if (!$productId || $productId <= 0) {
        throw new Exception('ID de producto inválido o no especificado.', 400);
    }

    $userId = getCurrentUserId();

    // Verificar que el producto existe y pertenece al usuario
    $stmt = $db->prepare("
        SELECT p.*, s.user_id as seller_user_id,
               (SELECT COUNT(*) FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE oi.product_id = p.id AND o.status IN ('pendiente', 'procesando', 'enviado')) as pending_orders
        FROM products p
        JOIN sellers s ON p.seller_id = s.id
        WHERE p.id = ?
    ");

    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        throw new Exception('Producto no encontrado.', 404);
    }

    // Verificar que el usuario sea el dueño del producto o admin
    if ($product['seller_user_id'] !== $userId && !isAdmin()) {
        throw new Exception('No tienes permisos para eliminar este producto.', 403);
    }

    // Verificar que no haya órdenes pendientes para este producto
    if ($product['pending_orders'] > 0) {
        throw new Exception("No se puede eliminar el producto porque tiene {$product['pending_orders']} orden(es) pendiente(s).", 400);
    }

    // Obtener información del producto antes de eliminar (para la respuesta)
    $productInfo = getProductWithDetails($productId);

    // Iniciar transacción
    $db->beginTransaction();

    try {
        // Eliminar imágenes del producto
        $stmt = $db->prepare("DELETE FROM product_images WHERE product_id = ?");
        $stmt->execute([$productId]);

        // Eliminar el producto (esto también eliminará los order_items relacionados por CASCADE)
        $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$productId]);

        if ($stmt->rowCount() === 0) {
            throw new Exception('No se pudo eliminar el producto.', 500);
        }

        // Confirmar transacción
        $db->commit();

        // Crear notificación de eliminación
        createProductDeletionNotification($productId, $productInfo, $userId);

        $response = [
            'success' => true,
            'message' => 'Producto eliminado exitosamente.',
            'data' => [
                'product_id' => $productId,
                'product_info' => [
                    'title' => $productInfo['title'],
                    'category' => $productInfo['category']['name'],
                    'price' => $productInfo['price'],
                    'quantity' => $productInfo['quantity']
                ],
                'images_deleted' => $productInfo['image_count'],
                'deleted_at' => date('Y-m-d H:i:s'),
                'deleted_by' => [
                    'user_id' => $userId,
                    'role' => isAdmin() ? 'admin' : 'seller'
                ]
            ]
        ];

    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $db->rollback();
        throw $e;
    }

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener detalles completos de un producto
function getProductWithDetails($productId) {
    global $db;

    $stmt = $db->prepare("
        SELECT
            p.*,
            c.name as category_name,
            c.slug as category_slug,
            s.user_id as seller_user_id,
            u.name as seller_name,
            u.email as seller_email,
            (SELECT COUNT(*) FROM product_images WHERE product_id = p.id) as image_count,
            (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
            (SELECT COUNT(*) FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE oi.product_id = p.id AND o.status NOT IN ('cancelado', 'entregado')) as pending_orders
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        JOIN sellers s ON p.seller_id = s.id
        LEFT JOIN users u ON s.user_id = u.id
        WHERE p.id = ?
    ");

    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        return null;
    }

    // Obtener imágenes del producto
    $stmt = $db->prepare("SELECT id, image_url, is_primary, sort_order FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order ASC");
    $stmt->execute([$productId]);
    $images = $stmt->fetchAll();

    return [
        'id' => (int)$product['id'],
        'title' => $product['title'],
        'slug' => $product['slug'],
        'description' => $product['description'],
        'price' => (float)$product['price'],
        'compare_price' => $product['compare_price'] ? (float)$product['compare_price'] : null,
        'quantity' => (int)$product['quantity'],
        'condition' => $product['condition'],
        'is_featured' => (bool)$product['is_featured'],
        'status' => $product['status'],
        'category' => [
            'id' => (int)$product['category_id'],
            'name' => $product['category_name'],
            'slug' => $product['category_slug']
        ],
        'seller' => [
            'id' => (int)$product['seller_user_id'],
            'name' => $product['seller_name'],
            'email' => $product['seller_email']
        ],
        'images' => array_map(function($img) {
            return [
                'id' => (int)$img['id'],
                'image_url' => $img['image_url'],
                'is_primary' => (bool)$img['is_primary'],
                'sort_order' => (int)$img['sort_order']
            ];
        }, $images),
        'image_count' => (int)$product['image_count'],
        'primary_image' => $product['primary_image'],
        'pending_orders' => (int)$product['pending_orders'],
        'created_at' => $product['created_at'],
        'updated_at' => $product['updated_at']
    ];
}

// Función auxiliar para crear notificación de eliminación de producto
function createProductDeletionNotification($productId, $productInfo, $deletedByUserId) {
    global $db;

    // Crear notificación para el vendedor
    $stmt = $db->prepare("
        INSERT INTO notifications (user_id, kind, payload, created_at)
        VALUES (?, 'product_deleted', ?, NOW())
    ");

    $payload = json_encode([
        'product_id' => $productId,
        'product_title' => $productInfo['title'],
        'category' => $productInfo['category']['name'],
        'price' => $productInfo['price'],
        'quantity' => $productInfo['quantity'],
        'deleted_by' => $deletedByUserId,
        'type' => 'deletion'
    ]);

    $stmt->execute([$deletedByUserId, $payload]);
}
?>