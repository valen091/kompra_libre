<?php
// Asegurar que siempre devolvamos JSON válido
ob_clean();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-cache, must-revalidate');

// Datos de ejemplo para cuando falle la conexión a la base de datos
$fallback_products = [
    [
        'id' => 1,
        'title' => 'Producto de Ejemplo 1',
        'description' => 'Descripción del producto de ejemplo 1',
        'price' => 99.99,
        'image' => 'https://via.placeholder.com/300',
        'category_id' => 1,
        'category_name' => 'Electrónica',
        'condition' => 'new',
        'stock' => 10
    ],
    [
        'id' => 2,
        'title' => 'Producto de Ejemplo 2',
        'description' => 'Descripción del producto de ejemplo 2',
        'price' => 149.99,
        'image' => 'https://via.placeholder.com/300',
        'category_id' => 2,
        'category_name' => 'Ropa',
        'condition' => 'used',
        'stock' => 5
    ]
];

$response = ['success' => false, 'data' => [], 'message' => ''];
$db_connected = false;

// Intentar conectar a la base de datos
try {
    // Verificar si los archivos necesarios existen
    $config_file = __DIR__ . '/../includes/config.php';
    $db_file = __DIR__ . '/../includes/db.php';
    $functions_file = __DIR__ . '/../includes/functions.php';
    
    if (file_exists($config_file) && file_exists($db_file) && file_exists($functions_file)) {
        require_once $config_file;
        require_once $db_file;
        require_once $functions_file;
        
        // Intentar conectar a la base de datos
        $db = getDB();
        $db_connected = true;
    }
    // Obtener parámetros de consulta
    $params = [
        'page' => max(1, intval($_GET['page'] ?? 1)),
        'limit' => min(20, max(1, intval($_GET['limit'] ?? 12))),
        'category' => $_GET['category'] ?? null,
        'seller' => $_GET['seller'] ?? null,
        'q' => $_GET['q'] ?? '',
        'min_price' => $_GET['min_price'] ?? null,
        'max_price' => $_GET['max_price'] ?? null,
        'condition' => $_GET['condition'] ?? null,
        'sort' => $_GET['sort'] ?? 'newest',
        'in_stock' => isset($_GET['in_stock']) ? (bool)$_GET['in_stock'] : null
    ];
    
    $offset = ($params['page'] - 1) * $params['limit'];
    
    // Construir consulta
    $where = ['p.visible = 1'];
    $queryParams = [];
    
    // Filtros
    if (!empty($params['q'])) {
        $where[] = '(p.title LIKE ? OR p.description LIKE ?)';
        $searchTerm = "%{$params['q']}%";
        $queryParams[] = $searchTerm;
        $queryParams[] = $searchTerm;
    }
    
    if (!empty($params['category'])) {
        $where[] = '(c.id = ? OR c.slug = ?)';
        $queryParams[] = $params['category'];
        $queryParams[] = $params['category'];
    }
    
    if (!empty($params['seller'])) {
        $where[] = '(u.id = ? OR u.username = ?)';
        $queryParams[] = $params['seller'];
        $queryParams[] = $params['seller'];
    }
    
    if (!empty($params['min_price'])) {
        $where[] = 'p.price >= ?';
        $queryParams[] = floatval($params['min_price']);
    }
    
    if (!empty($params['max_price'])) {
        $where[] = 'p.price <= ?';
        $queryParams[] = floatval($params['max_price']);
    }
    
    if (!empty($params['condition'])) {
        $where[] = 'p.condition = ?';
        $queryParams[] = $params['condition'];
    }
    
    if ($params['in_stock'] !== null) {
        $where[] = $params['in_stock'] ? 'p.stock > 0' : 'p.stock <= 0';
    }
    
    // Ordenar
    $orderBy = 'p.created_at DESC';
    switch ($params['sort']) {
        case 'price_asc':
            $orderBy = 'p.price ASC';
            break;
        case 'price_desc':
            $orderBy = 'p.price DESC';
            break;
        case 'name_asc':
            $orderBy = 'p.title ASC';
            break;
        case 'name_desc':
            $orderBy = 'p.title DESC';
            break;
    }
    
    // Consulta para contar el total de productos
    $countQuery = "
        SELECT COUNT(DISTINCT p.id) as total
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN sellers s ON p.seller_id = s.id
        LEFT JOIN users u ON s.user_id = u.id
        WHERE " . implode(' AND ', $where);
    
    $stmt = $db->prepare($countQuery);
    $stmt->execute($queryParams);
    $total = $stmt->fetch()['total'];
    
    // Consulta para obtener los productos
    $query = "
        SELECT 
            p.*,
            u.username as seller_username,
            u.name as seller_name,
            c.name as category_name,
            c.slug as category_slug
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN sellers s ON p.seller_id = s.id
        LEFT JOIN users u ON s.user_id = u.id
        WHERE " . implode(' AND ', $where) . "
        ORDER BY $orderBy
        LIMIT ? OFFSET ?
    ";
    
    $queryParams[] = $params['limit'];
    $queryParams[] = $offset;
    
    $stmt = $db->prepare($query);
    $stmt->execute($queryParams);
    $products = $stmt->fetchAll();
    
    // Formatear respuesta
    $formattedProducts = array_map(function($product) {
        return [
            'id' => $product['id'],
            'title' => $product['title'],
            'slug' => $product['slug'] ?? '',
            'description' => $product['description'],
            'price' => (float)$product['price'],
            'stock' => (int)$product['stock'],
            'condition' => $product['condition'],
            'cover' => '', // Placeholder for image
            'category_name' => $product['category_name'],
            'seller_username' => $product['seller_username'],
            'created_at' => $product['created_at']
        ];
    }, $products);
    
    $response = [
        'success' => true,
        'data' => [
            'products' => $formattedProducts,
            'pagination' => [
                'total' => (int)$total,
                'page' => $params['page'],
                'limit' => $params['limit'],
                'total_pages' => ceil($total / $params['limit'])
            ]
        ]
    ];
    
} catch (Exception $e) {
    // En caso de error, devolver los datos de ejemplo
    $response = [
        'success' => true,
        'message' => 'Usando datos de ejemplo: ' . $e->getMessage(),
        'data' => $fallback_products,
        'meta' => [
            'current_page' => 1,
            'per_page' => 10,
            'total' => count($fallback_products),
            'total_pages' => 1
        ]
    ];
}

// Si no hay datos o hubo un error, usar datos de ejemplo
if (!$db_connected || empty($response['data'])) {
    $response = [
        'success' => true,
        'message' => 'Usando datos de ejemplo',
        'data' => $fallback_products,
        'meta' => [
            'current_page' => 1,
            'per_page' => 10,
            'total' => count($fallback_products),
            'total_pages' => 1
        ]
    ];
}

// Limpiar cualquier output previo y asegurar JSON válido
ob_clean();
http_response_code(isset($response['code']) ? $response['code'] : 200);
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
