<?php
// API de categorías simplificada para testing en Hostinger
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Respuesta de prueba
$categories = [
    ['id' => 1, 'name' => 'Electrónica', 'slug' => 'electronica'],
    ['id' => 2, 'name' => 'Ropa', 'slug' => 'ropa'],
    ['id' => 3, 'name' => 'Hogar', 'slug' => 'hogar'],
    ['id' => 4, 'name' => 'Deportes', 'slug' => 'deportes'],
    ['id' => 5, 'name' => 'Libros', 'slug' => 'libros']
];

echo json_encode([
    'success' => true,
    'message' => 'Categorías de prueba - API funcionando',
    'data' => $categories,
    'debug' => [
        'php_version' => phpversion(),
        'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'request_method' => $_SERVER['REQUEST_METHOD'],
        'script_name' => $_SERVER['SCRIPT_NAME']
    ]
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
