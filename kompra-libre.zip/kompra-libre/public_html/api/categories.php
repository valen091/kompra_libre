<?php
// Asegurar que siempre devolvamos JSON válido
ob_clean();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-cache, must-revalidate');

// Datos de ejemplo para cuando falle la conexión a la base de datos
$fallback_categories = [
    ['id' => 1, 'name' => 'Electrónica', 'slug' => 'electronica'],
    ['id' => 2, 'name' => 'Ropa', 'slug' => 'ropa'],
    ['id' => 3, 'name' => 'Hogar', 'slug' => 'hogar'],
    ['id' => 4, 'name' => 'Deportes', 'slug' => 'deportes'],
    ['id' => 5, 'name' => 'Juguetes', 'slug' => 'juguetes']
];

$response = ['success' => false, 'message' => '', 'data' => []];

// Intentar cargar categorías de la base de datos
$db_connected = false;
$categories = [];

try {
    // Verificar si el archivo de configuración existe
    $config_file = __DIR__ . '/../includes/config.php';
    $db_file = __DIR__ . '/../includes/db.php';
    
    if (file_exists($config_file) && file_exists($db_file)) {
        require_once $config_file;
        require_once $db_file;
        
        // Intentar conectar a la base de datos
        $db = getDB();
        
        // Verificar si la tabla de categorías existe
        $table_check = $db->query("SHOW TABLES LIKE 'categories'");
        
        if ($table_check->rowCount() > 0) {
            // Obtener categorías
            $stmt = $db->prepare("SELECT id, name, slug FROM categories ORDER BY name");
            $stmt->execute();
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $db_connected = true;
        }
    }
    
    // Si no hay categorías de la base de datos, usar las de ejemplo
    if (empty($categories)) {
        $categories = $fallback_categories;
    }
    
    // Respuesta exitosa
    $response = [
        'success' => true,
        'message' => $db_connected ? 'Categorías obtenidas exitosamente' : 'Usando datos de ejemplo',
        'data' => $categories
    ];

} catch (Exception $e) {
    // En caso de error, devolver los datos de ejemplo
    $response = [
        'success' => true,
        'message' => 'Usando datos de ejemplo: ' . $e->getMessage(),
        'data' => $fallback_categories
    ];
}

// Limpiar cualquier output previo y asegurar JSON válido
ob_clean();
http_response_code(isset($response['code']) ? $response['code'] : 200);
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
exit;
?>
