<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Solo permitir método DELETE para remover del carrito
    if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
        throw new Exception('Método no permitido. Use DELETE para remover productos del carrito.', 405);
    }

    // Obtener datos del request - puede ser desde URL (GET) o body (JSON)
    $itemId = null;

    // Intentar obtener desde parámetros GET (para URLs como /api/cart/remove?item_id=123)
    if (isset($_GET['item_id'])) {
        $itemId = (int)$_GET['item_id'];
    } else {
        // Intentar obtener desde JSON body
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['item_id'])) {
            $itemId = (int)$data['item_id'];
        }
    }

    // Validar que se proporcionó el item_id
    if (!$itemId || $itemId <= 0) {
        throw new Exception('ID de item inválido o no especificado.', 400);
    }

    // Obtener el ID del carrito de la sesión
    $cartId = getOrCreateCartId();

    // Verificar que el carrito existe
    if (!$cartId) {
        throw new Exception('Carrito no encontrado.', 404);
    }

    // Verificar que el item pertenece al carrito actual
    $stmt = $db->prepare("SELECT id, product_id, quantity, variant_id FROM cart_items WHERE id = ? AND cart_id = ? LIMIT 1");
    $stmt->execute([$itemId, $cartId]);
    $item = $stmt->fetch();

    if (!$item) {
        throw new Exception('Item no encontrado en el carrito.', 404);
    }

    // Obtener detalles del producto para la respuesta
    $product = getProductDetails($item['product_id'], $item['variant_id']);

    // Eliminar el item del carrito
    $stmt = $db->prepare("DELETE FROM cart_items WHERE id = ? AND cart_id = ?");
    $stmt->execute([$itemId, $cartId]);

    // Verificar que se eliminó correctamente
    if ($stmt->rowCount() === 0) {
        throw new Exception('No se pudo eliminar el item del carrito.', 500);
    }

    // Obtener información actualizada del carrito
    $cartItemCount = getCartItemCount($cartId);
    $cartTotal = getCartTotal($cartId);

    $response = [
        'success' => true,
        'message' => 'Producto eliminado del carrito exitosamente.',
        'data' => [
            'action' => 'removed',
            'item_id' => $itemId,
            'product_id' => $item['product_id'],
            'variant_id' => $item['variant_id'],
            'quantity_removed' => $item['quantity'],
            'cart_item_count' => $cartItemCount,
            'cart_total' => $cartTotal,
            'product_info' => $product ? [
                'title' => $product['title'],
                'price' => (float)$product['price'],
                'image' => getProductImage($item['product_id']),
                'url' => "/producto/{$product['slug']}"
            ] : null
        ]
    ];

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener o crear un ID de carrito
function getOrCreateCartId() {
    global $db;

    // Si ya hay un carrito en la sesión, devolverlo
    if (isset($_SESSION['cart_id'])) {
        // Verificar que el carrito aún existe en la base de datos
        $stmt = $db->prepare("SELECT id FROM carts WHERE id = ? LIMIT 1");
        $stmt->execute([$_SESSION['cart_id']]);

        if ($stmt->rowCount() > 0) {
            return $_SESSION['cart_id'];
        }
    }

    // Si no hay carrito en sesión o no existe en BD, buscar carrito por session_id
    $sessionId = session_id();
    $stmt = $db->prepare("SELECT id FROM carts WHERE session_id = ? AND (user_id IS NULL OR user_id = ?) ORDER BY created_at DESC LIMIT 1");

    $userId = isAuthenticated() ? getCurrentUserId() : null;
    $stmt->execute([$sessionId, $userId]);

    $cart = $stmt->fetch();

    if ($cart) {
        // Usar carrito existente
        $_SESSION['cart_id'] = $cart['id'];
        return $cart['id'];
    }

    // Crear un nuevo carrito si no existe
    $stmt = $db->prepare("INSERT INTO carts (user_id, session_id, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
    $stmt->execute([$userId, $sessionId]);
    $cartId = $db->lastInsertId();

    // Guardar en la sesión
    $_SESSION['cart_id'] = $cartId;

    return $cartId;
}

// Función auxiliar para obtener detalles de un producto
function getProductDetails($productId, $variantId = null) {
    global $db;

    if ($variantId) {
        // Obtener producto con variante específica
        $stmt = $db->prepare("SELECT p.*, v.price, v.quantity, v.sku, v.option1, v.option2, v.option3 FROM products p JOIN product_variants v ON p.id = v.product_id WHERE p.id = ? AND v.id = ? AND p.status = 'active' LIMIT 1");
        $stmt->execute([$productId, $variantId]);
    } else {
        // Obtener producto sin variante
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$productId]);
    }

    return $stmt->fetch();
}

// Función auxiliar para contar ítems en el carrito
function getCartItemCount($cartId) {
    global $db;

    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity), 0) as total FROM cart_items WHERE cart_id = ?");
    $stmt->execute([$cartId]);
    return (int)$stmt->fetch()['total'];
}

// Función auxiliar para obtener el total del carrito
function getCartTotal($cartId) {
    global $db;

    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity * price), 0) as total FROM cart_items ci JOIN products p ON ci.product_id = p.id WHERE ci.cart_id = ? AND p.status = 'active'");
    $stmt->execute([$cartId]);
    return (float)$stmt->fetch()['total'];
}

// Función auxiliar para obtener la imagen de un producto
function getProductImage($productId) {
    global $db;

    $stmt = $db->prepare("SELECT image_url FROM product_images WHERE product_id = ? AND is_primary = 1 LIMIT 1");
    $stmt->execute([$productId]);
    $result = $stmt->fetch();

    return $result ? $result['image_url'] : '/img/placeholder-product.jpg';
}
?>