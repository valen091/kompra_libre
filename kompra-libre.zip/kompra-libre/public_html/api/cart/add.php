<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

$response = ['success' => false, 'data' => [], 'message' => ''];
$db = getDB();

try {
    // Solo permitir método POST para agregar al carrito
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido. Use POST para agregar productos al carrito.', 405);
    }

    // Obtener datos del request
    $data = json_decode(file_get_contents('php://input'), true);

    // Validar datos requeridos
    if (empty($data['product_id']) || empty($data['quantity'])) {
        throw new Exception('Faltan datos requeridos: product_id y quantity son obligatorios.', 400);
    }

    // Validar y sanitizar datos
    $productId = (int)$data['product_id'];
    $variantId = isset($data['variant_id']) ? (int)$data['variant_id'] : null;
    $quantity = (int)$data['quantity'];

    // Validaciones básicas
    if ($productId <= 0) {
        throw new Exception('ID de producto inválido.', 400);
    }

    if ($quantity < 1 || $quantity > 999) {
        throw new Exception('Cantidad debe estar entre 1 y 999.', 400);
    }

    if ($variantId && $variantId <= 0) {
        throw new Exception('ID de variante inválido.', 400);
    }

    // Obtener el ID del carrito de la sesión o crear uno nuevo
    $cartId = getOrCreateCartId();
    $userId = isAuthenticated() ? getCurrentUserId() : null;

    // Si el usuario está autenticado, asociar el carrito a su cuenta
    if ($userId && !isset($_SESSION['cart_user_id'])) {
        $stmt = $db->prepare("UPDATE carts SET user_id = ? WHERE id = ?");
        $stmt->execute([$userId, $cartId]);
        $_SESSION['cart_user_id'] = $userId;
    }

    // Obtener detalles del producto y verificar disponibilidad
    $product = getProductDetails($productId, $variantId);

    if (!$product) {
        throw new Exception('Producto no encontrado o no disponible.', 404);
    }

    // Verificar stock disponible
    if ($product['quantity'] < $quantity) {
        throw new Exception("Solo hay {$product['quantity']} unidades disponibles de este producto.", 400);
    }

    // Verificar si el producto ya está en el carrito
    $stmt = $db->prepare("SELECT id, quantity FROM cart_items WHERE cart_id = ? AND product_id = ? AND (variant_id = ? OR (? IS NULL AND variant_id IS NULL)) LIMIT 1");

    $stmt->execute([$cartId, $productId, $variantId, $variantId]);
    $existingItem = $stmt->fetch();

    if ($existingItem) {
        // Calcular nueva cantidad total
        $newQuantity = $existingItem['quantity'] + $quantity;

        // Verificar que no exceda el stock disponible
        if ($product['quantity'] < $newQuantity) {
            throw new Exception("No se pueden agregar {$quantity} productos. Solo hay {$product['quantity']} disponibles y ya tienes {$existingItem['quantity']} en el carrito.", 400);
        }

        // Actualizar cantidad existente
        $stmt = $db->prepare("UPDATE cart_items SET quantity = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$newQuantity, $existingItem['id']]);

        $message = "Cantidad actualizada en el carrito. Total: {$newQuantity} productos.";
        $action = 'updated';
    } else {
        // Agregar nuevo producto al carrito
        $stmt = $db->prepare("INSERT INTO cart_items (cart_id, product_id, variant_id, quantity, price, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())");

        $stmt->execute([
            $cartId,
            $productId,
            $variantId,
            $quantity,
            $product['price']
        ]);

        $message = "Producto agregado al carrito exitosamente.";
        $action = 'added';
    }

    // Obtener información actualizada del carrito
    $cartItemCount = getCartItemCount($cartId);
    $cartTotal = getCartTotal($cartId);

    $response = [
        'success' => true,
        'message' => $message,
        'data' => [
            'action' => $action,
            'cart_id' => $cartId,
            'product_id' => $productId,
            'variant_id' => $variantId,
            'quantity_added' => $quantity,
            'cart_item_count' => $cartItemCount,
            'cart_total' => $cartTotal,
            'product_info' => [
                'title' => $product['title'],
                'price' => (float)$product['price'],
                'image' => getProductImage($productId),
                'url' => "/producto/{$product['slug']}"
            ]
        ]
    ];

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'debug' => DEBUG_MODE ? [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ] : null
    ];
}

echo json_encode($response);

// Función auxiliar para obtener o crear un ID de carrito
function getOrCreateCartId() {
    global $db;

    // Si ya hay un carrito en la sesión, devolverlo
    if (isset($_SESSION['cart_id'])) {
        // Verificar que el carrito aún existe en la base de datos
        $stmt = $db->prepare("SELECT id FROM carts WHERE id = ? LIMIT 1");
        $stmt->execute([$_SESSION['cart_id']]);

        if ($stmt->rowCount() > 0) {
            return $_SESSION['cart_id'];
        }
    }

    // Crear un nuevo carrito si no existe o el anterior ya no está en BD
    $stmt = $db->prepare("INSERT INTO carts (user_id, session_id, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");

    $userId = isAuthenticated() ? getCurrentUserId() : null;
    $sessionId = session_id();

    $stmt->execute([$userId, $sessionId]);
    $cartId = $db->lastInsertId();

    // Guardar en la sesión
    $_SESSION['cart_id'] = $cartId;

    return $cartId;
}

// Función auxiliar para obtener detalles de un producto
function getProductDetails($productId, $variantId = null) {
    global $db;

    if ($variantId) {
        // Obtener producto con variante específica
        $stmt = $db->prepare("SELECT p.*, v.price, v.quantity, v.sku, v.option1, v.option2, v.option3 FROM products p JOIN product_variants v ON p.id = v.product_id WHERE p.id = ? AND v.id = ? AND p.status = 'active' LIMIT 1");
        $stmt->execute([$productId, $variantId]);
    } else {
        // Obtener producto sin variante
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ? AND status = 'active' LIMIT 1");
        $stmt->execute([$productId]);
    }

    return $stmt->fetch();
}

// Función auxiliar para contar ítems en el carrito
function getCartItemCount($cartId) {
    global $db;

    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity), 0) as total FROM cart_items WHERE cart_id = ?");
    $stmt->execute([$cartId]);
    return (int)$stmt->fetch()['total'];
}

// Función auxiliar para obtener el total del carrito
function getCartTotal($cartId) {
    global $db;

    $stmt = $db->prepare("SELECT COALESCE(SUM(quantity * price), 0) as total FROM cart_items ci JOIN products p ON ci.product_id = p.id WHERE ci.cart_id = ? AND p.status = 'active'");
    $stmt->execute([$cartId]);
    return (float)$stmt->fetch()['total'];
}

// Función auxiliar para obtener la imagen de un producto
function getProductImage($productId) {
    global $db;

    $stmt = $db->prepare("SELECT image_url FROM product_images WHERE product_id = ? AND is_primary = 1 LIMIT 1");
    $stmt->execute([$productId]);
    $result = $stmt->fetch();

    return $result ? $result['image_url'] : '/img/placeholder-product.jpg';
}
?>