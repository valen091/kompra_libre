# 🛒 API del Carrito - Kompra Libre

Este directorio contiene los endpoints específicos de la API para la gestión del carrito de compras.

## 📋 Endpoints Disponibles

### 📥 **Agregar al Carrito** - `add.php`
**POST** `/api/cart/add.php`

Agrega productos al carrito de compras con validación completa de stock y manejo de variantes.

#### **Parámetros (JSON):**
```json
{
  "product_id": 123,
  "quantity": 2,
  "variant_id": 456  // opcional
}
```

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Producto agregado al carrito exitosamente.",
  "data": {
    "action": "added",
    "cart_id": 789,
    "product_id": 123,
    "variant_id": 456,
    "quantity_added": 2,
    "cart_item_count": 5,
    "cart_total": 2599.98,
    "product_info": {
      "title": "iPhone 15 Pro Max",
      "price": 1299.99,
      "image": "/img/products/iphone-15-pro-max.jpg",
      "url": "/producto/iphone-15-pro-max"
    }
  }
}
```

#### **Funcionalidades:**
- ✅ **Validación completa** de datos de entrada
- ✅ **Verificación de stock** disponible
- ✅ **Manejo de variantes** de productos
- ✅ **Actualización automática** si el producto ya existe
- ✅ **Respuestas detalladas** con información del carrito

### 📤 **Remover del Carrito** - `remove.php`
**DELETE** `/api/cart/remove.php`

Elimina productos específicos del carrito de compras.

#### **Parámetros (GET o JSON):**
```json
{
  "item_id": 123
}
```

**O desde URL:**
```
/api/cart/remove.php?item_id=123
```

#### **Respuesta Exitosa:**
```json
{
  "success": true,
  "message": "Producto eliminado del carrito exitosamente.",
  "data": {
    "action": "removed",
    "item_id": 123,
    "product_id": 456,
    "variant_id": null,
    "quantity_removed": 1,
    "cart_item_count": 3,
    "cart_total": 899.97,
    "product_info": {
      "title": "MacBook Air M3",
      "price": 1099.99,
      "image": "/img/products/macbook-air-m3.jpg",
      "url": "/producto/macbook-air-m3"
    }
  }
}
```

#### **Funcionalidades:**
- ✅ **Eliminación segura** con verificación de propiedad
- ✅ **Múltiples métodos** de envío de parámetros
- ✅ **Validación de permisos** del carrito
- ✅ **Información detallada** del producto removido

### 📋 **Carrito General** - `index.php`
**GET, POST, PUT, DELETE** `/api/cart/index.php`

Endpoint principal que maneja todas las operaciones del carrito.

#### **GET** - Obtener carrito completo
#### **POST** - Agregar productos (alternativo a add.php)
#### **PUT** - Actualizar cantidades
#### **DELETE** - Remover productos (alternativo a remove.php)

## 🔧 **Códigos de Respuesta HTTP**

| Código | Descripción |
|--------|-------------|
| `200` | Operación exitosa |
| `400` | Datos inválidos o stock insuficiente |
| `404` | Producto o item no encontrado |
| `405` | Método HTTP no permitido |
| `500` | Error interno del servidor |

## 📝 **Ejemplos de Uso (JavaScript)**

### **Agregar al Carrito:**
```javascript
// Agregar producto simple
fetch('/api/cart/add.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        product_id: 123,
        quantity: 2
    })
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        console.log('Agregado:', data.data.cart_item_count, 'items en carrito');
        updateCartUI(data.data);
    } else {
        console.error('Error:', data.message);
    }
});
```

### **Agregar con Variante:**
```javascript
// Agregar producto con variante (ej: talla, color)
fetch('/api/cart/add.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        product_id: 123,
        variant_id: 456,  // ID de la variante específica
        quantity: 1
    })
})
.then(response => response.json())
.then(data => console.log(data));
```

### **Remover del Carrito:**
```javascript
// Remover item específico
fetch('/api/cart/remove.php?item_id=123', {
    method: 'DELETE'
})
.then(response => response.json())
.then(data => {
    if (data.success) {
        console.log('Eliminado del carrito');
        updateCartUI(data.data);
    }
});
```

## ⚠️ **Consideraciones de Seguridad**

### **Validaciones Implementadas:**
- ✅ **Autenticación de sesión** - Carrito ligado a usuario
- ✅ **Validación de datos** - Sanitización completa
- ✅ **Verificación de stock** - Previene overbooking
- ✅ **Control de permisos** - Solo items del propio carrito
- ✅ **Límites de cantidad** - Entre 1 y 999 productos

### **Gestión de Sesiones:**
- ✅ **Carrito por sesión** - Persistente durante la navegación
- ✅ **Asociación a usuario** - Se transfiere al login
- ✅ **Verificación de BD** - Carrito existe y es válido

## 🔄 **Flujo de Trabajo Típico**

1. **Usuario navega** productos
2. **Selecciona producto** y cantidad
3. **JavaScript envía** POST a `/api/cart/add.php`
4. **API valida** producto, stock, y permisos
5. **Agrega/actualiza** item en base de datos
6. **Devuelve respuesta** con estado actual del carrito
7. **Frontend actualiza** UI con nueva información

## 🚀 **Mejores Prácticas**

### **Para Frontend:**
- **Usa JSON** para todos los requests
- **Maneja errores** apropiadamente
- **Actualiza UI** con la respuesta de la API
- **Cache** información del carrito si es necesario

### **Para Backend:**
- **Valida todo** - Nunca confíes en datos del frontend
- **Logs** - Registra operaciones importantes
- **Rate limiting** - Considera límites por usuario/IP
- **Monitoring** - Monitorea uso y performance

## 📞 **Solución de Problemas**

### **Errores Comunes:**
1. **"Producto no encontrado"** → Verifica que el product_id existe y está activo
2. **"Stock insuficiente"** → El producto no tiene suficiente inventario
3. **"Item no encontrado"** → El item_id no existe o no pertenece al carrito
4. **"Carrito no encontrado"** → Problema con la sesión, intenta refrescar

### **Debug:**
- Revisa logs del servidor
- Usa herramientas como Postman para testing
- Verifica la base de datos directamente
- Consulta `docs/README.md` para troubleshooting

## 📈 **Performance**

### **Optimizaciones Implementadas:**
- ✅ **Consultas eficientes** con JOINs apropiados
- ✅ **Índices de BD** en campos críticos
- ✅ **Validación temprana** para evitar consultas innecesarias
- ✅ **Respuestas JSON** optimizadas
- ✅ **Manejo de sesiones** eficiente

### **Recomendaciones:**
- Implementar **caching** para productos frecuentes
- Considerar **CDN** para imágenes
- **Optimizar consultas** de BD
- **Monitorear** tiempos de respuesta

## 🔗 **Integración con Otros Módulos**

- **Productos** → `api/products/` para obtener detalles
- **Usuarios** → `api/auth/` para autenticación
- **Frontend** → `pages/` para interfaces de usuario
- **Tests** → `tests/` para validación de funcionalidad

---
**¡La API del carrito está lista para usar!** 🛒✨
