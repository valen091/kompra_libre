// 🛒 Ejemplos de uso de la API del Carrito - Kompra Libre

// Ejemplo completo de integración con JavaScript

class CartAPI {
    constructor(baseUrl = '/api/cart') {
        this.baseUrl = baseUrl;
    }

    // Agregar producto al carrito
    async addToCart(productId, quantity = 1, variantId = null) {
        try {
            const response = await fetch(`${this.baseUrl}/add.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    product_id: productId,
                    quantity: quantity,
                    variant_id: variantId
                })
            });

            const data = await response.json();

            if (data.success) {
                this.updateCartUI(data.data);
                this.showNotification(data.message, 'success');
            } else {
                this.showNotification(data.message, 'error');
            }

            return data;
        } catch (error) {
            console.error('Error adding to cart:', error);
            this.showNotification('Error al agregar al carrito', 'error');
        }
    }

    // Remover producto del carrito
    async removeFromCart(itemId) {
        try {
            const response = await fetch(`${this.baseUrl}/remove.php?item_id=${itemId}`, {
                method: 'DELETE'
            });

            const data = await response.json();

            if (data.success) {
                this.updateCartUI(data.data);
                this.showNotification(data.message, 'success');
            } else {
                this.showNotification(data.message, 'error');
            }

            return data;
        } catch (error) {
            console.error('Error removing from cart:', error);
            this.showNotification('Error al remover del carrito', 'error');
        }
    }

    // Obtener carrito completo
    async getCart() {
        try {
            const response = await fetch(`${this.baseUrl}/index.php`);
            const data = await response.json();

            if (data.success) {
                this.updateCartUI(data.data);
            }

            return data;
        } catch (error) {
            console.error('Error getting cart:', error);
        }
    }

    // Actualizar cantidad de un item
    async updateQuantity(itemId, newQuantity) {
        try {
            const response = await fetch(`${this.baseUrl}/index.php`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    item_id: itemId,
                    quantity: newQuantity
                })
            });

            const data = await response.json();

            if (data.success) {
                this.updateCartUI(data.data);
                this.showNotification(data.message, 'success');
            } else {
                this.showNotification(data.message, 'error');
            }

            return data;
        } catch (error) {
            console.error('Error updating quantity:', error);
            this.showNotification('Error al actualizar cantidad', 'error');
        }
    }

    // Actualizar UI del carrito
    updateCartUI(cartData) {
        // Actualizar contador en header
        const cartCount = document.querySelector('.cart-count');
        if (cartCount) {
            cartCount.textContent = cartData.cart_item_count || 0;
        }

        // Actualizar dropdown del carrito
        const cartDropdown = document.querySelector('.cart-dropdown');
        if (cartDropdown && cartData.items) {
            this.renderCartItems(cartDropdown, cartData.items, cartData.summary);
        }

        // Actualizar página del carrito si está abierta
        if (window.location.pathname.includes('carrito')) {
            this.refreshCartPage();
        }
    }

    // Renderizar items del carrito
    renderCartItems(container, items, summary) {
        container.innerHTML = `
            <div class="cart-items">
                ${items.map(item => `
                    <div class="cart-item" data-item-id="${item.id}">
                        <img src="${item.image}" alt="${item.title}">
                        <div class="item-info">
                            <h4>${item.title}</h4>
                            <p>$${item.price.toFixed(2)}</p>
                            <div class="quantity-controls">
                                <button class="qty-btn" onclick="cartAPI.updateQuantity(${item.id}, ${item.quantity - 1})">-</button>
                                <span class="quantity">${item.quantity}</span>
                                <button class="qty-btn" onclick="cartAPI.updateQuantity(${item.id}, ${item.quantity + 1})">+</button>
                            </div>
                        </div>
                        <div class="item-total">
                            <p>$${item.total.toFixed(2)}</p>
                            <button class="remove-btn" onclick="cartAPI.removeFromCart(${item.id})">
                                🗑️
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
            <div class="cart-summary">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span>$${summary.subtotal.toFixed(2)}</span>
                </div>
                <div class="summary-row">
                    <span>Envío:</span>
                    <span>$${summary.shipping.toFixed(2)}</span>
                </div>
                <div class="summary-row">
                    <span>Impuestos:</span>
                    <span>$${summary.tax.toFixed(2)}</span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span>$${summary.total.toFixed(2)}</span>
                </div>
                <button class="checkout-btn" onclick="window.location.href='/pages/checkout.html'">
                    Proceder al pago
                </button>
            </div>
        `;
    }

    // Mostrar notificaciones
    showNotification(message, type = 'info') {
        // Crear o usar sistema de notificaciones existente
        console.log(`[${type.toUpperCase()}] ${message}`);

        // Ejemplo con toast notifications
        if (typeof showToast === 'function') {
            showToast(message, type);
        }
    }

    // Refrescar página del carrito
    refreshCartPage() {
        if (typeof refreshCartPage === 'function') {
            refreshCartPage();
        } else {
            window.location.reload();
        }
    }
}

// Inicializar API del carrito
const cartAPI = new CartAPI();

// Ejemplos de uso en botones de productos
document.addEventListener('DOMContentLoaded', function() {
    // Botones "Agregar al carrito" en páginas de productos
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const productId = this.dataset.productId;
            const quantity = parseInt(this.dataset.quantity) || 1;
            const variantId = this.dataset.variantId || null;

            cartAPI.addToCart(productId, quantity, variantId);
        });
    });

    // Botones de remover en el dropdown del carrito
    document.querySelectorAll('.remove-from-cart').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            const itemId = this.dataset.itemId;
            cartAPI.removeFromCart(itemId);
        });
    });
});
