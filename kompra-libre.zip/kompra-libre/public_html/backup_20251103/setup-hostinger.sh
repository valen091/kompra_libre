#!/bin/bash
# Script de instalación para Hostinger
# Ejecutar desde la raíz de public_html

echo "🔧 Configurando Kompra Libre para Hostinger..."

# 1. Verificar estructura de archivos
echo "📁 Verificando estructura de archivos..."
if [ ! -d "api" ]; then
    echo "❌ Carpeta 'api' no encontrada"
    exit 1
fi

if [ ! -f "api/categories.php" ]; then
    echo "❌ api/categories.php no encontrado"
    exit 1
fi

if [ ! -f "api/products.php" ]; then
    echo "❌ api/products.php no encontrado"
    exit 1
fi

# 2. Configurar permisos
echo "🔐 Configurando permisos..."
find . -type d -exec chmod 755 {} \;
find . -type f -exec chmod 644 {} \;
chmod 755 api/
chmod 644 api/*.php
chmod 644 includes/*.php

# 3. Verificar archivos críticos
echo "✅ Verificando archivos críticos..."
if [ ! -f "includes/config.php" ]; then
    echo "❌ includes/config.php no encontrado"
    exit 1
fi

if [ ! -f ".htaccess" ]; then
    echo "❌ .htaccess no encontrado"
    exit 1
fi

# 4. Probar APIs
echo "🧪 Probando APIs..."

# Probar API de test
if curl -s "https://tu-dominio.com/api/test" > /dev/null 2>&1; then
    echo "✅ API de test funcionando"
else
    echo "❌ API de test no responde"
fi

# Probar API simplificada de categorías
if curl -s "https://tu-dominio.com/api/categories-simple" | grep -q "success"; then
    echo "✅ API de categorías simplificada funcionando"
else
    echo "❌ API de categorías simplificada no funciona"
fi

# Probar API simplificada de productos
if curl -s "https://tu-dominio.com/api/products-simple" | grep -q "success"; then
    echo "✅ API de productos simplificada funcionando"
else
    echo "❌ API de productos simplificada no funciona"
fi

# 5. Verificar base de datos (si está configurada)
echo "💾 Verificando configuración de base de datos..."
if grep -q "u472738607_kompra_libre" includes/config.php; then
    echo "⚠️  Base de datos configurada para Hostinger"
    echo "   Asegúrate de que la base de datos existe y es accesible"
else
    echo "❌ Configuración de base de datos no encontrada"
fi

echo ""
echo "🎉 Instalación completada!"
echo ""
echo "📝 Pasos siguientes:"
echo "1. Verifica que la base de datos esté creada en Hostinger"
echo "2. Importa el esquema de la base de datos desde sql/kompra_libre.sql"
echo "3. Actualiza las credenciales en includes/config.php si es necesario"
echo "4. Prueba las APIs directamente: https://tu-dominio.com/api/test"
echo "5. Si las APIs reales no funcionan, usa las simplificadas para testing"
echo ""
echo "🔍 URLs de debugging:"
echo "- Test general: https://tu-dominio.com/api/test"
echo "- Categorías (simple): https://tu-dominio.com/api/categories-simple"
echo "- Productos (simple): https://tu-dominio.com/api/products-simple"
echo "- Categorías (real): https://tu-dominio.com/api/categories"
echo "- Productos (real): https://tu-dominio.com/api/products"
