# Kompra Libre - Documentación de la API

## URL Base
```
http://localhost:3307/api
```

## Autenticación
La mayoría de las rutas protegidas requieren un token JWT en el header de autorización:
```
Authorization: Bearer <token>
```

---

## Rutas de Autenticación (`/api/auth`)

### 1. Registrar Usuario
**POST** `/api/auth/register`

**Body:**
```json
{
  "name": "Juan Pérez",
  "email": "juan@example.com",
  "password": "password123"
}
```

**Respuesta Exitosa (201):**
```json
{
  "success": true,
  "message": "Usuario registrado exitosamente",
  "token": "eyJhbGciOiJIUzI1...",
  "user": {
    "id": 1,
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "user_role": "buyer"
  }
}
```

### 2. Iniciar Sesión
**POST** `/api/auth/login`

**Body:**
```json
{
  "email": "juan@example.com",
  "password": "password123"
}
```

**Respuesta Exitosa (200):**
```json
{
  "success": true,
  "message": "Inicio de sesión exitoso",
  "token": "eyJhbGciOiJIUzI1...",
  "user": {
    "id": 1,
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "user_role": "buyer"
  }
}
```

### 3. Obtener Perfil
**GET** `/api/auth/profile`

**Headers:**
```
Authorization: Bearer <token>
```

**Respuesta Exitosa (200):**
```json
{
  "success": true,
  "user": {
    "id": 1,
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "user_role": "buyer",
    "created_at": "2024-01-01T00:00:00.000Z"
  }
}
```

### 4. Actualizar Perfil
**PUT** `/api/auth/profile`

**Headers:**
```
Authorization: Bearer <token>
```

**Body:**
```json
{
  "name": "Juan Carlos Pérez",
  "email": "juancarlos@example.com",
  "phone": "+598 99 123 456",
  "password": "newpassword123"
}
```

**Respuesta Exitosa (200):**
```json
{
  "success": true,
  "message": "Perfil actualizado exitosamente",
  "user": {
    "id": 1,
    "name": "Juan Carlos Pérez",
    "email": "juancarlos@example.com",
    "user_role": "buyer"
  }
}
```

### 5. Cerrar Sesión
**POST** `/api/auth/logout`

**Headers:**
```
Authorization: Bearer <token>
```

**Respuesta Exitosa (200):**
```json
{
  "success": true,
  "message": "Sesión cerrada exitosamente"
}
```

---

## Rutas de Productos (`/api/products`)

### 1. Listar Todos los Productos
**GET** `/api/products`

**Respuesta Exitosa (200):**
```json
{
  "success": true,
  "products": [...]
}
```

### 2. Obtener un Producto por ID
**GET** `/api/products/:id`

**Respuesta Exitosa (200):**
```json
{
  "success": true,
  "product": {...}
}
```

### 3. Crear Producto (Vendedor/Admin)
**POST** `/api/products`

**Headers:**
```
Authorization: Bearer <token>
```

**Body (form-data):**
- `name`: string
- `description`: string
- `price`: number
- `stock`: number
- `category`: string
- `image`: file

### 4. Actualizar Producto (Vendedor/Admin)
**PUT** `/api/products/:id`

**Headers:**
```
Authorization: Bearer <token>
```

### 5. Eliminar Producto (Vendedor/Admin)
**DELETE** `/api/products/:id`

**Headers:**
```
Authorization: Bearer <token>
```

---

## Rutas de Pagos (`/api/payments`)

### 1. Crear Preferencia de Pago
**POST** `/api/payments/create-preference`

**Headers:**
```
Authorization: Bearer <token>
```

**Body:**
```json
{
  "items": [
    {
      "id": "1",
      "title": "Producto 1",
      "description": "Descripción del producto",
      "quantity": 1,
      "price": 1000,
      "picture_url": "https://..."
    }
  ],
  "payer": {
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "phone": "+598 99 123 456",
    "address": "Calle 123",
    "city": "Montevideo"
  }
}
```

**Respuesta Exitosa (200):**
```json
{
  "success": true,
  "id": "123456789",
  "init_point": "https://www.mercadopago.com.uy/checkout/v1/redirect?pref_id=...",
  "sandbox_init_point": "https://sandbox.mercadopago.com.uy/checkout/v1/redirect?pref_id=..."
}
```

### 2. Webhook (Mercado Pago)
**POST** `/api/payments/webhook`

Esta ruta es llamada automáticamente por Mercado Pago cuando cambia el estado de un pago.

### 3. Obtener Estado de Pago
**GET** `/api/payments/status/:payment_id`

**Headers:**
```
Authorization: Bearer <token>
```

---

## Rutas de Chatbot (`/api/chat`)

### 1. Enviar Mensaje al Chatbot
**POST** `/api/chat`

**Headers:**
```
Authorization: Bearer <token>
```

**Body:**
```json
{
  "message": "¿Cómo puedo rastrear mi pedido?"
}
```

**Respuesta Exitosa (200):**
```json
{
  "success": true,
  "reply": "Para rastrear tu pedido, necesito el número de pedido. ¿Lo tienes a mano?"
}
```

---

## Rutas de Subida de Archivos (`/api/upload`)

### 1. Subir una Imagen
**POST** `/api/upload/single`

**Headers:**
```
Authorization: Bearer <token>
Content-Type: multipart/form-data
```

**Body (form-data):**
- `image`: file

### 2. Subir Múltiples Imágenes
**POST** `/api/upload/multiple`

**Headers:**
```
Authorization: Bearer <token>
Content-Type: multipart/form-data
```

**Body (form-data):**
- `images`: file[] (máximo 5 archivos)

---

## Códigos de Estado HTTP

- `200 OK`: Solicitud exitosa
- `201 Created`: Recurso creado exitosamente
- `400 Bad Request`: Datos de entrada inválidos
- `401 Unauthorized`: No autenticado o token inválido
- `403 Forbidden`: No autorizado (sin permisos)
- `404 Not Found`: Recurso no encontrado
- `500 Internal Server Error`: Error del servidor

---

## Notas Importantes

1. **Tokens JWT**: Los tokens tienen una duración de 24 horas. Después de ese tiempo, deberás iniciar sesión nuevamente.

2. **Roles de Usuario**:
   - `buyer`: Usuario comprador (por defecto)
   - `seller`: Usuario vendedor
   - `admin`: Administrador del sistema

3. **Validaciones**:
   - Nombre: mínimo 3 caracteres
   - Email: formato válido de correo electrónico
   - Contraseña: mínimo 6 caracteres

4. **CORS**: El servidor está configurado para aceptar peticiones desde el frontend en `http://localhost:3000`.

5. **Subida de Archivos**:
   - Tamaño máximo: 5MB por archivo
   - Formatos aceptados: JPG, JPEG, PNG, GIF, WEBP

---

## Ejemplos de Uso con cURL

### Registrar un usuario:
```bash
curl -X POST http://localhost:3307/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "password": "password123"
  }'
```

### Iniciar sesión:
```bash
curl -X POST http://localhost:3307/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "juan@example.com",
    "password": "password123"
  }'
```

### Obtener perfil (con token):
```bash
curl -X GET http://localhost:3307/api/auth/profile \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

---

## Variables de Entorno Requeridas

```env
# Base de datos
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=u472738607_kompra_libre
DB_PORT=3307

# JWT
JWT_SECRET=Kompralibre1

# Frontend
FRONTEND_URL=http://localhost:3000

# OpenAI
OPENAI_API_KEY=sk-...

# Mercado Pago
MP_ACCESS_TOKEN=APP_USR-...
MP_PUBLIC_KEY=APP_USR-...
MP_WEBHOOK_URL=https://tu-dominio.com/api/payments/webhook

# Configuración de la tienda
STORE_COUNTRY=UY
STORE_CURRENCY=UYU
STORE_TAX_RATE=22
```

---

## Estado del Servidor

### Verificar que el servidor está funcionando:
**GET** `/api/health`

**Respuesta:**
```json
{
  "success": true,
  "message": "Servidor funcionando correctamente",
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```
