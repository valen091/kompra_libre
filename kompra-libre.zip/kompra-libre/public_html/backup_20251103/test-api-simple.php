<?php
// Script simple para probar la API
$_GET['endpoint'] = 'categories';
require 'api.php';
?>
