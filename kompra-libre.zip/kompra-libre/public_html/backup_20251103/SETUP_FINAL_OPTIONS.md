# ✅ **SETUP FINAL - OPCIONES DISPONIBLES**

## **🎯 SETUP AUTOMÁTICO (elige 1 opción):**

### **🌟 OPCIÓN 1 - HTML CON INTERFAZ**
```
https://kompralibre.shop/setup-directo.html
```
✅ **Interfaz visual** - **Más fácil**
✅ **Estado en tiempo real**
✅ **Sin problemas de .htaccess**

### **🔧 OPCIÓN 2 - PHP SIMPLE**
```
https://kompralibre.shop/setup-simple.php
```
✅ **Configuración directa**
✅ **Funciona en cualquier hosting**
✅ **Base de datos fija**

### **📄 OPCIÓN 3 - PHP ULTRA SIMPLE**
```
https://kompralibre.shop/install.php
```
✅ **Sin dependencias**
✅ **Todo en un archivo**
✅ **Máxima compatibilidad**

---

## **🗄️ PHPMYADMIN (si las automáticas fallan):**
```
https://panel.hostinger.com → PHPMyAdmin → u472738607_kompra_libre
```

**SQL Schema (Paso 1):**
```sql
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'buyer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_email (email)
);

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL,
  UNIQUE KEY unique_slug (slug)
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seller_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  product_condition VARCHAR(20) DEFAULT 'nuevo',
  category_id INT,
  visible INT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**SQL Datos (Paso 2):**
```sql
INSERT INTO users (name, email, password_hash, role) VALUES
('Demo Comprador', 'comprador@demo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer'),
('Demo Vendedor', 'vendedor@demo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller'),
('Demo Admin', 'admin@demo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

INSERT INTO categories (name, slug) VALUES
('Electrónica', 'electronica'), ('Ropa', 'ropa'), ('Hogar', 'hogar'),
('Deportes', 'deportes'), ('Libros', 'libros');

INSERT INTO products (seller_id, title, price, category_id, visible) VALUES
(2, 'iPhone 15 Pro', 1299.99, 1, 1), (2, 'MacBook Air M3', 1099.99, 1, 1),
(2, 'Camiseta Nike', 29.99, 2, 1), (2, 'Balón Adidas', 39.99, 4, 1),
(2, 'Clean Code Libro', 49.99, 5, 1);
```

---

## **🔐 CUENTAS DE PRUEBA:**

| Email | Contraseña | Panel |
|-------|------------|--------|
| `comprador@gmail.com` | `demo123` | Usuario |
| `vendedor@gmail.com` | `demo123` | Vendedor |
| `admin@gmail.com` | `demo123` | Admin |

---

## **🎉 DESPUÉS DEL SETUP:**

- ✅ **Registro funciona:** `POST /api/auth/register`
- ✅ **Login funciona:** `POST /api/auth/login`
- ✅ **Productos cargan:** `GET /api/products`
- ✅ **Categorías disponibles:** `GET /api/categories`
- ✅ **Paneles operativos:** Usuario/Vendedor/Admin

---

## **🚀 PRUEBA EL RESULTADO:**

1. **Sitio web:** `https://kompralibre.shop`
2. **Registro:** Crea cuenta nueva ✅
3. **Login:** Usa cuentas demo ✅
4. **Productos:** Deberían aparecer ✅
5. **Diagnóstico:** `https://kompralibre.shop/diagnostico.php`

**¿Todo funciona ahora?** 🎉
