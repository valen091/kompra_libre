import fetch from 'node-fetch';

const API_URL = 'http://localhost:3307/api';
let authToken = '';

console.log('🧪 Iniciando pruebas de la API...\n');

// Test 1: Health Check
async function testHealthCheck() {
    console.log('1️⃣  Verificando estado del servidor...');
    try {
        const response = await fetch(`${API_URL}/health`);
        const data = await response.json();
        console.log('✅ Servidor funcionando:', data.message);
        console.log('   Timestamp:', data.timestamp, '\n');
    } catch (error) {
        console.error('❌ Error:', error.message, '\n');
    }
}

// Test 2: Registro de usuario
async function testRegister() {
    console.log('2️⃣  Probando registro de usuario...');
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: 'Usuario Prueba',
                email: `test${Date.now()}@example.com`,
                password: 'password123'
            })
        });
        const data = await response.json();
        
        if (data.success) {
            authToken = data.token;
            console.log('✅ Usuario registrado exitosamente');
            console.log('   ID:', data.user.id);
            console.log('   Nombre:', data.user.name);
            console.log('   Email:', data.user.email);
            console.log('   Token guardado ✓\n');
        } else {
            console.log('⚠️  Respuesta:', data.message, '\n');
        }
    } catch (error) {
        console.error('❌ Error:', error.message, '\n');
    }
}

// Test 3: Obtener perfil (ruta protegida)
async function testGetProfile() {
    console.log('3️⃣  Probando obtención de perfil (ruta protegida)...');
    try {
        if (!authToken) {
            console.log('⚠️  No hay token disponible, saltando prueba\n');
            return;
        }

        const response = await fetch(`${API_URL}/auth/profile`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const data = await response.json();
        
        if (data.success) {
            console.log('✅ Perfil obtenido exitosamente');
            console.log('   Usuario:', data.user.name);
            console.log('   Email:', data.user.email);
            console.log('   Rol:', data.user.user_role, '\n');
        } else {
            console.log('⚠️  Respuesta:', data.message, '\n');
        }
    } catch (error) {
        console.error('❌ Error:', error.message, '\n');
    }
}

// Test 4: Login
async function testLogin() {
    console.log('4️⃣  Probando inicio de sesión...');
    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: 'test@example.com',
                password: 'password123'
            })
        });
        const data = await response.json();
        
        if (data.success) {
            console.log('✅ Login exitoso');
            console.log('   Usuario:', data.user.name, '\n');
        } else {
            console.log('⚠️  Credenciales no válidas (esperado si es la primera vez)\n');
        }
    } catch (error) {
        console.error('❌ Error:', error.message, '\n');
    }
}

// Test 5: Ruta sin autenticación
async function testUnauthorized() {
    console.log('5️⃣  Probando acceso sin token (debe fallar)...');
    try {
        const response = await fetch(`${API_URL}/auth/profile`);
        const data = await response.json();
        
        if (!data.success && response.status === 401) {
            console.log('✅ Protección funcionando correctamente');
            console.log('   Mensaje:', data.message, '\n');
        } else {
            console.log('⚠️  Respuesta inesperada:', data, '\n');
        }
    } catch (error) {
        console.error('❌ Error:', error.message, '\n');
    }
}

// Ejecutar todas las pruebas
async function runAllTests() {
    await testHealthCheck();
    await testRegister();
    await testGetProfile();
    await testLogin();
    await testUnauthorized();
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('✅ Pruebas completadas');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    if (authToken) {
        console.log('🔑 Token JWT generado:');
        console.log(authToken.substring(0, 50) + '...\n');
        console.log('💡 Puedes usar este token en Postman o cURL para probar las rutas protegidas\n');
    }
}

// Ejecutar
runAllTests().catch(console.error);
