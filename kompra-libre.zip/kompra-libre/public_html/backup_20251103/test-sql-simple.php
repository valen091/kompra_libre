<?php
// Script de prueba para verificar que el SQL simplificado funciona
header('Content-Type: text/plain');

echo "🧪 PRUEBA DEL SQL SIMPLIFICADO PARA PHPMYADMIN\n";
echo "===============================================\n\n";

try {
    // Incluir configuración
    require_once __DIR__ . '/includes/config.php';
    require_once __DIR__ . '/includes/db.php';

    echo "✅ Configuración cargada\n";
    echo "📊 Base de datos: " . DB_NAME . "\n\n";

    // Conectar
    $pdo = getDB();
    echo "✅ Conexión a BD exitosa\n\n";

    // Verificar que las tablas existen
    echo "🔍 Verificando tablas...\n";
    $tables = ['users', 'categories', 'sellers', 'products'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        $exists = $stmt->rowCount() > 0;
        echo ($exists ? "✅" : "❌") . " Tabla $table\n";
    }
    echo "\n";

    // Simular el proceso del SQL simplificado
    echo "📋 SIMULANDO SQL SIMPLIFICADO...\n\n";

    // 1. Insertar usuario
    echo "1️⃣ Insertando usuario...\n";
    $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller')");
    echo "   ✅ Usuario insertado (o ya existía)\n\n";

    // 2. Insertar categorías
    echo "2️⃣ Insertando categorías...\n";
    $categories = [
        ['Electrónica', 'electronica'],
        ['Ropa', 'ropa'],
        ['Hogar', 'hogar'],
        ['Deportes', 'deportes'],
        ['Libros', 'libros']
    ];

    foreach ($categories as $cat) {
        $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('{$cat[0]}', '{$cat[1]}')");
    }
    echo "   ✅ 5 categorías insertadas\n\n";

    // 3. Insertar vendedor
    echo "3️⃣ Insertando vendedor...\n";
    $pdo->exec("INSERT IGNORE INTO sellers (user_id, shop_alias) SELECT id, 'Tienda Demo' FROM users WHERE email = 'demo@kompralibre.shop'");
    echo "   ✅ Vendedor creado\n\n";

    // 4. Insertar productos
    echo "4️⃣ Insertando productos...\n";
    $productos = [
        ['iPhone 15 Pro Max', 1299.99, 1],
        ['MacBook Air M3', 1099.99, 1],
        ['Camiseta Deportiva Nike', 29.99, 2],
        ['Juego de Sartenes', 89.99, 3],
        ['Balón de Fútbol Adidas', 39.99, 4],
        ['Clean Code - Libro', 49.99, 5],
        ['Auriculares Bluetooth Sony', 199.99, 1],
        ['Zapatillas Running Adidas', 89.99, 4],
        ['Lámpara de Escritorio LED', 45.99, 3],
        ['Chaqueta Impermeable', 79.99, 2]
    ];

    foreach ($productos as $prod) {
        $sql = "INSERT INTO products (seller_id, title, description, price, stock, condition, category_id, visible) " .
               "SELECT s.id, '{$prod[0]}', 'Descripción de {$prod[0]}', {$prod[1]}, 10, 'nuevo', {$prod[2]}, 1 " .
               "FROM sellers s WHERE s.shop_alias = 'Tienda Demo'";
        $pdo->exec($sql);
        echo "   ✅ {$prod[0]} insertado (Categoría {$prod[2]})\n";
    }
    echo "\n";

    // 5. Verificación final
    echo "📊 RESULTADOS FINALES:\n";
    echo "👤 Usuarios: " . $pdo->query("SELECT COUNT(*) FROM users WHERE email = 'demo@kompralibre.shop'")->fetchColumn() . "\n";
    echo "🏷️ Categorías: " . $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn() . "\n";
    echo "📦 Productos visibles: " . $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn() . "\n";
    echo "🏪 Vendedores: " . $pdo->query("SELECT COUNT(*) FROM sellers WHERE shop_alias = 'Tienda Demo'")->fetchColumn() . "\n\n";

    echo "🎉 ¡SQL SIMPLIFICADO FUNCIONA PERFECTAMENTE!\n\n";
    echo "✅ Sin errores de tablas inexistentes\n";
    echo "✅ Sin problemas de foreign keys\n";
    echo "✅ Compatible con PHPMyAdmin\n\n";

    echo "📋 PARA USAR EN PHPMYADMIN:\n\n";

    echo "1️⃣ PRIMERO - SCHEMA:\n";
    echo "   📁 sql/schema-simple-phpmyadmin.sql\n";
    echo "   (Crea las tablas básicas)\n\n";

    echo "2️⃣ SEGUNDO - DATOS:\n";
    echo "   📁 sql/datos-phpmyadmin-simple.sql\n";
    echo "   (Inserta usuario, categorías, vendedor, productos)\n\n";

    echo "📧 Usuario demo: demo@kompralibre.shop\n";
    echo "🔑 Contraseña: demo123\n";
    echo "🌐 URL: https://kompralibre.shop\n\n";

    echo "🚀 ¡Listo para usar en PHPMyAdmin!\n";

} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n\n";
    echo "🔧 Posibles soluciones:\n";
    echo "• Ejecuta primero el schema (sql/schema-simple-phpmyadmin.sql)\n";
    echo "• Verifica que la base de datos u472738607_kompra_libre existe\n";
    echo "• Asegúrate de que las tablas se crearon correctamente\n";
}
?>
