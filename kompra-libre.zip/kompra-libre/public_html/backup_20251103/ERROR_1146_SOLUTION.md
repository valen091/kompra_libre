# ✅ **SOLUCIÓN AL ERROR 1146 - TABLAS NO EXISTEN**

## **🔍 EL PROBLEMA:**
```
MySQL ha dicho: #1146 - La tabla 'u472738607_kompra_libre.users' no existe
```

## **✅ LA SOLUCIÓN: EJECUTAR EL SCHEMA PRIMERO**

### **🚨 PASOS EN PHPMYADMIN:**

## **📋 PASO 1: CREAR LAS TABLAS (SCHEMA)**

**Copia y pega esto en PHPMyAdmin:**

```sql
-- ✅ SCHEMA SIMPLIFICADO PARA PHPMYADMIN
-- Solo las tablas esenciales para los datos de ejemplo
-- Sin triggers complejos que podrían fallar

USE u472738607_kompra_libre;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('buyer','seller','admin') NOT NULL DEFAULT 'buyer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  parent_id INT NULL
);

CREATE TABLE sellers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  shop_alias VARCHAR(120),
  reputation INT DEFAULT 0
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seller_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  `condition` ENUM('nuevo','usado') DEFAULT 'nuevo',
  category_id INT,
  visible TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_products_title (title),
  INDEX idx_products_category (category_id)
);
```

## **📋 PASO 2: INSERTAR DATOS**

**Copia y pega esto en PHPMyAdmin:**

```sql
-- ✅ SQL CORREGIDO Y SIMPLIFICADO PARA PHPMYADMIN
-- Compatible con MySQL/MariaDB en Hostinger
-- Sin características avanzadas que podrían fallar

-- Usuario demo
INSERT IGNORE INTO users (name, email, password_hash, role) VALUES
('Demo User', 'demo@kompralibre.shop', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller');

-- Categorías
INSERT IGNORE INTO categories (name, slug) VALUES ('Electrónica', 'electronica');
INSERT IGNORE INTO categories (name, slug) VALUES ('Ropa', 'ropa');
INSERT IGNORE INTO categories (name, slug) VALUES ('Hogar', 'hogar');
INSERT IGNORE INTO categories (name, slug) VALUES ('Deportes', 'deportes');
INSERT IGNORE INTO categories (name, slug) VALUES ('Libros', 'libros');

-- Vendedor (usa el ID del usuario que acabamos de insertar)
INSERT IGNORE INTO sellers (user_id, shop_alias)
SELECT id, 'Tienda Demo' FROM users WHERE email = 'demo@kompralibre.shop';

-- Productos (usa IDs fijos para categorías, IDs dinámicos para vendedor)
INSERT IGNORE INTO products (seller_id, title, description, price, stock, condition, category_id, visible)
SELECT s.id, 'iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 10, 'nuevo', 1, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 5, 'nuevo', 1, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 20, 'nuevo', 2, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 15, 'nuevo', 3, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 8, 'nuevo', 4, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 12, 'usado', 5, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 7, 'nuevo', 1, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, 15, 'nuevo', 4, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 10, 'nuevo', 3, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo'
UNION ALL
SELECT s.id, 'Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, 8, 'nuevo', 2, 1
FROM sellers s WHERE s.shop_alias = 'Tienda Demo';

-- Verificación final
SELECT '✅ Usuarios:' as resultado, COUNT(*) as cantidad FROM users
UNION ALL
SELECT '✅ Categorías:', COUNT(*) FROM categories
UNION ALL
SELECT '✅ Productos visibles:', COUNT(*) FROM products WHERE visible = 1
UNION ALL
SELECT '✅ Vendedores:', COUNT(*) FROM sellers;
```

---

## **🎯 PASOS EXACTOS EN PHPMYADMIN:**

### **1️⃣ Acceder:**
- **URL:** `https://panel.hostinger.com` → PHPMyAdmin
- **Base de datos:** `u472738607_kompra_libre`
- **Pestaña:** `SQL`

### **2️⃣ Ejecutar Schema:**
```
📋 Copia el PRIMER bloque de SQL (CREATE TABLE...)
📋 Pégalo en PHPMyAdmin
📋 Haz clic en "Continuar" ✅
```

### **3️⃣ Ejecutar Datos:**
```
📋 Copia el SEGUNDO bloque de SQL (INSERT IGNORE...)
📋 Pégalo en PHPMyAdmin
📋 Haz clic en "Continuar" ✅
```

---

## **📊 RESULTADO ESPERADO:**

### **✅ Al final verás:**
```
✅ Usuarios: 1
✅ Categorías: 5
✅ Productos visibles: 10
✅ Vendedores: 1
```

### **✅ Usuario de prueba:**
- **Email:** `demo@kompralibre.shop`
- **Contraseña:** `demo123`
- **URL:** `https://kompralibre.shop`

---

## **🔧 OPCIONES ALTERNATIVAS:**

### **🎯 Script automático (más fácil):**
```
🌐 https://kompralibre.shop/setup-sencillo.html
```

### **🎯 Verificar que funciona:**
```
🌐 https://kompralibre.shop/test-sql-simple.php
```

---

## **❓ ¿AÚN TIENES ERRORES?**

### **Si dice "Base de datos no existe":**
- ✅ Verifica que estés en `u472738607_kompra_libre`
- ✅ Si no existe, créala en el panel de Hostinger

### **Si dice "Permisos denegados":**
- ✅ Usa el setup automático en su lugar
- ✅ `https://kompralibre.shop/setup-sencillo.html`

---

## **🎉 ¡PROBLEMA RESUELTO!**

**El error 1146 se soluciona ejecutando el schema primero.** Los archivos están listos para copiar y pegar en PHPMyAdmin.

**¿Ya ejecutaste los SQL?** ¿Los productos aparecen en la web? 🎉
