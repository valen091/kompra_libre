# 🚀 Guía de Inicio Rápido - Kompra Libre

## ✅ Estado Actual del Proyecto

### Sistema Completamente Funcional:

1. **✅ Base de Datos**: Conectada y funcionando
   - Host: localhost:3307
   - Base de datos: u472738607_kompra_libre
   - Tablas: users, products, orders, categories, etc.

2. **✅ Servidor Backend**: Operativo
   - Puerto: 3307
   - URL: http://localhost:3307
   - Framework: Express.js
   - Tipo: ES Modules

3. **✅ Sistema de Autenticación**: Implementado
   - Registro de usuarios
   - Login con JWT
   - Protección de rutas
   - Control de roles (buyer, seller, admin)

4. **✅ Integraciones**:
   - Mercado Pago (SDK v2)
   - OpenAI Chatbot
   - Sistema de subida de imágenes

---

## 🎯 Cómo Usar la Aplicación

### 1. Iniciar el Servidor

#### Modo Desarrollo (con auto-reload):
```bash
cd c:\xampp\htdocs\kompra-libre\public_html
npm run dev
```

#### Modo Producción:
```bash
cd c:\xampp\htdocs\kompra-libre\public_html
npm start
```

### 2. Verificar que el Servidor Está Funcionando

Abre tu navegador y ve a:
- **Health Check**: http://localhost:3307/api/health
- **Frontend**: http://localhost:3307

Deberías ver un mensaje indicando que el servidor está funcionando.

---

## 🧪 Probar la API

### Opción 1: Script de Prueba Automatizado

```bash
node test-api.js
```

Este script probará automáticamente:
- Estado del servidor
- Registro de usuario
- Login
- Obtención de perfil
- Protección de rutas

### Opción 2: Usando cURL

#### Registrar un usuario:
```bash
curl -X POST http://localhost:3307/api/auth/register ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Juan Perez\",\"email\":\"juan@example.com\",\"password\":\"password123\"}"
```

#### Iniciar sesión:
```bash
curl -X POST http://localhost:3307/api/auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"email\":\"juan@example.com\",\"password\":\"password123\"}"
```

#### Obtener perfil (con token):
```bash
curl -X GET http://localhost:3307/api/auth/profile ^
  -H "Authorization: Bearer TU_TOKEN_AQUI"
```

### Opción 3: Usando Postman

1. Descarga e instala [Postman](https://www.postman.com/downloads/)
2. Importa la colección de rutas (ver API_DOCS.md)
3. Comienza a probar las rutas

---

## 📁 Estructura del Proyecto

```
public_html/
├── src/
│   ├── config/
│   │   └── db.js                    # Configuración de base de datos
│   ├── controllers/
│   │   ├── auth.controller.js       # Lógica de autenticación
│   │   ├── chatbot.controller.js    # Lógica del chatbot
│   │   ├── payment.controller.js    # Lógica de pagos
│   │   ├── product.controller.js    # Lógica de productos
│   │   └── upload.controller.js     # Lógica de subida de archivos
│   ├── middlewares/
│   │   ├── auth.middleware.js       # Middleware de autenticación
│   │   └── validation.middleware.js # Middleware de validación
│   ├── models/
│   │   └── user.model.js            # Modelo de usuario
│   ├── routes/
│   │   ├── auth.routes.js           # Rutas de autenticación
│   │   ├── chatbot.routes.js        # Rutas del chatbot
│   │   ├── payment.routes.js        # Rutas de pagos
│   │   ├── product.routes.js        # Rutas de productos
│   │   └── upload.routes.js         # Rutas de subida
│   ├── validators/
│   │   └── auth.validator.js        # Validadores de autenticación
│   └── server.js                    # Archivo principal del servidor
├── public/                          # Archivos estáticos del frontend
├── uploads/                         # Carpeta de archivos subidos
├── .env                             # Variables de entorno
├── package.json                     # Dependencias del proyecto
├── API_DOCS.md                      # Documentación de la API
└── GUIA_INICIO.md                   # Esta guía
```

---

## 🔑 Variables de Entorno (.env)

Tu archivo `.env` actual contiene:

```env
# Base de datos
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=u472738607_kompra_libre
DB_PORT=3307

# Aplicación
NODE_ENV=development
PORT=3307
JWT_SECRET=Kompralibre1
FRONTEND_URL=http://localhost:3000

# OpenAI
OPENAI_API_KEY=sk-svcacct-Mb9n7...

# Mercado Pago
MP_ACCESS_TOKEN=APP_USR-6079658449065171...
MP_PUBLIC_KEY=APP_USR-1f0c8bd4...
MP_WEBHOOK_URL=http://localhost:3307/api/payments/webhook

# Configuración de la tienda
STORE_COUNTRY=UY
STORE_CURRENCY=UYU
STORE_TAX_RATE=22
```

---

## 📚 Documentación Adicional

### Rutas de la API
Ver `API_DOCS.md` para una lista completa de todas las rutas disponibles.

### Rutas Principales:

#### Autenticación
- `POST /api/auth/register` - Registrar usuario
- `POST /api/auth/login` - Iniciar sesión
- `GET /api/auth/profile` - Obtener perfil (protegida)
- `PUT /api/auth/profile` - Actualizar perfil (protegida)
- `POST /api/auth/logout` - Cerrar sesión (protegida)

#### Productos
- `GET /api/products` - Listar productos
- `GET /api/products/:id` - Obtener producto por ID
- `POST /api/products` - Crear producto (vendedor/admin)
- `PUT /api/products/:id` - Actualizar producto (vendedor/admin)
- `DELETE /api/products/:id` - Eliminar producto (vendedor/admin)

#### Pagos
- `POST /api/payments/create-preference` - Crear preferencia de pago (protegida)
- `POST /api/payments/webhook` - Webhook de Mercado Pago
- `GET /api/payments/status/:id` - Obtener estado de pago (protegida)

#### Chatbot
- `POST /api/chat` - Enviar mensaje al chatbot (protegida)

#### Subida de Archivos
- `POST /api/upload/single` - Subir una imagen (protegida)
- `POST /api/upload/multiple` - Subir múltiples imágenes (protegida)

---

## 🛠️ Comandos Útiles

### Desarrollo
```bash
# Iniciar servidor en modo desarrollo
npm run dev

# Probar la API
node test-api.js

# Probar la conexión a la base de datos
node test-db.js

# Instalar todas las dependencias
npm install
```

### Base de Datos
```bash
# Conectarse a MySQL (desde XAMPP)
C:\xampp\mysql\bin\mysql.exe -u root

# Ver bases de datos
SHOW DATABASES;

# Usar la base de datos de Kompra Libre
USE u472738607_kompra_libre;

# Ver tablas
SHOW TABLES;

# Ver usuarios registrados
SELECT id, name, email, user_role, created_at FROM users;
```

---

## 🐛 Solución de Problemas

### Error: "Access denied for user"
```bash
# Verifica que MySQL esté ejecutándose en XAMPP
# Verifica las credenciales en el archivo .env
# Prueba la conexión con:
node test-db.js
```

### Error: "Port already in use"
```bash
# Verifica si hay otro proceso usando el puerto 3307
# En Windows PowerShell:
netstat -ano | findstr :3307

# Mata el proceso si es necesario:
taskkill /PID <PID> /F
```

### Error: "Module not found"
```bash
# Reinstala las dependencias
npm install

# Verifica que package.json tenga "type": "module"
```

### El servidor no responde
```bash
# Verifica que el servidor esté ejecutándose
# Revisa la consola en busca de errores
# Verifica que XAMPP MySQL esté activo
```

---

## 🎨 Próximos Pasos

### Frontend
1. Crear páginas HTML para:
   - Registro/Login
   - Página de inicio
   - Catálogo de productos
   - Carrito de compras
   - Checkout

2. Conectar el frontend con la API usando fetch o axios

3. Implementar el flujo de pago con Mercado Pago

### Backend
1. Implementar más modelos (productos, pedidos, etc.)
2. Agregar más validaciones
3. Implementar sistema de búsqueda
4. Agregar paginación
5. Implementar sistema de favoritos

### Seguridad
1. Implementar rate limiting
2. Agregar HTTPS en producción
3. Configurar CORS apropiadamente
4. Agregar validación de emails
5. Implementar recuperación de contraseña

---

## 📞 Recursos Adicionales

- **Documentación de Express**: https://expressjs.com/
- **Documentación de JWT**: https://jwt.io/
- **Documentación de Mercado Pago**: https://www.mercadopago.com.uy/developers
- **Documentación de OpenAI**: https://platform.openai.com/docs

---

## ✅ Lista de Verificación

- [x] Servidor configurado y funcionando
- [x] Base de datos conectada
- [x] Sistema de autenticación implementado
- [x] Rutas protegidas configuradas
- [x] Integración con Mercado Pago
- [x] Integración con OpenAI
- [x] Sistema de subida de archivos
- [x] Documentación completa
- [ ] Frontend conectado
- [ ] Pruebas exhaustivas
- [ ] Despliegue en producción

---

**¡Tu aplicación está lista para desarrollar! 🎉**

Si necesitas ayuda con algún paso específico, consulta la documentación o ejecuta los scripts de prueba.
