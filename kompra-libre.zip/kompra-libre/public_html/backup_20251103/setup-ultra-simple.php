<?php
// Setup ultra simple - solo lo esencial
header('Content-Type: text/html; charset=utf-8');

echo "<h1>🛠️ SETUP ULTRA SIMPLE - KOMPRA LIBRE</h1>";
echo "<p>Configuración básica para PHPMyAdmin</p>";
echo "<hr>";

// Incluir configuración
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

try {
    $pdo = getDB();
    echo "<h2>✅ Conexión exitosa</h2>";

    // Verificar tablas existentes
    echo "<h3>📋 Verificando tablas...</h3>";
    $tables = ['users', 'categories', 'sellers', 'products'];
    $missing_tables = [];

    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() == 0) {
            $missing_tables[] = $table;
        }
    }

    if (!empty($missing_tables)) {
        echo "<div style='color: orange;'>⚠️ Faltan tablas: " . implode(', ', $missing_tables) . "</div>";
        echo "<h3>🔧 Creando tablas faltantes...</h3>";

        // Crear tablas básicas
        $sql = "
        CREATE TABLE IF NOT EXISTS users (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(100) NOT NULL,
          email VARCHAR(120) NOT NULL UNIQUE,
          password_hash VARCHAR(255) NOT NULL,
          role ENUM('buyer','seller','admin') NOT NULL DEFAULT 'buyer',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS categories (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(120) NOT NULL,
          slug VARCHAR(120) NOT NULL UNIQUE
        );

        CREATE TABLE IF NOT EXISTS sellers (
          id INT AUTO_INCREMENT PRIMARY KEY,
          user_id INT NOT NULL,
          shop_alias VARCHAR(120)
        );

        CREATE TABLE IF NOT EXISTS products (
          id INT AUTO_INCREMENT PRIMARY KEY,
          seller_id INT NOT NULL,
          title VARCHAR(200) NOT NULL,
          description TEXT,
          price DECIMAL(10,2) NOT NULL,
          stock INT NOT NULL DEFAULT 0,
          `condition` ENUM('nuevo','usado') DEFAULT 'nuevo',
          category_id INT,
          visible TINYINT(1) DEFAULT 1,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );";

        $pdo->exec($sql);
        echo "<div style='color: green;'>✅ Tablas creadas correctamente</div>";
    } else {
        echo "<div style='color: green;'>✅ Todas las tablas existen</div>";
    }

    // Insertar datos básicos
    echo "<h3>📦 Insertando datos...</h3>";

    // Usuario
    $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller')");
    echo "<div style='color: green;'>✅ Usuario demo creado</div>";

    // Categorías
    $categories = [
        ['Electrónica', 'electronica'],
        ['Ropa', 'ropa'],
        ['Hogar', 'hogar'],
        ['Deportes', 'deportes'],
        ['Libros', 'libros']
    ];

    foreach ($categories as $cat) {
        $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('{$cat[0]}', '{$cat[1]}')");
    }
    echo "<div style='color: green;'>✅ Categorías creadas</div>";

    // Vendedor
    $pdo->exec("INSERT IGNORE INTO sellers (user_id, shop_alias) SELECT id, 'Tienda Demo' FROM users WHERE email = 'demo@kompralibre.shop'");
    echo "<div style='color: green;'>✅ Vendedor creado</div>";

    // Productos
    $productos = [
        ['iPhone 15 Pro Max', 1299.99, 1],
        ['MacBook Air M3', 1099.99, 1],
        ['Camiseta Deportiva Nike', 29.99, 2],
        ['Juego de Sartenes', 89.99, 3],
        ['Balón de Fútbol Adidas', 39.99, 4],
        ['Clean Code - Libro', 49.99, 5],
        ['Auriculares Bluetooth Sony', 199.99, 1],
        ['Zapatillas Running Adidas', 89.99, 4],
        ['Lámpara de Escritorio LED', 45.99, 3],
        ['Chaqueta Impermeable', 79.99, 2]
    ];

    $stmt = $pdo->query("SELECT id FROM sellers WHERE shop_alias = 'Tienda Demo'");
    $seller_id = $stmt->fetch()['id'];

    foreach ($productos as $prod) {
        $pdo->exec("INSERT IGNORE INTO products (seller_id, title, description, price, stock, condition, category_id, visible) VALUES ($seller_id, '{$prod[0]}', 'Descripción de {$prod[0]}', {$prod[1]}, 10, 'nuevo', {$prod[2]}, 1)");
    }
    echo "<div style='color: green;'>✅ Productos creados</div>";

    // Resultados finales
    echo "<h3>📊 RESULTADOS FINALES:</h3>";
    echo "<div style='background: #f0f0f0; padding: 15px; border-radius: 5px;'>";
    echo "<strong>👤 Usuarios:</strong> " . $pdo->query("SELECT COUNT(*) FROM users WHERE email = 'demo@kompralibre.shop'")->fetchColumn() . "<br>";
    echo "<strong>🏷️ Categorías:</strong> " . $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn() . "<br>";
    echo "<strong>📦 Productos visibles:</strong> " . $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn() . "<br>";
    echo "<strong>🏪 Vendedores:</strong> " . $pdo->query("SELECT COUNT(*) FROM sellers WHERE shop_alias = 'Tienda Demo'")->fetchColumn() . "<br>";
    echo "</div>";

    echo "<h3>🎉 ¡SETUP COMPLETADO!</h3>";
    echo "<div style='color: green; font-size: 18px;'>✅ Todo configurado correctamente</div>";
    echo "<p><strong>Usuario demo:</strong> demo@kompralibre.shop<br>";
    echo "<strong>Contraseña:</strong> demo123<br>";
    echo "<strong>URL:</strong> <a href='https://kompralibre.shop'>https://kompralibre.shop</a></p>";

} catch (Exception $e) {
    echo "<h3>❌ ERROR:</h3>";
    echo "<div style='color: red; background: #ffe6e6; padding: 15px; border-radius: 5px;'>";
    echo $e->getMessage();
    echo "</div>";

    echo "<h3>🔧 SOLUCIÓN ALTERNATIVA:</h3>";
    echo "<p>Si este script no funciona, usa PHPMyAdmin directamente:</p>";
    echo "<p><a href='sql/schema-simple-phpmyadmin.sql' target='_blank'>📁 Schema (Crear tablas)</a><br>";
    echo "<a href='sql/datos-phpmyadmin-simple.sql' target='_blank'>📁 Datos (Insertar productos)</a></p>";
}
?>
