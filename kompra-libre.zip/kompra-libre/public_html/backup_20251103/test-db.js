import { testConnection } from './src/config/db.js';

async function runTest() {
    console.log('🔍 Probando conexión a la base de datos...');
    const isConnected = await testConnection();
    
    if (isConnected) {
        console.log('✅ ¡Conexión exitosa! La configuración es correcta.');
    } else {
        console.error('❌ No se pudo conectar a la base de datos. Verifica los siguientes puntos:');
        console.log('1. Que el servidor MySQL esté en ejecución');
        console.log('2. Que las credenciales en el archivo .env sean correctas');
        console.log('3. Que el usuario tenga los permisos necesarios');
        console.log('4. Que la base de datos exista');
        console.log('5. Que el firewall permita la conexión al puerto 3306');
    }
    
    process.exit(isConnected ? 0 : 1);
}

runTest().catch(console.error);
