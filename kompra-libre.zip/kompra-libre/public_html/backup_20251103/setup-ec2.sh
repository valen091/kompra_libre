#!/bin/bash

# Script de configuración para EC2 AWS - Kompra Libre
# Este script debe ejecutarse como superusuario (sudo)

# Actualizar el sistema
echo "Actualizando el sistema..."
apt-get update
apt-get upgrade -y

# Instalar dependencias
echo "Instalando dependencias..."
apt-get install -y apache2 mysql-server php php-mysql php-curl php-gd php-mbstring php-xml php-zip unzip certbot python3-certbot-apache

# Instalar Composer
echo "Instalando Composer..."
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer
chmod +x /usr/local/bin/composer

# Configurar MySQL
echo "Configurando MySQL..."
mysql_secure_installation

# Crear base de datos y usuario
echo "Creando base de datos..."
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS kompra_libre CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p -e "CREATE USER IF NOT EXISTS 'kompra_user'@'localhost' IDENTIFIED BY 'una_contraseña_segura';"
mysql -u root -p -e "GRANT ALL PRIVILEGES ON kompra_libre.* TO 'kompra_user'@'localhost';"
mysql -u root -p -e "FLUSH PRIVILEGES;"

# Configurar Apache
echo "Configurando Apache..."
cat > /etc/apache2/sites-available/kompra-libre.conf <<EOL
<VirtualHost *:80>
    ServerName tu-dominio.com
    ServerAdmin webmaster@tu-dominio.com
    DocumentRoot /var/www/kompra-libre/public_html
    
    <Directory /var/www/kompra-libre/public_html>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/kompra-libre-error.log
    CustomLog ${APACHE_LOG_DIR}/kompra-libre-access.log combined
</VirtualHost>
EOL

# Habilitar módulos de Apache
echo "Habilitando módulos de Apache..."
a2enmod rewrite headers expires

# Deshabilitar sitio por defecto
a2dissite 000-default.conf

# Habilitar sitio de Kompra Libre
a2ensite kompra-libre.conf

# Reiniciar Apache
systemctl restart apache2

# Configurar tarea programada para renovación de certificados
echo "Configurando renovación automática de certificados..."
echo "0 3 * * * root certbot renew --quiet --deploy-hook 'systemctl reload apache2'" | sudo tee -a /etc/cron.d/certbot

# Configurar permisos
echo "Configurando permisos..."
chown -R www-data:www-data /var/www/kompra-libre
find /var/www/kompra-libre -type d -exec chmod 755 {} \;
find /var/www/kompra-libre -type f -exec chmod 644 {} \;

# Instalar certificado SSL
echo "Instalando certificado SSL..."
certbot --apache -d tu-dominio.com --non-interactive --agree-tos -m admin@tu-dominio.com --redirect

# Configurar PHP
echo "Configurando PHP..."
sed -i 's/^upload_max_filesize = .*/upload_max_filesize = 20M/' /etc/php/*/apache2/php.ini
sed -i 's/^post_max_size = .*/post_max_size = 20M/' /etc/php/*/apache2/php.ini
sed -i 's/^memory_limit = .*/memory_limit = 256M/' /etc/php/*/apache2/php.ini

# Reiniciar Apache para aplicar cambios
systemctl restart apache2

echo "\n¡Configuración completada! Por favor, realiza los siguientes pasos manuales:"
echo "1. Configura tu dominio para que apunte a la IP de tu instancia EC2"
echo "2. Revisa el archivo de configuración en /etc/apache2/sites-available/kompra-libre.conf"
echo "3. Importa la base de datos: mysql -u root -p kompra_libre < ruta/a/tu/backup.sql"
echo "4. Asegúrate de que el archivo /var/www/kompra-libre/public_html/includes/config.php tenga las credenciales correctas"
echo "\n¡Listo! Tu tienda Kompra Libre debería estar funcionando en https://tu-dominio.com"
