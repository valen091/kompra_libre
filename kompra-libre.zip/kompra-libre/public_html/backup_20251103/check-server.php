<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/plain; charset=utf-8');

echo "=== Server Configuration Check ===\n\n";

// Check PHP version
$phpVersion = phpversion();
echo "PHP Version: $phpVersion\n";

// Check required PHP extensions
$requiredExtensions = ['pdo_mysql', 'json', 'mbstring', 'gd', 'fileinfo'];
$missingExtensions = [];

foreach ($requiredExtensions as $ext) {
    if (!extension_loaded($ext)) {
        $missingExtensions[] = $ext;
    }
}

if (empty($missingExtensions)) {
    echo "✓ All required PHP extensions are loaded\n";
} else {
    echo "✗ Missing PHP extensions: " . implode(', ', $missingExtensions) . "\n";
}

// Check file permissions
$writableDirs = [
    __DIR__ . '/../uploads' => 'Uploads directory',
    __DIR__ . '/../cache' => 'Cache directory',
    __DIR__ . '/../sessions' => 'Sessions directory'
];

foreach ($writableDirs as $dir => $description) {
    if (!file_exists($dir)) {
        if (!@mkdir($dir, 0755, true)) {
            echo "✗ $description does not exist and could not be created\n";
            continue;
        }
    }
    
    if (!is_writable($dir)) {
        if (!@chmod($dir, 0755)) {
            echo "✗ $description is not writable and could not be made writable\n";
        } else {
            echo "✓ $description is now writable\n";
        }
    } else {
        echo "✓ $description is writable\n";
    }
}

// Check database connection
echo "\n=== Database Connection Test ===\n";

try {
    $db = new PDO(
        "mysql:host=localhost;dbname=u472738607_kompra_libre;charset=utf8mb4",
        'u472738607_kompra_libre',
        'Kompralibre1',
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    
    echo "✓ Successfully connected to the database\n";
    
    // Check if users table exists
    $tables = $db->query("SHOW TABLES LIKE 'users'")->fetchAll();
    if (empty($tables)) {
        echo "✗ The 'users' table does not exist in the database\n";
    } else {
        echo "✓ 'users' table exists\n";
    }
    
} catch (PDOException $e) {
    echo "✗ Database connection failed: " . $e->getMessage() . "\n";
}

// Check .htaccess configuration
echo "\n=== .htaccess Check ===\n";

$htaccessPath = __DIR__ . '/../.htaccess';
if (!file_exists($htaccessPath)) {
    $htaccessContent = "<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /
    
    # Redirect to HTTPS
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
    
    # Handle Front Controller...
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [L]
    
    # Handle Authorization Header
    RewriteCond %{HTTP:Authorization} .
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
</IfModule>";
    
    if (@file_put_contents($htaccessPath, $htaccessContent)) {
        echo "✓ .htaccess file created with recommended settings\n";
    } else {
        echo "✗ Could not create .htaccess file. Please create it manually with the following content:\n\n$htaccessContent\n";
    }
} else {
    echo "✓ .htaccess file exists\n";
}

// Check PHP configuration
echo "\n=== PHP Configuration ===\n";
$requiredSettings = [
    'upload_max_filesize' => '10M',
    'post_max_size' => '12M',
    'memory_limit' => '128M',
    'max_execution_time' => '300',
    'max_input_time' => '300',
];

foreach ($requiredSettings as $setting => $required) {
    $current = ini_get($setting);
    echo str_pad("$setting: ", 20) . "$current";
    
    if ($this->comparePhpIniValues($current, $required)) {
        echo " ✓\n";
    } else {
        echo " ✗ (Recommended: $required)\n";
    }
}

// Helper function to compare PHP ini values
function comparePhpIniValues($current, $required) {
    $current = trim($current);
    $required = trim($required);
    
    // If they're exactly the same
    if ($current === $required) {
        return true;
    }
    
    // Convert to bytes for comparison
    $currentBytes = $this->returnBytes($current);
    $requiredBytes = $this->returnBytes($required);
    
    return $currentBytes >= $requiredBytes;
}

// Helper function to convert shorthand byte values to bytes
function returnBytes($val) {
    $val = trim($val);
    $last = strtolower($val[strlen($val)-1]);
    $val = (int) $val;
    
    switch($last) {
        case 'g':
            $val *= 1024;
        case 'm':
            $val *= 1024;
        case 'k':
            $val *= 1024;
    }
    
    return $val;
}

echo "\n=== Check Complete ===\n";
?>

<!-- Add a simple HTML form to test file uploads -->
<h2>File Upload Test</h2>
<form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="test_file">
    <button type="submit">Test Upload</button>
</form>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['test_file'])) {
    echo "<h3>Upload Test Results:</h3>";
    echo "<pre>";
    var_dump($_FILES['test_file']);
    echo "</pre>";
    
    $uploadDir = __DIR__ . '/../uploads/test/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $targetFile = $uploadDir . basename($_FILES['test_file']['name']);
    
    if (move_uploaded_file($_FILES['test_file']['tmp_name'], $targetFile)) {
        echo "File uploaded successfully to: " . htmlspecialchars($targetFile);
        unlink($targetFile); // Clean up
    } else {
        echo "Upload failed. Error: " . $_FILES['test_file']['error'];
    }
}
?>
