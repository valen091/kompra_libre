<?php
// Script PHP que hace TODO automáticamente - SIN SQL files externos
header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>";
echo "<html><head><title>Setup Kompra Libre</title>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
    .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
    .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; }
    .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; }
    .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 10px 0; }
    .info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; }
    .step { border-left: 4px solid #007cba; padding: 15px; margin: 15px 0; }
    .btn { background: #007cba; color: white; padding: 15px 30px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin: 10px; }
    .btn:hover { background: #005a8b; }
    table { width: 100%; border-collapse: collapse; margin: 15px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
</style>";
echo "</head><body>";
echo "<div class='container'>";

echo "<h1>🛠️ SETUP COMPLETO KOMPRA LIBRE</h1>";
echo "<p>Script PHP que hace TODO automáticamente sin archivos SQL externos</p>";

// Incluir configuración
try {
    require_once __DIR__ . '/includes/config.php';
    require_once __DIR__ . '/includes/db.php';

    $pdo = getDB();
    echo "<div class='success'>✅ Conexión a base de datos exitosa</div>";

    // PASO 1: Verificar y crear tablas
    echo "<div class='step'>";
    echo "<h3>📋 PASO 1: Verificando y creando tablas...</h3>";

    $tables_to_check = ['users', 'categories', 'sellers', 'products', 'admins'];
    $tables_created = 0;

    foreach ($tables_to_check as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() == 0) {
            // Crear tabla
            switch ($table) {
                case 'users':
                    $pdo->exec("CREATE TABLE users (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        email VARCHAR(120) NOT NULL UNIQUE,
                        password_hash VARCHAR(255) NOT NULL,
                        role ENUM('buyer','seller','admin') NOT NULL DEFAULT 'buyer',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )");
                    break;
                case 'categories':
                    $pdo->exec("CREATE TABLE categories (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(120) NOT NULL,
                        slug VARCHAR(120) NOT NULL UNIQUE
                    )");
                    break;
                case 'sellers':
                    $pdo->exec("CREATE TABLE sellers (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        shop_alias VARCHAR(120),
                        reputation INT DEFAULT 0
                    )");
                    break;
                case 'admins':
                    $pdo->exec("CREATE TABLE admins (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL
                    )");
                    break;
                case 'products':
                    $pdo->exec("CREATE TABLE products (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        seller_id INT NOT NULL,
                        title VARCHAR(200) NOT NULL,
                        description TEXT,
                        price DECIMAL(10,2) NOT NULL,
                        stock INT NOT NULL DEFAULT 0,
                        `condition` ENUM('nuevo','usado') DEFAULT 'nuevo',
                        category_id INT,
                        visible TINYINT(1) DEFAULT 1,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )");
                    break;
            }
            echo "<div class='success'>✅ Tabla $table creada</div>";
            $tables_created++;
        } else {
            echo "<div class='info'>✅ Tabla $table ya existe</div>";
        }
    }

    if ($tables_created > 0) {
        echo "<div class='success'>✅ $tables_created tablas creadas</div>";
    } else {
        echo "<div class='info'>✅ Todas las tablas ya existían</div>";
    }
    echo "</div>";

    // PASO 2: Insertar 3 cuentas demo
    echo "<div class='step'>";
    echo "<h3>👤 PASO 2: Creando 3 cuentas demo...</h3>";

    // Usuario demo (comprador)
    $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES
        ('Demo Comprador', 'comprador@demo.com', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer')");
    echo "<div class='success'>✅ Usuario demo (comprador) creado</div>";

    // Vendedor demo
    $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES
        ('Demo Vendedor', 'vendedor@demo.com', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller')");
    echo "<div class='success'>✅ Usuario demo (vendedor) creado</div>";

    // Admin demo
    $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES
        ('Demo Admin', 'admin@demo.com', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin')");
    echo "<div class='success'>✅ Usuario demo (admin) creado</div>";
    echo "</div>";

    // PASO 3: Crear vendedores y admins
    echo "<div class='step'>";
    echo "<h3>🏪 PASO 3: Configurando vendedores y admins...</h3>";

    // Crear vendedor para el usuario vendedor
    $pdo->exec("INSERT IGNORE INTO sellers (user_id, shop_alias)
        SELECT id, 'Tienda Demo' FROM users WHERE email = 'vendedor@demo.com'");
    echo "<div class='success'>✅ Vendedor configurado</div>";

    // Crear admin para el usuario admin
    $pdo->exec("INSERT IGNORE INTO admins (user_id)
        SELECT id FROM users WHERE email = 'admin@demo.com'");
    echo "<div class='success'>✅ Admin configurado</div>";
    echo "</div>";

    // PASO 4: Insertar categorías
    echo "<div class='step'>";
    echo "<h3>🏷️ PASO 4: Insertando categorías...</h3>";

    $categories = [
        ['Electrónica', 'electronica'],
        ['Ropa', 'ropa'],
        ['Hogar', 'hogar'],
        ['Deportes', 'deportes'],
        ['Libros', 'libros'],
        ['Automóvil', 'automovil'],
        ['Belleza', 'belleza'],
        ['Juguetes', 'juguetes'],
        ['Música', 'musica'],
        ['Salud', 'salud']
    ];

    foreach ($categories as $cat) {
        $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('{$cat[0]}', '{$cat[1]}')");
    }
    echo "<div class='success'>✅ " . count($categories) . " categorías insertadas</div>";
    echo "</div>";

    // PASO 5: Insertar productos
    echo "<div class='step'>";
    echo "<h3>📦 PASO 5: Insertando productos...</h3>";

    // Obtener el ID del vendedor
    $stmt = $pdo->query("SELECT id FROM sellers WHERE shop_alias = 'Tienda Demo'");
    $seller_id = $stmt->fetch()['id'];

    $productos = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional y chip A17 Pro', 1299.99, 1, 1],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3 y hasta 18 horas de batería', 1099.99, 1, 1],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable ideal para entrenamientos', 29.99, 2, 2],
        ['Juego de Sartenes Antiaderentes', 'Set de 3 sartenes con recubrimiento antiadherente', 89.99, 3, 3],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5 para partidos profesionales', 39.99, 4, 4],
        ['Clean Code - Robert C. Martin', 'Libro fundamental sobre buenas prácticas de programación', 49.99, 5, 5],
        ['Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 1, 1],
        ['Zapatillas Running Adidas', 'Zapatillas deportivas para running con amortiguación', 89.99, 4, 4],
        ['Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 3, 3],
        ['Chaqueta Impermeable', 'Chaqueta resistente al agua para actividades outdoor', 79.99, 2, 2],
        ['Televisor 4K Samsung 55"', 'Smart TV con resolución 4K y HDR', 899.99, 1, 1],
        ['Reloj Inteligente Apple Watch', 'Apple Watch Series 9 con GPS y cellular', 399.99, 1, 1],
        ['Sofá de 3 plazas', 'Sofá moderno y cómodo para sala de estar', 599.99, 3, 3],
        ['Bicicleta Mountain Bike', 'Bicicleta todo terreno con 21 velocidades', 299.99, 4, 4],
        ['Guitarra Acústica Yamaha', 'Guitarra acústica de madera con gran sonido', 199.99, 9, 5]
    ];

    $productos_insertados = 0;
    foreach ($productos as $prod) {
        $pdo->exec("INSERT IGNORE INTO products (seller_id, title, description, price, stock, condition, category_id, visible) VALUES
            ($seller_id, '{$prod[0]}', '{$prod[1]}', {$prod[2]}, 10, 'nuevo', {$prod[3]}, 1)");
        $productos_insertados++;
    }

    echo "<div class='success'>✅ $productos_insertados productos insertados</div>";
    echo "</div>";

    // PASO 6: Verificación final
    echo "<div class='step'>";
    echo "<h3>📊 PASO 6: Verificación final...</h3>";

    $stats = [
        'usuarios' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
        'categorias' => $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn(),
        'productos' => $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn(),
        'vendedores' => $pdo->query("SELECT COUNT(*) FROM sellers")->fetchColumn(),
        'admins' => $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn()
    ];

    echo "<table>";
    echo "<tr><th>Tipo</th><th>Cantidad</th></tr>";
    echo "<tr><td>👤 Usuarios Totales</td><td>{$stats['usuarios']}</td></tr>";
    echo "<tr><td>🏷️ Categorías</td><td>{$stats['categorias']}</td></tr>";
    echo "<tr><td>📦 Productos Visibles</td><td>{$stats['productos']}</td></tr>";
    echo "<tr><td>🏪 Vendedores</td><td>{$stats['vendedores']}</td></tr>";
    echo "<tr><td>👨‍💼 Admins</td><td>{$stats['admins']}</td></tr>";
    echo "</table>";
    echo "</div>";

    // Mostrar cuentas demo
    echo "<div class='step'>";
    echo "<h3>🔐 CUENTAS DEMO CREADAS:</h3>";
    echo "<table>";
    echo "<tr><th>Rol</th><th>Email</th><th>Contraseña</th><th>Estado</th></tr>";

    $cuentas = $pdo->query("SELECT name, email, role FROM users ORDER BY role, email")->fetchAll();
    foreach ($cuentas as $cuenta) {
        $pass = 'demo123';
        $estado = ($cuenta['role'] == 'admin') ? 'Panel Admin' :
                  (($cuenta['role'] == 'seller') ? 'Panel Vendedor' : 'Panel Usuario');
        echo "<tr><td>{$cuenta['role']}</td><td>{$cuenta['email']}</td><td>$pass</td><td>$estado</td></tr>";
    }
    echo "</table>";
    echo "</div>";

    echo "<div class='success'>";
    echo "<h2>🎉 ¡SETUP COMPLETADO EXITOSAMENTE!</h2>";
    echo "<p><strong>✅ Todas las tablas creadas</strong><br>";
    echo "<strong>✅ 3 cuentas demo configuradas</strong><br>";
    echo "<strong>✅ {$stats['categorias']} categorías insertadas</strong><br>";
    echo "<strong>✅ {$stats['productos']} productos visibles</strong><br>";
    echo "<strong>✅ APIs listas para usar</strong></p>";
    echo "<p><a href='https://kompralibre.shop' class='btn'>🚀 Ir al sitio web</a></p>";
    echo "</div>";

} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h3>❌ ERROR:</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<h4>🔧 Soluciones:</h4>";
    echo "<ul>";
    echo "<li>Verifica que la base de datos u472738607_kompra_libre existe</li>";
    echo "<li>Verifica las credenciales de conexión</li>";
    echo "<li>Revisa que config.php esté configurado correctamente</li>";
    echo "</ul>";
    echo "</div>";
}

echo "</div>";
echo "</body></html>";
?>
