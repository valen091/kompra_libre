<?php
// Disable error display for the test
ini_set('display_errors', 0);

echo "Testing database connection...\n";

$servername = 'srv1311.hstgr.io';  // Hostinger MySQL server
$username   = 'u472738607_kompra_libre';
$password   = 'Kompralibre1';
$dbname     = 'u472738607_kompra_libre';
$port       = 3306;  // Default MySQL port

try {
    // Test connection with PDO
    $dsn = "mysql:host=$servername;port=$port;dbname=$dbname;charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_TIMEOUT => 5,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    
    echo "Connecting to: $servername\n";
    echo "Database: $dbname\n";
    echo "Username: $username\n";
    
    $pdo = new PDO($dsn, $username, $password, $options);
    echo "✅ Successfully connected to the database!\n";
    
    // Test query
    $stmt = $pdo->query('SELECT 1 as test');
    $result = $stmt->fetch();
    echo "✅ Test query successful. Result: " . json_encode($result, JSON_PRETTY_PRINT) . "\n";
    
    // Test if tables exist
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    if (count($tables) > 0) {
        echo "✅ Found " . count($tables) . " tables in the database.\n";
        if (in_array('users', $tables)) {
            echo "✅ 'users' table exists.\n";
        } else {
            echo "⚠️ 'users' table does not exist.\n";
        }
    } else {
        echo "⚠️ No tables found in the database.\n";
    }
    
} catch (PDOException $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "\n";
    echo "Error Code: " . $e->getCode() . "\n";
    
    // Additional debugging info
    $errorInfo = $e->errorInfo ?? [];
    if (!empty($errorInfo)) {
        echo "SQL State: " . ($errorInfo[0] ?? 'N/A') . "\n";
        echo "Driver Error Code: " . ($errorInfo[1] ?? 'N/A') . "\n";
        echo "Driver Error Message: " . ($errorInfo[2] ?? 'N/A') . "\n";
    }
    
    // Test if we can at least connect to MySQL (without selecting a database)
    try {
        $dsn = "mysql:host=$servername;charset=utf8mb4";
        $pdo = new PDO($dsn, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 5,
        ]);
        echo "ℹ️ Can connect to MySQL server but had issues with the database.\n";
    } catch (PDOException $e2) {
        echo "❌ Cannot connect to MySQL server. Check your credentials and server status.\n";
        echo "Error: " . $e2->getMessage() . "\n";
    }
}
