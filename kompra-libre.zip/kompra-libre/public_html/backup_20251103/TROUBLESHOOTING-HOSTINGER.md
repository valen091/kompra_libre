# 🚨 Solución para Error 404 en APIs - Hostinger

## **Problema Identificado**
```
Uncaught (in promise) Error: A listener indicated an asynchronous response by returning true, but the message channel closed before a response was received
/api/categories:1 Failed to load resource: the server responded with a status of 404 ()
```

## **Causa del Error**
El error 404 indica que las APIs no están accesibles en Hostinger. Esto puede deberse a:

1. **Permisos de archivos incorrectos**
2. **Configuración PHP no habilitada para subdirectorios**
3. **Falta de archivos de configuración**
4. **Base de datos no accesible**

## **🔧 Solución Paso a Paso**

### **Paso 1: Verificar que los archivos existen**
Asegúrate de que estos archivos están en tu servidor:
```
public_html/
├── api/
│   ├── categories.php
│   ├── products.php
│   ├── test.php (nuevo)
│   ├── categories-simple.php (nuevo)
│   └── products-simple.php (nuevo)
├── includes/
│   ├── config.php
│   ├── db.php
│   └── functions.php
└── .htaccess
```

### **Paso 2: Configurar permisos correctos**
Ejecuta estos comandos en Hostinger (File Manager o SSH):

```bash
# Desde public_html
chmod 755 .
chmod 755 api/
chmod 644 api/*.php
chmod 644 includes/*.php
chmod 644 .htaccess
```

### **Paso 3: Probar APIs directamente**
Abre tu navegador y prueba estas URLs:

1. **API de Test (nueva)**: `https://tu-dominio.com/api/test`
   - Debería mostrar información de debugging

2. **API Simplificada de Categorías**: `https://tu-dominio.com/api/categories-simple`
   - Debería mostrar categorías de ejemplo

3. **API Simplificada de Productos**: `https://tu-dominio.com/api/products-simple`
   - Debería mostrar productos de ejemplo

### **Paso 4: Si las APIs simplificadas funcionan**
Si las APIs simplificadas funcionan pero las reales no, el problema es con la **base de datos**:

1. **Verifica que la BD existe** en Hostinger
2. **Importa el esquema** desde `sql/kompra_libre.sql`
3. **Verifica credenciales** en `includes/config.php`

### **Paso 5: Configuración de PHP en Hostinger**
Si ninguna API funciona:

1. Ve a **Hostinger Panel** → **Advanced** → **PHP Configuration**
2. Asegúrate de que PHP esté configurado correctamente
3. Habilita `display_errors` temporalmente para debugging

### **Paso 6: .htaccess específico para APIs**
Asegúrate de que el archivo `api/.htaccess` existe con este contenido:

```apache
# .htaccess específico para la carpeta API
RewriteEngine On

# Permitir acceso directo a todos los archivos PHP en /api/
RewriteCond %{REQUEST_URI} ^/api/.*$
RewriteRule ^ - [L]

# Headers para APIs
<IfModule mod_headers.c>
    Header always set Access-Control-Allow-Origin "*"
    Header always set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
    Header always set Access-Control-Allow-Headers "Content-Type, Authorization, Accept"
</IfModule>
```

## **🔍 Debugging URLs**

Prueba estas URLs en tu navegador para diagnosticar:

- `https://tu-dominio.com/api/test` - Información general del servidor
- `https://tu-dominio.com/api/categories-simple` - Categorías sin BD
- `https://tu-dominio.com/api/products-simple?page=1&limit=6` - Productos sin BD
- `https://tu-dominio.com/api/categories` - Categorías reales (requiere BD)
- `https://tu-dominio.com/api/products?page=1&limit=6` - Productos reales (requiere BD)

## **⚡ Solución Rápida (Fallback)**

El código ya incluye **fallback automático**:
1. Primero intenta APIs reales
2. Si fallan, usa APIs simplificadas
3. Muestra productos de ejemplo para que el sitio funcione

## **📞 Si nada funciona:**

1. **Contacta soporte de Hostinger** con estos detalles:
   - Error 404 en /api/categories
   - Las APIs simplificadas funcionan
   - Logs de error de PHP

2. **Verifica logs de error** en Hostinger:
   - Panel → Logs → Error Logs
   - Busca errores relacionados con PHP o base de datos

3. **Prueba en modo incógnito** para descartar cache del navegador

## **✅ Estado Actual del Código**

✅ **APIs simplificadas creadas** (funcionan sin base de datos)  
✅ **Fallback automático implementado** (cambia automáticamente)  
✅ **Mejor debugging** (logs detallados en consola)  
✅ **Scripts de instalación** (setup-hostinger.sh y .ps1)  

## **🎯 Próximos Pasos**

1. **Sube los nuevos archivos** a Hostinger
2. **Ejecuta los scripts de setup** si tienes SSH
3. **Prueba las URLs de debugging** en tu navegador
4. **Configura la base de datos** si las APIs simplificadas funcionan
5. **Contacta soporte** si persiste el error 404

---
**El sitio debería funcionar con las APIs simplificadas mientras resuelves el problema de la base de datos.**
