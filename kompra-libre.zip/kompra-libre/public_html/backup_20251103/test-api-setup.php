<?php
// Script de prueba para verificar que la API funciona
header('Content-Type: text/plain');

echo "🧪 PRUEBA DE API - KOMPRA LIBRE\n";
echo "==============================\n\n";

try {
    // Incluir archivos de configuración
    require_once __DIR__ . '/includes/config.php';
    require_once __DIR__ . '/includes/db.php';

    echo "✅ Configuración cargada correctamente\n";
    echo "📊 DB_HOST: " . DB_HOST . "\n";
    echo "📊 DB_NAME: " . DB_NAME . "\n";
    echo "📊 DB_USER: " . DB_USER . "\n\n";

    // Probar conexión a la base de datos
    echo "🔌 Probando conexión a la base de datos...\n";
    $pdo = getDB();
    echo "✅ Conexión exitosa\n\n";

    // Probar endpoint de categorías
    echo "🏷️ Probando API de categorías...\n";
    $stmt = $pdo->query('SELECT COUNT(*) as count FROM categories');
    $catCount = $stmt->fetch()['count'];
    echo "✅ Categorías encontradas: " . $catCount . "\n";

    // Probar endpoint de productos
    echo "📦 Probando API de productos...\n";
    $stmt = $pdo->query('SELECT COUNT(*) as count FROM products WHERE visible = 1');
    $prodCount = $stmt->fetch()['count'];
    echo "✅ Productos visibles: " . $prodCount . "\n\n";

    // Simular respuesta de API de categorías
    echo "📋 Simulando respuesta API categorías...\n";
    $stmt = $pdo->query('SELECT id, name, slug FROM categories ORDER BY name LIMIT 3');
    $categories = $stmt->fetchAll();
    echo "✅ Respuesta API categorías: " . json_encode(['data' => $categories]) . "\n\n";

    // Simular respuesta de API de productos
    echo "📋 Simulando respuesta API productos...\n";
    $stmt = $pdo->query('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.visible = 1 ORDER BY p.created_at DESC LIMIT 2');
    $products = $stmt->fetchAll();
    $response = [
        'data' => [
            'products' => $products,
            'page' => 1,
            'total' => $prodCount,
            'limit' => 9
        ]
    ];
    echo "✅ Respuesta API productos: " . json_encode($response) . "\n\n";

    echo "🎉 ¡LA API ESTÁ FUNCIONANDO CORRECTAMENTE!\n\n";
    echo "📍 URL de prueba en el navegador:\n";
    echo "🔗 https://kompralibre.shop/api.php?endpoint=categories\n";
    echo "🔗 https://kompralibre.shop/api.php?endpoint=products\n\n";

    echo "📝 El .htaccess redirige automáticamente:\n";
    echo "🔗 https://kompralibre.shop/api/categories → api.php?endpoint=categories\n";
    echo "🔗 https://kompralibre.shop/api/products → api.php?endpoint=products\n\n";

} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n\n";
    echo "🔧 Verifica:\n";
    echo "• Que la base de datos existe y está accesible\n";
    echo "• Que las credenciales son correctas\n";
    echo "• Que config.php está incluido correctamente\n";
}
?>
