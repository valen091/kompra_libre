# Script de instalación para Hostinger (Windows PowerShell)
# Ejecutar desde la raíz de public_html

Write-Host "🔧 Configurando Kompra Libre para Hostinger..." -ForegroundColor Green

# 1. Verificar estructura de archivos
Write-Host "📁 Verificando estructura de archivos..." -ForegroundColor Yellow

if (!(Test-Path "api")) {
    Write-Host "❌ Carpeta 'api' no encontrada" -ForegroundColor Red
    exit 1
}

if (!(Test-Path "api\categories.php")) {
    Write-Host "❌ api\categories.php no encontrado" -ForegroundColor Red
    exit 1
}

if (!(Test-Path "api\products.php")) {
    Write-Host "❌ api\products.php no encontrado" -ForegroundColor Red
    exit 1
}

# 2. Configurar permisos
Write-Host "🔐 Configurando permisos..." -ForegroundColor Yellow

# En Windows, establecer permisos requiere privilegios de administrador
# Los permisos se configuran automáticamente en Hostinger

# 3. Verificar archivos críticos
Write-Host "✅ Verificando archivos críticos..." -ForegroundColor Yellow

if (!(Test-Path "includes\config.php")) {
    Write-Host "❌ includes\config.php no encontrado" -ForegroundColor Red
    exit 1
}

if (!(Test-Path ".htaccess")) {
    Write-Host "❌ .htaccess no encontrado" -ForegroundColor Red
    exit 1
}

# 4. Verificar configuración de base de datos
Write-Host "💾 Verificando configuración de base de datos..." -ForegroundColor Yellow

if (Select-String -Path "includes\config.php" -Pattern "u472738607_kompra_libre" -Quiet) {
    Write-Host "⚠️  Base de datos configurada para Hostinger" -ForegroundColor Yellow
    Write-Host "   Asegúrate de que la base de datos existe y es accesible" -ForegroundColor Yellow
} else {
    Write-Host "❌ Configuración de base de datos no encontrada" -ForegroundColor Red
}

Write-Host ""
Write-Host "🎉 Instalación completada!" -ForegroundColor Green
Write-Host ""
Write-Host "📝 Pasos siguientes:" -ForegroundColor Cyan
Write-Host "1. Verifica que la base de datos esté creada en Hostinger" -ForegroundColor White
Write-Host "2. Importa el esquema de la base de datos desde sql\kompra_libre.sql" -ForegroundColor White
Write-Host "3. Actualiza las credenciales en includes\config.php si es necesario" -ForegroundColor White
Write-Host "4. Prueba las APIs directamente en tu navegador:" -ForegroundColor White
Write-Host "   - Test general: https://tu-dominio.com/api/test" -ForegroundColor Gray
Write-Host "   - Categorías (simple): https://tu-dominio.com/api/categories-simple" -ForegroundColor Gray
Write-Host "   - Productos (simple): https://tu-dominio.com/api/products-simple" -ForegroundColor Gray
Write-Host ""
Write-Host "🔍 Troubleshooting:" -ForegroundColor Cyan
Write-Host "• Si ves error 404, verifica que los archivos PHP estén en el lugar correcto" -ForegroundColor White
Write-Host "• Si ves error 500, revisa los logs de error de PHP en Hostinger" -ForegroundColor White
Write-Host "• Si no conecta a la BD, verifica las credenciales en config.php" -ForegroundColor White
Write-Host "• Las APIs simplificadas funcionan sin base de datos para testing inicial" -ForegroundColor White
