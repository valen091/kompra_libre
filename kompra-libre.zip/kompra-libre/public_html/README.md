# 📁 pages/ - Páginas HTML del Sitio

Este directorio contiene todas las páginas HTML del frontend del proyecto Kompra Libre.

## 📋 Contenido

### 🏠 Páginas Principales
- **`index.html`** - Página principal y home del sitio
- **`producto.html`** - Página de detalle de producto individual

### 🛒 Páginas de Comercio
- **`carrito.html`** - Página del carrito de compras
- **`checkout.html`** - Página de pago y finalización de compra
- **`favoritos.html`** - Página de productos favoritos

### 👤 Páginas de Usuario
- **`login.html`** - Página de inicio de sesión
- **`registro.html`** - Página de registro de nuevos usuarios

### 🔧 Páginas de Reparación
- **`repair-db.html`** - Página de reparación de base de datos

### 📊 Páginas de Panel
- **`panel-admin.html`** - Panel de administración completo
- **`panel-usuario.html`** - Panel de usuario estándar
- **`panel-vendedor.html`** - Panel específico para vendedores

## 🔍 Uso

### Para Desarrollo
1. **Pruebas**: Abre cualquier página directamente en el navegador
2. **Debug**: Usa las herramientas de desarrollador del navegador
3. **Responsive**: Verifica el diseño en diferentes tamaños de pantalla

### Para Producción
1. **SEO**: Asegúrate de que todas las páginas tengan meta tags apropiados
2. **Performance**: Optimiza imágenes y recursos
3. **Accesibilidad**: Verifica que las páginas sean accesibles

## 📁 Estructura Padre

```
📦 kompra-libre/
└── 📂 public_html/
    ├── 📂 config/
    ├── 📂 docs/
    ├── 📂 setup/
    ├── 📂 pages/          ← Estás aquí
    ├── 📂 tests/
    └── ... (otros directorios)
```

## 🔧 Personalización

### Modificar Páginas
1. **HTML**: Edita el contenido directamente
2. **CSS**: Los estilos están en `../css/` o usa Tailwind
3. **JavaScript**: Scripts en `../js/`

### Agregar Páginas
1. **Crea** el archivo HTML en este directorio
2. **Sigue** las convenciones de nombres existentes
3. **Actualiza** la navegación si es necesario

## 📱 Responsive Design

Todas las páginas están diseñadas para ser:
- ✅ **Mobile-first** - Optimizadas para móviles
- ✅ **Responsive** - Se adaptan a diferentes pantallas
- ✅ **Cross-browser** - Compatibles con navegadores modernos

## 🔗 Navegación

Las páginas están interconectadas a través de:
- **Enlaces internos** entre páginas
- **Formularios** que envían a otras páginas
- **JavaScript** para navegación dinámica
- **API calls** a `../api/` para datos dinámicos

## 📞 Mantenimiento

- **Actualiza** enlaces cuando cambies nombres de archivos
- **Mantén** consistencia en el diseño entre páginas
- **Prueba** todas las funcionalidades regularmente
- **Optimiza** imágenes y recursos para mejor performance
