<?php
// Incluir configuración
require_once __DIR__ . '/config.php';

// Verificar autenticación y obtener datos del usuario
$user = requireAuth();
$vendedor_id = $user['id'];
$vendedor_nombre = $user['name'];
$user_role = $user['role'];

// Obtener estadísticas del vendedor
try {
    $db = getDb();
    
    // Total de ventas
    $stmt = $db->prepare("SELECT COUNT(*) as total_ventas FROM ventas WHERE vendedor_id = ?");
    $stmt->execute([$vendedor_id]);
    $total_ventas = $stmt->fetch()['total_ventas'] ?? 0;
    
    // Ventas del mes actual
    $stmt = $db->prepare("
        SELECT COUNT(*) as ventas_mes, COALESCE(SUM(total), 0) as ingresos_mes 
        FROM ventas 
        WHERE vendedor_id = ? 
        AND MONTH(fecha_venta) = MONTH(CURRENT_DATE())
        AND YEAR(fecha_venta) = YEAR(CURRENT_DATE())
    ");
    $stmt->execute([$vendedor_id]);
    $ventas_mes = $stmt->fetch();
    
    // Productos más vendidos
    $stmt = $db->prepare("
        SELECT p.nombre, COUNT(*) as cantidad_vendida
        FROM ventas_detalle vd
        JOIN productos p ON vd.producto_id = p.id
        JOIN ventas v ON vd.venta_id = v.id
        WHERE v.vendedor_id = ?
        GROUP BY p.id, p.nombre
        ORDER BY cantidad_vendida DESC
        LIMIT 5
    ");
    $stmt->execute([$vendedor_id]);
    $productos_mas_vendidos = $stmt->fetchAll();
    
    // Últimas ventas
    $stmt = $db->prepare("
        SELECT v.id, v.fecha_venta, v.total, v.estado, 
               COUNT(vd.id) as items, c.nombre as cliente
        FROM ventas v
        LEFT JOIN ventas_detalle vd ON v.id = vd.venta_id
        LEFT JOIN clientes c ON v.cliente_id = c.id
        WHERE v.vendedor_id = ?
        GROUP BY v.id
        ORDER BY v.fecha_venta DESC
        LIMIT 5
    ");
    $stmt->execute([$vendedor_id]);
    $ultimas_ventas = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Error al obtener estadísticas del vendedor: " . $e->getMessage());
    $total_ventas = 0;
    $ventas_mes = ['ventas_mes' => 0, 'ingresos_mes' => 0];
    $productos_mas_vendidos = [];
    $ultimas_ventas = [];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Vendedor - Kompra Libre</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-64 p-4">
            <div class="text-xl font-bold mb-8">Kompra Libre</div>
            <nav>
                <a href="/panel-vendedor/" class="block py-2 px-4 bg-gray-700 rounded mb-2">
                    <i class="fas fa-tachometer-alt mr-2"></i>Inicio
                </a>
                <a href="/panel-vendedor/productos.php" class="block py-2 px-4 hover:bg-gray-700 rounded mb-2">
                    <i class="fas fa-box mr-2"></i>Mis Productos
                </a>
                <a href="/panel-vendedor/ventas.php" class="block py-2 px-4 hover:bg-gray-700 rounded mb-2">
                    <i class="fas fa-shopping-cart mr-2"></i>Ventas
                </a>
                <a href="/panel-vendedor/perfil.php" class="block py-2 px-4 hover:bg-gray-700 rounded mb-2">
                    <i class="fas fa-user mr-2"></i>Mi Perfil
                </a>
                <a href="/auth/logout.php" class="block py-2 px-4 hover:bg-gray-700 rounded">
                    <i class="fas fa-sign-out-alt mr-2"></i>Cerrar Sesión
                </a>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 p-8">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold">Panel de Vendedor</h1>
                <div class="text-sm text-gray-600">
                    <span class="font-medium"><?php echo htmlspecialchars($vendedor_nombre); ?></span>
                    <span class="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full ml-2">Vendedor</span>
                </div>
            </div>
            
            <!-- Estadísticas -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-blue-100 text-blue-600 mr-4">
                            <i class="fas fa-shopping-cart text-xl"></i>
                        </div>
                        <div>
                            <p class="text-gray-500 text-sm">Ventas del Mes</p>
                            <p class="text-2xl font-bold">$0.00</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-green-100 text-green-600 mr-4">
                            <i class="fas fa-boxes text-xl"></i>
                        </div>
                        <div>
                            <p class="text-gray-500 text-sm">Productos Activos</p>
                            <p class="text-2xl font-bold">0</p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-lg shadow">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-yellow-100 text-yellow-600 mr-4">
                            <i class="fas fa-star text-xl"></i>
                        </div>
                        <div>
                            <p class="text-gray-500 text-sm">Valoración</p>
                            <div class="flex items-center">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star text-yellow-400"></i>
                                <?php endfor; ?>
                                <span class="ml-2 text-gray-700">(0)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Acciones Rápidas -->
            <div class="bg-white p-6 rounded-lg shadow mb-8">
                <h2 class="text-xl font-semibold mb-4">Acciones Rápidas</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <a href="/panel-vendedor/productos/nuevo.php" class="border border-dashed border-gray-300 rounded-lg p-4 text-center hover:bg-gray-50 transition-colors">
                        <div class="text-blue-500 mb-2">
                            <i class="fas fa-plus-circle text-3xl"></i>
                        </div>
                        <p class="font-medium">Agregar Producto</p>
                    </a>
                    
                    <a href="/panel-vendedor/ventas/nueva.php" class="border border-dashed border-gray-300 rounded-lg p-4 text-center hover:bg-gray-50 transition-colors">
                        <div class="text-green-500 mb-2">
                            <i class="fas fa-cash-register text-3xl"></i>
                        </div>
                        <p class="font-medium">Registrar Venta</p>
                    </a>
                    
                    <a href="/panel-vendedor/inventario/" class="border border-dashed border-gray-300 rounded-lg p-4 text-center hover:bg-gray-50 transition-colors">
                        <div class="text-purple-500 mb-2">
                            <i class="fas fa-boxes text-3xl"></i>
                        </div>
                        <p class="font-medium">Gestionar Inventario</p>
                    </a>
                    
                    <a href="/panel-vendedor/reportes/" class="border border-dashed border-gray-300 rounded-lg p-4 text-center hover:bg-gray-50 transition-colors">
                        <div class="text-yellow-500 mb-2">
                            <i class="fas fa-chart-line text-3xl"></i>
                        </div>
                        <p class="font-medium">Ver Reportes</p>
                    </a>
                </div>
            </div>
            
            <!-- Últimas Ventas -->
            <div class="bg-white rounded-lg shadow overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-xl font-semibold">Últimas Ventas</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID Venta</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <tr>
                                <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                                    No hay ventas recientes
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="px-6 py-4 bg-gray-50 text-right">
                    <a href="/panel-vendedor/ventas/" class="text-sm font-medium text-blue-600 hover:text-blue-800">Ver todas las ventas</a>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Script para manejar el menú móvil
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            
            if (mobileMenuButton && mobileMenu) {
                mobileMenuButton.addEventListener('click', function() {
                    mobileMenu.classList.toggle('hidden');
                });
            }
            
            // Actualizar la hora actual
            function updateDateTime() {
                const now = new Date();
                const options = { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                };
                const dateTimeStr = now.toLocaleDateString('es-ES', options);
                const dateTimeElement = document.getElementById('current-datetime');
                if (dateTimeElement) {
                    dateTimeElement.textContent = dateTimeStr;
                }
            }
            
            // Actualizar cada minuto
            updateDateTime();
            setInterval(updateDateTime, 60000);
        });
    </script>
</body>
</html>
