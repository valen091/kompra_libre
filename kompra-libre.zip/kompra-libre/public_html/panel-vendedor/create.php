<?php
// Set headers first to prevent any output before them
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// Disable error display in production, log them instead
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../../../logs/php_errors.log');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Prevent caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');

// Define response structure
$response = [
    'success' => false,
    'message' => '',
    'errors' => [],
    'data' => null
];

try {
    // Load configuration safely
    $configFile = __DIR__ . '/../../includes/config.php';
    if (!file_exists($configFile)) {
        throw new Exception('Configuration file not found');
    }
    require_once $configFile;
    
    // Load other dependencies
    require_once __DIR__ . '/../../includes/db.php';
    require_once __DIR__ . '/../../includes/functions.php';

    // Check request method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Get and validate input
    $input = $_POST;
    $files = $_FILES;
    
    // Basic validation
    $errors = [];
    $requiredFields = ['title', 'description', 'price', 'category_id', 'quantity'];
    
    foreach ($requiredFields as $field) {
        if (empty(trim($input[$field] ?? ''))) {
            $errors[$field] = "El campo $field es obligatorio";
        }
    }
    
    if (!empty($errors)) {
        $response['errors'] = $errors;
        throw new Exception('Error de validación', 422);
    }
    
    // Sanitize and validate data
    $title = trim($input['title']);
    $description = trim($input['description']);
    $price = filter_var($input['price'], FILTER_VALIDATE_FLOAT);
    $categoryId = filter_var($input['category_id'], FILTER_VALIDATE_INT);
    $quantity = filter_var($input['quantity'], FILTER_VALIDATE_INT);
    
    if ($price === false || $price <= 0) {
        $errors['price'] = 'El precio debe ser un número mayor a cero';
    }
    
    if ($categoryId === false || $categoryId <= 0) {
        $errors['category_id'] = 'Categoría inválida';
    }
    
    if ($quantity === false || $quantity < 0) {
        $errors['quantity'] = 'Cantidad inválida';
    }
    
    if (!empty($errors)) {
        $response['errors'] = $errors;
        throw new Exception('Error de validación', 422);
    }

    // Process the product creation
    $db = getDB();
    $db->beginTransaction();
    
    try {
        // Insert product
        $stmt = $db->prepare("
            INSERT INTO products (
                seller_id, category_id, title, slug, description, 
                price, quantity, status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())
        ");
        
        $slug = generateSlug($title);
        $stmt->execute([
            getCurrentUserId(),
            $categoryId,
            $title,
            $slug,
            $description,
            $price,
            $quantity
        ]);
        
        $productId = $db->lastInsertId();
        
        // Handle file uploads if any
        if (!empty($files['images'])) {
            // Process file uploads here
            // Make sure to validate file types, sizes, etc.
        }
        
        $db->commit();
        
        $response = [
            'success' => true,
            'message' => 'Producto creado exitosamente',
            'data' => [
                'product_id' => $productId,
                'slug' => $slug
            ]
        ];
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
    
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response['message'] = $e->getMessage();
}

// Ensure no output before this
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
exit;