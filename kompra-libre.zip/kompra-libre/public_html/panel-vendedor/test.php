<?php
// Test file to verify PHP execution
echo "<h1>Test Page Working!</h1>";
echo "<p>If you can see this, PHP is working in the panel-vendedor directory.</p>";
?>
