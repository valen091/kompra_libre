<?php
// Debug de includes
echo "=== DEBUG DE INCLUDES ===\n\n";

echo "1. __DIR__: " . __DIR__ . "\n";
echo "2. __FILE__: " . __FILE__ . "\n";
echo "3. PHP Version: " . phpversion() . "\n";
echo "4. Error reporting: " . ini_get('error_reporting') . "\n";
echo "5. Display errors: " . ini_get('display_errors') . "\n\n";

try {
    echo "6. Incluyendo config.php...\n";
    require_once __DIR__ . '/config.php';
    echo "   ✅ Config cargado\n";
    echo "   DB_HOST: " . DB_HOST . "\n";
    echo "   DB_NAME: " . DB_NAME . "\n";
    echo "   DB_USER: " . DB_USER . "\n\n";

    echo "7. Incluyendo db.php...\n";
    require_once __DIR__ . '/db.php';
    echo "   ✅ DB cargado\n\n";

    echo "8. Incluyendo functions.php...\n";
    require_once __DIR__ . '/functions.php';
    echo "   ✅ Functions cargado\n\n";

    echo "9. Probando conexión BD...\n";
    $db = getDB();
    echo "   ✅ Conexión exitosa\n\n";

    echo "10. Verificando tablas...\n";
    $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "   Tablas encontradas: " . count($tables) . "\n";
    foreach ($tables as $table) {
        echo "   - $table\n";
    }

} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    echo "Código: " . $e->getCode() . "\n";
    echo "Archivo: " . $e->getFile() . "\n";
    echo "Línea: " . $e->getLine() . "\n";
}

echo "\n=== FIN DEBUG ===\n";
?>
