<?php
/**
 * Test de conexión a la base de datos
 */

// Mostrar errores
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Incluir configuración
require_once __DIR__ . '/includes/config.php';

// Encabezados para salida en navegador
header('Content-Type: text/plain; charset=utf-8');

try {
    echo "=== Prueba de conexión a la base de datos ===\n\n";
    
    // Mostrar información de configuración
    echo "Configuración de la base de datos:\n";
    echo "- Servidor: " . DB_HOST . "\n";
    echo "- Puerto: " . DB_PORT . "\n";
    echo "- Base de datos: " . DB_NAME . "\n";
    echo "- Usuario: " . DB_USER . "\n";
    echo "- Modo DEBUG: " . (APP_DEBUG ? 'Activado' : 'Desactivado') . "\n\n";
    
    // Configuración de la conexión PDO
    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        DB_HOST,
        DB_PORT,
        DB_NAME
    );
    
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
    ];
    
    echo "Intentando conectar a la base de datos...\n";
    
    // Establecer conexión
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    
    echo " Conexión exitosa a la base de datos.\n\n";
    
    // Probar consulta básica
    echo "Ejecutando consulta de prueba...\n";
    $stmt = $pdo->query('SELECT VERSION() as version, NOW() as fecha_servidor, DATABASE() as base_datos');
    $result = $stmt->fetch();
    
    echo " Consulta exitosa. Información del servidor:\n";
    echo "- Versión de MySQL: " . $result['version'] . "\n";
    echo "- Fecha y hora del servidor: " . $result['fecha_servidor'] . "\n";
    echo "- Base de datos actual: " . $result['base_datos'] . "\n\n";
    
    // Listar tablas
    echo "Obteniendo lista de tablas...\n";
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    echo " Se encontraron " . count($tables) . " tablas en la base de datos.\n";
    
    if (count($tables) > 0) {
        echo "\nLista de tablas:\n";
        foreach ($tables as $i => $table) {
            echo ($i + 1) . ". $table\n";
        }
        
        // Verificar tablas importantes
        $important_tables = ['users', 'productos', 'categorias', 'pedidos', 'ventas', 'clientes'];
        $missing_tables = [];
        
        echo "\nVerificando tablas importantes...\n";
        foreach ($important_tables as $table) {
            if (in_array($table, $tables)) {
                echo " Tabla '$table' existe.\n";
            } else {
                echo "  Tabla '$table' no encontrada.\n";
                $missing_tables[] = $table;
            }
        }
        
        if (!empty($missing_tables)) {
            echo "\n  Advertencia: Faltan algunas tablas importantes: " . implode(', ', $missing_tables) . "\n";
            echo "   Esto podría afectar el funcionamiento de la aplicación.\n";
        }
    }
    
    // Mostrar información de versión de PHP
    echo "\n=== Información del servidor ===\n";
    echo "- PHP version: " . phpversion() . "\n";
    echo "- Sistema operativo: " . php_uname('s') . ' ' . php_uname('r') . "\n";
    echo "- Servidor web: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'Desconocido') . "\n";
    
} catch (PDOException $e) {
    echo "\n Error de conexión a la base de datos:\n";
    echo "Mensaje: " . $e->getMessage() . "\n";
    echo "Código: " . $e->getCode() . "\n";
    
    // Intentar obtener más información sobre el error
    if (strpos($e->getMessage(), 'Access denied') !== false) {
        echo "\nPosibles causas:\n";
        echo "1. Usuario o contraseña incorrectos\n";
        echo "2. El usuario no tiene permisos para acceder a la base de datos\n";
        echo "3. La base de datos especificada no existe\n";
    } elseif (strpos($e->getMessage(), 'Connection refused') !== false) {
        echo "\nPosibles causas:\n";
        echo "1. El servidor de base de datos no está en ejecución\n";
        echo "2. El puerto de la base de datos es incorrecto\n";
        echo "3. El servidor no acepta conexiones remotas\n";
    }
    
    exit(1);
}

echo "\n Prueba completada exitosamente.\n";
