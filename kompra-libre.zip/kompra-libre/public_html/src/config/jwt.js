import jwt from 'jsonwebtoken';
const secret = process.env.JWT_SECRET;
if (!secret) { console.error('❌ FALTA JWT_SECRET en .env'); process.exit(1); }

export const signJwt = (payload, opts = {}) => jwt.sign(payload, secret, { expiresIn: '7d', ...opts });
export const verifyJwt = (token) => jwt.verify(token, secret);
