import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'u472738607_kompra_libre',
    port: Number(process.env.DB_PORT || 3307),
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: true } : false
});

// Función para probar la conexión
export async function testConnection() {
    let connection;
    try {
        connection = await pool.getConnection();
        console.log('✅ Conexión exitosa a la base de datos MySQL');
        return true;
    } catch (error) {
        console.error('❌ Error al conectar a la base de datos MySQL:');
        console.error(error.message);
        return false;
    } finally {
        if (connection) connection.release();
    }
}

// Probar la conexión al iniciar
if (process.env.NODE_ENV !== 'test') {
    testConnection().catch(console.error);
}

export { pool };
export default pool;