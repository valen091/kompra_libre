import { Pool } from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const pool = new Pool({
    user: process.env.DB_USERNAME || 'postgres',
    host: process.env.DB_HOST || 'localhost',
    database: process.env.DB_DATABASE || 'u472738607_kompra_libre',
    password: process.env.DB_PASSWORD || 'Kompralibre1',
    port: Number(process.env.DB_PORT) || 5432,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Función para ejecutar consultas SQL
export async function query(text, params) {
    const client = await pool.connect();
    try {
        const res = await client.query(text, params);
        return res;
    } finally {
        client.release();
    }
}

// Función para probar la conexión
export async function testConnection() {
    let client;
    try {
        client = await pool.connect();
        console.log('✅ Conexión exitosa a la base de datos PostgreSQL');
        return true;
    } catch (error) {
        console.error('❌ Error al conectar a la base de datos PostgreSQL:');
        console.error(error.message);
        return false;
    } finally {
        if (client) client.release();
    }
}

// Probar la conexión al iniciar
if (process.env.NODE_ENV !== 'test') {
    testConnection().catch(console.error);
}

// Exportar solo el pool como default
export default pool;