
import { pool } from '../config/db.js';
export async function queryProducts({q,category,price_min,price_max,condition,page=1,limit=12}){
  const where = ['p.visible=1']; const params=[];
  if(q){ where.push('p.title LIKE ?'); params.push('%'+q+'%'); }
  if(category){ where.push('p.category_id=?'); params.push(category); }
  if(price_min){ where.push('p.price>=?'); params.push(price_min); }
  if(price_max){ where.push('p.price<=?'); params.push(price_max); }
  if(condition){ where.push('p.`condition`=?'); params.push(condition); }
  const offset=(page-1)*limit;
  const [items]=await pool.query(`SELECT p.*, (SELECT path FROM product_images WHERE product_id=p.id ORDER BY sort_order LIMIT 1) AS cover FROM products p WHERE ${where.join(' AND ')} ORDER BY p.created_at DESC LIMIT ? OFFSET ?`,[...params,Number(limit),Number(offset)]);
  const [cnt]=await pool.query(`SELECT COUNT(*) as c FROM products p WHERE ${where.join(' AND ')}`,params);
  return { items, total: cnt[0].c };
}
export async function getProduct(id){ const [r]=await pool.query(`SELECT p.*, (SELECT path FROM product_images WHERE product_id=p.id ORDER BY sort_order LIMIT 1) AS cover FROM products p WHERE p.id=?`,[id]); return r[0]; }
export async function createProduct({seller_id,title,description,price,stock,condition,category_id}){ const [r]=await pool.query('INSERT INTO products (seller_id,title,description,price,stock,`condition`,category_id) VALUES (?,?,?,?,?,?,?)',[seller_id,title,description,price,stock,condition,category_id]); return r.insertId; }
export async function updateProduct(id, ownerUserId, fields){
  const [[s]]=await pool.query('SELECT id FROM sellers WHERE user_id=?',[ownerUserId]); if(!s) return;
  const sets=[]; const params=[];
  for(const k of ['title','description','price','stock','condition','category_id']) if(fields[k]!==undefined){ sets.push(k+'=?'); params.push(fields[k]); }
  if(!sets.length) return;
  params.push(id, s.id);
  await pool.query(`UPDATE products SET ${sets.join(', ')} WHERE id=? AND seller_id=?`, params);
}
export async function deleteProduct(id, ownerUserId){
  const [[s]]=await pool.query('SELECT id FROM sellers WHERE user_id=?',[ownerUserId]); if(!s) return;
  await pool.query('DELETE FROM products WHERE id=? AND seller_id=?',[id,s.id]);
}
export async function addImage(product_id,path,sort_order=0){ await pool.query('INSERT INTO product_images (product_id,path,sort_order) VALUES (?,?,?)',[product_id,path,sort_order]); }
export async function addReport(product_id,user_id,reason){ await pool.query('INSERT INTO product_reports (product_id,user_id,reason) VALUES (?,?,?)',[product_id,user_id,reason]); }
export async function listReviews(product_id){ const [r]=await pool.query('SELECT r.*, u.name as user_name FROM reviews r JOIN users u ON u.id=r.user_id WHERE product_id=? ORDER BY created_at DESC',[product_id]); return r; }
export async function addReview(product_id,user_id,rating,comment){ await pool.query('INSERT INTO reviews (product_id,user_id,rating,comment) VALUES (?,?,?,?)',[product_id,user_id,rating,comment]); }
export async function listSellerProducts(user_id){ const [[s]]=await pool.query('SELECT id FROM sellers WHERE user_id=?',[user_id]); if(!s) return []; const [r]=await pool.query('SELECT p.*, (SELECT path FROM product_images WHERE product_id=p.id ORDER BY sort_order LIMIT 1) AS cover FROM products p WHERE seller_id=? ORDER BY created_at DESC',[s.id]); return r; }
