import { query } from '../config/db.js';

// Save a chat message to the database
export const saveChatMessage = async ({ userId, sessionId, role, content, isVoice = false }) => {
    try {
        const result = await query(
            `INSERT INTO chat_messages 
             (user_id, session_id, role, content, is_voice, created_at)
             VALUES ($1, $2, $3, $4, $5, NOW())
             RETURNING *`,
            [userId, sessionId, role, content, isVoice]
        );
        return result.rows[0];
    } catch (error) {
        console.error('Error saving chat message:', error);
        throw error;
    }
};

// Get chat history for a user and session
export const getChatHistory = async (userId, sessionId, limit = 20) => {
    try {
        const result = await query(
            `SELECT id, role, content, is_voice, created_at
             FROM chat_messages
             WHERE user_id = $1 AND session_id = $2
             ORDER BY created_at ASC
             LIMIT $3`,
            [userId, sessionId, limit]
        );
        return result.rows;
    } catch (error) {
        console.error('Error fetching chat history:', error);
        throw error;
    }
};

// Clear chat history for a session
export const clearChatHistory = async (userId, sessionId) => {
    try {
        await query(
            `DELETE FROM chat_messages 
             WHERE user_id = $1 AND session_id = $2`,
            [userId, sessionId]
        );
        return true;
    } catch (error) {
        console.error('Error clearing chat history:', error);
        throw error;
    }
};

// Get recent sessions for a user
export const getUserSessions = async (userId, limit = 10) => {
    try {
        const result = await query(
            `SELECT DISTINCT session_id, MAX(created_at) as last_activity
             FROM chat_messages
             WHERE user_id = $1
             GROUP BY session_id
             ORDER BY last_activity DESC
             LIMIT $2`,
            [userId, limit]
        );
        return result.rows;
    } catch (error) {
        console.error('Error fetching user sessions:', error);
        throw error;
    }
};
