import pool from '../config/db.js';
import bcrypt from 'bcryptjs';

export const createUser = async (userData) => {
    const { name, email, password, role = 'buyer' } = userData;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const [result] = await pool.query(
        'INSERT INTO users (name, email, password_hash, user_role) VALUES (?, ?, ?, ?)',
        [name, email, hashedPassword, role]
    );
    
    return result.insertId;
};

export const findUserByEmail = async (email) => {
    const [users] = await pool.query(
        'SELECT * FROM users WHERE email = ?',
        [email]
    );
    return users[0];
};

export const findUserById = async (id) => {
    const [users] = await pool.query(
        'SELECT id, name, email, user_role, phone, avatar, email_verified, created_at FROM users WHERE id = ?',
        [id]
    );
    return users[0];
};

export const updateUser = async (id, userData) => {
    const { name, email, password, phone } = userData;
    let queryStr = 'UPDATE users SET name = ?, email = ?';
    const params = [name, email];

    if (phone) {
        queryStr += ', phone = ?';
        params.push(phone);
    }

    if (password) {
        const hashedPassword = await bcrypt.hash(password, 10);
        queryStr += ', password_hash = ?';
        params.push(hashedPassword);
    }

    queryStr += ' WHERE id = ?';
    params.push(id);

    await pool.query(queryStr, params);
};

export const deleteUser = async (id) => {
    await pool.query('DELETE FROM users WHERE id = ?', [id]);
};

export const verifyPassword = async (plainPassword, hashedPassword) => {
    return await bcrypt.compare(plainPassword, hashedPassword);
};