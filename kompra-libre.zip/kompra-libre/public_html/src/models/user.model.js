import pool from '../config/db.js';
import bcrypt from 'bcryptjs';

// Configuración de bcrypt
const SALT_ROUNDS = 10;

/**
 * Crea un nuevo usuario en la base de datos
 */
export const createUser = async (userData) => {
    const { name, email, password, role = 'buyer' } = userData;
    
    try {
        console.log(`Creando usuario: ${email}`);
        const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
        
        const [result] = await pool.query(
            'INSERT INTO users (name, email, password_hash, user_role) VALUES (?, ?, ?, ?)',
            [name, email, hashedPassword, role]
        );
        
        console.log(`Usuario creado con ID: ${result.insertId}`);
        return result.insertId;
    } catch (error) {
        console.error('Error al crear usuario:', error);
        throw new Error('Error al crear el usuario en la base de datos');
    }
};

/**
 * Busca un usuario por su email
 */
export const findUserByEmail = async (email) => {
    try {
        console.log(`Buscando usuario por email: ${email}`);
        const [users] = await pool.query(
            'SELECT * FROM users WHERE email = ?',
            [email]
        );
        
        if (users.length === 0) {
            console.log(`Usuario no encontrado: ${email}`);
            return null;
        }
        
        console.log(`Usuario encontrado: ${users[0].id}`);
        return users[0];
    } catch (error) {
        console.error('Error al buscar usuario por email:', error);
        throw new Error('Error al buscar el usuario');
    }
};

/**
 * Busca un usuario por su ID
 */
export const findUserById = async (id) => {
    try {
        console.log(`Buscando usuario por ID: ${id}`);
        const [users] = await pool.query(
            'SELECT id, name, email, user_role, phone, avatar, email_verified, created_at FROM users WHERE id = ?',
            [id]
        );
        
        if (users.length === 0) {
            console.log(`Usuario con ID ${id} no encontrado`);
            return null;
        }
        
        return users[0];
    } catch (error) {
        console.error('Error al buscar usuario por ID:', error);
        throw new Error('Error al buscar el usuario');
    }
};

/**
 * Actualiza los datos de un usuario
 */
export const updateUser = async (id, userData) => {
    const { name, email, password, phone } = userData;
    
    try {
        console.log(`Actualizando usuario ID: ${id}`);
        let queryStr = 'UPDATE users SET name = ?, email = ?';
        const params = [name, email];

        if (phone) {
            queryStr += ', phone = ?';
            params.push(phone);
        }

        if (password) {
            console.log('Actualizando contraseña del usuario');
            const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
            queryStr += ', password_hash = ?';
            params.push(hashedPassword);
        }

        queryStr += ' WHERE id = ?';
        params.push(id);

        await pool.query(queryStr, params);
        console.log(`Usuario ${id} actualizado correctamente`);
    } catch (error) {
        console.error('Error al actualizar usuario:', error);
        throw new Error('Error al actualizar el usuario');
    }
};

/**
 * Elimina un usuario por su ID
 */
export const deleteUser = async (id) => {
    try {
        console.log(`Eliminando usuario ID: ${id}`);
        await pool.query('DELETE FROM users WHERE id = ?', [id]);
        console.log(`Usuario ${id} eliminado correctamente`);
    } catch (error) {
        console.error('Error al eliminar usuario:', error);
        throw new Error('Error al eliminar el usuario');
    }
};

/**
 * Verifica si una contraseña coincide con el hash almacenado
 */
export const verifyPassword = async (plainPassword, hashedPassword) => {
    try {
        console.log('Verificando contraseña...');
        const isMatch = await bcrypt.compare(plainPassword, hashedPassword);
        console.log('Resultado de verificación:', isMatch);
        return isMatch;
    } catch (error) {
        console.error('Error al verificar la contraseña:', error);
        return false;
    }
};

/**
 * Obtiene las estadísticas del usuario
 */
export const getUserStats = async (userId) => {
    try {
        // Get purchase count
        const [[purchases]] = await pool.query(
            'SELECT COUNT(*) as count FROM orders WHERE user_id = ?',
            [userId]
        );

        // Get sales count (if user is a seller)
        const [[sales]] = await pool.query(
            `SELECT COUNT(DISTINCT o.id) as count 
             FROM orders o 
             JOIN order_items oi ON o.id = oi.order_id 
             JOIN products p ON oi.product_id = p.id 
             WHERE p.user_id = ?`,
            [userId]
        );

        // Get favorites count
        const [[favorites]] = await pool.query(
            'SELECT COUNT(*) as count FROM user_favorites WHERE user_id = ?',
            [userId]
        );

        // Get weekly changes
        const [[purchasesChange]] = await pool.query(
            `SELECT COUNT(*) as count 
             FROM orders 
             WHERE user_id = ? 
             AND created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)`,
            [userId]
        );

        const [[salesChange]] = await pool.query(
            `SELECT COUNT(DISTINCT o.id) as count 
             FROM orders o 
             JOIN order_items oi ON o.id = oi.order_id 
             JOIN products p ON oi.product_id = p.id 
             WHERE p.user_id = ? 
             AND o.created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)`,
            [userId]
        );

        return {
            purchases: purchases.count || 0,
            sales: sales.count || 0,
            favorites: favorites.count || 0,
            purchases_weekly_change: purchasesChange.count || 0,
            sales_weekly_change: salesChange.count || 0
        };
    } catch (error) {
        console.error('Error al obtener estadísticas del usuario:', error);
        // Return zeros if there's an error
        return {
            purchases: 0,
            sales: 0,
            favorites: 0,
            purchases_weekly_change: 0,
            sales_weekly_change: 0
        };
    }
};