// Re-export the query function and testConnection from the config/db.js
import { query, testConnection } from '../config/db.js';

export { query, testConnection };

// This file is a bridge to maintain backward compatibility with existing imports
// while keeping the database configuration in a more standard location (config/)
// You can now import from either:
// - '../models/db' (legacy path)
// - '../config/db' (preferred path)
