import { body } from 'express-validator';

const nameValidator = body('name')
    .trim()
    .notEmpty().withMessage('El nombre es requerido')
    .isLength({ min: 3 }).withMessage('El nombre debe tener al menos 3 caracteres')
    .isLength({ max: 100 }).withMessage('El nombre no puede tener más de 100 caracteres');

const emailValidator = body('email')
    .trim()
    .notEmpty().withMessage('El correo es requerido')
    .isEmail().withMessage('Correo electrónico no válido')
    .normalizeEmail();

const passwordValidator = body('password')
    .notEmpty().withMessage('La contraseña es requerida')
    .isLength({ min: 6 }).withMessage('La contraseña debe tener al menos 6 caracteres')
    .isLength({ max: 100 }).withMessage('La contraseña no puede tener más de 100 caracteres');

export const registerValidator = [
    nameValidator,
    emailValidator,
    passwordValidator
];

export const loginValidator = [
    emailValidator,
    body('password')
        .notEmpty().withMessage('La contraseña es requerida')
];

export const updateProfileValidator = [
    nameValidator,
    emailValidator,
    body('password')
        .optional()
        .isLength({ min: 6 }).withMessage('La contraseña debe tener al menos 6 caracteres')
        .isLength({ max: 100 }).withMessage('La contraseña no puede tener más de 100 caracteres')
];
