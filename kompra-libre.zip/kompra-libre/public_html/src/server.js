import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import cors from 'cors';
import morgan from 'morgan';

// Importar rutas
import authRoutes from './routes/auth.routes.js';
import chatbotRoutes from './routes/chatbot.routes.js';
import paymentRoutes from './routes/payment.routes.js';
import uploadRoutes from './routes/upload.routes.js';
import productRoutes from './routes/product.routes.js';

// Configuración de rutas de archivos
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PUBLIC_DIR = path.join(__dirname, '..');  // Raíz del proyecto (public_html)
const UPLOADS_DIR = path.join(__dirname, '..', 'uploads');

// Crear la aplicación Express
const app = express();

// Configuración CORS
const corsOptions = {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    exposedHeaders: ['set-cookie']
};

// Middlewares básicos
app.use(morgan('dev')); // Logging de peticiones HTTP
app.use(cors(corsOptions));
app.options('*', cors(corsOptions)); // Habilitar preflight para todas las rutas

// Configuración de body parser
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Configuración de cookies
app.use(cookieParser(process.env.COOKIE_SECRET || 'kompra-libre-secret'));

// Middleware para manejar CORS headers
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', corsOptions.origin);
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    res.header('Access-Control-Expose-Headers', 'set-cookie');
    next();
});

// Configuración de archivos estáticos
app.use(express.static(PUBLIC_DIR, {
    etag: true,
    maxAge: '1d',
    setHeaders: (res, path) => {
        // Cachear archivos estáticos por 1 día
        if (path.endsWith('.html')) {
            res.setHeader('Cache-Control', 'no-cache');
        } else {
            res.setHeader('Cache-Control', 'public, max-age=86400');
        }
    }
}));

// Rutas estáticas específicas para asegurar que se sirvan correctamente
app.use('/img', express.static(path.join(PUBLIC_DIR, 'img'), {
    maxAge: '30d',
    setHeaders: (res, path) => {
        res.setHeader('Cache-Control', 'public, max-age=2592000');
    }
}));

app.use('/css', express.static(path.join(PUBLIC_DIR, 'css'), {
    maxAge: '7d'
}));

app.use('/js', express.static(path.join(PUBLIC_DIR, 'js'), {
    maxAge: '7d'
}));

app.use('/includes', express.static(path.join(PUBLIC_DIR, 'includes'), {
    maxAge: '1d'
}));
app.use('/uploads', express.static(UPLOADS_DIR));

// Ruta para la página principal
app.get('/', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// Ruta para archivos en el directorio views
app.get('/views/:file', (req, res) => {
    const file = req.params.file;
    res.sendFile(path.join(PUBLIC_DIR, 'views', file), (err) => {
        if (err) {
            console.error(`Error al cargar el archivo: ${file}`, err);
            res.status(404).send('Página no encontrada');
        }
    });
});

// Ruta de salud para verificar que el servidor está funcionando
app.get('/api/health', (req, res) => {
    res.json({ 
        success: true,
        message: 'Servidor funcionando correctamente',
        timestamp: new Date().toISOString()
    });
});

// Rutas API (deben ir primero)
app.use('/api/auth', authRoutes);
app.use('/api/chat', chatbotRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/products', productRoutes);

// Servir archivos estáticos (CSS, JS, imágenes)
app.use('/css', express.static(path.join(PUBLIC_DIR, 'css')));
app.use('/js', express.static(path.join(PUBLIC_DIR, 'js')));
app.use('/img', express.static(path.join(PUBLIC_DIR, 'img')));
app.use('/includes', express.static(path.join(PUBLIC_DIR, 'includes')));
app.use('/uploads', express.static(UPLOADS_DIR));

// Ruta para la página principal
app.get('/', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// Ruta para archivos en el directorio views
app.get('/views/:file', (req, res) => {
    const file = req.params.file;
    res.sendFile(path.join(PUBLIC_DIR, 'views', file), (err) => {
        if (err) {
            console.error(`Error al cargar el archivo: ${file}`, err);
            res.status(404).send('Página no encontrada');
        }
    });
});

// Ruta para archivos en la raíz (redirigir a /views/ si es necesario)
app.get('/:file', (req, res, next) => {
    const file = req.params.file;
    const filePath = path.join(PUBLIC_DIR, file);
    
    // Verificar si el archivo existe en la raíz
    if (fs.existsSync(filePath) && file.endsWith('.html')) {
        res.sendFile(filePath);
    } else {
        // Si no existe, intentar cargarlo desde /views/
        const viewPath = path.join(PUBLIC_DIR, 'views', file);
        if (fs.existsSync(viewPath)) {
            res.redirect(`/views/${file}`);
        } else {
            next(); // Pasar al manejador de errores
        }
    }
});

// Catch-all para otras páginas HTML
app.get('*.html', (req, res) => {
    const filePath = path.join(PUBLIC_DIR, req.path);
    res.sendFile(filePath, (err) => {
        if (err) {
            // Si no se encuentra en la raíz, intentar en /views/
            const viewPath = path.join(PUBLIC_DIR, 'views', path.basename(req.path));
            res.sendFile(viewPath, (err) => {
                if (err) {
                    console.error('Error al cargar el archivo:', req.path, err);
                    res.status(404).json({ 
                        success: false,
                        message: 'Página no encontrada' 
                    });
                }
            });
        }
    });
});

// Manejo de errores general
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({ 
        success: false,
        message: 'Error interno del servidor',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined,
        stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
    });
});

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📚 Entorno: ${process.env.NODE_ENV || 'development'}`);
    console.log(`💾 Base de datos: ${process.env.DB_NAME}`);
});