import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import cors from 'cors';
import morgan from 'morgan';

// Importar rutas
import authRoutes from './routes/auth.routes.js';
import chatbotRoutes from './routes/chatbot.routes.js';
import paymentRoutes from './routes/payment.routes.js';
import uploadRoutes from './routes/upload.routes.js';
import productRoutes from './routes/product.routes.js';

// Configuración de rutas de archivos
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PUBLIC_DIR = path.join(__dirname, '..');  // Raíz del proyecto (public_html)
const UPLOADS_DIR = path.join(__dirname, '..', 'uploads');

// Crear la aplicación Express
const app = express();

// Middlewares básicos
app.use(morgan('dev')); // Logging de peticiones HTTP
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// Ruta de salud para verificar que el servidor está funcionando
app.get('/api/health', (req, res) => {
    res.json({ 
        success: true,
        message: 'Servidor funcionando correctamente',
        timestamp: new Date().toISOString()
    });
});

// Rutas API (deben ir primero)
app.use('/api/auth', authRoutes);
app.use('/api/chat', chatbotRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/products', productRoutes);

// Servir archivos estáticos (CSS, JS, imágenes)
app.use('/css', express.static(path.join(PUBLIC_DIR, 'css')));
app.use('/js', express.static(path.join(PUBLIC_DIR, 'js')));
app.use('/img', express.static(path.join(PUBLIC_DIR, 'img')));
app.use('/includes', express.static(path.join(PUBLIC_DIR, 'includes')));
app.use('/uploads', express.static(UPLOADS_DIR));

// Rutas de páginas HTML
app.get('/', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

app.get('/login.html', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'login.html'));
});

app.get('/registro.html', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'registro.html'));
});

app.get('/register.html', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'registro.html'));
});

// Catch-all para otras páginas HTML
app.get('*.html', (req, res) => {
    const filePath = path.join(PUBLIC_DIR, req.path);
    res.sendFile(filePath, (err) => {
        if (err) {
            res.status(404).json({ 
                success: false,
                message: 'Página no encontrada' 
            });
        }
    });
});

// Manejo de errores general
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({ 
        success: false,
        message: 'Error interno del servidor',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined,
        stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
    });
});

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📚 Entorno: ${process.env.NODE_ENV || 'development'}`);
    console.log(`💾 Base de datos: ${process.env.DB_NAME}`);
});