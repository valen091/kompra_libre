import { Router } from 'express';
import multer from 'multer';
import { auth, authorize } from '../middlewares/auth.middleware.js';
import { list, get, create, edit, remove, reviews, addReviewCtrl, report, sellerProducts } from '../controllers/product.controller.js';

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'public/img/uploads'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname.replace(/\s+/g, '_'))
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

const router = Router();

// Rutas públicas
router.get('/', list);
router.get('/:id', get);
router.get('/:id/reviews', reviews);

// Rutas protegidas - solo autenticación
router.post('/:id/reviews', auth, addReviewCtrl);
router.post('/:id/report', auth, report);
router.post('/:id/favorite', auth, (req, res) => res.json({ success: true }));

// Rutas protegidas - requieren rol de vendedor
router.post('/', auth, authorize('seller', 'admin'), upload.single('image'), create);
router.put('/:id', auth, authorize('seller', 'admin'), edit);
router.delete('/:id', auth, authorize('seller', 'admin'), remove);
router.get('/me/seller', auth, authorize('seller', 'admin'), sellerProducts);

export default router;
