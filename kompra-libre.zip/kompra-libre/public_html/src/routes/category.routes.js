import { Router } from 'express'; import { categories } from '../controllers/category.controller.js'; const r = Router(); r.get('/', categories); export default r;
