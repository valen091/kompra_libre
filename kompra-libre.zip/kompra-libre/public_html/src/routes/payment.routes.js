import express from 'express';
import { createPreference, webhook, getPaymentStatus } from '../controllers/payment.controller.js';
import { auth } from '../middlewares/auth.middleware.js';

const router = express.Router();

// Ruta para crear una preferencia de pago (protegida)
router.post('/create-preference', auth, createPreference);

// Webhook para recibir notificaciones de Mercado Pago (pública)
router.post('/webhook', webhook);

// Obtener estado de un pago (protegida)
router.get('/status/:payment_id', auth, getPaymentStatus);

export default router;
