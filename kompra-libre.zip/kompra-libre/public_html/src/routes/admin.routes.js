
import { Router } from 'express';
import { requireAuth, requireRole } from '../middlewares/auth.js';
import { dashboard } from '../controllers/admin.controller.js';
const r = Router();
r.get('/dashboard', requireAuth, requireRole('admin'), dashboard);
export default r;
