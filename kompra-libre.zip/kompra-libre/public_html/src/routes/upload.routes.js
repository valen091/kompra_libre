import express from 'express';
import { upload, uploadImage, uploadMultipleImages } from '../controllers/upload.controller.js';
import { auth } from '../middlewares/auth.middleware.js';

const router = express.Router();

// Ruta para subir una sola imagen
router.post('/single', auth, upload.single('image'), uploadImage);

// Ruta para subir múltiples imágenes
router.post('/multiple', auth, upload.array('images', 5), uploadMultipleImages);

export default router;
