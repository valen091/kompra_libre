
import { Router } from 'express';
import { requireAuth } from '../middlewares/auth.js';
import { 
    me, 
    updateProfile, 
    changePassword, 
    favorites, 
    stats 
} from '../controllers/user.controller.js';

const r = Router();

// User profile routes
r.get('/me', requireAuth, me);
r.put('/me', requireAuth, updateProfile);
r.put('/me/password', requireAuth, changePassword);

// User favorites
r.get('/me/favorites', requireAuth, favorites);

// User statistics
r.get('/me/stats', requireAuth, stats);

export default r;
