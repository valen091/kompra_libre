import express from 'express';
import { chatWithAI } from '../controllers/chatbot.controller.js';
import { auth } from '../middlewares/auth.middleware.js';

const router = express.Router();

// Ruta protegida que requiere autenticación
router.post('/', auth, chatWithAI);

export default router;
