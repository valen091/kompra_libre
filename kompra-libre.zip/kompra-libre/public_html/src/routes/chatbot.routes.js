import express from 'express';
import { 
    chatWithAI, 
    startNewChat, 
    getVoiceResponse 
} from '../controllers/chatbot.controller.js';
import { auth } from '../middlewares/auth.middleware.js';

const router = express.Router();

// Start a new chat session
router.post('/start', auth, startNewChat);

// Send a text message to the chatbot
router.post('/message', auth, chatWithAI);

// Convert text to speech
router.post('/speak', auth, getVoiceResponse);

// Get chat history for a session
router.get('/history/:sessionId', auth, async (req, res) => {
    try {
        const { sessionId } = req.params;
        const history = await getChatHistory(req.user.userId, sessionId);
        res.json({ success: true, history });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Error al obtener el historial de chat' 
        });
    }
});

// Clear chat history for a session
router.delete('/clear/:sessionId', auth, async (req, res) => {
    try {
        const { sessionId } = req.params;
        await clearChatHistory(req.user.userId, sessionId);
        res.json({ success: true, message: 'Historial eliminado' });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: 'Error al borrar el historial' 
        });
    }
});

export default router;
