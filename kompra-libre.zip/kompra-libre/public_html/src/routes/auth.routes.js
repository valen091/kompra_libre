import { Router } from 'express';
import { 
    register, 
    login, 
    logout,
    getProfile,
    updateProfile
} from '../controllers/auth.controller.js';
import { auth } from '../middlewares/auth.middleware.js';
import { 
    registerValidator, 
    loginValidator,
    updateProfileValidator
} from '../validators/auth.validator.js';
import { validate } from '../middlewares/validation.middleware.js';

const router = Router();

// Rutas públicas
router.post('/register', validate(registerValidator), register);
router.post('/login', validate(loginValidator), login);

// Rutas protegidas
router.get('/profile', auth, getProfile);
router.put('/profile', auth, validate(updateProfileValidator), updateProfile);
router.post('/logout', auth, logout);

export default router;