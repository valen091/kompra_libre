import jwt from 'jsonwebtoken';
import { createUser, findUserByEmail, findUserById, updateUser, verifyPassword } from '../models/user.model.js';

const generateToken = (userId) => {
    return jwt.sign(
        { userId },
        process.env.JWT_SECRET || 'Kompralibre1',
        { expiresIn: '24h' }
    );
};

export const register = async (req, res) => {
    try {
        const { name, email, password } = req.body;
        
        // Verificar si el usuario ya existe
        const existingUser = await findUserByEmail(email);
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'El correo ya está registrado'
            });
        }

        // Crear nuevo usuario
        const userId = await createUser({ name, email, password });
        
        // Generar token
        const token = generateToken(userId);
        
        // Obtener datos del usuario
        const user = await findUserById(userId);

        res.status(201).json({
            success: true,
            message: 'Usuario registrado exitosamente',
            token,
            user
        });
    } catch (error) {
        console.error('Error en registro:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error al registrar el usuario' 
        });
    }
};

export const login = async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Buscar usuario
        const user = await findUserByEmail(email);
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Credenciales inválidas'
            });
        }

        // Verificar contraseña
        const validPassword = await verifyPassword(password, user.password_hash);
        if (!validPassword) {
            return res.status(401).json({
                success: false,
                message: 'Credenciales inválidas'
            });
        }

        // Generar token
        const token = generateToken(user.id);
        
        // Eliminar contraseña del objeto de respuesta
        const { password_hash, ...userData } = user;

        res.json({
            success: true,
            message: 'Inicio de sesión exitoso',
            token,
            user: userData
        });
    } catch (error) {
        console.error('Error en login:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error al iniciar sesión' 
        });
    }
};

export const getProfile = async (req, res) => {
    try {
        const user = await findUserById(req.user.id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuario no encontrado'
            });
        }

        res.json({
            success: true,
            user
        });
    } catch (error) {
        console.error('Error al obtener perfil:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error al obtener el perfil' 
        });
    }
};

export const updateProfile = async (req, res) => {
    try {
        await updateUser(req.user.id, req.body);
        const user = await findUserById(req.user.id);
        
        res.json({
            success: true,
            message: 'Perfil actualizado exitosamente',
            user
        });
    } catch (error) {
        console.error('Error al actualizar perfil:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error al actualizar el perfil' 
        });
    }
};

export const logout = (req, res) => {
    res.json({
        success: true,
        message: 'Sesión cerrada exitosamente'
    });
};
