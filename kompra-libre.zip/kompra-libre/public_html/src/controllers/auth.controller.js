import jwt from 'jsonwebtoken';
import { createUser, findUserByEmail, findUserById, updateUser, verifyPassword } from '../models/user.model.js';

// Configuración de JWT
const JWT_SECRET = process.env.JWT_SECRET || 'Kompralibre1';
const TOKEN_EXPIRES_IN = '24h';

/**
 * Genera un token JWT para el usuario
 */
const generateToken = (userId, userRole = 'buyer') => {
    return jwt.sign(
        { 
            userId,
            role: userRole,
            iat: Math.floor(Date.now() / 1000),
        },
        JWT_SECRET,
        { expiresIn: TOKEN_EXPIRES_IN }
    );
};

/**
 * Registra un nuevo usuario
 */
export const register = async (req, res) => {
    try {
        const { name, email, password, role = 'buyer' } = req.body;
        
        // Validación de entrada
        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Por favor proporcione nombre, email y contraseña'
            });
        }

        // Validar formato de email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Por favor proporcione un email válido'
            });
        }
        
        // Verificar si el usuario ya existe
        console.log(`Verificando si el usuario ${email} ya existe...`);
        const existingUser = await findUserByEmail(email);
        if (existingUser) {
            console.log(`El usuario ${email} ya está registrado`);
            return res.status(400).json({
                success: false,
                message: 'El correo ya está registrado'
            });
        }

        console.log(`Creando nuevo usuario: ${email}`);
        // Crear nuevo usuario
        const userId = await createUser({ name, email, password, role });
        
        // Generar token
        const token = generateToken(userId, role);
        
        // Obtener datos del usuario
        const user = await findUserById(userId);

        console.log(`Usuario ${userId} registrado exitosamente`);
        res.status(201).json({
            success: true,
            message: 'Usuario registrado exitosamente',
            token,
            user
        });
    } catch (error) {
        console.error('Error en registro:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error al registrar el usuario',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

/**
 * Inicia sesión de un usuario
 */
export const login = async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Validación de entrada
        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Por favor proporcione email y contraseña'
            });
        }

        console.log(`Iniciando sesión para el usuario: ${email}`);
        
        // Buscar usuario
        const user = await findUserByEmail(email);
        if (!user) {
            console.log(`Usuario no encontrado: ${email}`);
            return res.status(401).json({
                success: false,
                message: 'Credenciales inválidas'
            });
        }

        console.log(`Usuario encontrado: ${user.id}, verificando contraseña...`);
        // Verificar contraseña
        const validPassword = await verifyPassword(password, user.password_hash);
        if (!validPassword) {
            console.log(`Contraseña incorrecta para el usuario: ${email}`);
            return res.status(401).json({
                success: false,
                message: 'Credenciales inválidas'
            });
        }

        // Generar token
        const token = generateToken(user.id, user.user_role);
        
        // Eliminar contraseña del objeto de respuesta
        const { password_hash, ...userData } = user;

        console.log(`Inicio de sesión exitoso para el usuario: ${user.id}`);
        res.json({
            success: true,
            message: 'Inicio de sesión exitoso',
            token,
            user: userData
        });
    } catch (error) {
        console.error('Error en login:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error al iniciar sesión',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

export const getProfile = async (req, res) => {
    try {
        const user = await findUserById(req.user.id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuario no encontrado'
            });
        }

        res.json({
            success: true,
            user
        });
    } catch (error) {
        console.error('Error al obtener perfil:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error al obtener el perfil' 
        });
    }
};

export const updateProfile = async (req, res) => {
    try {
        await updateUser(req.user.id, req.body);
        const user = await findUserById(req.user.id);
        
        res.json({
            success: true,
            message: 'Perfil actualizado exitosamente',
            user
        });
    } catch (error) {
        console.error('Error al actualizar perfil:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error al actualizar el perfil' 
        });
    }
};

export const logout = (req, res) => {
    res.json({
        success: true,
        message: 'Sesión cerrada exitosamente'
    });
};
