import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs-extra';
import sharp from 'sharp';

// Configuración de directorios
const uploadDir = path.join(process.cwd(), 'public_html', 'uploads', 'products');
const originalDir = path.join(uploadDir, 'originals');
const thumbnailDir = path.join(uploadDir, 'thumbnails');

// Crear directorios si no existen
fs.ensureDirSync(originalDir);
fs.ensureDirSync(thumbnailDir);

// Configuración de Multer
import multer from 'multer';

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, originalDir);
    },
    filename: (req, file, cb) => {
        const fileExt = path.extname(file.originalname).toLowerCase();
        const fileName = `${uuidv4()}${fileExt}`;
        cb(null, fileName);
    }
});

// Filtro de archivos
const fileFilter = (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|webp/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
        return cb(null, true);
    } else {
        cb(new Error('Solo se permiten imágenes (JPEG, JPG, PNG, WebP)'));
    }
};

export const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // Límite de 5MB
    fileFilter: fileFilter
});

// Función para procesar y guardar la imagen
const processImage = async (file) => {
    try {
        const fileExt = path.extname(file.filename).toLowerCase();
        const fileName = path.basename(file.filename, fileExt);
        const thumbnailPath = path.join(thumbnailDir, `${fileName}${fileExt}`);

        // Crear miniatura con Sharp
        await sharp(file.path)
            .resize(300, 300, {
                fit: 'cover',
                position: 'center'
            })
            .toFile(thumbnailPath);

        // Optimizar la imagen original
        await sharp(file.path)
            .jpeg({ quality: 85, progressive: true })
            .png({ quality: 85, progressive: true })
            .toFile(path.join(originalDir, `${fileName}_optimized${fileExt}`));

        // Reemplazar la imagen original por la optimizada
        await fs.rename(
            path.join(originalDir, `${fileName}_optimized${fileExt}`),
            path.join(originalDir, file.filename)
        );

        return {
            original: `/uploads/products/originals/${file.filename}`,
            thumbnail: `/uploads/products/thumbnails/${file.filename}`
        };
    } catch (error) {
        console.error('Error al procesar la imagen:', error);
        throw new Error('Error al procesar la imagen');
    }
};

// Controlador para subir una imagen
const uploadImage = (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No se ha subido ninguna imagen' });
    }

    processImage(req.file)
        .then((imagePaths) => {
            res.json({
                success: true,
                image: imagePaths.original,
                thumbnail: imagePaths.thumbnail
            });
        })
        .catch((error) => {
            console.error('Error al subir la imagen:', error);
            res.status(500).json({ error: 'Error al procesar la imagen' });
        });
};

// Controlador para subir múltiples imágenes
const uploadMultipleImages = (req, res) => {
    if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'No se han subido imágenes' });
    }

    Promise.all(req.files.map(file => processImage(file)))
        .then(images => {
            res.json({
                success: true,
                images: images.map(img => ({
                    original: img.original,
                    thumbnail: img.thumbnail
                }))
            });
        })
        .catch(error => {
            console.error('Error al subir las imágenes:', error);
            res.status(500).json({ error: 'Error al procesar las imágenes' });
        });
};

export { uploadImage, uploadMultipleImages };

export default {
    upload,
    uploadImage,
    uploadMultipleImages
};
