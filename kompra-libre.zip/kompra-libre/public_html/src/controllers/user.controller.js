
import bcrypt from 'bcryptjs';
import { 
    getMe, 
    updateMe, 
    updatePassword, 
    listFavorites, 
    getUserStats 
} from '../models/user.model.js';

export async function me(req, res) { 
    try {
        const user = await getMe(req.user.id);
        const stats = await getUserStats(req.user.id);
        res.json({ ...user, stats });
    } catch (error) {
        console.error('Error fetching user profile:', error);
        res.status(500).json({ error: 'Error al cargar el perfil' });
    }
}

export async function updateProfile(req, res) { 
    try {
        const { name } = req.body; 
        await updateMe(req.user.id, { name }); 
        res.json({ success: true });
    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'Error al actualizar el perfil' });
    }
}

export async function changePassword(req, res) { 
    try {
        const { password } = req.body; 
        const hash = await bcrypt.hash(password, 10); 
        await updatePassword(req.user.id, hash); 
        res.json({ success: true });
    } catch (error) {
        console.error('Error changing password:', error);
        res.status(500).json({ error: 'Error al cambiar la contraseña' });
    }
}

export async function favorites(req, res) { 
    try {
        const rows = await listFavorites(req.user.id); 
        res.json(rows);
    } catch (error) {
        console.error('Error fetching favorites:', error);
        res.status(500).json({ error: 'Error al cargar los favoritos' });
    }
}

// New endpoint to get user statistics
export async function stats(req, res) {
    try {
        const stats = await getUserStats(req.user.id);
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        console.error('Error fetching user stats:', error);
        res.status(500).json({
            success: false,
            message: 'Error al cargar las estadísticas'
        });
    }
}
