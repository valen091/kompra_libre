import { MercadoPagoConfig, Preference } from 'mercadopago';

// Configurar Mercado Pago con la nueva API
const client = new MercadoPagoConfig({ 
    accessToken: process.env.MP_ACCESS_TOKEN 
});

export const createPreference = async (req, res) => {
    try {
        const { items, payer } = req.body;
        
        // Validar que hay items en el carrito
        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'El carrito está vacío' });
        }

        // Calcular total con IVA (Uruguay tiene 22% de IVA)
        const ivaRate = parseFloat(process.env.STORE_TAX_RATE || 22) / 100;
        const shippingCost = parseFloat(process.env.STORE_SHIPPING_COST || 250);

        // Crear preferencia con configuración para Uruguay
        const preference = {
            items: items.map(item => {
                const unitPrice = parseFloat(item.price);
                const priceWithoutTax = unitPrice / (1 + ivaRate);
                
                return {
                    id: item.id,
                    title: item.title,
                    description: item.description || '',
                    quantity: item.quantity || 1,
                    currency_id: process.env.STORE_CURRENCY || 'UYU',
                    unit_price: priceWithoutTax, // Precio sin IVA
                    picture_url: item.picture_url || ''
                };
            }),
            payer: {
                name: payer?.name || '',
                surname: payer?.surname || '',
                email: payer?.email || '',
                phone: {
                    area_code: '',
                    number: payer?.phone || ''
                },
                address: {
                    zip_code: '',
                    street_name: '',
                    street_number: ''
                }
            },
            back_urls: {
                success: `${process.env.FRONTEND_URL}/pago-exitoso`,
                failure: `${process.env.FRONTEND_URL}/pago-rechazado`,
                pending: `${process.env.FRONTEND_URL}/pago-pendiente`
            },
            auto_return: 'approved',
            notification_url: process.env.MP_WEBHOOK_URL,
            external_reference: req.user?.id || 'guest',
            statement_descriptor: 'KOMPRA LIBRE',
            payment_methods: {
                installments: 12, // Hasta 12 cuotas
                excluded_payment_methods: [
                    {id: 'amex'}, // No aceptamos American Express en Uruguay
                ],
                excluded_payment_types: [],
                installments: 12, // Hasta 12 cuotas
                default_installments: 1
            },
            additional_info: {
                items: items.map(item => ({
                    id: item.id,
                    title: item.title,
                    description: item.description || '',
                    quantity: item.quantity || 1,
                    unit_price: parseFloat(item.price)
                })),
                payer: {
                    first_name: payer?.name?.split(' ')[0] || '',
                    last_name: payer?.name?.split(' ').slice(1).join(' ') || '',
                    phone: {
                        area_code: '',
                        number: payer?.phone || ''
                    },
                    address: {
                        zip_code: payer?.postal_code || '',
                        street_name: payer?.address || '',
                        street_number: payer?.address_number || 'S/N'
                    },
                    registration_date: new Date().toISOString()
                },
                shipments: {
                    receiver_address: {
                        zip_code: payer?.postal_code || '',
                        street_name: payer?.address || '',
                        street_number: payer?.address_number || 'S/N',
                        floor: '',
                        apartment: '',
                        city_name: payer?.city || 'Montevideo',
                        state_name: payer?.state || 'Montevideo',
                        country_name: 'Uruguay'
                    }
                }
            },
            metadata: {
                store: 'Kompralibre UY',
                platform: 'ecommerce',
                version: '1.0',
                environment: process.env.NODE_ENV || 'development'
            }
        };

        const preferenceClient = new Preference(client);
        const response = await preferenceClient.create({ body: preference });
        
        res.json({
            success: true,
            id: response.id,
            init_point: response.init_point,
            sandbox_init_point: response.sandbox_init_point
        });

    } catch (error) {
        console.error('Error al crear preferencia de pago:', error);
        res.status(500).json({ error: 'Error al procesar el pago' });
    }
};

export const webhook = async (req, res) => {
    try {
        if (req.method === 'POST') {
            const paymentId = req.query.id || req.body.data?.id;
            
            if (!paymentId) {
                return res.status(400).json({ error: 'Payment ID no proporcionado' });
            }
            
            // Aquí puedes actualizar tu base de datos con el estado del pago
            console.log('Webhook recibido:', {
                paymentId,
                type: req.body.type,
                action: req.body.action
            });

            // Responder a Mercado Pago
            res.status(200).json({ success: true, received: true });
        } else {
            res.status(405).json({ error: 'Método no permitido' });
        }
    } catch (error) {
        console.error('Error en webhook:', error);
        res.status(500).json({ error: 'Error al procesar el webhook' });
    }
};

export const getPaymentStatus = async (req, res) => {
    try {
        const { payment_id } = req.params;
        
        // Nota: Necesitarías implementar la obtención de pagos con la nueva API
        // Por ahora, devolvemos un mensaje indicando que la funcionalidad está en desarrollo
        res.json({ 
            success: true,
            message: 'Función en desarrollo',
            payment_id 
        });
    } catch (error) {
        console.error('Error al obtener estado del pago:', error);
        res.status(500).json({ error: 'Error al obtener el estado del pago' });
    }
};
