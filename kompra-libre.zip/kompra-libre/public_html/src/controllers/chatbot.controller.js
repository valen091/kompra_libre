import OpenAI from 'openai';

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

export const chatWithAI = async (req, res) => {
    try {
        const { message } = req.body;
        
        if (!message) {
            return res.status(400).json({ 
                success: false,
                message: 'El mensaje es requerido' 
            });
        }

        const completion = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
                {
                    role: "system",
                    content: "Eres Felix, un asistente virtual de Kompra Libre. Ayudas a los usuarios con preguntas sobre productos, seguimiento de pedidos y soporte general. Sé amable, conciso y profesional. Si no sabes la respuesta, ofrece contactar con el soporte."
                },
                {
                    role: "user",
                    content: message
                }
            ],
            temperature: 0.7,
            max_tokens: 150
        });

        const reply = completion.choices[0].message.content;
        
        res.json({ 
            success: true,
            reply 
        });
    } catch (error) {
        console.error('Error en el chatbot:', error);
        res.status(500).json({ 
            success: false,
            message: 'Error al procesar tu solicitud',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};
