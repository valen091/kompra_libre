import OpenAI from 'openai';
import { saveChatMessage, getChatHistory, clearChatHistory } from '../models/chatbot.model.js';
import { findUserById } from '../models/user.model.js';

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

// System prompt for the chatbot
const SYSTEM_PROMPT = `Eres Fénix, el asistente virtual de Kompra Libre. 
- Ayudas a los usuarios con preguntas sobre productos, seguimiento de pedidos y soporte general.
- Sé amable, conciso y profesional.
- Si no sabes la respuesta, ofrece contactar con el soporte.
- Usa el contexto proporcionado para dar respuestas personalizadas.`;

// Maximum tokens for the conversation history
const MAX_HISTORY_TOKENS = 1000;

// Clean and validate message text
const cleanMessage = (text) => {
    if (!text) return '';
    return text.trim().substring(0, 1000); // Limit message length
};

// Get conversation history with token limit
const getFormattedHistory = (history, maxTokens = MAX_HISTORY_TOKENS) => {
    let tokens = 0;
    const result = [];
    
    // Add system message first
    result.push({ role: 'system', content: SYSTEM_PROMPT });
    
    // Add history in reverse (newest first) until we reach token limit
    for (let i = history.length - 1; i >= 0; i--) {
        const msg = history[i];
        const messageTokens = msg.content ? msg.content.length / 4 : 0; // Rough estimate
        
        if (tokens + messageTokens > maxTokens) break;
        
        result.unshift({
            role: msg.role,
            content: cleanMessage(msg.content)
        });
        
        tokens += messageTokens;
    }
    
    return result;
};

export const chatWithAI = async (req, res) => {
    const { userId } = req.user;
    const { message, isVoice = false, sessionId } = req.body;
    const cleanedMessage = cleanMessage(message);
    
    if (!cleanedMessage) {
        return res.status(400).json({ 
            success: false,
            message: 'El mensaje es requerido' 
        });
    }

    try {
        // Get user data for context
        const user = await findUserById(userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuario no encontrado'
            });
        }

        // Save user message to database
        const userMessage = await saveChatMessage({
            userId,
            sessionId,
            role: 'user',
            content: cleanedMessage,
            isVoice
        });

        // Get conversation history
        const history = await getChatHistory(userId, sessionId);
        const messages = getFormattedHistory(history);
        
        // Add the new user message
        messages.push({
            role: 'user',
            content: cleanedMessage
        });

        // Get AI response
        const completion = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages,
            temperature: 0.7,
            max_tokens: 250
        });

        const aiReply = completion.choices[0].message.content;
        
        // Save AI response to database
        await saveChatMessage({
            userId,
            sessionId,
            role: 'assistant',
            content: aiReply,
            isVoice
        });

        res.json({ 
            success: true,
            reply: aiReply,
            sessionId
        });

    } catch (error) {
        console.error('Error en el chatbot:', error);
        res.status(500).json({ 
            success: false,
            message: 'Error al procesar tu solicitud',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

export const startNewChat = async (req, res) => {
    const { userId } = req.user;
    
    try {
        const sessionId = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        res.json({
            success: true,
            sessionId,
            message: 'Nueva conversación iniciada'
        });
    } catch (error) {
        console.error('Error al iniciar nueva conversación:', error);
        res.status(500).json({
            success: false,
            message: 'Error al iniciar una nueva conversación'
        });
    }
};

export const getVoiceResponse = async (req, res) => {
    const { text } = req.body;
    
    if (!text) {
        return res.status(400).json({
            success: false,
            message: 'El texto es requerido para la conversión de voz'
        });
    }
    
    try {
        // Use OpenAI's text-to-speech API or another TTS service
        const mp3 = await openai.audio.speech.create({
            model: "tts-1",
            voice: "alloy",
            input: text,
        });
        
        // Convert the response to a base64 string
        const buffer = Buffer.from(await mp3.arrayBuffer());
        const base64Audio = buffer.toString('base64');
        
        res.json({
            success: true,
            audio: `data:audio/mp3;base64,${base64Audio}`
        });
    } catch (error) {
        console.error('Error en la generación de voz:', error);
        res.status(500).json({
            success: false,
            message: 'Error al generar la respuesta de voz'
        });
    }
};
