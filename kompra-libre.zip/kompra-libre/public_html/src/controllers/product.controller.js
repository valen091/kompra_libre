
import { queryProducts, getProduct, createProduct, deleteProduct, updateProduct, addImage, addReport, listReviews, addReview, listSellerProducts } from '../models/product.model.js';
import { pool } from '../config/db.js';
export async function list(req,res){ const { q, category, price_min, price_max, condition, page=1, limit=12 } = req.query; const data = await queryProducts({ q, category, price_min, price_max, condition, page:Number(page), limit:Number(limit) }); res.json({ ...data, page:Number(page) }); }
export async function get(req,res){ const p = await getProduct(req.params.id); if(!p) return res.status(404).json({error:'No encontrado'}); res.json(p); }
export async function create(req,res){ const user_id=req.user.id; const [[seller]] = await pool.query('SELECT id FROM sellers WHERE user_id=?',[user_id]); if(!seller) return res.status(403).json({error:'No seller'}); const { title, description='', price=0, stock=0, condition='nuevo', category_id=null } = req.body; const id = await createProduct({ seller_id:seller.id, title, description, price, stock, condition, category_id }); if(req.file){ await addImage(id, '/img/uploads/'+req.file.filename, 0); } res.json({ id }); }
export async function edit(req,res){ await updateProduct(req.params.id, req.user.id, req.body); res.json({ ok:true }); }
export async function remove(req,res){ await deleteProduct(req.params.id, req.user.id); res.json({ ok:true }); }
export async function reviews(req,res){ const rows = await listReviews(req.params.id); res.json(rows); }
export async function addReviewCtrl(req,res){ const { rating, comment } = req.body; await addReview(req.params.id, req.user.id, rating, comment||''); res.json({ ok:true }); }
export async function report(req,res){ const { reason } = req.body; await addReport(req.params.id, req.user.id, reason||'Categoría incorrecta'); res.json({ ok:true }); }
export async function sellerProducts(req,res){ const rows = await listSellerProducts(req.user.id); res.json(rows); }
