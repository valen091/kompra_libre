import jwt from 'jsonwebtoken';
import { findUserById } from '../models/user.model.js';

export const auth = async (req, res, next) => {
    try {
        // Obtener el token del header
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ 
                success: false,
                message: 'Acceso denegado. No se proporcionó token.' 
            });
        }

        const token = authHeader.split(' ')[1];
        
        // Verificar el token
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'Kompralibre1');
        
        // Buscar usuario
        const user = await findUserById(decoded.userId);
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Usuario no encontrado'
            });
        }

        // Añadir usuario al objeto request
        req.user = user;
        next();
    } catch (error) {
        console.error('Error en autenticación:', error);
        
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Sesión expirada. Por favor, inicia sesión de nuevo.'
            });
        }

        res.status(401).json({
            success: false,
            message: 'Token inválido o expirado'
        });
    }
};

// Middleware para verificar roles
export const authorize = (...roles) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: 'No autorizado'
            });
        }

        if (roles.length && !roles.includes(req.user.user_role)) {
            return res.status(403).json({
                success: false,
                message: 'No tienes permiso para realizar esta acción'
            });
        }

        next();
    };
};

// Middleware específico para verificar rol de administrador
export const isAdmin = authorize('admin');