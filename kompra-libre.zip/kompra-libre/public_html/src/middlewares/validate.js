import { validationResult } from 'express-validator';
export const validate = (rules) => [
  ...rules,
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ message: 'Datos inválidos', errors: errors.array() });
    next();
  },
];
