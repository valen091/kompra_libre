import { validationResult } from 'express-validator';

export const validate = (validations) => {
    return async (req, res, next) => {
        // Ejecutar todas las validaciones
        for (let validation of validations) {
            const result = await validation.run(req);
            if (result.errors.length) break;
        }

        const errors = validationResult(req);
        if (errors.isEmpty()) {
            return next();
        }

        res.status(400).json({
            success: false,
            message: 'Error de validación',
            errors: errors.array()
        });
    };
};
