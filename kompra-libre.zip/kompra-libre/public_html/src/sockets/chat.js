
import { pool } from '../config/db.js';
export function initChat(io){
  io.on('connection', (socket)=>{
    socket.on('message:new', async (msg)=>{
      await pool.query('INSERT INTO messages (product_id,order_id,from_user_id,to_user_id,body) VALUES (?,?,?,?,?)',[msg.product_id||null,msg.order_id||null,msg.from,msg.to,msg.body]);
      io.to(String(msg.to)).emit('message:new', msg);
    });
    socket.on('auth', (userId)=>{ socket.join(String(userId)); });
  });
}
