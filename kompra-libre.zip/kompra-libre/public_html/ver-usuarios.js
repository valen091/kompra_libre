﻿/**
 * Script para ver todos los usuarios registrados en la base de datos
 */

import pool from './src/config/db.js';

async function verUsuarios() {
    try {
        console.log('\n📋 Usuarios registrados en la base de datos:\n');
        console.log('═'.repeat(100));
        
        const [users] = await pool.query(`
            SELECT 
                id,
                name,
                email,
                user_role,
                phone,
                email_verified,
                created_at,
                updated_at
            FROM users
            ORDER BY created_at DESC
        `);

        if (users.length === 0) {
            console.log('❌ No hay usuarios registrados todavía.\n');
            return;
        }

        console.log(`\n✅ Total de usuarios: ${users.length}\n`);

        users.forEach((user, index) => {
            console.log(`\n${index + 1}. Usuario #${user.id}`);
            console.log('─'.repeat(50));
            console.log(`   👤 Nombre:          ${user.name}`);
            console.log(`   📧 Email:           ${user.email}`);
            console.log(`   🏷️  Rol:             ${user.user_role}`);
            console.log(`   📱 Teléfono:        ${user.phone || 'No especificado'}`);
            console.log(`   ✉️  Email verificado: ${user.email_verified ? 'Sí' : 'No'}`);
            console.log(`   📅 Creado:          ${new Date(user.created_at).toLocaleString('es-UY')}`);
            console.log(`   🔄 Actualizado:     ${new Date(user.updated_at).toLocaleString('es-UY')}`);
        });

        console.log('\n' + '═'.repeat(100) + '\n');

        // Estadísticas
        const buyers = users.filter(u => u.user_role === 'buyer').length;
        const sellers = users.filter(u => u.user_role === 'seller').length;
        const admins = users.filter(u => u.user_role === 'admin').length;

        console.log('📊 Estadísticas:');
        console.log(`   🛒 Compradores: ${buyers}`);
        console.log(`   🏪 Vendedores:  ${sellers}`);
        console.log(`   👑 Admins:      ${admins}`);
        console.log('');

    } catch (error) {
        console.error('❌ Error al consultar usuarios:', error.message);
    } finally {
        process.exit(0);
    }
}

// Ejecutar
verUsuarios();
