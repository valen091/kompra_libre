const { testConnection } = require('./config/db');

async function runTest() {
  console.log('🔍 Probando conexión a la base de datos...');
  const isConnected = await testConnection();
  
  if (isConnected) {
    console.log('✅ ¡Conexión exitosa a la base de datos!');
    
    // Ejemplo de consulta a la tabla de usuarios
    try {
      const { query } = require('./config/db');
      const result = await query('SELECT * FROM usuarios LIMIT 1');
      console.log('📋 Datos de ejemplo de la tabla usuarios:');
      console.log(result.rows[0] || 'No se encontraron usuarios');
    } catch (error) {
      console.error('❌ Error al realizar la consulta:', error.message);
    }
  } else {
    console.error('❌ No se pudo conectar a la base de datos');
    console.log('🔧 Por favor, verifica lo siguiente:');
    console.log('1. Que PostgreSQL esté instalado y en ejecución');
    console.log('2. Que las credenciales en .env sean correctas');
    console.log('3. Que la base de datos exista y tengas los permisos necesarios');
  }
}

runTest();
