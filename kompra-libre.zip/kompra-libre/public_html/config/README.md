# 📁 config/ - Archivos de Configuración

Este directorio contiene todos los archivos de configuración del proyecto Kompra Libre.

## 📋 Contenido

### 🔧 Configuración del Servidor
- **`.htaccess`** - Reglas de reescritura URL y configuración de Apache
- **`.env`** - Variables de entorno y configuración sensible
- **`Procfile`** - Configuración de procesos para despliegue

### 📦 Configuración de Dependencias
- **`package.json`** - Dependencias y scripts de Node.js
- **`package-lock.json`** - Lock de versiones exactas de paquetes
- **`npm`** - Script de instalación de npm (generado)

### 🎨 Configuración de Frontend
- **`tailwind.config.js`** - Configuración de Tailwind CSS
- **`postcss.config.js`** - Configuración de PostCSS

### 🚀 Configuración de Despliegue
- **`netlify.toml`** - Configuración específica para Netlify
- **`railway.toml`** - Configuración específica para Railway

### 📝 Configuración de Git
- **`.gitignore`** - Archivos y directorios a ignorar por Git

## 🔍 Uso

- **Para desarrollo**: Revisa `.env` para variables de entorno
- **Para despliegue**: Configura `netlify.toml` o `railway.toml` según la plataforma
- **Para dependencias**: Ejecuta `npm install` desde el directorio padre
- **Para Git**: El `.gitignore` ya está configurado para ignorar archivos sensibles

## ⚠️ Importante

- **No** commits `.env` con datos reales de producción
- **Revisa** `.gitignore` antes de hacer commits
- **Actualiza** las URLs en `.htaccess` según tu dominio

## 📁 Estructura Padre

```
📦 kompra-libre/
└── 📂 public_html/
    ├── 📂 config/          ← Estás aquí
    ├── 📂 docs/
    ├── 📂 setup/
    ├── 📂 pages/
    ├── 📂 tests/
    └── ... (otros directorios)
```
