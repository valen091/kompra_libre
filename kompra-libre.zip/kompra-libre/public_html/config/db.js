const { Pool } = require('pg');
require('dotenv').config();

// Configuración de la base de datos PostgreSQL
const pool = new Pool({
  user: process.env.DB_USER || 'postgres',       // Usuario de PostgreSQL
  host: process.env.DB_HOST || 'localhost',      // Host de la base de datos
  database: process.env.DB_NAME || 'kompra_libre', // Nombre de la base de datos
  password: process.env.DB_PASSWORD || 'tu_contraseña', // Tu contraseña de PostgreSQL
  port: process.env.DB_PORT || 5432,             // Puerto de PostgreSQL (por defecto 5432)
});

// Probar la conexión a la base de datos
const testConnection = async () => {
  try {
    const client = await pool.connect();
    console.log('✅ Conexión exitosa a PostgreSQL');
    client.release();
    return true;
  } catch (error) {
    console.error('❌ Error al conectar a PostgreSQL:', error.message);
    return false;
  }
};

// Ejecutar prueba de conexión al cargar el módulo
testConnection();

module.exports = {
  query: (text, params) => pool.query(text, params),
  getClient: () => pool.connect(),
  testConnection
};
