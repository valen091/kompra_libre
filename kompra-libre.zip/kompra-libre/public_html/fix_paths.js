const fs = require('fs');
const path = require('path');

const publicDir = path.join(__dirname, 'public_html');
const viewsDir = path.join(publicDir, 'views');

// List of HTML files to update
const htmlFiles = [
    'views/registro.html',
    'views/login.html',
    'views/carrito.html',
    'views/mi-cuenta.html',
    'views/mis-compras.html',
    'views/panel-admin.html',
    'views/panel-usuario.html',
    'views/panel-vendedor.html'
];

// Patterns to replace
const replacements = [
    { from: 'src="/assets/img/', to: 'src="/img/' },
    { from: 'src="assets/img/', to: 'src="/img/' },
    { from: 'href="index.html"', to: 'href="/"' },
    { from: 'href="login.html"', to: 'href="/views/login.html"' },
    { from: 'href="registro.html"', to: 'href="/views/registro.html"' },
    { from: 'href="carrito.html"', to: 'href="/views/carrito.html"' },
    { from: 'href="mi-cuenta.html"', to: 'href="/views/mi-cuenta.html"' },
    { from: 'href="mis-compras.html"', to: 'href="/views/mis-compras.html"' },
];

// Process each HTML file
htmlFiles.forEach(file => {
    const filePath = path.join(publicDir, file);
    
    if (fs.existsSync(filePath)) {
        let content = fs.readFileSync(filePath, 'utf8');
        let updated = false;
        
        replacements.forEach(({ from, to }) => {
            if (content.includes(from)) {
                const regex = new RegExp(from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
                content = content.replace(regex, to);
                updated = true;
            }
        });
        
        if (updated) {
            fs.writeFileSync(filePath, content, 'utf8');
            console.log(`✅ Updated paths in ${file}`);
        } else {
            console.log(`ℹ️  No changes needed for ${file}`);
        }
    } else {
        console.log(`⚠️  File not found: ${filePath}`);
    }
});

console.log('\n🎉 Path updates completed!');
