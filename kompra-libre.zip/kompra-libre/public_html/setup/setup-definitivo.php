<?php
// SETUP DEFINITIVO - Funciona en CUALQUIER versión de MySQL/MariaDB
// Sin subconsultas, sin INSERT IGNORE, solo INSERTs básicos

header('Content-Type: application/json');

$startTime = microtime(true);

try {
    // Configuraciones a probar (agregando más opciones)
    $credentials = [
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
    ];

    $pdo = null;
    $connectionInfo = '';

    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};dbname={$cred['db']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $connectionInfo = "{$cred['user']}@{$cred['host']}/{$cred['db']}";
            break;
        } catch (Exception $e) {
            continue;
        }
    }

    if (!$pdo) {
        throw new Exception("No se pudo conectar con ninguna configuración de base de datos");
    }

    $response = [
        'success' => true,
        'connection' => $connectionInfo,
        'steps' => [],
        'start_time' => date('Y-m-d H:i:s')
    ];

    // PASO 1: Limpiar datos anteriores
    $response['steps'][] = ['step' => 1, 'action' => 'Limpiando datos anteriores', 'status' => 'in_progress'];
    try {
        $pdo->exec("DELETE FROM products WHERE title LIKE 'iPhone%' OR title LIKE 'MacBook%' OR title LIKE 'Camiseta%' OR title LIKE 'Juego%' OR title LIKE 'Balón%' OR title LIKE 'Clean%' OR title LIKE 'Auriculares%' OR title LIKE 'Zapatillas%' OR title LIKE 'Lámpara%' OR title LIKE 'Chaqueta%'");
        $pdo->exec("DELETE FROM categories WHERE name IN ('Electrónica', 'Ropa', 'Hogar', 'Deportes', 'Libros')");
        $pdo->exec("DELETE FROM sellers WHERE shop_alias = 'Tienda Demo'");
        $pdo->exec("DELETE FROM users WHERE email = 'demo@kompralibre.shop'");
        $response['steps'][0]['status'] = 'completed';
    } catch (Exception $e) {
        $response['steps'][0]['status'] = 'error';
        $response['steps'][0]['error'] = $e->getMessage();
    }

    // PASO 2: Crear usuario demo
    $response['steps'][] = ['step' => 2, 'action' => 'Creando usuario demo', 'status' => 'in_progress'];
    try {
        $demoPassword = password_hash('demo123', PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '{$demoPassword}', 'seller')");
        $userId = $pdo->lastInsertId();
        $response['steps'][1]['user_id'] = $userId;
        $response['steps'][1]['status'] = 'completed';
    } catch (Exception $e) {
        $response['steps'][1]['status'] = 'error';
        $response['steps'][1]['error'] = $e->getMessage();
    }

    // PASO 3: Crear categorías y guardar IDs
    $response['steps'][] = ['step' => 3, 'action' => 'Creando categorías', 'status' => 'in_progress'];
    $categories = [];
    try {
        $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Electrónica', 'electronica')");
        $categories['Electrónica'] = $pdo->lastInsertId();

        $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Ropa', 'ropa')");
        $categories['Ropa'] = $pdo->lastInsertId();

        $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Hogar', 'hogar')");
        $categories['Hogar'] = $pdo->lastInsertId();

        $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Deportes', 'deportes')");
        $categories['Deportes'] = $pdo->lastInsertId();

        $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Libros', 'libros')");
        $categories['Libros'] = $pdo->lastInsertId();

        $response['steps'][2]['categories'] = $categories;
        $response['steps'][2]['status'] = 'completed';
    } catch (Exception $e) {
        $response['steps'][2]['status'] = 'error';
        $response['steps'][2]['error'] = $e->getMessage();
    }

    // PASO 4: Crear vendedor
    $response['steps'][] = ['step' => 4, 'action' => 'Creando vendedor', 'status' => 'in_progress'];
    try {
        $pdo->exec("INSERT INTO sellers (user_id, shop_alias) VALUES ({$userId}, 'Tienda Demo')");
        $response['steps'][3]['status'] = 'completed';
    } catch (Exception $e) {
        $response['steps'][3]['status'] = 'error';
        $response['steps'][3]['error'] = $e->getMessage();
    }

    // PASO 5: Insertar productos uno por uno
    $response['steps'][] = ['step' => 5, 'action' => 'Insertando productos', 'status' => 'in_progress'];
    $productos = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 'Electrónica', 'nuevo'],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 'Electrónica', 'nuevo'],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 'Ropa', 'nuevo'],
        ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 'Hogar', 'nuevo'],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 'Deportes', 'nuevo'],
        ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 'Libros', 'usado'],
        ['Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 'Electrónica', 'nuevo'],
        ['Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, 'Deportes', 'nuevo'],
        ['Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 'Hogar', 'nuevo'],
        ['Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, 'Ropa', 'nuevo']
    ];

    $productosInsertados = [];
    try {
        foreach ($productos as $producto) {
            $categoryId = $categories[$producto[3]];
            $pdo->exec("INSERT INTO products (title, description, price, stock, condition, category_id, visible) VALUES ('{$producto[0]}', '{$producto[1]}', {$producto[2]}, 10, '{$producto[4]}', {$categoryId}, 1)");
            $productosInsertados[] = $producto[0];
        }
        $response['steps'][4]['products_inserted'] = $productosInsertados;
        $response['steps'][4]['status'] = 'completed';
    } catch (Exception $e) {
        $response['steps'][4]['status'] = 'error';
        $response['steps'][4]['error'] = $e->getMessage();
    }

    // PASO 6: Verificar resultados
    $response['steps'][] = ['step' => 6, 'action' => 'Verificando resultados', 'status' => 'in_progress'];
    try {
        $finalStats = [
            'users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
            'categories' => $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn(),
            'products' => $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn(),
            'sellers' => $pdo->query("SELECT COUNT(*) FROM sellers")->fetchColumn()
        ];
        $response['steps'][5]['final_stats'] = $finalStats;
        $response['steps'][5]['status'] = 'completed';
    } catch (Exception $e) {
        $response['steps'][5]['status'] = 'error';
        $response['steps'][5]['error'] = $e->getMessage();
    }

    // RESULTADO FINAL
    $endTime = microtime(true);
    $executionTime = round($endTime - $startTime, 2);

    $response['execution_time'] = $executionTime;
    $response['user_credentials'] = [
        'email' => 'demo@kompralibre.shop',
        'password' => 'demo123',
        'role' => 'seller'
    ];

    $response['message'] = '✅ Setup completado exitosamente en ' . $executionTime . ' segundos';
    $response['products_added'] = count($productosInsertados);
    $response['timestamp'] = date('Y-m-d H:i:s');

    echo json_encode($response, JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s'),
        'troubleshooting' => [
            '1. Verifica que la base de datos existe',
            '2. Verifica las credenciales de conexión',
            '3. Verifica que las tablas están creadas',
            '4. Usa el script SQL manual en PHPMyAdmin',
            '5. Contacta al soporte técnico'
        ]
    ], JSON_PRETTY_PRINT);
}
?>
