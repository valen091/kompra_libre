<?php
header('Content-Type: application/json');
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

try {
    $db = getDB();

    // Crear usuario vendedor de prueba si no existe
    $db->prepare("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', ?, 'seller')")->execute([password_hash('demo123', PASSWORD_DEFAULT)]);
    
    // Obtener ID del usuario demo
    $stmt = $db->query("SELECT id FROM users WHERE email = 'demo@kompralibre.shop'");
    $demoUser = $stmt->fetch();
    $demoUserId = $demoUser['id'];
    
    // Crear vendedor de prueba si no existe
    $db->prepare("INSERT IGNORE INTO sellers (user_id, shop_alias) VALUES (?, 'Tienda Demo')")->execute([$demoUserId]);

    // Insertar categorías de ejemplo
    $categories = [
        ['name' => 'Electrónica', 'slug' => 'electronica'],
        ['name' => 'Ropa', 'slug' => 'ropa'],
        ['name' => 'Hogar', 'slug' => 'hogar'],
        ['name' => 'Deportes', 'slug' => 'deportes'],
        ['name' => 'Libros', 'slug' => 'libros']
    ];

    foreach ($categories as $cat) {
        $db->prepare("INSERT IGNORE INTO categories (name, slug) VALUES (?, ?)")
           ->execute([$cat['name'], $cat['slug']]);
    }

    // Insertar productos de ejemplo
    $products = [
        [
            'title' => 'iPhone 15 Pro Max',
            'description' => 'El iPhone más avanzado con cámara profesional y chip A17 Pro.',
            'price' => 1299.99,
            'stock' => 10,
            'condition' => 'nuevo',
            'category' => 'Electrónica'
        ],
        [
            'title' => 'MacBook Air M3',
            'description' => 'Laptop ultraligera con chip M3 y hasta 18 horas de batería.',
            'price' => 1099.99,
            'stock' => 5,
            'condition' => 'nuevo',
            'category' => 'Electrónica'
        ],
        [
            'title' => 'Camiseta Deportiva Nike',
            'description' => 'Camiseta transpirable ideal para entrenamientos.',
            'price' => 29.99,
            'stock' => 20,
            'condition' => 'nuevo',
            'category' => 'Ropa'
        ],
        [
            'title' => 'Juego de Sartenes Antiaderentes',
            'description' => 'Set de 3 sartenes con recubrimiento antiadherente.',
            'price' => 89.99,
            'stock' => 15,
            'condition' => 'nuevo',
            'category' => 'Hogar'
        ],
        [
            'title' => 'Balón de Fútbol Adidas',
            'description' => 'Balón oficial tamaño 5 para partidos profesionales.',
            'price' => 39.99,
            'stock' => 8,
            'condition' => 'nuevo',
            'category' => 'Deportes'
        ],
        [
            'title' => 'Clean Code - Robert C. Martin',
            'description' => 'Libro fundamental sobre buenas prácticas de programación.',
            'price' => 49.99,
            'stock' => 12,
            'condition' => 'usado',
            'category' => 'Libros'
        ]
    ];

    foreach ($products as $product) {
        // Obtener ID de categoría
        $stmt = $db->prepare("SELECT id FROM categories WHERE name = ?");
        $stmt->execute([$product['category']]);
        $category = $stmt->fetch();

        if ($category) {
            // Insertar producto
            $stmt = $db->prepare("INSERT INTO products (title, description, price, stock, condition, category_id, visible) VALUES (?, ?, ?, ?, ?, ?, 1)");
            $stmt->execute([$product['title'], $product['description'], $product['price'], $product['stock'], $product['condition'], $category['id']]);
        }
    }

    echo json_encode([
        'success' => true,
        'message' => 'Datos de prueba insertados correctamente',
        'categories_added' => count($categories),
        'products_added' => count($products),
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}
?>
