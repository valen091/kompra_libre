<?php
header('Content-Type: application/json');

try {
    $db = new PDO("mysql:host=localhost;dbname=u472738607_kompra_libre", "u472738607_kompra_libre", "Kompralibre1");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Insertar todo de una vez
    $db->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '" . password_hash('demo123', PASSWORD_DEFAULT) . "', 'seller')");

    $db->exec("INSERT IGNORE INTO categories (name, slug) VALUES
        ('Electrónica', 'electronica'),
        ('Ropa', 'ropa'),
        ('Hogar', 'hogar'),
        ('Deportes', 'deportes'),
        ('Libros', 'libros')");

    $db->exec("INSERT IGNORE INTO sellers (user_id, shop_alias) SELECT id, 'Tienda Demo' FROM users WHERE email = 'demo@kompralibre.shop'");

    // Insertar productos usando subconsultas
    $db->exec("INSERT IGNORE INTO products (title, description, price, stock, condition, category_id, visible) VALUES
        ('iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional y chip A17 Pro', 1299.99, 10, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Electrónica'), 1),

        ('MacBook Air M3', 'Laptop ultraligera con chip M3 y hasta 18 horas de batería', 1099.99, 5, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Electrónica'), 1),

        ('Camiseta Deportiva Nike', 'Camiseta transpirable ideal para entrenamientos', 29.99, 20, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Ropa'), 1),

        ('Juego de Sartenes Antiaderentes', 'Set de 3 sartenes con recubrimiento antiadherente', 89.99, 15, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Hogar'), 1),

        ('Balón de Fútbol Adidas', 'Balón oficial tamaño 5 para partidos profesionales', 39.99, 8, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Deportes'), 1),

        ('Clean Code - Robert C. Martin', 'Libro fundamental sobre buenas prácticas de programación', 49.99, 12, 'usado',
         (SELECT id FROM categories WHERE name = 'Libros'), 1),

        ('Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 7, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Electrónica'), 1),

        ('Zapatillas Running Adidas', 'Zapatillas deportivas para running con amortiguación', 89.99, 15, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Deportes'), 1),

        ('Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 10, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Hogar'), 1),

        ('Chaqueta Impermeable', 'Chaqueta resistente al agua para actividades outdoor', 79.99, 8, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Ropa'), 1)");

    // Verificar cuántos productos se insertaron
    $stmt = $db->query("SELECT COUNT(*) as count FROM products WHERE visible = 1");
    $productCount = $stmt->fetch()['count'];

    echo json_encode([
        'success' => true,
        'message' => '✅ Datos de prueba insertados correctamente',
        'products_added' => $productCount,
        'categories_added' => 5,
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}
?>
