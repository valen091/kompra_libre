<?php
// Script PHP simple para insertar datos de prueba UNO POR UNO
// Esto evita todos los problemas de sintaxis SQL

header('Content-Type: text/plain');

try {
    // Conectar a la base de datos
    $pdo = new PDO("mysql:host=localhost;dbname=u472738607_kompra_libre", "u472738607_kompra_libre", "Kompralibre1");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "✅ Conexión exitosa a la base de datos\n\n";

    // 1. Insertar usuario demo (si no existe)
    try {
        $demoPassword = password_hash('demo123', PASSWORD_DEFAULT);
        $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '{$demoPassword}', 'seller')");
        echo "✅ Usuario demo insertado\n";
    } catch (Exception $e) {
        echo "⚠️ Error con usuario demo: " . $e->getMessage() . "\n";
    }

    // 2. Insertar categorías (si no existen)
    $categories = [
        ['Electrónica', 'electronica'],
        ['Ropa', 'ropa'],
        ['Hogar', 'hogar'],
        ['Deportes', 'deportes'],
        ['Libros', 'libros']
    ];

    foreach ($categories as $cat) {
        try {
            $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('{$cat[0]}', '{$cat[1]}')");
            echo "✅ Categoría '{$cat[0]}' insertada\n";
        } catch (Exception $e) {
            echo "⚠️ Error con categoría '{$cat[0]}': " . $e->getMessage() . "\n";
        }
    }

    // 3. Insertar vendedor (si no existe)
    try {
        $pdo->exec("INSERT IGNORE INTO sellers (user_id, shop_alias) SELECT id, 'Tienda Demo' FROM users WHERE email = 'demo@kompralibre.shop'");
        echo "✅ Vendedor demo insertado\n";
    } catch (Exception $e) {
        echo "⚠️ Error con vendedor demo: " . $e->getMessage() . "\n";
    }

    // 4. Insertar productos UNO POR UNO (para evitar errores de sintaxis)
    $products = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 'Electrónica', 'nuevo'],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 'Electrónica', 'nuevo'],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 'Ropa', 'nuevo'],
        ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 'Hogar', 'nuevo'],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 'Deportes', 'nuevo'],
        ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 'Libros', 'usado'],
        ['Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 'Electrónica', 'nuevo'],
        ['Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, 'Deportes', 'nuevo'],
        ['Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 'Hogar', 'nuevo'],
        ['Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, 'Ropa', 'nuevo']
    ];

    foreach ($products as $product) {
        try {
            // Obtener el ID de la categoría
            $stmt = $pdo->query("SELECT id FROM categories WHERE name = '{$product[3]}'");
            $category = $stmt->fetch();

            if ($category) {
                $pdo->exec("INSERT IGNORE INTO products (title, description, price, stock, condition, category_id, visible) VALUES ('{$product[0]}', '{$product[1]}', {$product[2]}, 10, '{$product[4]}', {$category['id']}, 1)");
                echo "✅ Producto '{$product[0]}' insertado\n";
            } else {
                echo "❌ Categoría '{$product[3]}' no encontrada para producto '{$product[0]}'\n";
            }
        } catch (Exception $e) {
            echo "❌ Error con producto '{$product[0]}': " . $e->getMessage() . "\n";
        }
    }

    // 5. Verificar resultados
    echo "\n📊 RESULTADOS FINALES:\n";

    $users = $pdo->query("SELECT COUNT(*) FROM users")->fetch()['count'] ?? 0;
    echo "👤 Usuarios totales: {$users}\n";

    $categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetch()['count'] ?? 0;
    echo "🏷️ Categorías totales: {$categories}\n";

    $products = $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetch()['count'] ?? 0;
    echo "📦 Productos visibles: {$products}\n";

    $sellers = $pdo->query("SELECT COUNT(*) FROM sellers")->fetch()['count'] ?? 0;
    echo "🏪 Vendedores: {$sellers}\n";

    echo "\n🎉 ¡Datos de prueba insertados exitosamente!\n";
    echo "📧 Usuario demo: demo@kompralibre.shop\n";
    echo "🔑 Contraseña: demo123\n";

} catch (Exception $e) {
    echo "❌ ERROR GENERAL: " . $e->getMessage() . "\n";
    echo "🔧 Verifica que la base de datos 'u472738607_kompra_libre' existe y las credenciales son correctas.\n";
}
?>
