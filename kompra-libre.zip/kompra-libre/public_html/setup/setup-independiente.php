<?php
// Script PHP INDEPENDIENTE - No depende de archivos SQL
// Ejecuta todo desde PHP sin subconsultas ni archivos externos

header('Content-Type: text/plain');

try {
    // Conectar a la base de datos con diferentes credenciales
    $credentials = [
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => ''],
    ];

    $pdo = null;
    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};dbname={$cred['db']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "✅ Conectado como {$cred['user']}@{$cred['host']}/{$cred['db']}\n\n";
            break;
        } catch (Exception $e) {
            continue;
        }
    }

    if (!$pdo) {
        throw new Exception("No se pudo conectar con ninguna configuración");
    }

    echo "🗑️ Limpiando datos anteriores...\n";
    $pdo->exec("DELETE FROM products WHERE title LIKE 'iPhone%' OR title LIKE 'MacBook%' OR title LIKE 'Camiseta%' OR title LIKE 'Juego%' OR title LIKE 'Balón%' OR title LIKE 'Clean%' OR title LIKE 'Auriculares%' OR title LIKE 'Zapatillas%' OR title LIKE 'Lámpara%' OR title LIKE 'Chaqueta%'");
    $pdo->exec("DELETE FROM categories WHERE name IN ('Electrónica', 'Ropa', 'Hogar', 'Deportes', 'Libros')");
    $pdo->exec("DELETE FROM sellers WHERE shop_alias = 'Tienda Demo'");
    $pdo->exec("DELETE FROM users WHERE email = 'demo@kompralibre.shop'");

    echo "👤 Creando usuario demo...\n";
    $demoPassword = password_hash('demo123', PASSWORD_DEFAULT);
    $pdo->exec("INSERT INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '{$demoPassword}', 'seller')");
    $userId = $pdo->lastInsertId();
    echo "✅ Usuario creado con ID: {$userId}\n";

    echo "🏷️ Creando categorías...\n";
    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Electrónica', 'electronica')");
    $catElectronica = $pdo->lastInsertId();

    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Ropa', 'ropa')");
    $catRopa = $pdo->lastInsertId();

    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Hogar', 'hogar')");
    $catHogar = $pdo->lastInsertId();

    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Deportes', 'deportes')");
    $catDeportes = $pdo->lastInsertId();

    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Libros', 'libros')");
    $catLibros = $pdo->lastInsertId();

    echo "✅ Categorías creadas con IDs: {$catElectronica}, {$catRopa}, {$catHogar}, {$catDeportes}, {$catLibros}\n";

    echo "🏪 Creando vendedor...\n";
    $pdo->exec("INSERT INTO sellers (user_id, shop_alias) VALUES ({$userId}, 'Tienda Demo')");
    echo "✅ Vendedor creado\n";

    echo "📦 Insertando productos uno por uno...\n";

    $productos = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, $catElectronica, 'nuevo'],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, $catElectronica, 'nuevo'],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, $catRopa, 'nuevo'],
        ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, $catHogar, 'nuevo'],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, $catDeportes, 'nuevo'],
        ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, $catLibros, 'usado'],
        ['Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, $catElectronica, 'nuevo'],
        ['Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, $catDeportes, 'nuevo'],
        ['Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, $catHogar, 'nuevo'],
        ['Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, $catRopa, 'nuevo']
    ];

    foreach ($productos as $producto) {
        $pdo->exec("INSERT INTO products (title, description, price, stock, condition, category_id, visible) VALUES ('{$producto[0]}', '{$producto[1]}', {$producto[2]}, 10, '{$producto[4]}', {$producto[3]}, 1)");
        echo "✅ Producto '{$producto[0]}' insertado\n";
    }

    echo "\n📊 RESULTADOS FINALES:\n";
    echo "👤 Usuarios: " . $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() . "\n";
    echo "🏷️ Categorías: " . $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn() . "\n";
    echo "📦 Productos visibles: " . $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn() . "\n";
    echo "🏪 Vendedores: " . $pdo->query("SELECT COUNT(*) FROM sellers")->fetchColumn() . "\n";

    echo "\n🎉 ¡DATOS INSERTADOS EXITOSAMENTE!\n";
    echo "📧 Usuario: demo@kompralibre.shop\n";
    echo "🔑 Contraseña: demo123\n";
    echo "🌐 Los productos aparecerán en la página principal\n";

} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    echo "\n🔧 Soluciones posibles:\n";
    echo "1. Verifica que la base de datos existe\n";
    echo "2. Verifica las credenciales de conexión\n";
    echo "3. Verifica que las tablas están creadas\n";
    echo "4. Ejecuta el script SQL manualmente en PHPMyAdmin\n";
}
?>
