# 📁 setup/ - Scripts de Instalación y Configuración

Este directorio contiene todos los scripts de instalación, configuración y setup del proyecto Kompra Libre.

## 📋 Contenido

### 🖥️ Scripts de Setup con Interfaz Web
- **`setup-automatico.html`** - Setup automático con interfaz web
- **`setup-gui.html`** - Setup con interfaz gráfica de usuario
- **`setup-sencillo.html`** - Setup sencillo y directo
- **`setup-ultra-simple.php`** - Setup ultra simple en PHP

### ⚙️ Scripts de Setup Avanzados
- **`setup-definitivo.php`** - Setup definitivo y completo
- **`setup-final.php`** - Setup final optimizado
- **`setup-independiente.php`** - Setup independiente con múltiples credenciales
- **`setup-demo-data.php`** - Setup específico para datos de demostración

### 🔧 Scripts de Configuración Rápida
- **`one-click-setup.php`** - Setup de un solo clic
- **`quick-setup.php`** - Setup rápido y directo

### 🗄️ Scripts de Base de Datos
- **`auto-fix-db.php`** - Corrección automática de base de datos
- **`fix-and-setup-db.php`** - Fix y setup combinado de base de datos
- **`init-demo-data.php`** - Inicialización de datos de demostración
- **`insertar-datos-prueba.php`** - Insertar datos de prueba
- **`insertar-datos-uno-por-uno.php`** - Insertar datos uno por uno

## 🔍 Uso

### Para Instalación Inicial
1. **Más fácil**: Usa `setup-sencillo.html` (interfaz web)
2. **Completo**: Ejecuta `setup-definitivo.php`
3. **Rápido**: Prueba `one-click-setup.php`

### Para Reparaciones
1. **Base de datos**: `auto-fix-db.php` o `fix-and-setup-db.php`
2. **Datos demo**: `setup-demo-data.php` o `init-demo-data.php`

### Para Desarrollo
1. **Datos de prueba**: `insertar-datos-prueba.php`
2. **Debug**: Revisa la salida de cualquier script de setup

## 📁 Estructura Padre

```
📦 kompra-libre/
└── 📂 public_html/
    ├── 📂 config/
    ├── 📂 docs/
    ├── 📂 setup/           ← Estás aquí
    ├── 📂 pages/
    ├── 📂 tests/
    └── ... (otros directorios)
```

## ⚠️ Importante

- **Prueba** primero en un entorno de desarrollo
- **Haz respaldo** de la base de datos antes de ejecutar
- **Verifica** las credenciales de base de datos en cada script
- **Revisa** los logs de errores si algo falla

## 🔧 Personalización

Los scripts pueden ser modificados para:
- Cambiar credenciales de base de datos
- Ajustar datos de demostración
- Modificar configuraciones específicas
- Adaptar a diferentes entornos (desarrollo, staging, producción)

## 📞 Soporte

Si encuentras problemas:
1. Revisa `docs/DEPLOYMENT.md` para configuración
2. Consulta `docs/README.md` para troubleshooting
3. Verifica que la base de datos esté accesible
4. Comprueba los logs de errores del servidor
