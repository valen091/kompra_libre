<?php
header('Content-Type: application/json');

// Script para verificar y corregir la base de datos
try {
    // Probar credenciales más comunes en Hostinger
    $credentials = [
        ['host' => 'localhost', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1', 'db' => 'u472738607_kompra_libre'],
        ['host' => 'localhost', 'user' => 'root', 'pass' => '', 'db' => 'u472738607_kompra_libre'],
        ['host' => 'localhost', 'user' => 'u472738607_kompra_libre', 'pass' => '', 'db' => 'u472738607_kompra_libre'],
    ];

    $workingConnection = null;
    $connectionInfo = [];

    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Verificar si la base de datos existe
            $databases = $pdo->query("SHOW DATABASES")->fetchAll(PDO::FETCH_COLUMN);
            $dbExists = in_array($cred['db'], $databases);

            if ($dbExists) {
                // Usar la base de datos
                $pdo->exec("USE {$cred['db']}");
                $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

                $workingConnection = $pdo;
                $connectionInfo = [
                    'credentials' => $cred,
                    'tables' => $tables,
                    'database_exists' => true
                ];
                break;
            }
        } catch (Exception $e) {
            continue;
        }
    }

    if (!$workingConnection) {
        throw new Exception("No se pudo conectar con ninguna configuración");
    }

    // Si no hay tablas, necesitamos crear el schema
    if (empty($connectionInfo['tables'])) {
        // Crear tablas básicas
        $workingConnection->exec("
            CREATE TABLE IF NOT EXISTS categories (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                slug VARCHAR(255) NOT NULL UNIQUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $workingConnection->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) NOT NULL UNIQUE,
                password_hash VARCHAR(255) NOT NULL,
                role ENUM('buyer', 'seller') DEFAULT 'buyer',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $workingConnection->exec("
            CREATE TABLE IF NOT EXISTS products (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                description TEXT,
                price DECIMAL(10,2) NOT NULL,
                stock INT DEFAULT 0,
                condition ENUM('nuevo', 'usado') DEFAULT 'nuevo',
                category_id INT,
                visible BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (category_id) REFERENCES categories(id)
            )
        ");

        $connectionInfo['schema_created'] = true;
    }

    // Insertar datos de prueba
    $workingConnection->exec("
        INSERT IGNORE INTO categories (name, slug) VALUES
        ('Electrónica', 'electronica'),
        ('Ropa', 'ropa'),
        ('Hogar', 'hogar'),
        ('Deportes', 'deportes'),
        ('Libros', 'libros')
    ");

    $workingConnection->exec("
        INSERT IGNORE INTO products (title, description, price, stock, condition, category_id, visible) VALUES
        ('iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 10, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Electrónica'), 1),

        ('MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 5, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Electrónica'), 1),

        ('Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 20, 'nuevo',
         (SELECT id FROM categories WHERE name = 'Ropa'), 1)
    ");

    echo json_encode([
        'success' => true,
        'message' => 'Base de datos configurada correctamente',
        'connection_info' => $connectionInfo,
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}
?>
