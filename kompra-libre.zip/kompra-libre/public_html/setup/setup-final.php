<?php
// SETUP FINAL - Script PHP 100% INDEPENDIENTE
// No depende de archivos SQL, no usa subconsultas, funciona en cualquier MySQL/MariaDB

header('Content-Type: application/json');

try {
    // Credenciales a probar (en orden de prioridad)
    $credentials = [
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'kompra_libre', 'user' => 'root', 'pass' => ''],
    ];

    $pdo = null;
    $connectionInfo = '';

    // Probar cada configuración
    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};dbname={$cred['db']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $connectionInfo = "✅ Conectado como {$cred['user']}@{$cred['host']}/{$cred['db']}";
            break;
        } catch (Exception $e) {
            continue;
        }
    }

    if (!$pdo) {
        throw new Exception("❌ No se pudo conectar con ninguna configuración de base de datos");
    }

    $results = [];
    $results['connection'] = $connectionInfo;

    // 1. Limpiar datos anteriores para empezar fresco
    $results['cleanup'] = "🗑️ Limpiando datos anteriores...";
    $pdo->exec("DELETE FROM products WHERE title LIKE 'iPhone%' OR title LIKE 'MacBook%' OR title LIKE 'Camiseta%' OR title LIKE 'Juego%' OR title LIKE 'Balón%' OR title LIKE 'Clean%' OR title LIKE 'Auriculares%' OR title LIKE 'Zapatillas%' OR title LIKE 'Lámpara%' OR title LIKE 'Chaqueta%'");
    $pdo->exec("DELETE FROM categories WHERE name IN ('Electrónica', 'Ropa', 'Hogar', 'Deportes', 'Libros')");
    $pdo->exec("DELETE FROM sellers WHERE shop_alias = 'Tienda Demo'");
    $pdo->exec("DELETE FROM users WHERE email = 'demo@kompralibre.shop'");

    // 2. Insertar usuario demo
    $results['user'] = "👤 Creando usuario demo...";
    $demoPassword = password_hash('demo123', PASSWORD_DEFAULT);
    $pdo->exec("INSERT INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '{$demoPassword}', 'seller')");
    $userId = $pdo->lastInsertId();
    $results['user_id'] = $userId;

    // 3. Insertar categorías y obtener sus IDs
    $results['categories'] = "🏷️ Creando categorías...";
    $categories = [];
    $categoryNames = ['Electrónica', 'Ropa', 'Hogar', 'Deportes', 'Libros'];

    foreach ($categoryNames as $index => $name) {
        $slug = strtolower($name);
        $pdo->exec("INSERT INTO categories (name, slug) VALUES ('{$name}', '{$slug}')");
        $categories[$name] = $pdo->lastInsertId();
    }
    $results['category_ids'] = $categories;

    // 4. Insertar vendedor
    $results['seller'] = "🏪 Creando vendedor...";
    $pdo->exec("INSERT INTO sellers (user_id, shop_alias) VALUES ({$userId}, 'Tienda Demo')");

    // 5. Insertar productos uno por uno con IDs fijos
    $results['products'] = "📦 Insertando productos...";
    $productos = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 'Electrónica', 'nuevo'],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 'Electrónica', 'nuevo'],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 'Ropa', 'nuevo'],
        ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 'Hogar', 'nuevo'],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 'Deportes', 'nuevo'],
        ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 'Libros', 'usado'],
        ['Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 'Electrónica', 'nuevo'],
        ['Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, 'Deportes', 'nuevo'],
        ['Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 'Hogar', 'nuevo'],
        ['Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, 'Ropa', 'nuevo']
    ];

    $productosInsertados = [];
    foreach ($productos as $producto) {
        $categoryId = $categories[$producto[3]];
        $pdo->exec("INSERT INTO products (title, description, price, stock, condition, category_id, visible) VALUES ('{$producto[0]}', '{$producto[1]}', {$producto[2]}, 10, '{$producto[4]}', {$categoryId}, 1)");
        $productosInsertados[] = $producto[0];
    }
    $results['products_list'] = $productosInsertados;

    // 6. Verificar resultados finales
    $results['verification'] = "🔍 Verificando resultados...";
    $finalStats = [
        'users' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
        'categories' => $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn(),
        'products' => $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn(),
        'sellers' => $pdo->query("SELECT COUNT(*) FROM sellers")->fetchColumn()
    ];
    $results['final_stats'] = $finalStats;

    // Respuesta exitosa
    echo json_encode([
        'success' => true,
        'message' => '✅ Setup completado exitosamente',
        'steps' => $results,
        'user_credentials' => [
            'email' => 'demo@kompralibre.shop',
            'password' => 'demo123',
            'role' => 'seller'
        ],
        'products_added' => count($productosInsertados),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'possible_solutions' => [
            '1. Verifica que la base de datos existe',
            '2. Verifica las credenciales de conexión',
            '3. Verifica que las tablas están creadas',
            '4. Usa el script SQL manual en PHPMyAdmin'
        ],
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);
}
?>
