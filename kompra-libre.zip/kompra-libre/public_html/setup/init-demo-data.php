<?php
header('Content-Type: application/json');
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

try {
    $db = getDB();

    // Crear usuario demo si no existe
    $demoPassword = password_hash('demo123', PASSWORD_DEFAULT);
    $db->prepare("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', ?, 'seller')")
       ->execute([$demoPassword]);

    // Obtener ID del usuario demo
    $stmt = $db->query("SELECT id FROM users WHERE email = 'demo@kompralibre.shop'");
    $demoUser = $stmt->fetch();
    $demoUserId = $demoUser['id'];

    // Crear perfil de vendedor
    $db->prepare("INSERT IGNORE INTO sellers (user_id, shop_alias) VALUES (?, 'Tienda Demo')")
       ->execute([$demoUserId]);

    // Insertar categorías
    $categories = [
        'Electrónica' => 'electronica',
        'Ropa' => 'ropa',
        'Hogar' => 'hogar',
        'Deportes' => 'deportes',
        'Libros' => 'libros'
    ];

    foreach ($categories as $name => $slug) {
        $db->prepare("INSERT IGNORE INTO categories (name, slug) VALUES (?, ?)")
           ->execute([$name, $slug]);
    }

    // Insertar productos
    $products = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 'Electrónica', 'nuevo'],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 'Electrónica', 'nuevo'],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 'Ropa', 'nuevo'],
        ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 'Hogar', 'nuevo'],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 'Deportes', 'nuevo'],
        ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 'Libros', 'usado']
    ];

    foreach ($products as $product) {
        // Obtener categoría
        $stmt = $db->prepare("SELECT id FROM categories WHERE name = ?");
        $stmt->execute([$product[3]]);
        $category = $stmt->fetch();

        if ($category) {
            $db->prepare("
                INSERT IGNORE INTO products (title, description, price, stock, condition, category_id, visible)
                VALUES (?, ?, ?, 10, ?, ?, 1)
            ")->execute([$product[0], $product[1], $product[2], $product[4], $category['id']]);
        }
    }

    // Contar resultados
    $stmt = $db->query("SELECT COUNT(*) as total FROM products WHERE visible = 1");
    $productsCount = $stmt->fetch()['total'];

    $stmt = $db->query("SELECT COUNT(*) as total FROM categories");
    $categoriesCount = $stmt->fetch()['total'];

    echo json_encode([
        'success' => true,
        'message' => 'Datos de demostración configurados correctamente',
        'products_added' => $productsCount,
        'categories_added' => $categoriesCount,
        'demo_user_id' => $demoUserId,
        'timestamp' => date('Y-m-d H:i:s')
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}
?>
