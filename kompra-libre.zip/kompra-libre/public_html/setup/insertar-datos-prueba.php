<?php
header('Content-Type: application/json');

try {
    // Intentar conectar con diferentes credenciales
    $credentials = [
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => ''],
    ];

    $pdo = null;
    $connectionInfo = '';

    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};dbname={$cred['db']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $connectionInfo = "Conectado como {$cred['user']}@{$cred['host']}/{$cred['db']}";
            break;
        } catch (Exception $e) {
            continue;
        }
    }

    if (!$pdo) {
        throw new Exception("No se pudo conectar con ninguna configuración de base de datos");
    }

    // Insertar usuario demo
    $demoPassword = password_hash('demo123', PASSWORD_DEFAULT);
    $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '{$demoPassword}', 'seller')");

    // Insertar categorías
    $categories = [
        ['name' => 'Electrónica', 'slug' => 'electronica'],
        ['name' => 'Ropa', 'slug' => 'ropa'],
        ['name' => 'Hogar', 'slug' => 'hogar'],
        ['name' => 'Deportes', 'slug' => 'deportes'],
        ['name' => 'Libros', 'slug' => 'libros']
    ];

    foreach ($categories as $cat) {
        $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('{$cat['name']}', '{$cat['slug']}')");
    }

    // Insertar perfil de vendedor
    $pdo->exec("INSERT IGNORE INTO sellers (user_id, shop_alias) SELECT id, 'Tienda Demo' FROM users WHERE email = 'demo@kompralibre.shop'");

    // Insertar productos
    $products = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 'Electrónica', 'nuevo'],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 'Electrónica', 'nuevo'],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 'Ropa', 'nuevo'],
        ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 'Hogar', 'nuevo'],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 'Deportes', 'nuevo'],
        ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 'Libros', 'usado'],
        ['Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 'Electrónica', 'nuevo'],
        ['Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, 'Deportes', 'nuevo'],
        ['Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 'Hogar', 'nuevo'],
        ['Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, 'Ropa', 'nuevo']
    ];

    foreach ($products as $product) {
        $categoryId = $pdo->query("SELECT id FROM categories WHERE name = '{$product[3]}'")->fetch()['id'];
        $pdo->exec("INSERT IGNORE INTO products (title, description, price, stock, condition, category_id, visible) VALUES ('{$product[0]}', '{$product[1]}', {$product[2]}, 10, '{$product[4]}', {$categoryId}, 1)");
    }

    // Verificar resultados
    $users = $pdo->query("SELECT COUNT(*) FROM users")->fetch()['count'] ?? 0;
    $categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetch()['count'] ?? 0;
    $products = $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetch()['count'] ?? 0;

    echo json_encode([
        'success' => true,
        'message' => 'Datos de prueba insertados correctamente',
        'connection' => $connectionInfo,
        'data' => [
            'users' => $users,
            'categories' => $categories,
            'products' => $products
        ],
        'products_list' => $products,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_PRETTY_PRINT);
}
?>
