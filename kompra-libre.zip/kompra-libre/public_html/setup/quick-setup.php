<?php
header('Content-Type: application/json');

try {
    $db = new PDO("mysql:host=localhost;dbname=u472738607_kompra_libre", "u472738607_kompra_libre", "Kompralibre1");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Crear usuario demo
    $demoPassword = password_hash('demo123', PASSWORD_DEFAULT);
    $db->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '{$demoPassword}', 'seller')");

    // Crear perfil de vendedor
    $db->exec("INSERT IGNORE INTO sellers (user_id, shop_alias) SELECT id, 'Tienda Demo' FROM users WHERE email = 'demo@kompralibre.shop'");

    // Insertar categorías
    $categories = [
        'Electrónica' => 'electronica',
        'Ropa' => 'ropa',
        'Hogar' => 'hogar',
        'Deportes' => 'deportes',
        'Libros' => 'libros'
    ];

    foreach ($categories as $name => $slug) {
        $db->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('{$name}', '{$slug}')");
    }

    // Insertar productos
    $products = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 'Electrónica', 'nuevo'],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 'Electrónica', 'nuevo'],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 'Ropa', 'nuevo'],
        ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 'Hogar', 'nuevo'],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 'Deportes', 'nuevo'],
        ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 'Libros', 'usado']
    ];

    foreach ($products as $product) {
        $categoryId = $db->query("SELECT id FROM categories WHERE name = '{$product[3]}'")->fetch()['id'];
        $db->exec("INSERT IGNORE INTO products (title, description, price, stock, condition, category_id, visible) VALUES ('{$product[0]}', '{$product[1]}', {$product[2]}, 10, '{$product[4]}', {$categoryId}, 1)");
    }

    echo json_encode([
        'success' => true,
        'message' => 'Datos de prueba insertados correctamente',
        'products' => count($products),
        'categories' => count($categories)
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
