<?php
header('Content-Type: application/json');

$results = [];

// Probar diferentes configuraciones de Hostinger
$configs = [
    'hostinger_1' => ['host' => 'localhost', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1', 'db' => 'u472738607_kompra_libre'],
    'hostinger_2' => ['host' => 'localhost', 'user' => 'root', 'pass' => '', 'db' => 'u472738607_kompra_libre'],
    'hostinger_3' => ['host' => 'localhost', 'user' => 'u472738607_kompra_libre', 'pass' => '', 'db' => 'u472738607_kompra_libre'],
    'fallback' => ['host' => 'localhost', 'user' => 'root', 'pass' => 'Kompralibre1', 'db' => 'u472738607_kompra_libre']
];

foreach ($configs as $name => $config) {
    try {
        $pdo = new PDO("mysql:host={$config['host']};charset=utf8", $config['user'], $config['pass']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $databases = $pdo->query("SHOW DATABASES")->fetchAll(PDO::FETCH_COLUMN);
        $dbExists = in_array($config['db'], $databases);

        if ($dbExists) {
            $pdo->exec("USE {$config['db']}");
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

            $results['working_config'] = $config;
            $results['tables'] = $tables;
            $results['success'] = true;

            // Si no hay tablas, crear schema básico
            if (empty($tables)) {
                $pdo->exec("CREATE TABLE IF NOT EXISTS categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, slug VARCHAR(255) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
                $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, role ENUM('buyer', 'seller') DEFAULT 'buyer', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
                $pdo->exec("CREATE TABLE IF NOT EXISTS products (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255) NOT NULL, description TEXT, price DECIMAL(10,2) NOT NULL, stock INT DEFAULT 0, condition ENUM('nuevo', 'usado') DEFAULT 'nuevo', category_id INT, visible BOOLEAN DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (category_id) REFERENCES categories(id))");

                $results['schema_created'] = true;
            }

            break;
        }
    } catch (Exception $e) {
        $results[$name] = ['error' => $e->getMessage()];
    }
}

if (isset($results['working_config'])) {
    // Actualizar config.php con las credenciales que funcionan
    $configContent = "<?php
// Configuración de la aplicación
define('APP_NAME', 'Kompra Libre');
define('APP_URL', 'https://kompralibre.shop/');
define('APP_DEBUG', true);

// Configuración de la base de datos (autodetectada)
define('DB_HOST', '{$results['working_config']['host']}');
define('DB_NAME', '{$results['working_config']['db']}');
define('DB_USER', '{$results['working_config']['user']}');
define('DB_PASS', '{$results['working_config']['pass']}');

// Configuración de sesión
define('SESSION_NAME', 'kompra_libre_session');
define('SESSION_LIFETIME', 86400);

// Configuración de JWT
define('JWT_SECRET', 'tu_clave_secreta_muy_segura');
define('JWT_EXPIRE', 86400);

// Habilitar manejo de errores
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

date_default_timezone_set('America/Uruguay/Montevideo');
session_name(SESSION_NAME);
session_set_cookie_params(['lifetime' => SESSION_LIFETIME, 'path' => '/', 'domain' => '', 'secure' => isset(\$_SERVER['HTTPS']), 'httponly' => true, 'samesite' => 'Lax']);
session_start();
?>";

    file_put_contents(__DIR__ . '/includes/config.php', $configContent);
    $results['config_updated'] = true;
}

echo json_encode($results, JSON_PRETTY_PRINT);
?>
