<?php
// Script PHP ULTRA SIMPLE - SIN SUBCONSULTAS NI INSERT IGNORE
// Ejecuta INSERTs básicos uno por uno

try {
    $pdo = new PDO("mysql:host=localhost;dbname=u472738607_kompra_libre", "u472738607_kompra_libre", "Kompralibre1");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "✅ Conexión exitosa\n\n";

    // 1. Borrar datos existentes para empezar limpio
    echo "🗑️ Limpiando datos existentes...\n";
    $pdo->exec("DELETE FROM products WHERE title LIKE 'iPhone%' OR title LIKE 'MacBook%' OR title LIKE 'Camiseta%' OR title LIKE 'Juego%' OR title LIKE 'Balón%' OR title LIKE 'Clean%' OR title LIKE 'Auriculares%' OR title LIKE 'Zapatillas%' OR title LIKE 'Lámpara%' OR title LIKE 'Chaqueta%'");
    $pdo->exec("DELETE FROM categories WHERE name IN ('Electrónica', 'Ropa', 'Hogar', 'Deportes', 'Libros')");
    $pdo->exec("DELETE FROM sellers WHERE shop_alias = 'Tienda Demo'");
    $pdo->exec("DELETE FROM users WHERE email = 'demo@kompralibre.shop'");

    // 2. Insertar usuario demo
    echo "👤 Insertando usuario demo...\n";
    $demoPassword = password_hash('demo123', PASSWORD_DEFAULT);
    $pdo->exec("INSERT INTO users (name, email, password_hash, role) VALUES ('Demo User', 'demo@kompralibre.shop', '{$demoPassword}', 'seller')");
    $userId = $pdo->lastInsertId();
    echo "✅ Usuario demo creado con ID: {$userId}\n";

    // 3. Insertar categorías
    echo "🏷️ Insertando categorías...\n";
    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Electrónica', 'electronica')");
    $catElectronica = $pdo->lastInsertId();

    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Ropa', 'ropa')");
    $catRopa = $pdo->lastInsertId();

    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Hogar', 'hogar')");
    $catHogar = $pdo->lastInsertId();

    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Deportes', 'deportes')");
    $catDeportes = $pdo->lastInsertId();

    $pdo->exec("INSERT INTO categories (name, slug) VALUES ('Libros', 'libros')");
    $catLibros = $pdo->lastInsertId();

    echo "✅ Categorías creadas con IDs: {$catElectronica}, {$catRopa}, {$catHogar}, {$catDeportes}, {$catLibros}\n";

    // 4. Insertar vendedor
    echo "🏪 Insertando vendedor...\n";
    $pdo->exec("INSERT INTO sellers (user_id, shop_alias) VALUES ({$userId}, 'Tienda Demo')");
    echo "✅ Vendedor creado\n";

    // 5. Insertar productos uno por uno con IDs fijos
    echo "📦 Insertando productos...\n";

    $productos = [
        ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, $catElectronica, 'nuevo'],
        ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, $catElectronica, 'nuevo'],
        ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, $catRopa, 'nuevo'],
        ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, $catHogar, 'nuevo'],
        ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, $catDeportes, 'nuevo'],
        ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, $catLibros, 'usado'],
        ['Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, $catElectronica, 'nuevo'],
        ['Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, $catDeportes, 'nuevo'],
        ['Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, $catHogar, 'nuevo'],
        ['Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, $catRopa, 'nuevo']
    ];

    foreach ($productos as $producto) {
        $sql = "INSERT INTO products (title, description, price, stock, condition, category_id, visible) VALUES ('{$producto[0]}', '{$producto[1]}', {$producto[2]}, 10, '{$producto[4]}', {$producto[3]}, 1)";
        $pdo->exec($sql);
        echo "✅ Producto '{$producto[0]}' insertado\n";
    }

    // 6. Verificar resultados
    echo "\n📊 RESULTADOS FINALES:\n";

    $users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    echo "👤 Usuarios: {$users}\n";

    $categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
    echo "🏷️ Categorías: {$categories}\n";

    $products = $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn();
    echo "📦 Productos visibles: {$products}\n";

    $sellers = $pdo->query("SELECT COUNT(*) FROM sellers")->fetchColumn();
    echo "🏪 Vendedores: {$sellers}\n";

    echo "\n🎉 ¡TODO INSERTADO CORRECTAMENTE!\n";
    echo "📧 Usuario: demo@kompralibre.shop\n";
    echo "🔑 Contraseña: demo123\n";
    echo "🌐 Los productos deberían aparecer en la página principal ahora\n";

} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    echo "🔧 Verifica que:\n";
    echo "- La base de datos existe\n";
    echo "- Las credenciales son correctas\n";
    echo "- Las tablas están creadas\n";
}
?>
