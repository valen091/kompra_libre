/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./public_html/**/*.{html,js}",
    "./public_html/views/**/*.{html,js}"
  ],
  theme: {
    extend: {
      colors: {
        'light-blue': '#93C5FD',
        'gold': '#D4AF37',
      },
    },
  },
  plugins: [],
}
