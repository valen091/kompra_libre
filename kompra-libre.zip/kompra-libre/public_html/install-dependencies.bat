@echo off
echo ======================================
echo Instalando dependencias de Kompra Libre
echo ======================================
echo.

cd /d "%~dp0"

echo Instalando dependencias principales...
call npm install express cors morgan bcryptjs jsonwebtoken express-validator mysql2 dotenv cookie-parser

echo.
echo Instalando dependencias de desarrollo...
call npm install --save-dev nodemon

echo.
echo Instalando dependencias adicionales...
call npm install multer sharp uuid fs-extra openai

echo.
echo Instalando Mercado Pago SDK...
call npm install mercadopago

echo.
echo ======================================
echo Instalación completada
echo ======================================
echo.
echo Para iniciar el servidor en desarrollo, ejecuta:
echo npm run dev
echo.
echo Para iniciar el servidor en producción, ejecuta:
echo npm start
echo.
pause
