# 📁 Estructura de Archivos Organizada - Kompra Libre

## 🎯 Nueva Organización

Esta es la estructura de archivos reorganizada para mejorar la mantenibilidad y navegación:

### 📂 `config/` - Archivos de Configuración
- **`.env`** - Variables de entorno
- **`.htaccess`** - Configuración del servidor Apache
- **`.gitignore`** - Archivos a ignorar por Git
- **`package.json`** - Dependencias de Node.js
- **`package-lock.json`** - Lock de versiones de paquetes
- **`tailwind.config.js`** - Configuración de Tailwind CSS
- **`postcss.config.js`** - Configuración de PostCSS
- **`netlify.toml`** - Configuración de despliegue en Netlify
- **`railway.toml`** - Configuración de despliegue en Railway
- **`Procfile`** - Configuración de procesos

### 📂 `docs/` - Documentación
- **`README.md`** - Documentación principal del proyecto
- **`DEMO_DATA_FIXED.md`** - Correcciones de datos de demostración
- **`DEPLOYMENT.md`** - Guía de despliegue
- **`FIX_PRODUCTOS.md`** - Correcciones de productos
- **`MIGRATION_HOSTINGER.md`** - Migración a Hostinger
- **`PANEL_ADMIN_FIX.md`** - Correcciones del panel de administración
- **`PANEL_COMPLETO_FIX.md`** - Correcciones del panel completo
- **`PANEL_USUARIO_FIX.md`** - Correcciones del panel de usuario
- **`REGISTRO_FIX.md`** - Correcciones de registro
- **`REVISION_COMPLETA.md`** - Revisión completa del proyecto
- **`SQL_100_COMPATIBLE.md`** - SQL 100% compatible
- **`SQL_FIX_COMPLETO.md`** - Correcciones SQL completas
- **`SQL_FIX_FINAL.md`** - Correcciones SQL finales

### 📂 `setup/` - Scripts de Instalación y Configuración
- **`setup-automatico.html`** - Setup automático
- **`setup-definitivo.php`** - Setup definitivo
- **`setup-demo-data.php`** - Setup de datos de demostración
- **`setup-final.php`** - Setup final
- **`setup-gui.html`** - Setup con interfaz gráfica
- **`setup-independiente.php`** - Setup independiente
- **`setup-sencillo.html`** - Setup sencillo
- **`setup-ultra-simple.php`** - Setup ultra simple
- **`one-click-setup.php`** - Setup de un clic
- **`quick-setup.php`** - Setup rápido
- **`auto-fix-db.php`** - Corrección automática de base de datos
- **`fix-and-setup-db.php`** - Fix y setup de base de datos
- **`init-demo-data.php`** - Inicialización de datos de demo
- **`insertar-datos-prueba.php`** - Insertar datos de prueba
- **`insertar-datos-uno-por-uno.php`** - Insertar datos uno por uno

### 📂 `pages/` - Páginas HTML del Sitio
- **`index.html`** - Página principal
- **`carrito.html`** - Página del carrito de compras
- **`checkout.html`** - Página de pago
- **`login.html`** - Página de login
- **`registro.html`** - Página de registro
- **`producto.html`** - Página de producto individual
- **`favoritos.html`** - Página de favoritos
- **`repair-db.html`** - Página de reparación de base de datos
- **`panel-admin.html`** - Panel de administración
- **`panel-usuario.html`** - Panel de usuario
- **`panel-vendedor.html`** - Panel de vendedor

### 📂 `tests/` - Scripts de Prueba y Verificación
- **`test-api.php`** - Pruebas de API
- **`test-db-connection.php`** - Pruebas de conexión a base de datos
- **`test-db.php`** - Pruebas de base de datos
- **`test-demo-data.php`** - Pruebas de datos de demostración
- **`test-demo-data-corregido.php`** - Pruebas de datos corregidos
- **`check-db.php`** - Verificación de base de datos
- **`debug-info.php`** - Información de debug
- **`diagnose-db.php`** - Diagnóstico de base de datos
- **`verificacion-final.php`** - Verificación final
- **`verificar-db.php`** - Verificar base de datos

### 📂 `scripts/` - Scripts Utilitarios
- **`api.php`** - API principal
- **`verificacion-final.php`** - Script de verificación final

## 🏗️ Estructura de Directorios Existente (Mantenida)

### 📂 `api/` - API Endpoints
- `auth/` - Autenticación
- `cart/` - Carrito
- `orders/` - Pedidos

### 📂 `css/` - Hojas de Estilo
- **`custom.css`** - Estilos personalizados
- **`paleta.json`** - Paleta de colores

### 📂 `img/` - Imágenes
- `empresas/` - Imágenes de empresas
- `figma/` - Recursos de Figma
- `productos/` - Imágenes de productos

### 📂 `includes/` - Archivos PHP Incluidos
- **`config.php`** - Configuración
- **`db.php`** - Conexión a base de datos
- **`functions.php`** - Funciones utilitarias

### 📂 `js/` - Archivos JavaScript
- Scripts de frontend

### 📂 `sql/` - Scripts SQL
- **`demo-data.sql`** - Datos de demostración
- **`schema_hostinger.sql`** - Esquema de Hostinger
- **`productos-demo-corregido.sql`** - Productos corregidos

### 📂 `src/` - Código Fuente
- Archivos fuente del proyecto

### 📂 `logs/` - Logs del Sistema
- Archivos de log

### 📂 `node_modules/` - Dependencias de Node.js
- Paquetes instalados

### 📂 `php/` - Scripts PHP Adicionales

## 📋 Archivos Reorganizados

### ✅ Completado:
- [x] **Configuración** → `config/`
- [x] **Documentación** → `docs/`
- [x] **Setup** → `setup/`
- [x] **Páginas** → `pages/`
- [x] **Tests** → `tests/`
- [x] **Scripts** → `scripts/`

### 🔄 Pendiente:
- [ ] Actualizar referencias en código
- [ ] Verificar enlaces en documentación
- [ ] Probar que todo funciona correctamente

## 🚀 Beneficios de esta Organización

1. **📁 Mejor navegación** - Archivos agrupados por función
2. **🔍 Fácil mantenimiento** - Localizar archivos rápidamente
3. **📚 Documentación clara** - README en cada directorio
4. **🧹 Limpieza visual** - Directorio raíz más ordenado
5. **🔄 Escalabilidad** - Estructura preparada para crecimiento

## 📖 Guía de Uso

Para encontrar archivos específicos:
- **Configuración** → `config/`
- **Documentación** → `docs/`
- **Instalación** → `setup/`
- **Páginas web** → `pages/`
- **Pruebas** → `tests/`
- **Utilitarios** → `scripts/`

¡La estructura está lista para usar! 🎉
