# 🚀 **PRODUCTOS NO SE MUESTRAN - SOLUCIÓN**

## **Problema identificado:**
La base de datos está vacía - no hay productos ni categorías para mostrar.

## **Solución - Ejecutar datos de prueba:**

### **Opción 1: Script PHP (Recomendado)**
1. Ve a: `https://kompralibre.shop/quick-setup.php`
2. Esto insertará productos y categorías automáticamente

### **Opción 2: SQL Manual**
1. Ve a PHPMyAdmin en Hostinger
2. Selecciona la base de datos `u472738607_kompra_libre`
3. Ejecuta el contenido del archivo `demo-data.sql`

### **Opción 3: Script con credenciales**
1. Ve a: `https://kompralibre.shop/init-demo-data.php`
2. Esto creará usuario, categorías y productos

## **Después de ejecutar los datos:**

1. **Actualiza la página:** `https://kompralibre.shop/`
2. **Deberías ver** 6 productos en la página principal
3. **Prueba los filtros** por categoría y precio
4. **Verifica el carrito** y otras funciones

## **Productos que se agregarán:**

✅ **Electrónica:** iPhone 15 Pro Max, MacBook Air M3
✅ **Ropa:** Camiseta Deportiva Nike, Chaqueta Impermeable
✅ **Hogar:** Juego de Sartenes, Lámpara LED
✅ **Deportes:** Balón de Fútbol Adidas, Zapatillas Running
✅ **Libros:** Clean Code - Robert C. Martin

## **Si sigue sin funcionar:**

1. **Abre DevTools** (F12) en `https://kompralibre.shop/`
2. **Ve a Console** y busca errores
3. **Ve a Network** y verifica las llamadas a `/api/products`
4. **Comparte** cualquier error que aparezca

**¿Ya ejecutaste alguno de estos scripts? ¿Los productos aparecen ahora?**
