# 📁 Instrucciones para Reorganizar Archivos - Kompra Libre

## 🚀 Cómo Organizar los Archivos

Tu proyecto tiene muchos archivos en el directorio raíz que pueden ser organizados en una estructura más clara y mantenible.

### 📋 Estructura Propuesta

```
📦 public_html/
├── 📂 config/          ← Archivos de configuración
├── 📂 docs/           ← Documentación
├── 📂 setup/          ← Scripts de instalación
├── 📂 pages/          ← Páginas HTML
├── 📂 tests/          ← Scripts de prueba
├── 📂 scripts/        ← Scripts utilitarios
├── 📂 api/            ← API endpoints (existente)
├── 📂 css/            ← Hojas de estilo (existente)
├── 📂 img/            ← Imágenes (existente)
├── 📂 includes/       ← PHP includes (existente)
├── 📂 js/             ← JavaScript (existente)
├── 📂 sql/            ← Scripts SQL (existente)
└── ... (otros directorios existentes)
```

### ⚡ Opción 1: Script Automático (Recomendado)

**Para Windows (PowerShell):**
```powershell
powershell -ExecutionPolicy Bypass -File reorganize-files.ps1
```

**Para Linux/Mac (Bash):**
```bash
bash reorganize-files.sh
```

### ⚡ Opción 2: Comandos Manuales

Si prefieres hacerlo manualmente, ejecuta estos comandos:

```powershell
# Crear directorios
mkdir config, docs, setup, pages, tests, scripts

# Mover archivos de configuración
mv .env, .gitignore, .htaccess, Procfile, netlify.toml, railway.toml, package.json, package-lock.json, postcss.config.js, tailwind.config.js config/

# Mover documentación
mv *.md docs/

# Mover setups
mv setup-*.html, setup-*.php, one-click-setup.php, quick-setup.php, auto-fix-db.php, fix-and-setup-db.php, init-demo-data.php, insertar-datos-*.php setup/

# Mover páginas HTML
mv *.html pages/

# Mover tests
mv test-*.php, check-*.php, debug-*.php, diagnose-*.php, verificacion-*.php, verificar-*.php tests/

# Mover scripts restantes
mv api.php, verificacion-final.php scripts/
```

### 🔧 Archivos que se Moverán

#### 📂 `config/` (10 archivos)
- `.env`, `.gitignore`, `.htaccess`, `Procfile`
- `netlify.toml`, `railway.toml`
- `package.json`, `package-lock.json`
- `postcss.config.js`, `tailwind.config.js`

#### 📂 `docs/` (13 archivos)
- `README.md`, `DEMO_DATA_FIXED.md`
- `DEPLOYMENT.md`, `FIX_PRODUCTOS.md`
- `MIGRATION_HOSTINGER.md`
- `PANEL_ADMIN_FIX.md`, `PANEL_COMPLETO_FIX.md`
- `PANEL_USUARIO_FIX.md`, `REGISTRO_FIX.md`
- `REVISION_COMPLETA.md`
- `SQL_100_COMPATIBLE.md`, `SQL_FIX_COMPLETO.md`
- `SQL_FIX_FINAL.md`

#### 📂 `setup/` (12 archivos)
- `setup-automatico.html`, `setup-definitivo.php`
- `setup-demo-data.php`, `setup-final.php`
- `setup-gui.html`, `setup-independiente.php`
- `setup-sencillo.html`, `setup-ultra-simple.php`
- `one-click-setup.php`, `quick-setup.php`
- `auto-fix-db.php`, `fix-and-setup-db.php`
- `init-demo-data.php`, `insertar-datos-prueba.php`
- `insertar-datos-uno-por-uno.php`

#### 📂 `pages/` (10 archivos)
- `index.html`, `carrito.html`, `checkout.html`
- `login.html`, `registro.html`, `producto.html`
- `favoritos.html`, `repair-db.html`
- `panel-admin.html`, `panel-usuario.html`
- `panel-vendedor.html`

#### 📂 `tests/` (6 archivos)
- `test-api.php`, `test-db-connection.php`
- `test-db.php`, `test-demo-data.php`
- `test-demo-data-corregido.php`, `check-db.php`
- `debug-info.php`, `diagnose-db.php`
- `verificacion-final.php`, `verificar-db.php`

#### 📂 `scripts/` (2 archivos)
- `api.php`, `verificacion-final.php`

### ⚠️ Importante - Actualizar Referencias

Después de mover los archivos, necesitarás actualizar las referencias en el código:

1. **Enlaces en HTML**: Cambiar rutas relativas
2. **Includes en PHP**: Actualizar `include` y `require`
3. **Referencias en JavaScript**: Actualizar URLs de API
4. **Enlaces en documentación**: Actualizar paths

### 📋 Verificación

Para verificar que todo esté correcto:

```powershell
# Listar contenido de cada directorio
Get-ChildItem -Directory | ForEach-Object {
    Write-Host "📂 $($_.Name)/" -ForegroundColor Cyan
    Get-ChildItem $_.FullName | Select-Object Name
    Write-Host ""
}
```

### 🎯 Beneficios de la Nueva Estructura

1. **📁 Mejor organización** - Archivos agrupados por función
2. **🔍 Fácil navegación** - Encontrar archivos rápidamente
3. **🧹 Directorio raíz limpio** - Solo directorios organizados
4. **📚 Mantenimiento simple** - Estructura escalable
5. **🔄 Desarrollo eficiente** - Workflow más profesional

### ❓ ¿Necesitas Ayuda?

Si encuentras algún problema durante la reorganización:

1. **Revisa** que todos los archivos se movieron correctamente
2. **Verifica** que no haya enlaces rotos en el código
3. **Prueba** que el proyecto sigue funcionando
4. **Consulta** la documentación en `docs/`

¡La reorganización mejorará significativamente la mantenibilidad de tu proyecto! 🎉
