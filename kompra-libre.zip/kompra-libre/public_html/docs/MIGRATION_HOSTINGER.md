# Migración a Hostinger

## Instrucciones para desplegar en Hostinger

### 1. Crear la base de datos en Hostinger

1. Ve al panel de control de Hostinger (hPanel)
2. Busca "Bases de datos MySQL" en el menú
3. Crea una nueva base de datos con el nombre: `u472738607_kompra_libre`
4. Crea un nuevo usuario de base de datos (o usa el existente)
5. Asigna todos los privilegios al usuario para la base de datos

### 2. Subir archivos al servidor

**IMPORTANTE:** En Hostinger, el directorio raíz es `public_html/`, no `public/`.

Sube todos los archivos de tu proyecto a `public_html/` manteniendo esta estructura:

```
public_html/
├── .htaccess
├── api.php
├── index.html
├── carrito.html
├── checkout.html
├── login.html
├── registro.html
├── producto.html
├── css/
├── js/
├── img/
├── api/
│   ├── auth/
│   ├── cart/
│   ├── orders/
│   └── products/
└── includes/
    ├── config.php
    ├── db.php
    └── functions.php
```

### 3. Ejecutar el schema de la base de datos

1. Ve a PHPMyAdmin en Hostinger
2. Selecciona la base de datos `u472738607_kompra_libre`
3. Ejecuta el contenido del archivo `sql/schema_hostinger.sql`

### 4. Verificar configuración

Asegúrate de que el archivo `includes/config.php` tenga la configuración correcta:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'u472738607_kompra_libre');
define('DB_USER', 'u472738607_kompra_libre');
define('DB_PASS', 'tu_contraseña_real');
define('APP_URL', 'https://kompralibre.shop/');
```

### 5. Crear directorio de uploads

Crea el directorio `public_html/uploads/` y asigna permisos 755:
```bash
mkdir uploads
chmod 755 uploads
```

### 6. Probar el sitio

Una vez subidos todos los archivos y ejecutado el schema:

1. Visita `https://kompralibre.shop/`
2. Regístrate como usuario
3. Prueba crear productos si eres vendedor
4. Verifica que el carrito funcione correctamente

## Archivos modificados para Hostinger

### Archivos de configuración actualizados:
- `includes/config.php` - Credenciales de Hostinger y URL del sitio
- `includes/db.php` - Conexión a base de datos
- `api.php` - Configuración de base de datos hardcodeada
- `.htaccess` - Reglas de reescritura para estructura public_html

### Archivos frontend actualizados:
- `index.html` - Rutas relativas para CSS, JS e imágenes
- `carrito.html` - Rutas API y enlaces actualizados
- `registro.html` - URLs hardcodeadas y rutas de redirección
- `login.html` - Rutas de enlaces actualizadas

### Archivos JavaScript actualizados:
- `js/app.js` - Rutas API para categorías y productos
- `js/login.js` - Rutas de API y redirección
- `js/registro.js` - Rutas de API y enlaces
- `js/utils.js` - Funciones API (ya estaban correctas)

### Archivos API:
- Todos los archivos en `api/` usan la configuración centralizada desde `includes/`
- No requieren cambios adicionales

## Notas importantes

1. **Rutas absolutas vs relativas**: Cambié todas las rutas de `/ruta` a `ruta` para que funcionen en Hostinger
2. **Base de datos**: El schema no incluye `CREATE DATABASE` ya que Hostinger no permite esa operación
3. **Permisos**: Asegúrate de que el directorio `uploads/` tenga permisos de escritura
4. **SSL**: Hostinger maneja HTTPS automáticamente, pero verifica que tu sitio sea accesible por HTTPS

## Solución de problemas

Si encuentras errores:

1. **Error 404**: Verifica que `.htaccess` esté correctamente configurado
2. **Error de conexión DB**: Revisa las credenciales en `config.php`
3. **Archivos no encontrados**: Asegúrate de que todos los archivos estén en `public_html/`
4. **Problemas de permisos**: Verifica permisos en directorios y archivos

## URLs importantes

- **Sitio principal**: https://kompralibre.shop/
- **API endpoints**: https://kompralibre.shop/api/*
- **Panel de administración**: https://kompralibre.shop/panel-admin.html
