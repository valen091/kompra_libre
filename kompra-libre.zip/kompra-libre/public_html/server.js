import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import cors from 'cors';
import morgan from 'morgan';

// Configuración de rutas de archivos
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PUBLIC_DIR = path.join(__dirname);  // Raíz del proyecto (public_html)
const UPLOADS_DIR = path.join(__dirname, 'uploads');

// Crear la aplicación Express
const app = express();

// Configuración CORS
const corsOptions = {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    exposedHeaders: ['set-cookie']
};

// Middlewares básicos
app.use(morgan('dev'));
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));

// Configuración de body parser
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Configuración de cookies
app.use(cookieParser(process.env.COOKIE_SECRET || 'kompra-libre-secret'));

// Configuración de archivos estáticos
app.use(express.static(PUBLIC_DIR, {
    etag: true,
    maxAge: '1d',
    setHeaders: (res, path) => {
        if (path.endsWith('.html')) {
            res.setHeader('Cache-Control', 'no-cache');
        } else {
            res.setHeader('Cache-Control', 'public, max-age=86400');
        }
    }
}));

// Servir archivos CSS
app.use('/css', express.static(path.join(PUBLIC_DIR, 'css'), {
    maxAge: '7d',
    setHeaders: (res, path) => {
        res.setHeader('Cache-Control', 'public, max-age=604800');
    }
}));

// Servir archivos JS
app.use('/js', express.static(path.join(PUBLIC_DIR, 'js'), {
    maxAge: '7d',
    setHeaders: (res, path) => {
        res.setHeader('Cache-Control', 'public, max-age=604800');
    }
}));

// Servir imágenes
app.use('/img', express.static(path.join(PUBLIC_DIR, 'img'), {
    maxAge: '30d',
    setHeaders: (res, path) => {
        res.setHeader('Cache-Control', 'public, max-age=2592000');
    }
}));

// Servir assets
app.use('/assets', express.static(path.join(PUBLIC_DIR, 'assets'), {
    maxAge: '30d',
    setHeaders: (res, path) => {
        res.setHeader('Cache-Control', 'public, max-age=2592000');
    }
}));

// Rutas para las páginas HTML
app.get('/', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// Servir archivos HTML de la carpeta views
app.get('/views/:page', (req, res) => {
    const page = req.params.page;
    const filePath = path.join(PUBLIC_DIR, 'views', page);
    
    // Verificar si el archivo existe
    if (fs.existsSync(filePath)) {
        res.sendFile(filePath);
    } else {
        res.status(404).send('Página no encontrada');
    }
});

// Ruta directa para login
app.get('/login', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'views', 'nuevo-login.html'));
});

// Ruta directa para registro
app.get('/registro', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'views', 'registro.html'));
});

// Ruta directa para carrito
app.get('/carrito', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'views', 'carrito.html'));
});

// Ruta directa para favoritos
app.get('/favoritos', (req, res) => {
    res.sendFile(path.join(PUBLIC_DIR, 'views', 'favoritos.html'));
});

// Ruta para archivos en el directorio views
app.get('/views/:file', (req, res) => {
    const file = req.params.file;
    res.sendFile(path.join(PUBLIC_DIR, 'views', file), (err) => {
        if (err) {
            console.error(`Error al cargar el archivo: ${file}`, err);
            res.status(404).send('Página no encontrada');
        }
    });
});

// Ruta de salud
app.get('/api/health', (req, res) => {
    res.json({ 
        success: true,
        message: 'Servidor funcionando correctamente',
        timestamp: new Date().toISOString()
    });
});

// Manejo de errores 404
app.use((req, res) => {
    res.status(404).send('Página no encontrada');
});

// Iniciar el servidor
const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
