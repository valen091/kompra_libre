<?php
// Test file to check permissions and user context
header('Content-Type: text/plain');

echo "Current user: " . get_current_user() . "\n";
echo "Process user: " . (function_exists('posix_getpwuid') ? posix_getpwuid(posix_geteuid())['name'] : 'posix extension not available') . "\n";

echo "\nChecking permissions for config.php:\n";
$configFile = __DIR__ . '/includes/config.php';

echo "File exists: " . (file_exists($configFile) ? 'Yes' : 'No') . "\n";
echo "Is readable: " . (is_readable($configFile) ? 'Yes' : 'No') . "\n";
echo "Last error: " . error_get_last()['message'] ?? 'None' . "\n";

// Try to include the file
echo "\nTrying to include the file...\n";
@include_once $configFile;

echo "\nIncluded successfully!\n";
?>
