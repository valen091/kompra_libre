<?php
// Iniciar la sesión
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: /auth/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Verificar si el usuario tiene permiso para acceder al dashboard
$user_role = $_SESSION['user_role'] ?? 'user';
if (!in_array($user_role, ['admin', 'vendedor'])) {
    header('HTTP/1.0 403 Forbidden');
    die('Acceso denegado. No tienes permiso para acceder a esta sección.');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Control - Kompra Libre</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <div class="bg-gray-800 text-white w-64 p-4">
            <div class="text-xl font-bold mb-8">Kompra Libre</div>
            <nav>
                <a href="/dashboard/" class="block py-2 px-4 bg-gray-700 rounded mb-2">Inicio</a>
                <a href="/perfil/" class="block py-2 px-4 hover:bg-gray-700 rounded mb-2">Mi Perfil</a>
                <a href="/auth/logout.php" class="block py-2 px-4 hover:bg-gray-700 rounded">Cerrar Sesión</a>
            </nav>
        </div>
        
        <!-- Main Content -->
        <div class="flex-1 p-8">
            <h1 class="text-2xl font-bold mb-6">Bienvenido al Panel de Control</h1>
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h2 class="text-xl font-semibold mb-4">Resumen</h2>
                <p>Bienvenido, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Usuario'); ?> (<?php echo htmlspecialchars($user_role); ?>)</p>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <h3 class="font-medium text-blue-800">Ventas del Mes</h3>
                        <p class="text-2xl font-bold">$0.00</p>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg">
                        <h3 class="font-medium text-green-800">Órdenes</h3>
                        <p class="text-2xl font-bold">0</p>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg">
                        <h3 class="font-medium text-yellow-800">Productos</h3>
                        <p class="text-2xl font-bold">0</p>
                    </div>
                </div>
                
                <!-- Sección de acciones rápidas -->
                <div class="mt-8">
                    <h3 class="text-lg font-semibold mb-4">Acciones Rápidas</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <a href="/dashboard/productos/nuevo" class="bg-blue-50 hover:bg-blue-100 text-blue-800 p-4 rounded-lg text-center">
                            <i class="fas fa-plus-circle text-2xl mb-2"></i>
                            <p>Nuevo Producto</p>
                        </a>
                        <a href="/dashboard/ordenes" class="bg-green-50 hover:bg-green-100 text-green-800 p-4 rounded-lg text-center">
                            <i class="fas fa-shopping-cart text-2xl mb-2"></i>
                            <p>Ver Órdenes</p>
                        </a>
                        <a href="/dashboard/clientes" class="bg-purple-50 hover:bg-purple-100 text-purple-800 p-4 rounded-lg text-center">
                            <i class="fas fa-users text-2xl mb-2"></i>
                            <p>Clientes</p>
                        </a>
                        <a href="/dashboard/reportes" class="bg-yellow-50 hover:bg-yellow-100 text-yellow-800 p-4 rounded-lg text-center">
                            <i class="fas fa-chart-bar text-2xl mb-2"></i>
                            <p>Reportes</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Script para manejar el menú móvil
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            
            if (mobileMenuButton && mobileMenu) {
                mobileMenuButton.addEventListener('click', function() {
                    mobileMenu.classList.toggle('hidden');
                });
            }
        });
    </script>
</body>
</html>
