                </div>
            </main>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
        <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="text-sm text-gray-500 dark:text-gray-400">
                    &copy; <?php echo date('Y'); ?> Kompra Libre. Todos los derechos reservados.
                </div>
                <div class="mt-2 md:mt-0">
                    <p class="text-sm text-gray-500 dark:text-gray-400">
                        Versión 1.0.0
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Dark mode toggle script -->
    <script>
        // Dark mode toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        const darkModeIcon = document.getElementById('darkModeIcon');
        const moonIcon = document.getElementById('moonIcon');
        const sunIcon = document.getElementById('sunIcon');
        
        darkModeToggle.addEventListener('click', function() {
            // Toggle dark mode class
            if (document.documentElement.classList.contains('dark')) {
                document.documentElement.classList.remove('dark');
                localStorage.theme = 'light';
                moonIcon.classList.add('hidden');
                sunIcon.classList.remove('hidden');
            } else {
                document.documentElement.classList.add('dark');
                localStorage.theme = 'dark';
                sunIcon.classList.add('hidden');
                moonIcon.classList.remove('hidden');
            }
        });
        
        // Initialize dark mode based on user preference or system preference
        if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        } else {
            document.documentElement.classList.remove('dark');
            moonIcon.classList.add('hidden');
            sunIcon.classList.remove('hidden');
        }
        
        // Initialize Alpine.js for mobile menu
        document.addEventListener('alpine:init', () => {
            Alpine.data('mobileMenuOpen', false);
        });
    </script>
    
    <!-- Custom scripts -->
    <script src="/js/dashboard.js"></script>
</body>
</html>
