# Read the SQL file content
$sqlFile = "c:\xampp\htdocs\kompra-libre\public_html\database\postgresql\cleaned_kompra_libre_v2.sql"
$content = Get-Content -Path $sqlFile -Raw

# Perform replacements
$replacements = @{
    "COMMENT '([^']*)'" = "-- `$1"
    "AUTO_INCREMENT" = "GENERATED ALWAYS AS IDENTITY"
    "INT\(11\)" = "INTEGER"
    "TINYINT\(1\)" = "BOOLEAN"
    "DATETIME" = "TIMESTAMP"
    "ENGINE=InnoDB" = ""
    "DEFAULT CHARSET=utf8mb4" = ""
    "COLLATE utf8mb4_unicode_ci" = ""
    "ON UPDATE CURRENT_TIMESTAMP" = ""
    "DEFAULT NULL" = ""
    "UNSIGNED" = ""
    "CHARACTER SET utf8mb4" = ""
}

foreach ($key in $replacements.Keys) {
    $content = $content -replace $key, $replacements[$key]
}

# Save the updated content
$content | Set-Content -Path $sqlFile -NoNewline

Write-Host "SQL file has been updated successfully."
