<?php
// Script de prueba para el endpoint de registro
require_once 'public_html/includes/config.php';

echo "=== PRUEBA DEL ENDPOINT DE REGISTRO ===\n\n";

// Verificar configuración
echo "1. Configuración de BD:\n";
echo "   Host: " . DB_HOST . "\n";
echo "   Base: " . DB_NAME . "\n";
echo "   User: " . DB_USER . "\n";
echo "   Debug: " . (APP_DEBUG ? 'true' : 'false') . "\n\n";

// Probar conexión a BD
try {
    require_once 'public_html/includes/db.php';
    $db = getDB();

    echo "2. Conexión a BD: ✅ Exitosa\n";

    // Verificar tablas
    $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "3. Tablas encontradas: " . count($tables) . "\n";
    foreach ($tables as $table) {
        echo "   - $table\n";
    }

    // Verificar estructura de tabla users
    if (in_array('users', $tables)) {
        $columns = $db->query("DESCRIBE users")->fetchAll(PDO::FETCH_COLUMN);
        echo "\n4. Estructura de tabla 'users':\n";
        foreach ($columns as $column) {
            echo "   - $column\n";
        }
    }

} catch (Exception $e) {
    echo "2. Conexión a BD: ❌ Error\n";
    echo "   Error: " . $e->getMessage() . "\n";
    echo "   Código: " . $e->getCode() . "\n";
}

echo "\n=== FIN DE PRUEBA ===\n";
?>
