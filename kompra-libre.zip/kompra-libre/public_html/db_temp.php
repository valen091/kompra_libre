<?php
/**
 * Manejo de la conexión a la base de datos
 */

// Incluir configuración
require_once __DIR__ . '/includes/config.php';

/**
 * Clase Database para manejar la conexión a la base de datos
 */
class Database {
    private static $instance = null;
    private $connection;
    
    /**
     * Constructor privado para evitar instanciación directa
     */
    private function __construct() {
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                DB_HOST,
                DB_PORT,
                DB_NAME
            );
            
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_PERSISTENT         => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];
            
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
            
        } catch (PDOException $e) {
            // Registrar el error
            error_log('Error de conexión a la base de datos: ' . $e->getMessage());
            
            // Mostrar mensaje amigable en producción
            if (getenv('APP_ENV') === 'production') {
                error_log('Database connection error: ' . $e->getMessage());
                die('Error de conexión con la base de datos. Por favor, intente más tarde o contacte al administrador.');
            } else {
                die('Error de conexión: ' . $e->getMessage() . 
                    '\nHost: ' . getenv('DB_HOST') . 
                    '\nDatabase: ' . getenv('DB_NAME'));
            }
        }
    }
    
    /**
     * Obtener instancia única de la base de datos (Singleton)
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Obtener la conexión PDO
     */
    public function getConnection() {
        return $this->connection;
    }
    
    // Prevenir la clonación del objeto
    private function __clone() {}
    
    // Prevenir la deserialización del objeto
    private function __wakeup() {}
}

/**
 * Función auxiliar para obtener la conexión a la base de datos
 * 
 * @return PDO Instancia de la conexión PDO
 */
function getDB() {
    return Database::getInstance()->getConnection();
}

// Probar la conexión al incluir este archivo
if (php_sapi_name() === 'cli' && basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    try {
        $db = getDB();
        echo "✅ Conexión a la base de datos exitosa!\n";
        
        // Probar consulta básica
        $stmt = $db->query('SELECT 1 as test');
        $result = $stmt->fetch();
        echo "✅ Consulta de prueba exitosa. Resultado: " . json_encode($result, JSON_PRETTY_PRINT) . "\n";
        
    } catch (PDOException $e) {
        echo "❌ Error de conexión: " . $e->getMessage() . "\n";
    }
}
