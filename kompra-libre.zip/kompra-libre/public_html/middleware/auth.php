<?php
function verificarAutenticacion() {
    // Obtener el token del encabezado de autorización
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';
    
    // Verificar si el encabezado de autorización existe y tiene el formato correcto
    if (!preg_match('/Bearer\s(.*)/', $authHeader, $matches)) {
        return null;
    }
    
    $token = $matches[1];
    
    try {
        // Decodificar el token JWT
        $secretKey = getenv('JWT_SECRET') ?: 'tu_clave_secreta_por_defecto';
        $decoded = \Firebase\JWT\JWT::decode($token, $secretKey, ['HS256']);
        
        // Verificar si el token ha expirado
        $now = new DateTimeImmutable();
        if (isset($decoded->exp) && $decoded->exp < $now->getTimestamp()) {
            return null;
        }
        
        // Devolver los datos del usuario
        return [
            'id' => $decoded->sub,
            'email' => $decoded->email,
            'rol' => $decoded->rol ?? 'usuario'
        ];
        
    } catch (Exception $e) {
        error_log('Error al verificar el token: ' . $e->getMessage());
        return null;
    }
}

// Función para generar un token JWT
function generarTokenJWT($usuario) {
    $secretKey = getenv('JWT_SECRET') ?: 'tu_clave_secreta_por_defecto';
    $issuedAt = new DateTimeImmutable();
    $expire = $issuedAt->modify('+24 hours')->getTimestamp();
    
    $payload = [
        'iat' => $issuedAt->getTimestamp(),
        'iss' => 'kompra-libre',
        'nbf' => $issuedAt->getTimestamp(),
        'exp' => $expire,
        'sub' => $usuario['id'],
        'email' => $usuario['email'],
        'rol' => $usuario['rol'] ?? 'usuario'
    ];
    
    return \Firebase\JWT\JWT::encode($payload, $secretKey, 'HS256');
}
