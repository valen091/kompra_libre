<?php
// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is authenticated and has seller role
function isSellerAuthenticated() {
    // Check new session format first
    if (isset($_SESSION['user']) && is_array($_SESSION['user'])) {
        return ($_SESSION['user']['role'] === 'vendedor');
    } 
    // Fallback to legacy session format
    elseif (isset($_SESSION['user_role'])) {
        return ($_SESSION['user_role'] === 'vendedor');
    }
    return false;
}

// Redirect to login if not authenticated as seller
if (!isSellerAuthenticated()) {
    $_SESSION['login_redirect'] = $_SERVER['REQUEST_URI'];
    header('Location: /auth/login?error=no_seller_access');
    exit();
}

// Make user data available to all views
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
} else {
    // Fallback to legacy session variables
    $user = [
        'id' => $_SESSION['user_id'] ?? null,
        'name' => $_SESSION['user_name'] ?? 'Usuario',
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'cliente'
    ];
    $_SESSION['user'] = $user; // Update to new format
}

// Make $user available in all included files
return $user;
