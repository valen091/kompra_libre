<?php
// Script para crear base de datos y tablas
try {
    echo "=== CREANDO BASE DE DATOS Y TABLAS ===\n\n";

    // Conectar sin especificar base de datos
    $pdo = new PDO("mysql:host=localhost;charset=utf8", 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "1. Conexión a MySQL exitosa\n";

    // Verificar si la base de datos existe
    $databases = $pdo->query("SHOW DATABASES")->fetchAll(PDO::FETCH_COLUMN);

    if (!in_array('kompra_libre', $databases)) {
        echo "2. Creando base de datos 'kompra_libre'...\n";
        $pdo->exec("CREATE DATABASE kompra_libre CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        echo "   ✅ Base de datos creada\n";
    } else {
        echo "2. Base de datos 'kompra_libre' ya existe\n";
    }

    // Seleccionar la base de datos
    $pdo->exec("USE kompra_libre");
    echo "3. Base de datos seleccionada\n";

    // Verificar tablas existentes
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "4. Tablas existentes: " . count($tables) . "\n";
    foreach ($tables as $table) {
        echo "   - $table\n";
    }

    // Crear tabla users si no existe
    if (!in_array('users', $tables)) {
        echo "\n5. Creando tabla 'users'...\n";
        $pdo->exec("
            CREATE TABLE users (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                role ENUM('buyer', 'seller', 'admin') DEFAULT 'buyer',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "   ✅ Tabla 'users' creada\n";
    } else {
        echo "\n5. Tabla 'users' ya existe\n";
    }

    // Crear tabla sellers si no existe
    if (!in_array('sellers', $tables)) {
        echo "6. Creando tabla 'sellers'...\n";
        $pdo->exec("
            CREATE TABLE sellers (
                id INT PRIMARY KEY AUTO_INCREMENT,
                user_id INT UNIQUE NOT NULL,
                shop_alias VARCHAR(255) NOT NULL,
                description TEXT,
                business_type ENUM('individual', 'company') DEFAULT 'individual',
                tax_id VARCHAR(50),
                business_address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "   ✅ Tabla 'sellers' creada\n";
    } else {
        echo "6. Tabla 'sellers' ya existe\n";
    }

    echo "\n✅ ¡CONFIGURACIÓN COMPLETADA EXITOSAMENTE!\n";
    echo "   Base de datos: kompra_libre\n";
    echo "   Usuario: root\n";
    echo "   Password: (vacío)\n";
    echo "\n   El endpoint debería funcionar ahora.\n";

} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    echo "   Código: " . $e->getCode() . "\n";
}
?>
