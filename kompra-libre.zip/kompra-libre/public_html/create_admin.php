<?php
// Conectar a la base de datos
try {
    $pdo = new PDO('mysql:host=localhost;dbname=u472738607_kompra_libre', 'u472738607_kompralibre', 'Kompralibre1');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Crear usuario admin si no existe
    $email = 'admin@kompralibre.com';
    $password = password_hash('password123', PASSWORD_DEFAULT);
    $nombre = 'Administrador';
    
    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'admin') ON DUPLICATE KEY UPDATE rol='admin'");
    $stmt->execute([$nombre, $email, $password]);
    
    echo "Usuario administrador creado/actualizado exitosamente.\n";
    echo "Email: admin@kompralibre.com\n";
    echo "Contraseña: password123\n";
    
} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
