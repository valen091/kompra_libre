<?php
// Script para verificar y crear tablas necesarias
require_once 'public_html/includes/config.php';
require_once 'public_html/includes/db.php';

try {
    $db = getDB();

    echo "Conexión a BD exitosa\n";
    echo "Base de datos: " . DB_NAME . "\n\n";

    // Verificar tablas existentes
    $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "Tablas existentes:\n";
    foreach ($tables as $table) {
        echo "- $table\n";
    }
    echo "\n";

    // Verificar si existe tabla users
    if (!in_array('users', $tables)) {
        echo "Creando tabla 'users'...\n";
        $db->exec("
            CREATE TABLE users (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                role ENUM('buyer', 'seller', 'admin') DEFAULT 'buyer',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ");
        echo "Tabla 'users' creada exitosamente\n";
    } else {
        echo "Tabla 'users' ya existe\n";
    }

    // Verificar si existe tabla sellers
    if (!in_array('sellers', $tables)) {
        echo "Creando tabla 'sellers'...\n";
        $db->exec("
            CREATE TABLE sellers (
                id INT PRIMARY KEY AUTO_INCREMENT,
                user_id INT UNIQUE NOT NULL,
                shop_alias VARCHAR(255) NOT NULL,
                description TEXT,
                business_type ENUM('individual', 'company') DEFAULT 'individual',
                tax_id VARCHAR(50),
                business_address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ");
        echo "Tabla 'sellers' creada exitosamente\n";
    } else {
        echo "Tabla 'sellers' ya existe\n";
    }

    echo "\n✅ Verificación completada exitosamente!\n";

} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "Código de error: " . $e->getCode() . "\n";
}
?>
