# Script de limpieza final - Kompra Libre (PowerShell)
Write-Host "🧹 Limpiando archivos temporales..." -ForegroundColor Green

# Archivos a eliminar
$tempFiles = @(
    "backup-and-revert.ps1",
    "complete-reorganize.ps1",
    "reorganize-files-simple.ps1",
    "reorganize-files.ps1",
    "reorganize-files.sh",
    "REORGANIZAR-LEEME.md"
)

foreach ($file in $tempFiles) {
    if (Test-Path $file) {
        Remove-Item $file -ErrorAction SilentlyContinue
        Write-Host "✅ Eliminado: $file" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "🎉 Limpieza completada!" -ForegroundColor Green
Write-Host ""
Write-Host "📋 Estructura final limpia:" -ForegroundColor Cyan
Write-Host "📂 config/  - Archivos de configuración" -ForegroundColor White
Write-Host "📂 docs/    - Documentación completa" -ForegroundColor White
Write-Host "📂 setup/   - Scripts de instalación" -ForegroundColor White
Write-Host "📂 pages/   - Páginas HTML" -ForegroundColor White
Write-Host "📂 tests/   - Scripts de prueba" -ForegroundColor White
Write-Host "📂 scripts/ - API y utilitarios" -ForegroundColor White
Write-Host ""
Write-Host "🚀 ¡Proyecto listo para usar!" -ForegroundColor Green
