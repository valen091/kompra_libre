-- Script de migración a PostgreSQL para Kompra Libre Uruguay
-- Versión: 1.0
-- Fecha: 2025-03-05

-- Configuración inicial
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

-- Crear extensión para UUID si no existe
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =================================================================
-- TABLAS PRINCIPALES
-- =================================================================

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  contrasena_hash VARCHAR(255) NOT NULL,
  rol VARCHAR(20) NOT NULL CHECK (rol IN ('admin', 'vendedor', 'comprador')) DEFAULT 'comprador',
  telefono VARCHAR(20),
  avatar VARCHAR(255),
  email_verificado BOOLEAN DEFAULT FALSE,
  rut VARCHAR(12) UNIQUE,
  direccion TEXT,
  departamento VARCHAR(50),
  ciudad VARCHAR(100),
  codigo_postal VARCHAR(10),
  creado_en TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  ultimo_acceso TIMESTAMP WITH TIME ZONE,
  estado VARCHAR(20) CHECK (estado IN ('activo', 'suspendido', 'eliminado')) DEFAULT 'activo'
);

-- Índices para la tabla de usuarios
CREATE INDEX idx_usuarios_rol ON usuarios(rol);
CREATE INDEX idx_usuarios_estado ON usuarios(estado);

-- Tabla de logs del sistema
CREATE TABLE IF NOT EXISTS logs (
  id SERIAL PRIMARY KEY,
  nivel VARCHAR(20) NOT NULL CHECK (nivel IN ('emergencia', 'alerta', 'critico', 'error', 'advertencia', 'noticia', 'informacion', 'depuracion')),
  mensaje TEXT NOT NULL,
  contexto JSONB,
  usuario_id INTEGER REFERENCES usuarios(id) ON DELETE SET NULL ON UPDATE CASCADE,
  ip VARCHAR(45),
  user_agent VARCHAR(255),
  url VARCHAR(512),
  metodo VARCHAR(10),
  referer VARCHAR(512),
  codigo_estado INTEGER,
  tiempo_ejecucion DECIMAL(10,4),
  consumo_memoria BIGINT,
  creado_en TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para la tabla de logs
CREATE INDEX idx_logs_nivel ON logs(nivel);
CREATE INDEX idx_logs_fecha ON logs(creado_en);
CREATE INDEX idx_logs_usuario_id ON logs(usuario_id);

-- Función para actualizar automáticamente la columna actualizado_en
CREATE OR REPLACE FUNCTION actualizar_timestamp()
RETURNS TRIGGER AS $$
BEGIN
   NEW.actualizado_en = NOW();
   RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para actualizar automáticamente la columna actualizado_en en la tabla usuarios
CREATE TRIGGER actualizar_usuarios_timestamp
BEFORE UPDATE ON usuarios
FOR EACH ROW
EXECUTE FUNCTION actualizar_timestamp();
