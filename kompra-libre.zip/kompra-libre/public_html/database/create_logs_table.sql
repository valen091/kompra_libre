-- Tabla de logs del sistema
CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nivel` enum('emergencia','alerta','critico','error','advertencia','noticia','informacion','depuracion') NOT NULL,
  `mensaje` text NOT NULL,
  `contexto` json DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `url` varchar(512) DEFAULT NULL,
  `metodo` varchar(10) DEFAULT NULL,
  `referer` varchar(512) DEFAULT NULL,
  `codigo_estado` int(11) DEFAULT NULL,
  `tiempo_ejecucion` decimal(10,4) DEFAULT NULL COMMENT 'Tiempo de ejecución en segundos',
  `consumo_memoria` int(11) DEFAULT NULL COMMENT 'Consumo de memoria en bytes',
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_logs_nivel` (`nivel`),
  KEY `idx_logs_fecha` (`creado_en`),
  CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`usuario_id`) 
    REFERENCES `usuarios` (`id`) 
    ON DELETE SET NULL 
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;