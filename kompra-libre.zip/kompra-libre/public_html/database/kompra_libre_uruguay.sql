-- ✅ KOMPRA LIBRE - BASE DE DATOS URUGUAY
-- Versión optimizada y completa para Uruguay
-- Compatible con MySQL 5.7+ y MariaDB 10.0+
-- Creado: 2025-03-05

-- Configuración inicial
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "-03:00";  -- Hora de Uruguay

-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS `u472738607_kompra_libre` 
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `u472738607_kompra_libre`;

-- =================================================================
-- TABLAS PRINCIPALES
-- =================================================================

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `contrasena_hash` varchar(255) NOT NULL,
  `rol` enum('admin','vendedor','comprador') NOT NULL DEFAULT 'comprador',
  `telefono` varchar(20) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `email_verificado` tinyint(1) DEFAULT 0,
  `rut` varchar(12) UNIQUE COMMENT 'RUT uruguayo con formato 12345678-9',
  `direccion` text,
  `departamento` varchar(50) COMMENT 'Departamento de Uruguay',
  `ciudad` varchar(100),
  `codigo_postal` varchar(10),
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ultimo_acceso` datetime DEFAULT NULL,
  `estado` enum('activo','suspendido','eliminado') DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_usuarios_rol` (`rol`),
  KEY `idx_usuarios_estado` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de categorías
CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `descripcion` text,
  `categoria_padre_id` int(11) DEFAULT NULL,
  `icono` varchar(50) DEFAULT 'fas fa-tag',
  `orden` int(11) DEFAULT 0,
  `cantidad_productos` int(11) DEFAULT 0,
  `destacada` tinyint(1) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `categoria_padre_id` (`categoria_padre_id`),
  KEY `idx_categorias_orden` (`orden`),
  KEY `idx_categorias_destacada` (`destacada`),
  CONSTRAINT `categorias_ibfk_1` FOREIGN KEY (`categoria_padre_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de vendedores
CREATE TABLE IF NOT EXISTS `vendedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `alias_tienda` varchar(120) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `descripcion_tienda` text,
  `logo_tienda` varchar(255) DEFAULT NULL,
  `portada_tienda` varchar(255) DEFAULT NULL,
  `puntuacion` decimal(3,2) DEFAULT 5.00,
  `ventas_totales` int(11) DEFAULT 0,
  `total_productos` int(11) DEFAULT 0,
  `verificado` tinyint(1) DEFAULT 0,
  `rut_empresa` varchar(12) COMMENT 'RUT de la empresa',
  `direccion_fiscal` text,
  `telefono_contacto` varchar(20),
  `horario_atencion` varchar(100) DEFAULT 'Lunes a Viernes de 9:00 a 18:00',
  `politicas` text COMMENT 'Políticas de la tienda',
  `redes_sociales` json DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `estado` enum('activo','pendiente','suspendido') DEFAULT 'pendiente',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario_id` (`usuario_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_vendedores_estado` (`estado`),
  KEY `idx_vendedores_verificado` (`verificado`),
  CONSTRAINT `vendedores_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de productos
CREATE TABLE IF NOT EXISTS `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendedor_id` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `descripcion` text,
  `descripcion_corta` varchar(500) DEFAULT NULL,
  `precio` decimal(12,2) NOT NULL,
  `precio_original` decimal(12,2) DEFAULT NULL,
  `costo` decimal(12,2) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `stock_minimo` int(11) DEFAULT 5,
  `sku` varchar(100) DEFAULT NULL,
  `codigo_barras` varchar(100) DEFAULT NULL,
  `condicion` enum('nuevo','usado','reacondicionado') DEFAULT 'nuevo',
  `categoria_id` int(11) DEFAULT NULL,
  `subcategoria_id` int(11) DEFAULT NULL,
  `marca` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `peso_kg` decimal(8,3) DEFAULT NULL,
  `largo_cm` decimal(8,2) DEFAULT NULL,
  `ancho_cm` decimal(8,2) DEFAULT NULL,
  `alto_cm` decimal(8,2) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT 1,
  `destacado` tinyint(1) DEFAULT 0,
  `contador_vistas` int(11) DEFAULT 0,
  `contador_ventas` int(11) DEFAULT 0,
  `calificacion_promedio` decimal(3,2) DEFAULT 0.00,
  `cantidad_calificaciones` int(11) DEFAULT 0,
  `incluye_iva` tinyint(1) DEFAULT 1 COMMENT '1 = Precio incluye IVA, 0 = Precio no incluye IVA',
  `garantia_meses` int(11) DEFAULT 12,
  `etiquetas` json DEFAULT NULL,
  `atributos` json DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `estado` enum('activo','inactivo','agotado','eliminado') DEFAULT 'activo',
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `sku` (`sku`),
  KEY `vendedor_id` (`vendedor_id`),
  KEY `categoria_id` (`categoria_id`),
  KEY `subcategoria_id` (`subcategoria_id`),
  KEY `idx_productos_visible` (`visible`),
  KEY `idx_productos_destacado` (`destacado`),
  KEY `idx_productos_precio` (`precio`),
  KEY `idx_productos_estado` (`estado`),
  FULLTEXT KEY `ft_productos_busqueda` (`titulo`,`descripcion`,`descripcion_corta`,`marca`,`modelo`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`vendedor_id`) REFERENCES `vendedores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `productos_ibfk_3` FOREIGN KEY (`subcategoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de imágenes de productos
CREATE TABLE IF NOT EXISTS `imagenes_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `ruta_imagen` varchar(255) NOT NULL,
  `texto_alternativo` varchar(255) DEFAULT NULL,
  `titulo` varchar(200) DEFAULT NULL,
  `descripcion` text,
  `orden` int(11) DEFAULT 0,
  `es_principal` tinyint(1) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `idx_imagenes_orden` (`orden`),
  KEY `idx_imagenes_principal` (`es_principal`),
  CONSTRAINT `imagenes_productos_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de variantes de productos
CREATE TABLE IF NOT EXISTS `variantes_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL COMMENT 'Ej: Color, Talla, etc.',
  `valor` varchar(100) NOT NULL COMMENT 'Ej: Rojo, Azul, S, M, L, etc.',
  `precio_adicional` decimal(10,2) DEFAULT 0.00,
  `sku` varchar(100) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `codigo_barras` varchar(100) DEFAULT NULL,
  `imagen_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `imagen_id` (`imagen_id`),
  CONSTRAINT `variantes_productos_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variantes_productos_ibfk_2` FOREIGN KEY (`imagen_id`) REFERENCES `imagenes_productos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de atributos de productos
CREATE TABLE IF NOT EXISTS `atributos_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `valor` text NOT NULL,
  `orden` int(11) DEFAULT 0,
  `visible` tinyint(1) DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `idx_atributos_orden` (`orden`),
  CONSTRAINT `atributos_productos_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de departamentos de Uruguay
CREATE TABLE IF NOT EXISTS `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `codigo` varchar(3) NOT NULL,
  `capital` varchar(50) NOT NULL,
  `superficie_km2` int(11) DEFAULT NULL,
  `poblacion` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `idx_departamentos_nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de localidades/ciudades
CREATE TABLE IF NOT EXISTS `localidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `departamento_id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `codigo_postal` varchar(10) DEFAULT NULL,
  `es_capital` tinyint(1) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `departamento_id` (`departamento_id`),
  KEY `idx_localidades_nombre` (`nombre`),
  CONSTRAINT `localidades_ibfk_1` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de zonas de envío
CREATE TABLE IF NOT EXISTS `zonas_envio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `tipo` enum('nacional','regional','local') NOT NULL DEFAULT 'nacional',
  `departamento_id` int(11) DEFAULT NULL,
  `localidad_id` int(11) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `dias_habiles_min` int(11) DEFAULT 2,
  `dias_habiles_max` int(11) DEFAULT 5,
  `costo_adicional` decimal(10,2) DEFAULT 0.00,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `departamento_id` (`departamento_id`),
  KEY `localidad_id` (`localidad_id`),
  KEY `idx_zonas_envio_activo` (`activo`),
  CONSTRAINT `zonas_envio_ibfk_1` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `zonas_envio_ibfk_2` FOREIGN KEY (`localidad_id`) REFERENCES `localidades` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de métodos de envío
CREATE TABLE IF NOT EXISTS `metodos_envio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `tipo` enum('estandar','express','retiro','gratis') NOT NULL DEFAULT 'estandar',
  `costo_base` decimal(10,2) NOT NULL DEFAULT 0.00,
  `costo_gratis_desde` decimal(10,2) DEFAULT NULL,
  `peso_maximo_kg` decimal(8,3) DEFAULT NULL,
  `dimensiones_maximas` varchar(50) DEFAULT NULL,
  `dias_habiles_min` int(11) DEFAULT 2,
  `dias_habiles_max` int(11) DEFAULT 5,
  `activo` tinyint(1) DEFAULT 1,
  `requiere_direccion` tinyint(1) DEFAULT 1,
  `permite_retiro` tinyint(1) DEFAULT 0,
  `direccion_retiro` text,
  `horario_retiro` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_metodos_envio_activo` (`activo`),
  KEY `idx_metodos_envio_tipo` (`tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de zonas de cobertura por método de envío
CREATE TABLE IF NOT EXISTS `metodos_envio_zonas` (
  `metodo_envio_id` int(11) NOT NULL,
  `zona_id` int(11) NOT NULL,
  `costo_adicional` decimal(10,2) DEFAULT 0.00,
  `dias_adicionales` int(11) DEFAULT 0,
  `disponible` tinyint(1) DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`metodo_envio_id`, `zona_id`),
  KEY `zona_id` (`zona_id`),
  CONSTRAINT `metodos_envio_zonas_ibfk_1` FOREIGN KEY (`metodo_envio_id`) REFERENCES `metodos_envio` (`id`) ON DELETE CASCADE,
  CONSTRAINT `metodos_envio_zonas_ibfk_2` FOREIGN KEY (`zona_id`) REFERENCES `zonas_envio` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de direcciones de usuarios
CREATE TABLE IF NOT EXISTS `direcciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `nombre_completo` varchar(200) NOT NULL,
  `documento` varchar(20) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `direccion` text NOT NULL,
  `referencia` text,
  `codigo_postal` varchar(10) DEFAULT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `localidad_id` int(11) DEFAULT NULL,
  `localidad_nombre` varchar(100) DEFAULT NULL,
  `es_principal` tinyint(1) DEFAULT 0,
  `es_facturacion` tinyint(1) DEFAULT 0,
  `es_envio` tinyint(1) DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `departamento_id` (`departamento_id`),
  KEY `localidad_id` (`localidad_id`),
  KEY `idx_direcciones_principal` (`es_principal`),
  KEY `idx_direcciones_facturacion` (`es_facturacion`),
  CONSTRAINT `direcciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `direcciones_ibfk_2` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `direcciones_ibfk_3` FOREIGN KEY (`localidad_id`) REFERENCES `localidades` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de métodos de pago
CREATE TABLE IF NOT EXISTS `metodos_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `descripcion` text,
  `tipo` enum('tarjeta','transferencia','efectivo','billetera_digital','cuotas_sin_interes','otro') NOT NULL,
  `comision_porcentaje` decimal(5,2) DEFAULT 0.00,
  `comision_fija` decimal(10,2) DEFAULT 0.00,
  `activo` tinyint(1) DEFAULT 1,
  `orden` int(11) DEFAULT 0,
  `icono` varchar(50) DEFAULT NULL,
  `instrucciones` text,
  `configuracion` json DEFAULT NULL,
  `requiere_verificacion` tinyint(1) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `idx_metodos_pago_activo` (`activo`),
  KEY `idx_metodos_pago_orden` (`orden`),
  KEY `idx_metodos_pago_tipo` (`tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de configuraciones de MercadoPago
CREATE TABLE IF NOT EXISTS `configuracion_mercadopago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `access_token` varchar(255) NOT NULL,
  `public_key` varchar(255) NOT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `client_id` varchar(100) DEFAULT NULL,
  `client_secret` varchar(100) DEFAULT NULL,
  `sandbox` tinyint(1) DEFAULT 1,
  `webhook_url` varchar(255) DEFAULT NULL,
  `webhook_id` varchar(100) DEFAULT NULL,
  `fecha_verificacion` datetime DEFAULT NULL,
  `estado` enum('activo','inactivo','pendiente') DEFAULT 'pendiente',
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de pedidos
CREATE TABLE IF NOT EXISTS `pedidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_pedido` varchar(20) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `vendedor_id` int(11) NOT NULL,
  `estado_pedido` enum('pendiente','confirmado','preparando','enviado','entregado','cancelado','reembolsado') DEFAULT 'pendiente',
  `estado_pago` enum('pendiente','pagado_parcial','pagado','reembolsado_parcial','reembolsado','rechazado') DEFAULT 'pendiente',
  `metodo_pago_id` int(11) DEFAULT NULL,
  `metodo_pago_nombre` varchar(100) DEFAULT NULL,
  `metodo_pago_referencia` varchar(255) DEFAULT NULL,
  `metodo_pago_detalles` text,
  `metodo_envio_id` int(11) DEFAULT NULL,
  `metodo_envio_nombre` varchar(100) DEFAULT NULL,
  `metodo_envio_costo` decimal(10,2) DEFAULT 0.00,
  `direccion_envio_id` int(11) DEFAULT NULL,
  `direccion_envio` json DEFAULT NULL,
  `direccion_facturacion_id` int(11) DEFAULT NULL,
  `direccion_facturacion` json DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `descuento` decimal(12,2) DEFAULT 0.00,
  `costo_envio` decimal(10,2) DEFAULT 0.00,
  `impuestos` decimal(12,2) DEFAULT 0.00,
  `total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `moneda` char(3) DEFAULT 'UYU',
  `tipo_cambio` decimal(10,4) DEFAULT 1.0000,
  `notas` text,
  `seguimiento_numero` varchar(100) DEFAULT NULL,
  `seguimiento_url` varchar(255) DEFAULT NULL,
  `fecha_pago` datetime DEFAULT NULL,
  `fecha_envio` datetime DEFAULT NULL,
  `fecha_entrega` datetime DEFAULT NULL,
  `fecha_cancelacion` datetime DEFAULT NULL,
  `motivo_cancelacion` text,
  `ip_cliente` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `facturacion` json DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero_pedido` (`numero_pedido`),
  KEY `usuario_id` (`usuario_id`),
  KEY `vendedor_id` (`vendedor_id`),
  KEY `metodo_pago_id` (`metodo_pago_id`),
  KEY `metodo_envio_id` (`metodo_envio_id`),
  KEY `direccion_envio_id` (`direccion_envio_id`),
  KEY `direccion_facturacion_id` (`direccion_facturacion_id`),
  KEY `idx_pedidos_estado` (`estado_pedido`),
  KEY `idx_pedidos_fecha` (`creado_en`),
  CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`vendedor_id`) REFERENCES `vendedores` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pedidos_ibfk_3` FOREIGN KEY (`metodo_pago_id`) REFERENCES `metodos_pago` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pedidos_ibfk_4` FOREIGN KEY (`metodo_envio_id`) REFERENCES `metodos_envio` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pedidos_ibfk_5` FOREIGN KEY (`direccion_envio_id`) REFERENCES `direcciones` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pedidos_ibfk_6` FOREIGN KEY (`direccion_facturacion_id`) REFERENCES `direcciones` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de ítems de pedido
CREATE TABLE IF NOT EXISTS `items_pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `variante_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(12,2) NOT NULL,
  `precio_original` decimal(12,2) DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `impuestos` decimal(12,2) DEFAULT 0.00,
  `total` decimal(12,2) NOT NULL,
  `atributos` json DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `codigo_barras` varchar(100) DEFAULT NULL,
  `devolucion_solicitada` tinyint(1) DEFAULT 0,
  `devolucion_aprobada` tinyint(1) DEFAULT NULL,
  `devolucion_razon` text,
  `devolucion_comentario` text,
  `devolucion_estado` enum('pendiente','aprobada','rechazada','completada') DEFAULT NULL,
  `devolucion_fecha_solicitud` datetime DEFAULT NULL,
  `devolucion_fecha_respuesta` datetime DEFAULT NULL,
  `devolucion_monto` decimal(12,2) DEFAULT NULL,
  `devolucion_metodo` varchar(50) DEFAULT NULL,
  `devolucion_comprobante` varchar(255) DEFAULT NULL,
  `devolucion_notas` text,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `pedido_id` (`pedido_id`),
  KEY `producto_id` (`producto_id`),
  KEY `variante_id` (`variante_id`),
  KEY `idx_items_pedido_sku` (`sku`),
  CONSTRAINT `items_pedido_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `items_pedido_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `items_pedido_ibfk_3` FOREIGN KEY (`variante_id`) REFERENCES `variantes_productos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de transacciones de pago
CREATE TABLE IF NOT EXISTS `transacciones_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `metodo_pago_id` int(11) DEFAULT NULL,
  `metodo_pago_nombre` varchar(100) DEFAULT NULL,
  `monto` decimal(12,2) NOT NULL,
  `moneda` char(3) DEFAULT 'UYU',
  `tipo_cambio` decimal(10,4) DEFAULT 1.0000,
  `referencia` varchar(255) DEFAULT NULL,
  `codigo_autorizacion` varchar(100) DEFAULT NULL,
  `estado` enum('pendiente','aprobado','rechazado','reembolsado','reembolso_parcial','error') DEFAULT 'pendiente',
  `respuesta` text,
  `notas` text,
  `fecha_procesamiento` datetime DEFAULT NULL,
  `fecha_aprobacion` datetime DEFAULT NULL,
  `fecha_rechazo` datetime DEFAULT NULL,
  `ip_cliente` varchar(45) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `pedido_id` (`pedido_id`),
  KEY `metodo_pago_id` (`metodo_pago_id`),
  KEY `idx_transacciones_estado` (`estado`),
  KEY `idx_transacciones_fecha` (`creado_en`),
  CONSTRAINT `transacciones_pago_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transacciones_pago_ibfk_2` FOREIGN KEY (`metodo_pago_id`) REFERENCES `metodos_pago` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de facturas electrónicas
CREATE TABLE IF NOT EXISTS `facturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_id` int(11) NOT NULL,
  `tipo` enum('e-Ticket','e-Factura','e-Ticket Venta Común','Nota de Crédito','Nota de Débito') NOT NULL,
  `numero` varchar(50) NOT NULL,
  `serie` varchar(10) NOT NULL,
  `fecha_emision` datetime NOT NULL,
  `fecha_vencimiento` datetime DEFAULT NULL,
  `fecha_vencimiento_pago` datetime DEFAULT NULL,
  `moneda` char(3) DEFAULT 'UYU',
  `tipo_cambio` decimal(10,4) DEFAULT 1.0000,
  `subtotal` decimal(12,2) NOT NULL,
  `descuento` decimal(12,2) DEFAULT 0.00,
  `impuestos` decimal(12,2) DEFAULT 0.00,
  `total` decimal(12,2) NOT NULL,
  `saldo_pendiente` decimal(12,2) DEFAULT 0.00,
  `estado` enum('pendiente','emitida','anulada','vencida','pagada','parcialmente_pagada') DEFAULT 'pendiente',
  `cliente_nombre` varchar(200) NOT NULL,
  `cliente_documento` varchar(20) NOT NULL,
  `cliente_direccion` text,
  `cliente_telefono` varchar(20) DEFAULT NULL,
  `cliente_email` varchar(120) DEFAULT NULL,
  `condicion_venta` enum('contado','credito') DEFAULT 'contado',
  `plazo_dias` int(11) DEFAULT 0,
  `cae` varchar(20) DEFAULT NULL,
  `cae_vto` date DEFAULT NULL,
  `qr_img` text,
  `respuesta_afip` json DEFAULT NULL,
  `observaciones` text,
  `usuario_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero` (`numero`),
  KEY `pedido_id` (`pedido_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_facturas_fecha` (`fecha_emision`),
  KEY `idx_facturas_estado` (`estado`),
  KEY `idx_facturas_cliente` (`cliente_documento`),
  CONSTRAINT `facturas_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `facturas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de impuestos
CREATE TABLE IF NOT EXISTS `impuestos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `tipo` enum('iva','otros_impuestos','tasas','percepciones','retenciones') NOT NULL,
  `porcentaje` decimal(5,2) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) DEFAULT 1,
  `aplicable_productos` tinyint(1) DEFAULT 1,
  `aplicable_envio` tinyint(1) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `idx_impuestos_activo` (`activo`),
  KEY `idx_impuestos_tipo` (`tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de impuestos por producto
CREATE TABLE IF NOT EXISTS `impuestos_productos` (
  `producto_id` int(11) NOT NULL,
  `impuesto_id` int(11) NOT NULL,
  `porcentaje` decimal(5,2) NOT NULL,
  `incluido_precio` tinyint(1) DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`producto_id`, `impuesto_id`),
  KEY `impuesto_id` (`impuesto_id`),
  CONSTRAINT `impuestos_productos_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `impuestos_productos_ibfk_2` FOREIGN KEY (`impuesto_id`) REFERENCES `impuestos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de carritos de compra
CREATE TABLE IF NOT EXISTS `carritos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `sesion_id` varchar(100) DEFAULT NULL,
  `direccion_envio_id` int(11) DEFAULT NULL,
  `direccion_facturacion_id` int(11) DEFAULT NULL,
  `metodo_envio_id` int(11) DEFAULT NULL,
  `metodo_envio_nombre` varchar(100) DEFAULT NULL,
  `metodo_envio_costo` decimal(10,2) DEFAULT 0.00,
  `metodo_pago_id` int(11) DEFAULT NULL,
  `metodo_pago_nombre` varchar(100) DEFAULT NULL,
  `subtotal` decimal(12,2) DEFAULT 0.00,
  `descuento` decimal(12,2) DEFAULT 0.00,
  `costo_envio` decimal(10,2) DEFAULT 0.00,
  `impuestos` decimal(12,2) DEFAULT 0.00,
  `total` decimal(12,2) DEFAULT 0.00,
  `moneda` char(3) DEFAULT 'UYU',
  `tipo_cambio` decimal(10,4) DEFAULT 1.0000,
  `notas` text,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expiracion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `sesion_id` (`sesion_id`),
  KEY `direccion_envio_id` (`direccion_envio_id`),
  KEY `direccion_facturacion_id` (`direccion_facturacion_id`),
  KEY `metodo_envio_id` (`metodo_envio_id`),
  KEY `metodo_pago_id` (`metodo_pago_id`),
  CONSTRAINT `carritos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `carritos_ibfk_2` FOREIGN KEY (`direccion_envio_id`) REFERENCES `direcciones` (`id`) ON DELETE SET NULL,
  CONSTRAINT `carritos_ibfk_3` FOREIGN KEY (`direccion_facturacion_id`) REFERENCES `direcciones` (`id`) ON DELETE SET NULL,
  CONSTRAINT `carritos_ibfk_4` FOREIGN KEY (`metodo_envio_id`) REFERENCES `metodos_envio` (`id`) ON DELETE SET NULL,
  CONSTRAINT `carritos_ibfk_5` FOREIGN KEY (`metodo_pago_id`) REFERENCES `metodos_pago` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de ítems del carrito
CREATE TABLE IF NOT EXISTS `items_carrito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `carrito_id` int(11) NOT NULL,
  `producto_id` int(11) DEFAULT NULL,
  `variante_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) NOT NULL,
  `cantidad` int(11) NOT NULL DEFAULT 1,
  `precio_unitario` decimal(12,2) NOT NULL,
  `precio_original` decimal(12,2) DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `impuestos` decimal(12,2) DEFAULT 0.00,
  `total` decimal(12,2) NOT NULL,
  `atributos` json DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `carrito_id` (`carrito_id`),
  KEY `producto_id` (`producto_id`),
  KEY `variante_id` (`variante_id`),
  CONSTRAINT `items_carrito_ibfk_1` FOREIGN KEY (`carrito_id`) REFERENCES `carritos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `items_carrito_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `items_carrito_ibfk_3` FOREIGN KEY (`variante_id`) REFERENCES `variantes_productos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de lista de deseos
CREATE TABLE IF NOT EXISTS `lista_deseos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT 'Mi lista de deseos',
  `es_privada` tinyint(1) DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `lista_deseos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de ítems de lista de deseos
CREATE TABLE IF NOT EXISTS `items_lista_deseos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lista_deseos_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `variante_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT 1,
  `notas` text,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_item` (`lista_deseos_id`, `producto_id`, `variante_id`),
  KEY `producto_id` (`producto_id`),
  KEY `variante_id` (`variante_id`),
  CONSTRAINT `items_lista_deseos_ibfk_1` FOREIGN KEY (`lista_deseos_id`) REFERENCES `lista_deseos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `items_lista_deseos_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `items_lista_deseos_ibfk_3` FOREIGN KEY (`variante_id`) REFERENCES `variantes_productos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de reseñas de productos
CREATE TABLE IF NOT EXISTS `resenas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `puntuacion` int(11) NOT NULL CHECK (puntuacion >= 1 AND puntuacion <= 5),
  `titulo` varchar(200) DEFAULT NULL,
  `comentario` text,
  `respuesta` text,
  `fecha_respuesta` datetime DEFAULT NULL,
  `aprobado` tinyint(1) DEFAULT 0,
  `compra_verificada` tinyint(1) DEFAULT 1,
  `votos_utiles` int(11) DEFAULT 0,
  `votos_totales` int(11) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `pedido_id` (`pedido_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_resenas_puntuacion` (`puntuacion`),
  KEY `idx_resenas_aprobado` (`aprobado`),
  CONSTRAINT `resenas_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `resenas_ibfk_2` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `resenas_ibfk_3` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de votos de reseñas
CREATE TABLE IF NOT EXISTS `votos_resenas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resena_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `es_util` tinyint(1) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_voto` (`resena_id`, `usuario_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `votos_resenas_ibfk_1` FOREIGN KEY (`resena_id`) REFERENCES `resenas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `votos_resenas_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de notificaciones
CREATE TABLE IF NOT EXISTS `notificaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `titulo` varchar(255) NOT NULL,
  `mensaje` text,
  `tipo` enum('sistema','pedido','pago','envio','promocion','otro') NOT NULL DEFAULT 'sistema',
  `enlace` varchar(255) DEFAULT NULL,
  `icono` varchar(50) DEFAULT NULL,
  `leida` tinyint(1) DEFAULT 0,
  `fecha_leida` datetime DEFAULT NULL,
  `fecha_expiracion` datetime DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_notificaciones_tipo` (`tipo`),
  KEY `idx_notificaciones_leida` (`leida`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de mensajes
CREATE TABLE IF NOT EXISTS `mensajes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conversacion_id` varchar(100) NOT NULL,
  `usuario_remitente_id` int(11) DEFAULT NULL,
  `usuario_destinatario_id` int(11) DEFAULT NULL,
  `asunto` varchar(255) DEFAULT NULL,
  `mensaje` text,
  `adjuntos` json DEFAULT NULL,
  `leido` tinyint(1) DEFAULT 0,
  `fecha_leido` datetime DEFAULT NULL,
  `eliminado_remitente` tinyint(1) DEFAULT 0,
  `eliminado_destinatario` tinyint(1) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_remitente_id` (`usuario_remitente_id`),
  KEY `usuario_destinatario_id` (`usuario_destinatario_id`),
  KEY `idx_mensajes_conversacion` (`conversacion_id`),
  KEY `idx_mensajes_leido` (`leido`),
  CONSTRAINT `mensajes_ibfk_1` FOREIGN KEY (`usuario_remitente_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `mensajes_ibfk_2` FOREIGN KEY (`usuario_destinatario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de configuraciones del sistema
CREATE TABLE IF NOT EXISTS `configuraciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grupo` varchar(50) NOT NULL DEFAULT 'general',
  `clave` varchar(100) NOT NULL,
  `valor` text,
  `tipo` enum('texto','numero','decimal','booleano','json','fecha','hora','fecha_hora','select','multiselect','textarea','editor','imagen','archivo') NOT NULL DEFAULT 'texto',
  `opciones` text COMMENT 'JSON para campos select/multiselect',
  `etiqueta` varchar(255) DEFAULT NULL,
  `descripcion` text,
  `es_publica` tinyint(1) DEFAULT 0,
  `orden` int(11) DEFAULT 0,
  `validacion` varchar(255) DEFAULT NULL,
  `requerido` tinyint(1) DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `grupo_clave` (`grupo`, `clave`),
  KEY `idx_configuraciones_grupo` (`grupo`),
  KEY `idx_configuraciones_orden` (`orden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de historial de precios
CREATE TABLE IF NOT EXISTS `historial_precios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `precio_anterior` decimal(12,2) NOT NULL,
  `precio_nuevo` decimal(12,2) NOT NULL,
  `tipo_cambio` enum('aumento','disminucion','oferta','ajuste_manual','sincronizacion') NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_historial_precios_fecha` (`creado_en`),
  CONSTRAINT `historial_precios_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `historial_precios_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de búsquedas
CREATE TABLE IF NOT EXISTS `busquedas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta` varchar(255) NOT NULL,
  `resultados` int(11) DEFAULT 0,
  `usuario_id` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `filtros` json DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_busquedas_consulta` (`consulta`),
  KEY `idx_busquedas_fecha` (`creado_en`),
  CONSTRAINT `busquedas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de visitas a productos
CREATE TABLE IF NOT EXISTS `visitas_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `pagina_origen` varchar(255) DEFAULT NULL,
  `dispositivo` enum('desktop','tablet','mobile','bot','otro') DEFAULT NULL,
  `sistema_operativo` varchar(50) DEFAULT NULL,
  `navegador` varchar(50) DEFAULT NULL,
  `pais` char(2) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_visitas_fecha` (`creado_en`),
  CONSTRAINT `visitas_productos_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `visitas_productos_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de seguimiento de inventario
CREATE TABLE IF NOT EXISTS `movimientos_inventario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `variante_id` int(11) DEFAULT NULL,
  `tipo` enum('entrada','salida','ajuste','venta','devolucion','dañado','caducado','otro') NOT NULL,
  `cantidad` int(11) NOT NULL,
  `stock_anterior` int(11) NOT NULL,
  `stock_nuevo` int(11) NOT NULL,
  `referencia_id` int(11) DEFAULT NULL COMMENT 'ID de la referencia (pedido, factura, etc.)',
  `referencia_tipo` varchar(50) DEFAULT NULL COMMENT 'Tipo de referencia (pedido, factura, ajuste, etc.)',
  `notas` text,
  `usuario_id` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `variante_id` (`variante_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_movimientos_tipo` (`tipo`),
  KEY `idx_movimientos_referencia` (`referencia_tipo`, `referencia_id`),
  CONSTRAINT `movimientos_inventario_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `movimientos_inventario_ibfk_2` FOREIGN KEY (`variante_id`) REFERENCES `variantes_productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `movimientos_inventario_ibfk_3` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de códigos de descuento
CREATE TABLE IF NOT EXISTS `descuentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `tipo` enum('porcentaje','monto_fijo','envio_gratis') NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `descripcion` text,
  `fecha_inicio` datetime DEFAULT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `usos_maximos` int(11) DEFAULT NULL,
  `usos_actuales` int(11) DEFAULT 0,
  `minimo_compra` decimal(12,2) DEFAULT NULL,
  `aplicable_productos` enum('todos','seleccionados','categorias','marcas') DEFAULT 'todos',
  `productos_ids` json DEFAULT NULL,
  `categorias_ids` json DEFAULT NULL,
  `marcas` json DEFAULT NULL,
  `usos_por_usuario` int(11) DEFAULT 1,
  `combinable` tinyint(1) DEFAULT 0,
  `activo` tinyint(1) DEFAULT 1,
  `creado_por` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `creado_por` (`creado_por`),
  KEY `idx_descuentos_activo` (`activo`),
  KEY `idx_descuentos_fechas` (`fecha_inicio`, `fecha_fin`),
  CONSTRAINT `descuentos_ibfk_1` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de usos de códigos de descuento
CREATE TABLE IF NOT EXISTS `usos_descuentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descuento_id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `pedido_id` int(11) DEFAULT NULL,
  `valor_aplicado` decimal(10,2) NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `descuento_id` (`descuento_id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `pedido_id` (`pedido_id`),
  CONSTRAINT `usos_descuentos_ibfk_1` FOREIGN KEY (`descuento_id`) REFERENCES `descuentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usos_descuentos_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `usos_descuentos_ibfk_3` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de suscriptores al boletín
CREATE TABLE IF NOT EXISTS `suscriptores_newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(120) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `codigo_confirmacion` varchar(100) DEFAULT NULL,
  `confirmado` tinyint(1) DEFAULT 0,
  `origen` varchar(50) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_confirmacion` datetime DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_suscriptores_activo` (`activo`),
  KEY `idx_suscriptores_confirmado` (`confirmado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de plantillas de correo electrónico
CREATE TABLE IF NOT EXISTS `plantillas_correo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(100) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `asunto` varchar(255) NOT NULL,
  `contenido` text NOT NULL,
  `variables` text COMMENT 'JSON con las variables disponibles',
  `activo` tinyint(1) DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`),
  KEY `idx_plantillas_activo` (`activo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de colas de correo electrónico
CREATE TABLE IF NOT EXISTS `cola_correos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `destinatario` varchar(255) NOT NULL,
  `asunto` varchar(255) NOT NULL,
  `contenido` text NOT NULL,
  `plantilla_id` int(11) DEFAULT NULL,
  `variables` text COMMENT 'JSON con las variables para la plantilla',
  `estado` enum('pendiente','enviando','enviado','fallido') DEFAULT 'pendiente',
  `intentos` int(11) DEFAULT 0,
  `ultimo_intento` datetime DEFAULT NULL,
  `error` text,
  `programado_para` datetime DEFAULT NULL,
  `enviado_en` datetime DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `plantilla_id` (`plantilla_id`),
  KEY `idx_cola_correos_estado` (`estado`),
  KEY `idx_cola_correos_programado` (`programado_para`),
  CONSTRAINT `cola_correos_ibfk_1` FOREIGN KEY (`plantilla_id`) REFERENCES `plantillas_correo` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de archivos subidos
CREATE TABLE IF NOT EXISTS `archivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_original` varchar(255) NOT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `ruta` varchar(512) NOT NULL,
  `extension` varchar(10) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `tamano` int(11) NOT NULL COMMENT 'Tamaño en bytes',
  `ancho` int(11) DEFAULT NULL COMMENT 'Para imágenes',
  `alto` int(11) DEFAULT NULL COMMENT 'Para imágenes',
  `tipo` enum('imagen','documento','archivo','video','audio','otro') NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `visibilidad` enum('publico','privado','protegido') DEFAULT 'publico',
  `descripcion` text,
  `metadatos` json DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_archivos_tipo` (`tipo`),
  KEY `idx_archivos_visibilidad` (`visibilidad`),
  CONSTRAINT `archivos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de logs del sistema
CREATE TABLE IF NOT EXISTS [logs](cci:7://file:///c:/xampp/htdocs/kompra-libre/public_html/logs:0:0-0:0) (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nivel` enum('emergencia','alerta','critico','error','advertencia','noticia','informacion','depuracion') NOT NULL,
  `mensaje` text NOT NULL,
  `contexto` json DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `url` varchar(512) DEFAULT NULL,
  `metodo` varchar(10) DEFAULT NULL,
  `referer` varchar(512) DEFAULT NULL,
  `codigo_estado` int(11) DEFAULT NULL,
  `tiempo_ejecucion` decimal(10,4) DEFAULT NULL COMMENT 'Tiempo de ejecución en segundos',
  `consumo_memoria` int(11) DEFAULT NULL COMMENT 'Consumo de memoria en bytes',
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_logs_nivel` (`nivel`),
  KEY `idx_logs_fecha` (`creado_en`),
  CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de tareas programadas
CREATE TABLE IF NOT EXISTS `tareas_programadas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `frecuencia` varchar(50) NOT NULL,
  `comando` varchar(255) NOT NULL,
  `parametros` json DEFAULT NULL,
  `ultima_ejecucion` datetime DEFAULT NULL,
  `proxima_ejecucion` datetime DEFAULT NULL,
  `estado` enum('activo','inactivo','pausado') DEFAULT 'activo',
  `ejecutando` tinyint(1) DEFAULT 0,
  `bloqueado` tinyint(1) DEFAULT 0,
  `bloqueado_desde` datetime DEFAULT NULL,
  `bloqueado_por` varchar(100) DEFAULT NULL,
  `ultimo_error` text,
  `notificar_error` tinyint(1) DEFAULT 1,
  `notificar_exito` tinyint(1) DEFAULT 0,
  `tiempo_maximo_segundos` int(11) DEFAULT 300,
  `tiempo_promedio` decimal(10,4) DEFAULT NULL,
  `tiempo_ultimo` decimal(10,4) DEFAULT NULL,
  `memoria_promedio` int(11) DEFAULT NULL,
  `memoria_ultima` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `idx_tareas_estado` (`estado`),
  KEY `idx_tareas_proxima_ejecucion` (`proxima_ejecucion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de registros de ejecución de tareas
CREATE TABLE IF NOT EXISTS `registros_tareas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tarea_id` int(11) NOT NULL,
  `inicio` datetime NOT NULL,
  `fin` datetime DEFAULT NULL,
  `estado` enum('exitoso','fallido','ejecutando') NOT NULL,
  `salida` text,
  `error` text,
  `tiempo_ejecucion` decimal(10,4) DEFAULT NULL COMMENT 'Tiempo de ejecución en segundos',
  `consumo_memoria` int(11) DEFAULT NULL COMMENT 'Consumo de memoria en bytes',
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tarea_id` (`tarea_id`),
  KEY `idx_registros_tareas_fecha` (`inicio`),
  KEY `idx_registros_tareas_estado` (`estado`),
  CONSTRAINT `registros_tareas_ibfk_1` FOREIGN KEY (`tarea_id`) REFERENCES `tareas_programadas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de caché
CREATE TABLE IF NOT EXISTS `cache` (
  `clave` varchar(255) NOT NULL,
  `valor` longtext NOT NULL,
  `expiracion` int(11) NOT NULL,
  `etiquetas` json DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`clave`),
  KEY `idx_cache_expiracion` (`expiracion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de bloqueos
CREATE TABLE IF NOT EXISTS `bloqueos` (
  `clave` varchar(255) NOT NULL,
  `valor` varchar(255) NOT NULL,
  `expiracion` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =================================================================
-- ÍNDICES ADICIONALES
-- =================================================================

-- Índices para búsquedas full-text
ALTER TABLE `productos` ADD FULLTEXT INDEX `ft_productos_busqueda` (`titulo`, `descripcion`, `descripcion_corta`, `marca`, `modelo`);

-- Índices para búsquedas por rango de fechas
ALTER TABLE `pedidos` ADD INDEX `idx_pedidos_rango_fechas` (`creado_en`, `actualizado_en`);
ALTER TABLE `facturas` ADD INDEX `idx_facturas_rango_fechas` (`fecha_emision`, `fecha_vencimiento`);

-- Índices para estadísticas
ALTER TABLE `visitas_productos` ADD INDEX `idx_visitas_estadisticas` (`producto_id`, `creado_en`);
ALTER TABLE `pedidos` ADD INDEX `idx_pedidos_estadisticas` (`estado_pedido`, `creado_en`);
ALTER TABLE `productos` ADD INDEX `idx_productos_estadisticas` (`contador_ventas`, `contador_vistas`);

-- =================================================================
-- VISTAS
-- =================================================================

-- Vista para productos destacados
CREATE OR REPLACE VIEW `vista_productos_destacados` AS
SELECT 
    p.id,
    p.titulo,
    p.slug,
    p.descripcion_corta,
    p.precio,
    p.precio_original,
    p.calificacion_promedio,
    p.cantidad_calificaciones,
    p.contador_ventas,
    p.contador_vistas,
    p.destacado,
    p.creado_en,
    v.alias_tienda as vendedor_nombre,
    v.slug as vendedor_slug,
    v.puntuacion as vendedor_puntuacion,
    (SELECT ruta_imagen FROM imagenes_productos WHERE producto_id = p.id AND es_principal = 1 LIMIT 1) as imagen_principal,
    (SELECT COUNT(*) FROM items_pedido ip JOIN pedidos pe ON ip.pedido_id = pe.id WHERE ip.producto_id = p.id AND pe.estado_pedido = 'entregado') as unidades_vendidas,
    (SELECT AVG(puntuacion) FROM resenas WHERE producto_id = p.id AND aprobado = 1) as puntuacion_media
FROM 
    productos p
JOIN 
    vendedores v ON p.vendedor_id = v.id
WHERE 
    p.visible = 1 
    AND p.estado = 'activo'
    AND v.estado = 'activo'
ORDER BY 
    p.destacado DESC,
    p.contador_ventas DESC,
    p.creado_en DESC
LIMIT 50;

-- Vista para ofertas especiales
CREATE OR REPLACE VIEW `vista_ofertas_especiales` AS
SELECT 
    p.id,
    p.titulo,
    p.slug,
    p.descripcion_corta,
    p.precio,
    p.precio_original,
    ROUND(((p.precio_original - p.precio) / p.precio_original) * 100, 0) as descuento_porcentaje,
    p.calificacion_promedio,
    p.cantidad_calificaciones,
    p.contador_ventas,
    v.alias_tienda as vendedor_nombre,
    v.slug as vendedor_slug,
    (SELECT ruta_imagen FROM imagenes_productos WHERE producto_id = p.id AND es_principal = 1 LIMIT 1) as imagen_principal
FROM 
    productos p
JOIN 
    vendedores v ON p.vendedor_id = v.id
WHERE 
    p.visible = 1 
    AND p.estado = 'activo'
    AND v.estado = 'activo'
    AND p.precio_original > p.precio
    AND p.precio_original IS NOT NULL
    AND p.precio < p.precio_original
ORDER BY 
    descuento_porcentaje DESC,
    p.contador_ventas DESC
LIMIT 50;

-- Vista para productos recientes
CREATE OR REPLACE VIEW `vista_productos_recientes` AS
SELECT 
    p.id,
    p.titulo,
    p.slug,
    p.descripcion_corta,
    p.precio,
    p.precio_original,
    p.calificacion_promedio,
    p.cantidad_calificaciones,
    p.contador_ventas,
    v.alias_tienda as vendedor_nombre,
    v.slug as vendedor_slug,
    (SELECT ruta_imagen FROM imagenes_productos WHERE producto_id = p.id AND es_principal = 1 LIMIT 1) as imagen_principal,
    DATEDIFF(NOW(), p.creado_en) as dias_desde_creacion
FROM 
    productos p
JOIN 
    vendedores v ON p.vendedor_id = v.id
WHERE 
    p.visible = 1 
    AND p.estado = 'activo'
    AND v.estado = 'activo'
    AND DATEDIFF(NOW(), p.creado_en) <= 30  -- Últimos 30 días
ORDER BY 
    p.creado_en DESC
LIMIT 50;

-- Vista para productos más vendidos
CREATE OR REPLACE VIEW `vista_mas_vendidos` AS
SELECT 
    p.id,
    p.titulo,
    p.slug,
    p.descripcion_corta,
    p.precio,
    p.precio_original,
    p.calificacion_promedio,
    p.cantidad_calificaciones,
    p.contador_ventas,
    v.alias_tienda as vendedor_nombre,
    v.slug as vendedor_slug,
    (SELECT ruta_imagen FROM imagenes_productos WHERE producto_id = p.id AND es_principal = 1 LIMIT 1) as imagen_principal,
    COUNT(ip.id) as total_vendido
FROM 
    productos p
JOIN 
    vendedores v ON p.vendedor_id = v.id
LEFT JOIN 
    items_pedido ip ON p.id = ip.producto_id
LEFT JOIN 
    pedidos pe ON ip.pedido_id = pe.id
WHERE 
    p.visible = 1 
    AND p.estado = 'activo'
    AND v.estado = 'activo'
    AND pe.estado_pedido = 'entregado'
    AND pe.creado_en >= DATE_SUB(NOW(), INTERVAL 3 MONTH)  -- Últimos 3 meses
GROUP BY 
    p.id
ORDER BY 
    total_vendido DESC,
    p.contador_ventas DESC
LIMIT 50;

-- Vista para productos mejor valorados
CREATE OR REPLACE VIEW `vista_mejor_valorados` AS
SELECT 
    p.id,
    p.titulo,
    p.slug,
    p.descripcion_corta,
    p.precio,
    p.precio_original,
    p.calificacion_promedio,
    p.cantidad_calificaciones,
    p.contador_ventas,
    v.alias_tienda as vendedor_nombre,
    v.slug as vendedor_slug,
    (SELECT ruta_imagen FROM imagenes_productos WHERE producto_id = p.id AND es_principal = 1 LIMIT 1) as imagen_principal
FROM 
    productos p
JOIN 
    vendedores v ON p.vendedor_id = v.id
WHERE 
    p.visible = 1 
    AND p.estado = 'activo'
    AND v.estado = 'activo'
    AND p.calificacion_promedio >= 4  -- Mínimo 4 estrellas
    AND p.cantidad_calificaciones >= 5  -- Mínimo 5 valoraciones
ORDER BY 
    p.calificacion_promedio DESC,
    p.cantidad_calificaciones DESC
LIMIT 50;

-- Vista para estadísticas de ventas
CREATE OR REPLACE VIEW `vista_estadisticas_ventas` AS
SELECT 
    DATE(p.creado_en) as fecha,
    COUNT(DISTINCT p.id) as total_pedidos,
    COUNT(DISTINCT p.usuario_id) as clientes_unicos,
    SUM(ip.cantidad) as unidades_vendidas,
    SUM(ip.total) as venta_bruta,
    SUM(ip.total - (ip.cantidad * (SELECT costo FROM productos WHERE id = ip.producto_id))) as beneficio_bruto,
    AVG(ip.total) as ticket_medio
FROM 
    pedidos p
JOIN 
    items_pedido ip ON p.id = ip.pedido_id
WHERE 
    p.estado_pedido = 'entregado'
    AND p.creado_en >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
GROUP BY 
    DATE(p.creado_en)
ORDER BY 
    fecha DESC;

-- Vista para productos con bajo stock
CREATE OR REPLACE VIEW `vista_bajo_stock` AS
SELECT 
    p.id,
    p.titulo,
    p.sku,
    p.stock,
    p.stock_minimo,
    v.alias_tienda as vendedor,
    c.nombre as categoria,
    (SELECT ruta_imagen FROM imagenes_productos WHERE producto_id = p.id AND es_principal = 1 LIMIT 1) as imagen_principal
FROM 
    productos p
JOIN 
    vendedores v ON p.vendedor_id = v.id
LEFT JOIN 
    categorias c ON p.categoria_id = c.id
WHERE 
    p.visible = 1 
    AND p.estado = 'activo'
    AND v.estado = 'activo'
    AND p.stock <= p.stock_minimo
ORDER BY 
    (p.stock / NULLIF(p.stock_minimo, 0)) ASC,
    p.stock ASC;

-- =================================================================
-- FUNCIONES Y PROCEDIMIENTOS ALMACENADOS
-- =================================================================

-- Función para generar SKU único
DELIMITER //
CREATE FUNCTION `generar_sku`(categoria_id INT, producto_id INT) 
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    DECLARE prefix VARCHAR(3);
    DECLARE sku VARCHAR(20);
    
    -- Obtener prefijo basado en la categoría
    SELECT 
        CASE 
            WHEN id = 1 THEN 'ELC'  -- Electrónica
            WHEN id = 2 THEN 'RPA'  -- Ropa y Accesorios
            WHEN id = 3 THEN 'HOG'  -- Hogar
            WHEN id = 4 THEN 'DEP'  -- Deportes
            WHEN id = 5 THEN 'LIB'  -- Libros
            WHEN id = 6 THEN 'AUT'  -- Automóviles
            WHEN id = 7 THEN 'BEL'  -- Belleza
            WHEN id = 8 THEN 'JUG'  -- Juguetes
            WHEN id = 9 THEN 'MUS'  -- Música
            WHEN id = 10 THEN 'SAL' -- Salud
            ELSE 'GEN'              -- General
        END INTO prefix
    FROM categorias 
    WHERE id = categoria_id;
    
    -- Generar SKU con prefijo + ID de categoría + ID de producto
    SET sku = CONCAT(prefix, LPAD(categoria_id, 2, '0'), '-', LPAD(producto_id, 5, '0'));
    
    RETURN sku;
END //
DELIMITER ;

-- Función para formatear números con separadores de miles
DELIMITER //
CREATE FUNCTION `formatear_numero`(numero DECIMAL(12,2), decimales INT) 
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE resultado VARCHAR(50);
    
    SET resultado = FORMAT(numero, decimales);
    SET resultado = REPLACE(resultado, ',', '|');
    SET resultado = REPLACE(resultado, '.', ',');
    SET resultado = REPLACE(resultado, '|', '.');
    
    RETURN resultado;
END //
DELIMITER ;

-- Función para calcular el precio con IVA
DELIMITER //
CREATE FUNCTION `calcular_precio_con_iva`(precio_sin_iva DECIMAL(12,2), porcentaje_iva DECIMAL(5,2)) 
RETURNS DECIMAL(12,2)
DETERMINISTIC
BEGIN
    RETURN ROUND(precio_sin_iva * (1 + (porcentaje_iva / 100)), 2);
END //
DELIMITER ;

-- Función para calcular el precio sin IVA
DELIMITER //
CREATE FUNCTION `calcular_precio_sin_iva`(precio_con_iva DECIMAL(12,2), porcentaje_iva DECIMAL(5,2)) 
RETURNS DECIMAL(12,2)
DETERMINISTIC
BEGIN
    RETURN ROUND(precio_con_iva / (1 + (porcentaje_iva / 100)), 2);
END //
DELIMITER ;

-- Función para validar RUT uruguayo
DELIMITER //
CREATE FUNCTION `validar_rut_uruguay`(rut VARCHAR(12)) 
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    -- Formato esperado: 12345678-9
    IF rut REGEXP '^[0-9]{7,8}-[0-9]$' THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
END //
DELIMITER ;

-- Procedimiento para actualizar el contador de productos por categoría
DELIMITER //
CREATE PROCEDURE `actualizar_contador_categorias`()
BEGIN
    -- Actualizar contador de productos para categorías principales
    UPDATE categorias c
    SET cantidad_productos = (
        SELECT COUNT(*) 
        FROM productos p 
        WHERE (p.categoria_id = c.id OR p.subcategoria_id = c.id)
        AND p.visible = 1
        AND p.estado = 'activo'
    );
END //
DELIMITER ;

-- Procedimiento para actualizar las estadísticas de un producto
DELIMITER //
CREATE PROCEDURE `actualizar_estadisticas_producto`(IN producto_id_param INT)
BEGIN
    DECLARE total_ventas INT;
    DECLARE total_valoraciones INT;
    DECLARE promedio_valoraciones DECIMAL(3,2);
    
    -- Calcular total de ventas
    SELECT IFNULL(SUM(ip.cantidad), 0) INTO total_ventas
    FROM items_pedido ip
    JOIN pedidos p ON ip.pedido_id = p.id
    WHERE ip.producto_id = producto_id_param
    AND p.estado_pedido = 'entregado';
    
    -- Calcular estadísticas de valoraciones
    SELECT 
        COUNT(*),
        IFNULL(AVG(puntuacion), 0)
    INTO 
        total_valoraciones,
        promedio_valoraciones
    FROM resenas
    WHERE producto_id = producto_id_param
    AND aprobado = 1;
    
    -- Actualizar el producto
    UPDATE productos
    SET 
        contador_ventas = total_ventas,
        cantidad_calificaciones = total_valoraciones,
        calificacion_promedio = promedio_valoraciones,
        actualizado_en = NOW()
    WHERE id = producto_id_param;
END //
DELIMITER ;

-- Procedimiento para generar un número de pedido único
DELIMITER //
CREATE PROCEDURE `generar_numero_pedido`(OUT numero_pedido VARCHAR(20))
BEGIN
    DECLARE prefijo VARCHAR(3) DEFAULT 'PED';
    DECLARE anio CHAR(2);
    DECLARE secuencia INT;
    
    -- Obtener año en formato corto (últimos 2 dígitos)
    SET anio = DATE_FORMAT(CURDATE(), '%y');
    
    -- Obtener el siguiente número de secuencia
    SELECT IFNULL(MAX(SUBSTRING_INDEX(SUBSTRING_INDEX(numero_pedido, '-', -1), '/', 1)), 0) + 1 
    INTO secuencia
    FROM pedidos
    WHERE numero_pedido LIKE CONCAT(prefijo, '-', anio, '/%');
    
    -- Formatear el número de pedido (ejemplo: PED-23/00001)
    SET numero_pedido = CONCAT(prefijo, '-', anio, '/', LPAD(secuencia, 5, '0'));
END //
DELIMITER ;

-- Procedimiento para procesar el pago de un pedido
DELIMITER //
CREATE PROCEDURE `procesar_pago_pedido`(
    IN pedido_id_param INT,
    IN metodo_pago_id_param INT,
    IN monto_param DECIMAL(12,2),
    IN referencia_param VARCHAR(255),
    IN datos_adicionales TEXT,
    OUT resultado BOOLEAN,
    OUT mensaje VARCHAR(255)
)
BEGIN
    DECLARE estado_actual VARCHAR(20);
    DECLARE total_pedido DECIMAL(12,2);
    DECLARE monto_pagado DECIMAL(12,2);
    DECLARE metodo_pago_nombre_var VARCHAR(100);
    
    -- Iniciar transacción
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET resultado = FALSE;
        SET mensaje = 'Error al procesar el pago.';
    END;
    
    START TRANSACTION;
    
    -- Obtener estado actual y total del pedido
    SELECT estado_pago, total INTO estado_actual, total_pedido
    FROM pedidos
    WHERE id = pedido_id_param
    FOR UPDATE;
    
    -- Verificar si el pedido ya está pagado
    IF estado_actual IN ('pagado', 'reembolsado') THEN
        SET resultado = FALSE;
        SET mensaje = 'El pedido ya ha sido pagado.';
        ROLLBACK;
        LEAVE proc_exit;
    END IF;
    
    -- Obtener monto ya pagado
    SELECT IFNULL(SUM(monto), 0) INTO monto_pagado
    FROM transacciones_pago
    WHERE pedido_id = pedido_id_param
    AND estado = 'aprobado';
    
    -- Verificar si el pago completo excede el total
    IF (monto_pagado + monto_param) > total_pedido THEN
        SET resultado = FALSE;
        SET mensaje = 'El monto del pago excede el total del pedido.';
        ROLLBACK;
        LEAVE proc_exit;
    END IF;
    
    -- Obtener nombre del método de pago
    SELECT nombre INTO metodo_pago_nombre_var
    FROM metodos_pago
    WHERE id = metodo_pago_id_param;
    
    -- Registrar la transacción de pago
    INSERT INTO transacciones_pago (
        pedido_id,
        metodo_pago_id,
        metodo_pago_nombre,
        monto,
        referencia,
        estado,
        respuesta,
        creado_en,
        actualizado_en
    ) VALUES (
        pedido_id_param,
        metodo_pago_id_param,
        metodo_pago_nombre_var,
        monto_param,
        referencia_param,
        'aprobado',
        datos_adicionales,
        NOW(),
        NOW()
    );
    
    -- Actualizar estado del pedido
    IF (monto_pagado + monto_param) >= total_pedido THEN
        -- Pago completo
        UPDATE pedidos
        SET 
            estado_pago = 'pagado',
            fecha_pago = NOW(),
            actualizado_en = NOW()
        WHERE id = pedido_id_param;
        
        -- Aquí podrías agregar lógica adicional como enviar correo de confirmación, etc.
    ELSE
        -- Pago parcial
        UPDATE pedidos
        SET 
            estado_pago = 'pagado_parcial',
            actualizado_en = NOW()
        WHERE id = pedido_id_param;
    END IF;
    
    -- Confirmar transacción
    COMMIT;
    
    SET resultado = TRUE;
    SET mensaje = 'Pago procesado correctamente.';
    
    proc_exit: BEGIN END;
END //
DELIMITER ;

-- Procedimiento para actualizar el stock de productos
DELIMITER //
CREATE PROCEDURE `actualizar_stock_producto`(
    IN producto_id_param INT,
    IN variante_id_param INT,
    IN cantidad_param INT,
    IN tipo_movimiento ENUM('entrada','salida','ajuste'),
    IN motivo VARCHAR(255),
    IN usuario_id_param INT,
    IN referencia_tipo VARCHAR(50),
    IN referencia_id INT
)
BEGIN
    DECLARE stock_actual INT;
    DECLARE stock_nuevo INT;
    DECLARE operacion_exitosa BOOLEAN DEFAULT TRUE;
    
    -- Iniciar transacción
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SET operacion_exitosa = FALSE;
        ROLLBACK;
        -- Aquí podrías registrar el error en una tabla de logs
    END;
    
    START TRANSACTION;
    
    -- Obtener stock actual
    IF variante_id_param IS NOT NULL THEN
        -- Actualizar stock de la variante
        SELECT stock INTO stock_actual
        FROM variantes_productos
        WHERE id = variante_id_param
        FOR UPDATE;
        
        -- Calcular nuevo stock
        IF tipo_movimiento = 'entrada' THEN
            SET stock_nuevo = stock_actual + cantidad_param;
        ELSEIF tipo_movimiento = 'salida' THEN
            SET stock_nuevo = stock_actual - cantidad_param;
            -- Verificar stock suficiente
            IF stock_nuevo < 0 THEN
                SET operacion_exitosa = FALSE;
                -- Aquí podrías lanzar un error personalizado
            END IF;
        ELSE -- ajuste
            SET stock_nuevo = cantidad_param;
        END IF;
        
        -- Actualizar stock de la variante
        UPDATE variantes_productos
        SET stock = stock_nuevo
        WHERE id = variante_id_param;
        
        -- Actualizar stock total del producto (suma de todas las variantes)
        UPDATE productos p
        SET stock = (
            SELECT SUM(stock) 
            FROM variantes_productos 
            WHERE producto_id = p.id
        )
        WHERE id = producto_id_param;
    ELSE
        -- Actualizar stock del producto (sin variantes)
        SELECT stock INTO stock_actual
        FROM productos
        WHERE id = producto_id_param
        FOR UPDATE;
        
        -- Calcular nuevo stock
        IF tipo_movimiento = 'entrada' THEN
            SET stock_nuevo = stock_actual + cantidad_param;
        ELSEIF tipo_movimiento = 'salida' THEN
            SET stock_nuevo = stock_actual - cantidad_param;
            -- Verificar stock suficiente
            IF stock_nuevo < 0 THEN
                SET operacion_exitosa = FALSE;
                -- Aquí podrías lanzar un error personalizado
            END IF;
        ELSE -- ajuste
            SET stock_nuevo = cantidad_param;
        END IF;
        
        -- Actualizar stock del producto
        UPDATE productos
        SET stock = stock_nuevo
        WHERE id = producto_id_param;
    END IF;
    
    -- Registrar movimiento de inventario
    INSERT INTO movimientos_inventario (
        producto_id,
        variante_id,
        tipo,
        cantidad,
        stock_anterior,
        stock_nuevo,
        referencia_id,
        referencia_tipo,
        notas,
        usuario_id,
        creado_en
    ) VALUES (
        producto_id_param,
        variante_id_param,
        tipo_movimiento,
        cantidad_param,
        stock_actual,
        stock_nuevo,
        referencia_id,
        referencia_tipo,
        motivo,
        usuario_id_param,
        NOW()
    );
    
    -- Verificar si se debe generar alerta de bajo stock
    IF stock_nuevo <= (SELECT stock_minimo FROM productos WHERE id = producto_id_param) THEN
        -- Aquí podrías insertar una notificación o enviar un correo
        -- Ejemplo: INSERT INTO notificaciones (...)
    END IF;
    
    -- Confirmar transacción si todo salió bien
    IF operacion_exitosa THEN
        COMMIT;
    ELSE
        ROLLBACK;
    END IF;
END //
DELIMITER ;

-- Procedimiento para generar factura electrónica
DELIMITER //
CREATE PROCEDURE `generar_factura_electronica`(
    IN pedido_id_param INT,
    IN usuario_id_param INT,
    OUT factura_id INT,
    OUT resultado BOOLEAN,
    OUT mensaje VARCHAR(255)
)
BEGIN
    DECLARE pedido_existente INT;
    DECLARE cliente_nombre VARCHAR(200);
    DECLARE cliente_documento VARCHAR(20);
    DECLARE cliente_direccion TEXT;
    DECLARE cliente_telefono VARCHAR(20);
    DECLARE cliente_email VARCHAR(120);
    DECLARE total_pedido DECIMAL(12,2);
    DECLARE subtotal_pedido DECIMAL(12,2);
    DECLARE impuestos_pedido DECIMAL(12,2);
    DECLARE descuento_pedido DECIMAL(12,2);
    DECLARE proximo_numero INT;
    DECLARE serie_factura VARCHAR(10) DEFAULT 'A';
    DECLARE numero_factura VARCHAR(50);
    DECLARE fecha_emision DATETIME;
    DECLARE fecha_vencimiento DATETIME;
    
    -- Iniciar transacción
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET resultado = FALSE;
        SET mensaje = CONCAT('Error al generar la factura: ', IFNULL(SUBSTRING(SQL_ERROR_MESSAGE, 1, 200), 'Error desconocido'));
    END;
    
    START TRANSACTION;
    
    -- Verificar si el pedido existe
    SELECT COUNT(*) INTO pedido_existente
    FROM pedidos
    WHERE id = pedido_id_param;
    
    IF pedido_existente = 0 THEN
        SET resultado = FALSE;
        SET mensaje = 'El pedido especificado no existe.';
        ROLLBACK;
        LEAVE proc_exit;
    END IF;
    
    -- Verificar si ya existe una factura para este pedido
    SELECT COUNT(*) INTO pedido_existente
    FROM facturas
    WHERE pedido_id = pedido_id_param;
    
    IF pedido_existente > 0 THEN
        SET resultado = FALSE;
        SET mensaje = 'Ya existe una factura para este pedido.';
        ROLLBACK;
        LEAVE proc_exit;
    END IF;
    
    -- Obtener datos del pedido
    SELECT 
        CONCAT(u.nombre, ' ', u.apellido) as nombre_completo,
        COALESCE(p.direccion_facturacion->>'$.documento', '') as documento,
        COALESCE(p.direccion_facturacion->>'$.direccion', '') as direccion,
        COALESCE(p.direccion_facturacion->>'$.telefono', '') as telefono,
        u.email,
        p.total,
        p.subtotal,
        p.impuestos,
        p.descuento
    INTO 
        cliente_nombre,
        cliente_documento,
        cliente_direccion,
        cliente_telefono,
        cliente_email,
        total_pedido,
        subtotal_pedido,
        impuestos_pedido,
        descuento_pedido
    FROM pedidos p
    JOIN usuarios u ON p.usuario_id = u.id
    WHERE p.id = pedido_id_param;
    
    -- Validar datos del cliente para facturación
    IF cliente_documento IS NULL OR cliente_documento = '' THEN
        SET resultado = FALSE;
        SET mensaje = 'El cliente no tiene documento de identidad registrado.';
        ROLLBACK;
        LEAVE proc_exit;
    END IF;
    
    -- Obtener el próximo número de factura (esto podría venir de una tabla de secuencias)
    SELECT IFNULL(MAX(CAST(SUBSTRING_INDEX(numero, '-', -1) AS UNSIGNED)), 0) + 1 
    INTO proximo_numero
    FROM facturas
    WHERE serie = serie_factura;
    
    -- Generar número de factura (ejemplo: A-00001-2023)
    SET fecha_emision = NOW();
    SET numero_factura = CONCAT(serie_factura, '-', LPAD(proximo_numero, 5, '0'), '-', YEAR(fecha_emision));
    SET fecha_vencimiento = DATE_ADD(fecha_emision, INTERVAL 30 DAY); -- 30 días de plazo por defecto
    
    -- Insertar la factura
    INSERT INTO facturas (
        pedido_id,
        tipo,
        numero,
        serie,
        fecha_emision,
        fecha_vencimiento,
        moneda,
        subtotal,
        descuento,
        impuestos,
        total,
        saldo_pendiente,
        estado,
        cliente_nombre,
        cliente_documento,
        cliente_direccion,
        cliente_telefono,
        cliente_email,
        condicion_venta,
        plazo_dias,
        usuario_id,
        creado_en,
        actualizado_en
    ) VALUES (
        pedido_id_param,
        'e-Factura',
        numero_factura,
        serie_factura,
        fecha_emision,
        fecha_vencimiento,
        'UYU',
        subtotal_pedido,
        descuento_pedido,
        impuestos_pedido,
        total_pedido,
        total_pedido, -- Por defecto, el saldo pendiente es igual al total
        'pendiente',
        cliente_nombre,
        cliente_documento,
        cliente_direccion,
        cliente_telefono,
        cliente_email,
        'contado',
        0, -- Contado
        usuario_id_param,
        NOW(),
        NOW()
    );
    
    -- Obtener el ID de la factura generada
    SET factura_id = LAST_INSERT_ID();
    
    -- Insertar los ítems de la factura (podrías tener una tabla aparte para esto)
    -- Aquí asumimos que los ítems se almacenan en un campo JSON en la tabla facturas
    -- En una implementación real, podrías tener una tabla de ítems de factura
    
    -- Actualizar el pedido con la referencia a la factura
    UPDATE pedidos
    SET facturacion = JSON_MERGE_PRESERVE(
        IFNULL(facturacion, '{}'),
        JSON_OBJECT(
            'factura_id', factura_id,
            'factura_numero', numero_factura,
            'factura_serie', serie_factura,
            'factura_fecha', DATE(fecha_emision)
        )
    )
    WHERE id = pedido_id_param;
    
    -- Aquí iría la lógica para conectar con el servicio de facturación electrónica (AFIP, etc.)
    -- Por ejemplo:
    -- 1. Preparar los datos para el web service
    -- 2. Realizar la petición
    -- 3. Procesar la respuesta
    -- 4. Actualizar la factura con el CAE, número de autorización, etc.
    
    -- Ejemplo simulado:
    /*
    SET [cae](cci:4://file://cae:0:0-0:0) = '12345678901234';
    SET [cae_vto](cci:4://file://cae_vto:0:0-0:0) = '20231231';
    SET [qr_img](cci:4://file://qr_img:0:0-0:0) = 'https://ejemplo.com/qr/12345678901234';
    
    UPDATE facturas
    SET 
        cae = [cae,](cci:4://file://cae,:0:0-0:0)
        cae_vto = STR_TO_DATE([cae_vto,](cci:4://file://cae_vto,:0:0-0:0) '%Y%m%d'),
        qr_img = [qr_img,](cci:4://file://qr_img,:0:0-0:0)
        estado = 'emitida',
        respuesta_afip = '{"status": "A", "message": "Aprobado"}',
        actualizado_en = NOW()
    WHERE id = factura_id;
    */
    
    -- Por ahora, simulamos una factura aprobada
    UPDATE facturas
    SET 
        cae = LPAD(FLOOR(RAND() * 100000000000000), 14, '0'),
        cae_vto = DATE_ADD(CURDATE(), INTERVAL 10 DAY),
        estado = 'emitida',
        respuesta_afip = '{"status": "A", "message": "Aprobado (simulado)"}',
        actualizado_en = NOW()
    WHERE id = factura_id;
    
    -- Confirmar transacción
    COMMIT;
    
    SET resultado = TRUE;
    SET mensaje = CONCAT('Factura generada correctamente: ', numero_factura);
    
    proc_exit: BEGIN END;
END //
DELIMITER ;

-- =================================================================
-- TRIGGERS
-- =================================================================

-- Trigger para actualizar automáticamente el slug de un producto
DELIMITER //
CREATE TRIGGER `before_insert_producto_slug`
BEFORE INSERT ON `productos`
FOR EACH ROW
BEGIN
    DECLARE slug_base VARCHAR(200);
    DECLARE contador INT DEFAULT 1;
    DECLARE nuevo_slug VARCHAR(200);
    
    -- Generar slug base (eliminar acentos, caracteres especiales, etc.)
    SET slug_base = LOWER(NEW.titulo);
    SET slug_base = REGEXP_REPLACE(slug_base, '[^a-z0-9]+', '-');
    SET slug_base = TRIM(BOTH '-' FROM slug_base);
    
    -- Verificar si el slug ya existe
    SET nuevo_slug = slug_base;
    
    WHILE EXISTS (SELECT 1 FROM productos WHERE slug = nuevo_slug AND (id != NEW.id OR NEW.id IS NULL)) DO
        SET nuevo_slug = CONCAT(slug_base, '-', contador);
        SET contador = contador + 1;
    END WHILE;
    
    SET NEW.slug = nuevo_slug;
    
    -- Generar SKU si no se proporciona
    IF NEW.sku IS NULL OR NEW.sku = '' THEN
        SET NEW.sku = generar_sku(
            IFNULL(NEW.categoria_id, 0), 
            (SELECT AUTO_INCREMENT FROM information_schema.TABLES 
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'productos')
        );
    END IF;
END //
DELIMITER ;

-- Trigger para actualizar automáticamente el slug de una categoría
DELIMITER //
CREATE TRIGGER `before_insert_categoria_slug`
BEFORE INSERT ON `categorias`
FOR EACH ROW
BEGIN
    DECLARE slug_base VARCHAR(120);
    DECLARE contador INT DEFAULT 1;
    DECLARE nuevo_slug VARCHAR(120);
    
    -- Generar slug base
    SET slug_base = LOWER(NEW.nombre);
    SET slug_base = REGEXP_REPLACE(slug_base, '[^a-z0-9]+', '-');
    SET slug_base = TRIM(BOTH '-' FROM slug_base);
    
    -- Verificar si el slug ya existe
    SET nuevo_slug = slug_base;
    
    WHILE EXISTS (SELECT 1 FROM categorias WHERE slug = nuevo_slug AND (id != NEW.id OR NEW.id IS NULL)) DO
        SET nuevo_slug = CONCAT(slug_base, '-', contador);
        SET contador = contador + 1;
    END WHILE;
    
    SET NEW.slug = nuevo_slug;
END //
DELIMITER ;

-- Trigger para actualizar contadores después de insertar un producto
DELIMITER //
CREATE TRIGGER `after_insert_producto`
AFTER INSERT ON `productos`
FOR EACH ROW
BEGIN
    -- Actualizar contador de productos del vendedor
    UPDATE vendedores 
    SET total_productos = total_productos + 1 
    WHERE id = NEW.vendedor_id;
    
    -- Actualizar contador de productos por categoría
    CALL actualizar_contador_categorias();
END //
DELIMITER ;

-- Trigger para actualizar contadores después de eliminar un producto
DELIMITER //
CREATE TRIGGER `after_delete_producto`
AFTER DELETE ON `productos`
FOR EACH ROW
BEGIN
    -- Actualizar contador de productos del vendedor
    UPDATE vendedores 
    SET total_productos = GREATEST(0, total_productos - 1) 
    WHERE id = OLD.vendedor_id;
    
    -- Actualizar contador de productos por categoría
    CALL actualizar_contador_categorias();
END //
DELIMITER ;

-- Trigger para actualizar contadores después de actualizar un producto
DELIMITER //
CREATE TRIGGER `after_update_producto`
AFTER UPDATE ON `productos`
FOR EACH ROW
BEGIN
    -- Si cambió la categoría o subcategoría, actualizar contadores
    IF OLD.categoria_id != NEW.categoria_id OR OLD.subcategoria_id != NEW.subcategoria_id THEN
        CALL actualizar_contador_categorias();
    END IF;
    
    -- Si cambió el vendedor, actualizar contadores de vendedores
    IF OLD.vendedor_id != NEW.vendedor_id THEN
        -- Restar del vendedor anterior
        UPDATE vendedores 
        SET total_productos = GREATEST(0, total_productos - 1) 
        WHERE id = OLD.vendedor_id;
        
        -- Sumar al nuevo vendedor
        UPDATE vendedores 
        SET total_productos = total_productos + 1 
        WHERE id = NEW.vendedor_id;
    END IF;
END //
DELIMITER ;

-- Trigger para actualizar el stock después de un pedido
DELIMITER //
CREATE TRIGGER `after_insert_item_pedido`
AFTER INSERT ON `items_pedido`
FOR EACH ROW
BEGIN
    DECLARE producto_stock INT;
    DECLARE producto_stock_minimo INT;
    DECLARE producto_id_var INT;
    
    -- Obtener información del producto
    SELECT p.id, p.stock, p.stock_minimo 
    INTO producto_id_var, producto_stock, producto_stock_minimo
    FROM productos p
    WHERE p.id = NEW.producto_id;
    
    -- Actualizar contador de ventas del producto
    UPDATE productos
    SET 
        contador_ventas = contador_ventas + NEW.cantidad,
        actualizado_en = NOW()
    WHERE id = producto_id_var;
    
    -- Actualizar stock (si no es un producto digital)
    IF producto_stock IS NOT NULL THEN
        CALL actualizar_stock_producto(
            producto_id_var,
            NEW.variante_id,
            NEW.cantidad,
            'salida',
            CONCAT('Venta - Pedido #', (SELECT numero_pedido FROM pedidos WHERE id = NEW.pedido_id)),
            (SELECT usuario_id FROM pedidos WHERE id = NEW.pedido_id),
            'pedido',
            NEW.pedido_id
        );
    END IF;
END //
DELIMITER ;

-- Trigger para actualizar el estado del pedido cuando se completa el pago
DELIMITER //
CREATE TRIGGER `after_update_pedido_pago`
AFTER UPDATE ON `pedidos`
FOR EACH ROW
BEGIN
    -- Si el estado de pago cambió a "pagado" y el pedido estaba "pendiente"
    IF NEW.estado_pago = 'pagado' AND OLD.estado_pago != 'pagado' AND NEW.estado_pedido = 'pendiente' THEN
        -- Actualizar el estado del pedido a "confirmado"
        UPDATE pedidos
        SET 
            estado_pedido = 'confirmado',
            actualizado_en = NOW()
        WHERE id = NEW.id;
    END IF;
END //
DELIMITER ;

-- =================================================================
-- DATOS INICIALES
-- =================================================================

-- Insertar departamentos de Uruguay
INSERT INTO `departamentos` (`nombre`, `codigo`, `capital`, `superficie_km2`, `poblacion`) VALUES
('Artigas', 'AR', 'Artigas', 11928, 73124),
('Canelones', 'CA', 'Canelones', 4536, 588959),
('Cerro Largo', 'CL', 'Melo', 13648, 84810),
('Colonia', 'CO', 'Colonia del Sacramento', 6106, 123203),
('Durazno', 'DU', 'Durazno', 11643, 57088),
('Flores', 'FS', 'Trinidad', 5144, 25050),
('Florida', 'FD', 'Florida', 10417, 67128),
('Lavalleja', 'LA', 'Minas', 10016, 58315),
('Maldonado', 'MA', 'Maldonado', 4793, 190500),
('Montevideo', 'MO', 'Montevideo', 530, 1686048),
('Paysandú', 'PA', 'Paysandú', 13922, 113124),
('Río Negro', 'RN', 'Fray Bentos', 9282, 54665),
('Rivera', 'RV', 'Rivera', 9370, 103493),
('Rocha', 'RO', 'Rocha', 10551, 68300),
('Salto', 'SA', 'Salto', 14163, 124878),
('San José', 'SJ', 'San José de Mayo', 4992, 113120),
('Soriano', 'SO', 'Mercedes', 9008, 82108),
('Tacuarembó', 'TA', 'Tacuarembó', 15438, 89825),
('Treinta y Tres', 'TT', 'Treinta y Tres', 9529, 48034);

-- Insertar localidades principales (ejemplo para Montevideo)
INSERT INTO `localidades` (`departamento_id`, `nombre`, `codigo_postal`, `es_capital`) VALUES
(10, 'Montevideo', '11000', 1),
(10, 'Ciudad de la Costa', '15000', 0),
(10, 'Paso Carrasco', '15000', 0),
(10, 'Pocitos', '11300', 0),
(10, 'Punta Carretas', '11300', 0),
(10, 'Carrasco', '11500', 0),
(10, 'Malvín', '11300', 0),
(10, 'Pocitos', '11300', 0),
(10, 'Parque Rodó', '11200', 0),
(10, 'Centro', '11000', 0),
(10, 'Cordón', '11200', 0),
(10, 'Palermo', '11200', 0),
(10, 'Aguada', '11800', 0),
(10, 'Prado', '11800', 0),
(10, 'Cerro', '12500', 0),
(10, 'Pajas Blancas', '12500', 0),
(10, 'Casavalle', '12600', 0),
(10, 'Piedras Blancas', '12100', 0),
(10, 'Colón', '11600', 0),
(10, 'Punta Gorda', '11300', 0);

-- Insertar métodos de pago
INSERT INTO `metodos_pago` (`nombre`, `codigo`, `descripcion`, `tipo`, `comision_porcentaje`, `comision_fija`, `activo`, `orden`, `icono`, `instrucciones`, `configuracion`) VALUES
('Tarjeta de crédito', 'tarjeta_credito', 'Pago con tarjeta de crédito', 'tarjeta', 5.00, 0.00, 1, 1, 'credit-card', 'Puede pagar con cualquier tarjeta de crédito. Aceptamos Visa, Mastercard, American Express y otras.', '{"habilitar_cuotas":true,"cuotas_sin_interes":3,"cuotas_maximas":12,"bancos_aceptados":["BROU","BROU_AMEX","SCOTIABANK","ITAU","SANTANDER","BBVA","HERITAGE","CARTESIS","OCA","LIDER","DINERS"]}'),
('MercadoPago', 'mercadopago', 'Pago a través de MercadoPago', 'billetera_digital', 4.99, 0.00, 1, 2, 'shopping-bag', 'Será redirigido a MercadoPago para completar el pago de forma segura.', '{"habilitar_cuotas":true,"cuotas_sin_interes":3,"cuotas_maximas":12}'),
('Transferencia bancaria', 'transferencia', 'Transferencia bancaria directa', 'transferencia', 0.00, 0.00, 1, 3, 'bank', 'Realice una transferencia a nuestra cuenta bancaria. Su pedido se procesará una vez confirmado el pago.', '{"cuentas_bancarias":[{"banco":"BROU","tipo_cuenta":"Pesos Uruguayo","numero_cuenta":"001234567-00001","cbu":"1234567890123456789012","alias":"MI.TIENDA.URU","titular":"Mi Tienda S.A.","rut":"21234567015"}]}'),
('Efectivo', 'efectivo', 'Pago en efectivo al retirar', 'efectivo', 0.00, 0.00, 1, 4, 'money-bill-wave', 'Pague en efectivo al momento de retirar su pedido en nuestro local.', '{"solo_retiro":true}'),
('Abitab', 'abitab', 'Pago en efectivo a través de Abitab', 'efectivo', 3.50, 0.00, 1, 5, 'store', 'Puede pagar en cualquier sucursal de Abitab o RedPagos con el número de referencia que le proporcionaremos.', '{"mostrar_codigo_barras":true}'),
('RedPagos', 'redpagos', 'Pago en efectivo a través de RedPagos', 'efectivo', 3.50, 0.00, 1, 6, 'money-check', 'Puede pagar en cualquier sucursal de RedPagos con el número de referencia que le proporcionaremos.', '{"mostrar_codigo_barras":true}'),
('Cuenta Corriente', 'cuenta_corriente', 'Factura a cuenta corriente', 'otro', 0.00, 0.00, 1, 7, 'file-invoice', 'Solo para clientes con cuenta corriente aprobada.', '{"requiere_aprobacion":true}');

-- Insertar métodos de envío
INSERT INTO `metodos_envio` (`nombre`, `descripcion`, `tipo`, `costo_base`, `costo_gratis_desde`, `peso_maximo_kg`, `dimensiones_maximas`, `dias_habiles_min`, `dias_habiles_max`, `activo`, `requiere_direccion`, `permite_retiro`, `direccion_retiro`, `horario_retiro`) VALUES
('Envío Estándar', 'Entrega a domicilio en 3-5 días hábiles', 'estandar', 250.00, 5000.00, 30.000, '50x50x70 cm', 3, 5, 1, 1, 0, NULL, NULL),
('Envío Express', 'Entrega al día siguiente en Montevideo, 48hs en el interior', 'express', 450.00, 8000.00, 15.000, '40x40x60 cm', 1, 2, 1, 1, 0, NULL, NULL),
('Retiro en Tienda', 'Retire su pedido en nuestro local', 'retiro', 0.00, NULL, NULL, NULL, 1, 1, 1, 0, 1, 'Av. 18 de Julio 1234, Local 5, Montevideo', 'Lunes a Viernes de 10:00 a 18:00, Sábados de 10:00 a 14:00'),
('Envío Gratis', 'Envío sin costo para compras superiores a $5000', 'gratis', 0.00, 5000.00, 20.000, '50x50x70 cm', 3, 7, 1, 1, 0, NULL, NULL);

-- Insertar configuraciones del sistema
INSERT INTO `configuraciones` (`grupo`, `clave`, `valor`, `tipo`, `opciones`, `etiqueta`, `descripcion`, `es_publica`, `orden`, `validacion`, `requerido`) VALUES
-- Configuración General
('general', 'nombre_sitio', 'Kompa Libre', 'texto', NULL, 'Nombre del Sitio', 'Nombre que se muestra en el sitio web', 1, 1, 'required|min:3|max:100', 1),
('general', 'descripcion_sitio', 'Tu tienda en línea de confianza', 'texto', NULL, 'Descripción del Sitio', 'Breve descripción del sitio web', 1, 2, 'required|min:10|max:255', 1),
('general', 'email_contacto', 'contacto[kompralibre.com',](cci:4://file://kompralibre.com',:0:0-0:0) 'email', NULL, 'Email de Contacto', 'Correo electrónico de contacto principal', 1, 3, 'required|email', 1),
('general', 'telefono_contacto', '2900 1234', 'texto', NULL, 'Teléfono de Contacto', 'Teléfono de contacto principal', 1, 4, 'required', 1),
('general', 'direccion_tienda', 'Av. 18 de Julio 1234, Montevideo, Uruguay', 'texto', NULL, 'Dirección de la Tienda', 'Dirección física de la tienda', 1, 5, 'required', 1),
('general', 'horario_atencion', 'Lunes a Viernes de 9:00 a 18:00', 'texto', NULL, 'Horario de Atención', 'Horario de atención al cliente', 1, 6, 'required', 1),
('general', 'moneda', 'UYU', 'select', '["UYU", "USD"]', 'Moneda Principal', 'Moneda principal del sitio', 1, 7, 'required', 1),
('general', 'simbolo_moneda', '$', 'texto', NULL, 'Símbolo de Moneda', 'Símbolo de la moneda (ej: $, U$S, €)', 1, 8, 'required', 1),
('general', 'formato_moneda', '1.0', 'select', '{"1.0":"$1.234,56", "2.0":"1.234,56 $", "3.0":"$ 1,234.56", "4.0":"1,234.56 $"}', 'Formato de Moneda', 'Formato en que se muestran los precios', 1, 9, 'required', 1),
('general', 'zona_horaria', 'America/Montevideo', 'select', '["America/Montevideo", "America/Argentina/Buenos_Aires", "America/Sao_Paulo", "America/New_York", "Europe/Madrid"]', 'Zona Horaria', 'Zona horaria del sitio', 0, 10, 'required', 1),
('general', 'idioma_principal', 'es', 'select', '{"es":"Español", "en":"Inglés", "pt":"Portugués"}', 'Idioma Principal', 'Idioma principal del sitio', 1, 11, 'required', 1),
('general', 'pais_por_defecto', 'UY', 'select', '{"UY":"Uruguay", "AR":"Argentina", "BR":"Brasil", "PY":"Paraguay"}', 'País por Defecto', 'País seleccionado por defecto', 1, 12, 'required', 1),
('general', 'pagina_inicio', 'inicio', 'select', '{"inicio":"Página de Inicio", "catalogo":"Catálogo de Productos", "ofertas":"Ofertas Especiales"}', 'Página de Inicio', 'Página que se muestra al acceder al sitio', 1, 13, 'required', 1),
('general', 'mantenimiento', '0', 'booleano', NULL, 'Modo Mantenimiento', 'Activar para poner el sitio en modo mantenimiento', 0, 14, NULL, 0),
('general', 'mensaje_mantenimiento', 'Estamos realizando tareas de mantenimiento. Volveremos pronto.', 'textarea', NULL, 'Mensaje de Mantenimiento', 'Mensaje que se muestra cuando el sitio está en mantenimiento', 0, 15, NULL, 0),
('general', 'ips_permitidas', '127.0.0.1,::1', 'texto', NULL, 'IPs Permitidas', 'IPs que pueden acceder en modo mantenimiento (separadas por comas)', 0, 16, NULL, 0),

-- Configuración de Tienda
('tienda', 'impuesto_por_defecto', '22', 'numero', NULL, 'IVA por Defecto (%)', 'Porcentaje de IVA por defecto para los productos', 0, 1, 'required|numeric|min:0|max:100', 1),
('tienda', 'unidades_por_pagina', '12', 'numero', NULL, 'Productos por Página', 'Número de productos a mostrar por página en el catálogo', 1, 2, 'required|numeric|min:1|max:100', 1),
('tienda', 'orden_por_defecto', 'mas_recientes', 'select', '{"mas_recientes":"Más recientes", "precio_menor_mayor":"Precio: menor a mayor", "precio_mayor_menor":"Precio: mayor a menor", "mas_vendidos":"Más vendidos", "mejor_valorados":"Mejor valorados", "nombre_asc":"Nombre (A-Z)", "nombre_desc":"Nombre (Z-A)"}', 'Orden por Defecto', 'Ordenación por defecto de los productos', 1, 3, 'required', 1),
('tienda', 'mostrar_iva_incluido', '1', 'booleano', NULL, 'Mostrar Precios con IVA Incluido', 'Mostrar los precios con IVA incluido en el catálogo', 1, 4, NULL, 1),
('tienda', 'mostrar_precio_antes_descuento', '1', 'booleano', NULL, 'Mostrar Precio Anterior en Descuentos', 'Mostrar el precio tachado en productos con descuento', 1, 5, NULL, 1),
('tienda', 'minimo_carrito', '500', 'numero', NULL, 'Mínimo de Compra', 'Monto mínimo para realizar un pedido', 1, 6, 'required|numeric|min:0', 1),
('tienda', 'dias_para_anular_pedido', '2', 'numero', NULL, 'Días para Anular Pedido', 'Número de días que un cliente tiene para anular un pedido', 1, 7, 'required|numeric|min:0', 1),
('tienda', 'dias_para_devolucion', '30', 'numero', NULL, 'Días para Devolución', 'Número de días que un cliente tiene para solicitar una devolución', 1, 8, 'required|numeric|min:0', 1),
('tienda', 'mostrar_stock', '1', 'booleano', NULL, 'Mostrar Stock Disponible', 'Mostrar la cantidad de stock disponible en la ficha del producto', 1, 9, NULL, 1),
('tienda', 'mostrar_agotados', '1', 'booleano', NULL, 'Mostrar Productos Agotados', 'Mostrar productos sin stock en el catálogo', 1, 10, NULL, 1),
('tienda', 'permitir_comentarios', '1', 'booleano', NULL, 'Permitir Comentarios', 'Permitir a los clientes dejar comentarios en los productos', 1, 11, NULL, 1),
('tienda', 'moderar_comentarios', '1', 'booleano', NULL, 'Moderar Comentarios', 'Revisar los comentarios antes de publicarlos', 0, 12, NULL, 0),
('tienda', 'comprar_sin_registro', '1', 'booleano', NULL, 'Permitir Comprar sin Registro', 'Permitir realizar compras sin crear una cuenta', 1, 13, NULL, 0),
('tienda', 'terminos_condiciones', '1', 'booleano', NULL, 'Requerir Aceptación de Términos', 'Obligar a aceptar los términos y condiciones al finalizar la compra', 1, 14, NULL, 0),
('tienda', 'politica_privacidad', '1', 'booleano', NULL, 'Requerir Aceptación de Política de Privacidad', 'Obligar a aceptar la política de privacidad al crear una cuenta', 1, 15, NULL, 0),

-- Configuración de Envíos
('envios', 'calcular_envio_automatico', '1', 'booleano', NULL, 'Calcular Costo de Envío Automáticamente', 'Calcular automáticamente el costo de envío según la dirección', 1, 1, NULL, 0),
('envios', 'origen_nombre', 'Tienda Principal', 'texto', NULL, 'Nombre del Origen', 'Nombre del lugar de origen de los envíos', 0, 2, 'required', 1),
('envios', 'origen_direccion', 'Av. 18 de Julio 1234', 'texto', NULL, 'Dirección de Origen', 'Dirección de origen de los envíos', 0, 3, 'required', 1),
('envios', 'origen_ciudad', 'Montevideo', 'texto', NULL, 'Ciudad de Origen', 'Ciudad de origen de los envíos', 0, 4, 'required', 1),
('envios', 'origen_departamento', 'Montevideo', 'texto', NULL, 'Departamento de Origen', 'Departamento de origen de los envíos', 0, 5, 'required', 1),
('envios', 'origen_codigo_postal', '11200', 'texto', NULL, 'Código Postal de Origen', 'Código postal de origen de los envíos', 0, 6, 'required', 1),
('envios', 'origen_pais', 'UY', 'select', '{"UY":"Uruguay", "AR":"Argentina", "BR":"Brasil", "PY":"Paraguay"}', 'País de Origen', 'País de origen de los envíos', 0, 7, 'required', 1),
('envios', 'dias_habiles_por_defecto', '3', 'numero', NULL, 'Días Hábiles por Defecto', 'Tiempo de entrega estimado por defecto (días hábiles)', 1, 8, 'required|numeric|min:1', 1),
('envios', 'peso_maximo_por_paquete', '30', 'numero', NULL, 'Peso Máximo por Paquete (kg)', 'Peso máximo permitido por paquete en kilogramos', 0, 9, 'required|numeric|min:0.1', 1),
('envios', 'costo_adicional_por_kg', '50', 'numero', NULL, 'Costo Adicional por kg (UYU)', 'Costo adicional por kilogramo excedente', 0, 10, 'required|numeric|min:0', 1),
('envios', 'horario_entrega', 'Lunes a Viernes de 9:00 a 18:00', 'texto', NULL, 'Horario de Entrega', 'Horario en que se realizan las entregas', 1, 11, 'required', 1),
('envios', 'excluir_fines_semana', '1', 'booleano', NULL, 'Excluir Fines de Semana', 'No contar sábados y domingos como días hábiles', 1, 12, NULL, 1),
('envios', 'dias_adicionales_interior', '2', 'numero', NULL, 'Días Adicionales para Interior', 'Días adicionales para envíos al interior del país', 1, 13, 'required|numeric|min:0', 1),

-- Configuración de Redes Sociales
('redes_sociales', 'twitter', 'https://x.com/nendndjd55861', 'texto', NULL, 'Twitter (X)', 'URL del perfil de Twitter (X) de Kompa Libre', 1, 1, 'url', 0),
('redes_sociales', 'facebook', '', 'texto', NULL, 'Facebook', 'URL del perfil de Facebook de Kompa Libre', 1, 2, 'url', 0),
('redes_sociales', 'instagram', '', 'texto', NULL, 'Instagram', 'URL del perfil de Instagram de Kompa Libre', 1, 3, 'url', 0),
('redes_sociales', 'linkedin', '', 'texto', NULL, 'LinkedIn', 'URL del perfil de LinkedIn de Kompa Libre', 1, 4, 'url', 0),
('redes_sociales', 'youtube', '', 'texto', NULL, 'YouTube', 'URL del canal de YouTube de Kompa Libre', 1, 5, 'url', 0),

-- Configuración de Facturación Electrónica
('facturacion', 'habilitar_facturacion', '1', 'booleano', NULL, 'Habilitar Facturación Electrónica', 'Activar la generación de facturas electrónicas', 0, 1, NULL, 1),
('facturacion', 'tipo_empresa', 'Responsable Inscripto', 'select', '{"Responsable Inscripto":"Responsable Inscripto","Monotributista":"Monotributista"}', 'Tipo de Empresa', 'Tipo de empresa para facturación', 0, 2, 'required', 1),
('facturacion', 'rut_empresa', '', 'texto', NULL, 'RUT de la Empresa', 'RUT de la empresa con formato 123456780015', 0, 3, 'required|rut', 1),
('facturacion', 'razon_social', '', 'texto', NULL, 'Razón Social', 'Razón social de la empresa', 0, 4, 'required', 1),
('facturacion', 'nombre_fantasia', 'Kompa Libre', 'texto', NULL, 'Nombre de Fantasía', 'Nombre comercial de la empresa', 0, 5, 'required', 1),
('facturacion', 'direccion_fiscal', '', 'texto', NULL, 'Dirección Fiscal', 'Dirección fiscal completa', 0, 6, 'required', 1),
('facturacion', 'telefono_contacto', '', 'texto', NULL, 'Teléfono de Contacto', 'Teléfono para facturación', 0, 7, 'required', 1),
('facturacion', 'email_contacto', 'contacto@kompralibre.com', 'email', NULL, 'Email de Contacto', 'Email para facturación', 0, 8, 'required|email', 1),
('facturacion', 'sucursal_afip', '1', 'numero', NULL, 'Sucursal AFIP', 'Número de sucursal en AFIP', 0, 9, 'required|numeric|min:1', 1),
('facturacion', 'punto_venta', '1', 'numero', NULL, 'Punto de Venta', 'Número de punto de venta', 0, 10, 'required|numeric|min:1', 1),

-- Configuración de Seguridad
('seguridad', 'requerir_verificacion_email', '1', 'booleano', NULL, 'Requerir Verificación de Email', 'Los usuarios deben verificar su correo electrónico', 0, 1, NULL, 1),
('seguridad', 'intentos_maximos_login', '5', 'numero', NULL, 'Intentos Máximos de Inicio de Sesión', 'Número de intentos fallidos antes de bloquear la cuenta', 0, 2, 'required|numeric|min:1|max:10', 1),
('seguridad', 'tiempo_bloqueo_intentos', '15', 'numero', NULL, 'Minutos de Bloqueo', 'Minutos de bloqueo tras superar el límite de intentos', 0, 3, 'required|numeric|min:1', 1),
('seguridad', 'requerir_contrasena_fuerte', '1', 'booleano', NULL, 'Requerir Contraseña Fuerte', 'Exigir contraseñas complejas', 0, 4, NULL, 1),
('seguridad', 'tiempo_sesion', '120', 'numero', NULL, 'Tiempo de Sesión (minutos)', 'Tiempo de inactividad antes de cerrar sesión', 0, 5, 'required|numeric|min:5', 1),

-- Configuración de SEO
('seo', 'meta_titulo', 'Kompa Libre - Tu tienda online en Uruguay', 'texto', NULL, 'Meta Título', 'Título que aparece en los resultados de búsqueda', 1, 1, 'required|max:60', 1),
('seo', 'meta_descripcion', 'Compra online en Kompa Libre. Los mejores precios en electrónica, moda, hogar y más. Envíos a todo Uruguay.', 'texto', NULL, 'Meta Descripción', 'Descripción que aparece en los resultados de búsqueda', 1, 2, 'required|max:160', 1),
('seo', 'meta_palabras_clave', 'compra online, uruguay, tienda, electrónica, moda, hogar, envíos', 'texto', NULL, 'Palabras Clave', 'Palabras clave para SEO, separadas por comas', 1, 3, NULL, 0),
('seo', 'google_analytics_id', '', 'texto', NULL, 'ID de Google Analytics', 'ID de seguimiento de Google Analytics', 0, 4, NULL, 0),
('seo', 'google_search_console', '', 'texto', NULL, 'Código de Google Search Console', 'Código de verificación de Google Search Console', 0, 5, NULL, 0),

-- Configuración de Notificaciones
('notificaciones', 'email_nuevo_pedido', '1', 'booleano', NULL, 'Notificar Nuevos Pedidos', 'Enviar email al administrador por cada nuevo pedido', 0, 1, NULL, 1),
('notificaciones', 'email_actualizacion_pedido', '1', 'booleano', NULL, 'Actualizaciones de Estado', 'Enviar email al cliente al actualizar el estado del pedido', 1, 2, NULL, 1),
('notificaciones', 'email_bienvenida', '1', 'booleano', NULL, 'Email de Bienvenida', 'Enviar email de bienvenida a nuevos usuarios', 1, 3, NULL, 1),
('notificaciones', 'email_factura', '1', 'booleano', NULL, 'Enviar Factura por Email', 'Enviar factura electrónica por email al cliente', 1, 4, NULL, 1),

-- Configuración de Pagos
('pagos', 'modo_pruebas', '1', 'booleano', NULL, 'Modo Pruebas', 'Activar modo pruebas para pasarelas de pago', 0, 1, NULL, 1),
('pagos', 'moneda_principal', 'UYU', 'select', '{"UYU":"Peso Uruguayo","USD":"Dólar Estadounidense"}', 'Moneda Principal', 'Moneda principal para transacciones', 0, 2, 'required', 1),
('pagos', 'tipo_cambio_usd', '40.5', 'numero', NULL, 'Tipo de Cambio USD', 'Tipo de cambio actual de USD a UYU', 0, 3, 'required|numeric|min:0.01', 1),
('pagos', 'dias_vencimiento_pago', '3', 'numero', NULL, 'Días para el Vencimiento', 'Días para realizar el pago de la orden', 1, 4, 'required|numeric|min:1', 1),

-- Configuración del Tema
('tema', 'color_principal', '#3498db', 'color', NULL, 'Color Principal', 'Color principal del tema', 1, 1, NULL, 1),
('tema', 'color_secundario', '#2ecc71', 'color', NULL, 'Color Secundario', 'Color secundario del tema', 1, 2, NULL, 1),
('tema', 'logo', '/img/logo.png', 'imagen', NULL, 'Logo del Sitio', 'Logo principal del sitio web', 1, 3, 'image', 1),
('tema', 'favicon', '/favicon.ico', 'imagen', NULL, 'Favicon', 'Ícono que aparece en la pestaña del navegador', 1, 4, 'image', 1),
('tema', 'modo_oscuro', '0', 'booleano', NULL, 'Habilitar Modo Oscuro', 'Permitir a los usuarios activar el modo oscuro', 1, 5, NULL, 1);

-- Tabla de logs del sistema
CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nivel` enum('emergencia','alerta','critico','error','advertencia','noticia','informacion','depuracion') NOT NULL,
  `mensaje` text NOT NULL,
  `contexto` json DEFAULT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `url` varchar(512) DEFAULT NULL,
  `metodo` varchar(10) DEFAULT NULL,
  `referer` varchar(512) DEFAULT NULL,
  `codigo_estado` int(11) DEFAULT NULL,
  `tiempo_ejecucion` decimal(10,4) DEFAULT NULL COMMENT 'Tiempo de ejecución en segundos',
  `consumo_memoria` int(11) DEFAULT NULL COMMENT 'Consumo de memoria en bytes',
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_logs_nivel` (`nivel`),
  KEY `idx_logs_fecha` (`creado_en`),
  CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`usuario_id`) 
    REFERENCES `usuarios` (`id`) 
    ON DELETE SET NULL 
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;