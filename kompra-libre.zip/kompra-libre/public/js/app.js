import { api } from './utils.js';

let page = 1;
const limit = 9;

async function loadCategories() {
    try {
        const cats = await api('/api/categories');
        const sel = document.getElementById('f_categoria');
        if (sel) {
            sel.innerHTML = '<option value="">Todas las categorías</option>' + 
                cats.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }
    } catch (error) {
        console.error('Error al cargar categorías:', error);
    }
}

async function loadProducts() {
    try {
        const q = document.getElementById('q')?.value || '';
        const category = document.getElementById('f_categoria')?.value || '';
        const priceMin = document.getElementById('f_pmin')?.value || '';
        const priceMax = document.getElementById('f_pmax')?.value || '';
        const cond = document.getElementById('f_cond')?.value || '';
        
        const params = new URLSearchParams({
            q,
            category,
            price_min: priceMin,
            price_max: priceMax,
            condition: cond,
            page,
            limit
        }).toString();

        const res = await api(`/api/products?${params}`);
        const cont = document.getElementById('productos');
        
        if (cont) {
            cont.innerHTML = res.items.map(p => `
                <article class="bg-white p-3 rounded shadow hover:shadow-md transition-shadow">
                    <a href="/producto.html?id=${p.id}" class="block">
                        <div class="aspect-square bg-gray-100 rounded overflow-hidden mb-2">
                            <img src="${p.cover || '/img/placeholder.jpg'}" 
                                 alt="${p.title}" 
                                 class="w-full h-full object-cover">
                        </div>
                        <h3 class="font-medium text-gray-900 line-clamp-2 h-12">${p.title}</h3>
                        <div class="text-sm text-gray-500 mb-1">${p.category_name || 'Sin categoría'}</div>
                        <div class="text-lg font-bold text-green-600">$${parseFloat(p.price).toFixed(2)}</div>
                        <div class="text-xs text-gray-400 mt-1">${p.condition === 'nuevo' ? 'Nuevo' : 'Usado'}</div>
                    </a>
                </article>
            `).join('');
        }

        // Actualizar paginación
        const pageEl = document.getElementById('page');
        if (pageEl) {
            pageEl.textContent = page;
        }

    } catch (error) {
        console.error('Error al cargar productos:', error);
        const cont = document.getElementById('productos');
        if (cont) {
            cont.innerHTML = `
                <div class="col-span-full text-center py-10">
                    <div class="text-red-500 mb-2">Error al cargar los productos</div>
                    <button onclick="location.reload()" class="text-blue-500 hover:underline">
                        Reintentar
                    </button>
                </div>
            `;
        }
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', async () => {
    await loadCategories();
    await loadProducts();

    // Buscar al hacer clic en el botón
    const btnBuscar = document.getElementById('btnBuscar');
    if (btnBuscar) {
        btnBuscar.addEventListener('click', () => {
            page = 1;
            loadProducts();
        });
    }

    // Buscar al presionar Enter en el input
    function setupSearchInput() {
        const searchInput = document.getElementById('q');
        if (!searchInput) {
            console.warn('Search input element not found');
            return;
        }

        // Asegurarse de que el input sea visible y habilitado
        if (searchInput.offsetParent === null || searchInput.disabled) {
            console.warn('Search input is not visible or is disabled');
            return;
        }

        const handleSearch = (e) => {
            if (e.key === 'Enter' || e.type === 'click') {
                e.preventDefault();
                page = 1;
                loadProducts();
                
                // Opcional: Quitar el foco del input después de buscar
                if (e.type === 'keypress') {
                    searchInput.blur();
                }
            }
        };

        // Agregar event listeners
        searchInput.addEventListener('keypress', handleSearch);
        
        // También manejar el clic en el botón de búsqueda
        const searchButton = document.querySelector('.search-button, [type="submit"], button[type="button"]');
        if (searchButton) {
            searchButton.addEventListener('click', handleSearch);
        }
    }

    // Configurar el input de búsqueda
    setupSearchInput();

    // Filtros
    const btnFiltrar = document.getElementById('btnFiltrar');
    if (btnFiltrar) {
        btnFiltrar.addEventListener('click', () => {
            page = 1;
            loadProducts();
        });
    }

    // Paginación
    const prevBtn = document.getElementById('prev');
    const nextBtn = document.getElementById('next');

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (page > 1) {
                page--;
                loadProducts();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            page++;
            loadProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Autocompletado de búsqueda
    const searchInput = document.getElementById('q');
    const datalist = document.getElementById('sugs');
    let timeoutId;

    if (searchInput && datalist) {
        searchInput.addEventListener('input', () => {
            clearTimeout(timeoutId);
            const query = searchInput.value.trim();
            
            if (query.length < 2) {
                datalist.innerHTML = '';
                return;
            }

            timeoutId = setTimeout(async () => {
                try {
                    const suggestions = await api(`/api/search/suggest?q=${encodeURIComponent(query)}`);
                    datalist.innerHTML = suggestions.map(s => 
                        `<option value="${s.title}">`
                    ).join('');
                } catch (error) {
                    console.error('Error al obtener sugerencias:', error);
                }
            }, 300);
        });
    }
});