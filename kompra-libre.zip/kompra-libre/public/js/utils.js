export async function api(path) {
  try {
    const baseUrl = ''; // Deja esto vacío para rutas relativas
    const url = `${baseUrl}${path}`;
    const r = await fetch(url, { 
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
    
    if (!r.ok) {
      const errorData = await r.json().catch(() => ({}));
      throw new Error(`HTTP ${r.status}: ${errorData.error || 'Error en la solicitud'}`);
    }
    
    return await r.json();
  } catch (error) {
    console.error('Error en la petición:', error);
    throw error;
  }
}

export async function apiPost(path, body) {
  const r = await fetch(path, { 
    method: 'POST', 
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }, 
    body: JSON.stringify(body), 
    credentials: 'include' 
  });
  try { 
    return await r.json(); 
  } catch(e) { 
    return { ok: r.ok, status: r.status }; 
  }
}

export async function apiPut(path, body) {
  const r = await fetch(path, { 
    method: 'PUT', 
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }, 
    body: JSON.stringify(body), 
    credentials: 'include' 
  });
  return r.json();
}

export async function apiDel(path) {
  const r = await fetch(path, { 
    method: 'DELETE', 
    headers: {
      'Accept': 'application/json'
    },
    credentials: 'include' 
  });
  return r.json();
}