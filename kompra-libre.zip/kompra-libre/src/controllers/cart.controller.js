
import { getCart, addToCart, updateCartItem, deleteCartItem } from '../models/cart.model.js';
export async function getMyCart(req,res){ const { items } = await getCart(req.user.id); res.json({ items }); }
export async function addItem(req,res){ const { product_id, quantity=1 } = req.body; await addToCart(req.user.id, product_id, quantity); res.json({ ok:true }); }
export async function updateItem(req,res){ const { quantity } = req.body; await updateCartItem(req.params.itemId, quantity||1); res.json({ ok:true }); }
export async function deleteItem(req,res){ await deleteCartItem(req.params.itemId); res.json({ ok:true }); }
