import bcrypt from 'bcryptjs';
import { matchedData } from 'express-validator';
import { signJwt } from '../config/jwt.js';
import * as Users from '../models/user.model.js';

export async function register(req, res) {
  try {
    const { name, email, password, role } = matchedData(req);
    const exists = await Users.findByEmail(email);
    if (exists) return res.status(409).json({ message: 'El email ya está registrado.' });

    const hash = await bcrypt.hash(password, 10);
    const newUser = await Users.create({ name, email, hash_password: hash, role });

    return res.status(201).json({ id: newUser.id, message: 'Cuenta creada.' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Error al registrar.' });
  }
}

export async function login(req, res) {
  try {
    const { email, password } = matchedData(req);
    const user = await Users.findByEmail(email);
    if (!user) return res.status(401).json({ message: 'Credenciales inválidas.' });

    const ok = await bcrypt.compare(password, user.hash_password);
    if (!ok) return res.status(401).json({ message: 'Credenciales inválidas.' });

    const token = signJwt({ uid: user.id, role: user.role });

    // Cookie HttpOnly (ajusta dominio/secure según tu entorno)
    res.cookie('kl_token', token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: false,        // true si usas HTTPS
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: '/',
    });

    return res.json({ message: 'Login OK' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Error al iniciar sesión.' });
  }
}

export async function logout(_req, res) {
  res.clearCookie('kl_token', { path: '/' });
  res.json({ message: 'Logout OK' });
}
