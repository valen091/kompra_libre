
import bcrypt from 'bcryptjs';
import { getMe, updateMe, updatePassword, listFavorites } from '../models/user.model.js';
export async function me(req,res){ const u = await getMe(req.user.id); res.json(u); }
export async function updateProfile(req,res){ const { name } = req.body; await updateMe(req.user.id, { name }); res.json({ ok:true }); }
export async function changePassword(req,res){ const { password } = req.body; const hash = await bcrypt.hash(password, 10); await updatePassword(req.user.id, hash); res.json({ ok:true }); }
export async function favorites(req,res){ const rows = await listFavorites(req.user.id); res.json(rows); }
