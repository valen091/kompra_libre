import { pool } from '../config/db.js';

export async function findByEmail(email) {
  const [rows] = await pool.query('SELECT id, name, email, hash_password, role FROM users WHERE email = ? LIMIT 1', [email]);
  return rows[0] || null;
}

export async function create({ name, email, hash_password, role }) {
  const [res] = await pool.query(
    'INSERT INTO users (name, email, hash_password, role, created_at) VALUES (?, ?, ?, ?, NOW())',
    [name, email, hash_password, role]
  );
  return { id: res.insertId, name, email, role };
}