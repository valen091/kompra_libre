
import { Router } from 'express';
import { requireAuth } from '../middlewares/auth.js';
import { pool } from '../config/db.js';
const r = Router();
r.post('/order-status', requireAuth, async (req,res)=>{
  const { order_id, status } = req.body;
  const [[o]] = await pool.query('SELECT user_id FROM orders WHERE id=?',[order_id]);
  if(!o) return res.status(404).json({error:'Order not found'});
  await pool.query('INSERT INTO notifications (user_id,kind,payload) VALUES (?,?,?)',[o.user_id,'order_status', JSON.stringify({ order_id, status, ts: new Date().toISOString() })]);
  res.json({ ok:true });
});
export default r;
