
import { Router } from 'express';
import { requireAuth } from '../middlewares/auth.js';
import { pool } from '../config/db.js';
const r = Router();
r.get('/', requireAuth, async (req,res)=>{
  const [rows] = await pool.query('SELECT * FROM messages WHERE from_user_id=? OR to_user_id=? ORDER BY created_at DESC LIMIT 100',[req.user.id, req.user.id]);
  res.json(rows);
});
r.post('/', requireAuth, async (req,res)=>{
  const { to_user_id, body, product_id=null, order_id=null } = req.body;
  await pool.query('INSERT INTO messages (product_id,order_id,from_user_id,to_user_id,body) VALUES (?,?,?,?,?)',[product_id,order_id,req.user.id,to_user_id,body]);
  res.json({ ok:true });
});
export default r;
