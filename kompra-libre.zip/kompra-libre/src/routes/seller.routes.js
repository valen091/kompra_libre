
import { Router } from 'express';
import { requireAuth, requireRole } from '../middlewares/auth.js';
import { listSellerProducts } from '../models/product.model.js';
const r = Router();
r.get('/me/products', requireAuth, requireRole('seller'), async (req,res)=>{
  const items = await listSellerProducts(req.user.id);
  res.json(items);
});
export default r;
