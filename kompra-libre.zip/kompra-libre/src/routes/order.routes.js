
import { Router } from 'express';
import { requireAuth, requireRole } from '../middlewares/auth.js';
import { checkout, myOrders, setStatus } from '../controllers/order.controller.js';
const r = Router();
r.post('/', requireAuth, checkout);
r.get('/', requireAuth, myOrders);
r.put('/:id/status', requireAuth, requireRole('admin'), setStatus);
export default r;
