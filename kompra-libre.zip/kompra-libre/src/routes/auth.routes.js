import { Router } from 'express';
import { body } from 'express-validator';
import { register, login, logout } from '../controllers/auth.controller.js';
import { validate } from '../middlewares/validate.js';

const router = Router();

router.post(
  '/register',
  validate([
    body('name').isString().isLength({ min: 2 }),
    body('email').isEmail(),
    body('password').isLength({ min: 6 }),
    body('role').isIn(['buyer', 'seller']),
  ]),
  register
);

router.post(
  '/login',
  validate([
    body('email').isEmail(),
    body('password').isLength({ min: 1 }),
  ]),
  login
);

router.post('/logout', logout);

export default router;