import jwt from 'jsonwebtoken';export const signJwt=(p,o={})=>jwt.sign(p,process.env.JWT_SECRET,{expiresIn:'7d',...o});export const verifyJwt=(t)=>jwt.verify(t,process.env.JWT_SECRET);
