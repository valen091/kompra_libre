
import fs from 'fs';
import { pool } from '../config/db.js';
import '../config/dotenv-load.js';
async function run(){
  const schema = fs.readFileSync('sql/schema.sql','utf-8');
  const seed = fs.readFileSync('sql/seed.sql','utf-8');
  const conn = await pool.getConnection();
  try{
    await conn.query(schema);
    await conn.query(seed);
    console.log('DB initialized.');
    process.exit(0);
  }catch(e){
    console.error('DB init error', e);
    process.exit(1);
  }finally{ conn.release(); }
}
run();
