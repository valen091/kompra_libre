
import { pool } from '../config/db.js';
export async function findUserByEmail(email){ const [r]=await pool.query('SELECT * FROM users WHERE email=?',[email]); return r[0]; }
export async function createUser({name,email,password_hash,role}){ const [r]=await pool.query('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)',[name,email,password_hash,role]); return r.insertId; }
export async function getMe(userId){ const [r]=await pool.query('SELECT id,name,email,role,created_at FROM users WHERE id=?',[userId]); return r[0]; }
export async function updateMe(userId,{name}){ await pool.query('UPDATE users SET name=? WHERE id=?',[name,userId]); }
export async function updatePassword(userId,hash){ await pool.query('UPDATE users SET password_hash=? WHERE id=?',[hash,userId]); }
export async function listFavorites(userId){ const [r]=await pool.query('SELECT p.id,p.title,p.price,(SELECT path FROM product_images WHERE product_id=p.id ORDER BY sort_order LIMIT 1) AS cover FROM products p JOIN favorites f ON f.product_id=p.id WHERE f.user_id=?',[userId]); return r; }
