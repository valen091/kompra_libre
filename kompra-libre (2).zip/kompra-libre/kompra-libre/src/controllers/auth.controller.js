
import bcrypt from 'bcryptjs';
import { signJwt } from '../config/jwt.js';
import { findUserByEmail, createUser } from '../models/user.model.js';
import { pool } from '../config/db.js';

export async function register(req,res){
  const { name, email, password, role='buyer' } = req.body;
  if(!name || !email || !password) return res.status(400).json({error:'Datos faltantes'});
  const exists = await findUserByEmail(email);
  if(exists) return res.status(400).json({error:'Email ya registrado'});
  const hash = await bcrypt.hash(password, 10);
  const userId = await createUser({name,email,password_hash:hash,role});
  if(role==='seller'){ await pool.query('INSERT INTO sellers (user_id, shop_alias) VALUES (?,?)',[userId, name]); }
  const token = signJwt({ id:userId, role });
  res.cookie('token', token, { httpOnly:true, sameSite:'lax' });
  res.json({ ok:true });
}
export async function login(req,res){
  const { email, password } = req.body;
  const user = await findUserByEmail(email);
  if(!user) return res.status(400).json({error:'Credenciales inválidas'});
  const match = await bcrypt.compare(password, user.password_hash).catch(()=>false);
  if(!match) return res.status(400).json({error:'Credenciales inválidas'});
  const token = signJwt({ id:user.id, role:user.role });
  res.cookie('token', token, { httpOnly:true, sameSite:'lax' });
  res.json({ ok:true });
}
export async function logout(req,res){ res.clearCookie('token'); res.json({ ok:true }); }
export async function seedUsersDev(req,res){
  const samples=[['Comprador','comprador@test.com','comprador123!','buyer'],['Vendedor','vendedor@test.com','vendedor123!','seller'],['Admin','admin@test.com','Admin123!','admin']];
  for(const [name,email,pass,role] of samples){
    const [rows] = await pool.query('SELECT * FROM users WHERE email=?',[email]);
    const hash = await bcrypt.hash(pass,10);
    if(rows[0]){ await pool.query('UPDATE users SET password_hash=?, role=? WHERE email=?',[hash,role,email]); }
    else { const [r]=await pool.query('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)',[name,email,hash,role]); if(role==='seller') await pool.query('INSERT INTO sellers (user_id, shop_alias) VALUES (?,?)',[r.insertId,name]); if(role==='admin') await pool.query('INSERT INTO admins (user_id) VALUES (?)',[r.insertId]); }
  }
  res.json({ ok:true });
}
