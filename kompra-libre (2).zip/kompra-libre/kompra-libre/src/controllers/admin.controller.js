
import { pool } from '../config/db.js';
export async function dashboard(req,res){
  const [[sales]] = await pool.query('SELECT IFNULL(SUM(total),0) as sales_total FROM orders');
  const [[users]] = await pool.query('SELECT COUNT(*) as c FROM users');
  const [[reported]] = await pool.query('SELECT COUNT(DISTINCT product_id) as c FROM product_reports');
  res.json({ sales_total: Number(sales.sales_total||0), active_users: users.c, reported_products: reported.c });
}
