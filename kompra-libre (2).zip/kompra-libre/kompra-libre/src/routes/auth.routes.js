
import { Router } from 'express';
import { body } from 'express-validator';
import { register, login, logout, seedUsersDev } from '../controllers/auth.controller.js';
const r = Router();
r.post('/register', body('email').isEmail(), body('password').isLength({min:6}), register);
r.post('/login', body('email').isEmail(), body('password').isLength({min:6}), login);
r.post('/logout', logout);
r.get('/dev/seed-users', seedUsersDev);
export default r;
