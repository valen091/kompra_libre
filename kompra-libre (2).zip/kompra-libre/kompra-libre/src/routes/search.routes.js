
import { Router } from 'express';
import { pool } from '../config/db.js';
const r = Router();
r.get('/suggest', async (req,res)=>{
  const q = (req.query.q||'').trim();
  if(!q) return res.json([]);
  const [p] = await pool.query('SELECT title FROM products WHERE title LIKE ? ORDER BY created_at DESC LIMIT 8',['%'+q+'%']);
  const [c] = await pool.query('SELECT name as title FROM categories WHERE name LIKE ? ORDER BY name LIMIT 5',['%'+q+'%']);
  res.json([...p,...c]);
});
export default r;
