
import './config/dotenv-load.js';
import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import morgan from 'morgan';
import fs from 'fs';
import { Server as IOServer } from 'socket.io';
import { initChat } from './sockets/chat.js';

import authRoutes from './routes/auth.routes.js';
import userRoutes from './routes/user.routes.js';
import productRoutes from './routes/product.routes.js';
import cartRoutes from './routes/cart.routes.js';
import orderRoutes from './routes/order.routes.js';
import adminRoutes from './routes/admin.routes.js';
import categoryRoutes from './routes/category.routes.js';
import messageRoutes from './routes/message.routes.js';
import sellerRoutes from './routes/seller.routes.js';
import notifyRoutes from './routes/notify.routes.js';
import searchRoutes from './routes/search.routes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new IOServer(server, { cors: { origin: process.env.ALLOW_ORIGIN || 'http://localhost:3000', credentials: true }});
initChat(io);

const logStream = fs.createWriteStream(path.join(__dirname, '..', 'logs', 'app.log'), { flags: 'a' });
app.use(morgan('combined', { stream: logStream }));

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(cookieParser());
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.use('/', express.static(path.join(__dirname, '..', 'public')));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/sellers', sellerRoutes);
app.use('/api/notify', notifyRoutes);
app.use('/api/search', searchRoutes);

app.get('/api/health', (req,res)=>res.json({ ok:true }));

const PORT = process.env.PORT || 3000;
server.listen(PORT, ()=>{ console.log('Kompra Libre on http://localhost:'+PORT); });
