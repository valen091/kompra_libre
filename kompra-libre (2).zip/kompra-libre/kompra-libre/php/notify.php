
<?php
header('Content-Type: application/json');
$order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
$status = isset($_POST['status']) ? $_POST['status'] : 'procesando';
$mysqli = new mysqli('localhost', 'root', '', 'kompra_libre');
if ($mysqli->connect_errno) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>'DB error']); exit; }
$res = $mysqli->query("SELECT user_id FROM orders WHERE id=$order_id");
if ($row = $res->fetch_assoc()) {
  $user_id = intval($row['user_id']);
  $stmt = $mysqli->prepare("INSERT INTO notifications (user_id, kind, payload) VALUES (?,?,?)");
  $kind = 'order_status';
  $payload = json_encode(['order_id'=>$order_id,'status'=>$status,'ts'=>date('c')]);
  $stmt->bind_param('iss', $user_id, $kind, $payload);
  $stmt->execute();
  file_put_contents(__DIR__ . '/../logs/app.log', "[".date('c')."] notify order #$order_id -> $status\n", FILE_APPEND);
  echo json_encode(['ok'=>true]);
} else { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'order not found']); }
