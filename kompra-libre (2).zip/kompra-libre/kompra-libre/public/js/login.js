
import { apiPost } from '/js/utils.js';
const form = document.getElementById('formLogin');
form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(form);
  const res = await apiPost('/api/auth/login', { email: fd.get('email'), password: fd.get('password') });
  document.getElementById('msg').textContent = res?.ok ? '' : (res?.error || 'Error');
  if(res?.ok) location.href = '/';
});
