
import { apiPost } from '/js/utils.js';
const form = document.getElementById('formRegistro');
form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(form);
  const data = Object.fromEntries(fd.entries());
  const res = await apiPost('/api/auth/register', data);
  document.getElementById('msg').textContent = res?.ok ? '' : (res?.error || 'Error en registro');
  if(res?.ok) location.href = '/login.html';
});
