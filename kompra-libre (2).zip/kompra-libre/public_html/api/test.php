<?php
// Script de verificación de APIs para Hostinger
header('Content-Type: application/json');

// Incluir configuración
require_once __DIR__ . '/../includes/config.php';

// Verificar si la configuración se cargó correctamente
if (!defined('DB_HOST')) {
    echo json_encode([
        'success' => false,
        'error' => 'Configuración no encontrada',
        'debug' => [
            'config_file' => __DIR__ . '/../includes/config.php',
            'file_exists' => file_exists(__DIR__ . '/../includes/config.php'),
            'php_version' => phpversion()
        ]
    ]);
    exit;
}

// Verificar conexión a base de datos
try {
    require_once __DIR__ . '/../includes/db.php';
    $db = getDB();

    // Probar consulta simple
    $stmt = $db->query("SELECT 1 as test");
    $result = $stmt->fetch();

    if ($result['test'] == 1) {
        echo json_encode([
            'success' => true,
            'message' => 'Conexión a base de datos exitosa',
            'debug' => [
                'db_host' => DB_HOST,
                'db_name' => DB_NAME,
                'php_version' => phpversion(),
                'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
            ]
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Error en consulta de prueba',
            'debug' => ['db_host' => DB_HOST, 'db_name' => DB_NAME]
        ]);
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'debug' => [
            'db_host' => DB_HOST,
            'db_name' => DB_NAME,
            'error_code' => $e->getCode(),
            'php_version' => phpversion()
        ]
    ]);
}
?>
