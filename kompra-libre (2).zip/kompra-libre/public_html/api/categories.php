<?php
// Asegurar que siempre devolvamos JSON válido
ob_clean();
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$response = ['success' => false, 'message' => '', 'data' => []];

try {
    // Conectar a la base de datos
    $db = getDB();

    // Obtener categorías
    $stmt = $db->prepare("SELECT id, name, slug FROM categories ORDER BY name");
    $stmt->execute();
    $categories = $stmt->fetchAll();

    // Respuesta exitosa
    $response = [
        'success' => true,
        'message' => 'Categorías obtenidas exitosamente',
        'data' => $categories
    ];

} catch (Exception $e) {
    $response = [
        'success' => false,
        'message' => $e->getMessage(),
        'code' => $e->getCode() ?: 500,
        'data' => []
    ];
}

// Limpiar cualquier output previo y asegurar JSON válido
ob_clean();
http_response_code(isset($response['code']) ? $response['code'] : 200);
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
exit;
?>
