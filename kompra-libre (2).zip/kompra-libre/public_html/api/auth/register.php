<?php
// Configuración de cabeceras para API REST
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: ' . APP_URL);
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Access-Control-Allow-Credentials: true');
header('Cache-Control: no-cache, must-revalidate');

// Manejar solicitudes OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Iniciar búfer de salida
ob_start();

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';

// Función para limpiar el búfer y enviar la respuesta
function sendJsonResponse($data, $statusCode = 200) {
    ob_end_clean();
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

try {
    // Obtener y validar el método de la solicitud
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Obtener datos de la solicitud
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    // Si no hay datos JSON, intentar con POST
    if (json_last_error() !== JSON_ERROR_NONE || !$data) {
        $data = $_POST;
    }
    
    // Validar datos requeridos
    $required = ['email', 'password', 'name'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            throw new Exception("El campo $field es obligatorio", 400);
        }
    }
    
    // Sanitizar y validar datos
    $email = filter_var(trim($data['email']), FILTER_SANITIZE_EMAIL);
    $password = $data['password'];
    $name = sanitize(trim($data['name']));
    $role = in_array($data['role'] ?? 'buyer', ['buyer', 'seller']) ? $data['role'] : 'buyer';
    $phone = !empty($data['phone']) ? preg_replace('/[^0-9+]/', '', $data['phone']) : null;
    
    // Validaciones adicionales
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('El correo electrónico no es válido', 400);
    }
    
    if (strlen($password) < 8) {
        throw new Exception('La contraseña debe tener al menos 8 caracteres', 400);
    }
    
    if (strlen($name) < 2) {
        throw new Exception('El nombre debe tener al menos 2 caracteres', 400);
    }
    // Solo permitir método POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método no permitido', 405);
    }

    // Obtener datos del cuerpo de la petición
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Si no se pudo decodificar el JSON, intentar desde POST
    if (json_last_error() !== JSON_ERROR_NONE && !empty($_POST)) {
        $data = $_POST;
    }

    // Validar que tengamos datos
    if (!$data) {
        throw new Exception('Datos de registro requeridos', 400);
    }

    // Verificar si el correo ya existe
    $db = getDB();
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        throw new Exception('Este correo electrónico ya está registrado', 409);
    }
    
    // Hashear la contraseña
    $password_hash = password_hash($password, PASSWORD_DEFAULT, ['cost' => 12]);
    
    // Iniciar transacción
    $db->beginTransaction();
    
    try {
        // Insertar usuario
        $stmt = $db->prepare("
            INSERT INTO users (name, email, password_hash, user_role, phone, email_verified)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $email_verified = 1; // O 0 si implementas verificación por correo
        
        $stmt->execute([
            $name,
            $email,
            $password_hash,
            $role,
            $phone,
            $email_verified
        ]);
        
        $user_id = $db->lastInsertId();
        
        // Si es vendedor, crear registro en la tabla sellers
        if ($role === 'seller') {
            $shop_name = substr("Tienda de " . $name, 0, 100);
            $shop_slug = createSlug($shop_name);
            
            $stmt = $db->prepare("
                INSERT INTO sellers (user_id, shop_name, shop_slug, status)
                VALUES (?, ?, ?, 'active')
            ");
            $stmt->execute([$user_id, $shop_name, $shop_slug]);
        }
        
        // Confirmar transacción
        $db->commit();
        
        // Iniciar sesión automáticamente
        $_SESSION['user_id'] = $user_id;
        $_SESSION['user_role'] = $role;
        $_SESSION['email'] = $email;
        $_SESSION['name'] = $name;
        
        if ($role === 'seller') {
            $_SESSION['is_seller'] = true;
            $_SESSION['shop_name'] = $shop_name;
        }
        
        // Generar token JWT
        $token = generateJWT([
            'user_id' => $user_id,
            'email' => $email,
            'role' => $role
        ]);
        
        // Enviar respuesta exitosa
        sendJsonResponse([
            'success' => true,
            'message' => 'Registro exitoso. ¡Bienvenido a ' . APP_NAME . '!',
            'token' => $token,
            'user' => [
                'id' => $user_id,
                'name' => $name,
                'email' => $email,
                'role' => $role,
                'is_seller' => ($role === 'seller'),
                'shop_name' => $shop_name ?? null
            ]
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
        throw new Exception('La contraseña debe tener al menos 8 caracteres', 400);
    }

    // Si no hay nombre, usar parte del email
    if (empty($name) && !empty($email)) {
        $name = explode('@', $email)[0];
    }

    // Conectar a la base de datos usando el sistema unificado
    $db = getDB();

    // Generar username a partir del email si no se proporciona
    $username = $data['username'] ?? explode('@', $email)[0];

    // Verificar si el usuario ya existe
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
    $stmt->execute([$email, $username]);

    if ($stmt->rowCount() > 0) {
        throw new Exception('El correo electrónico o nombre de usuario ya está en uso', 409);
    }

    // Insertar nuevo usuario
    $stmt = $db->prepare("INSERT INTO users (username, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$username, $name, $email, $hashedPassword, $role]);
    $userId = $db->lastInsertId();

    // Si es vendedor, crear perfil de vendedor
    if ($role === 'seller') {
        $storeName = $data['store_name'] ?? $name . ' Store';
        $stmt = $db->prepare("INSERT INTO sellers (user_id, shop_alias) VALUES (?, ?)");
        $stmt->execute([$userId, $storeName]);
    }

    // Iniciar sesión automáticamente después del registro
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_role'] = $role;
    $_SESSION['username'] = $username;

    // Generar token JWT
    $token = generateJWT([
        'user_id' => $userId,
        'username' => $username,
        'role' => $role
    ]);

    // Respuesta exitosa
    $response = [
        'success' => true,
        'message' => 'Registro exitoso',
        'data' => [
            'user' => [
                'id' => $userId,
                'username' => $username,
                'name' => $name,
                'email' => $email,
                'role' => $role
            ],
        ]
    ]);

} catch (Exception $e) {
    $db->rollBack();

    // Limpiar cualquier salida antes de enviar la respuesta de error
    if (ob_get_level() > 0) {
        ob_end_clean();
    }

    // Registrar el error
    error_log("Error en registro: " . $e->getMessage());

    // Determinar el código de estado HTTP
    $statusCode = $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500;

    // Mensaje de error amigable
    $errorMessage = $e->getMessage();

    // Si es un error de base de datos y estamos en producción, ocultar detalles
    if ($statusCode === 500 && !APP_DEBUG) {
        $errorMessage = 'Ocurrió un error al procesar el registro. Por favor, intente nuevamente.';
    }

    // Enviar respuesta de error
    $response = [
        'success' => false,
        'message' => $errorMessage
    ];

    // Agregar información de depuración si está habilitada
    if (APP_DEBUG) {
        $response['debug'] = [
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ];

        if (isset($e->errorInfo) && is_array($e->errorInfo)) {
            $response['debug']['error_info'] = $e->errorInfo;
        }
    }

    http_response_code($statusCode);
    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}