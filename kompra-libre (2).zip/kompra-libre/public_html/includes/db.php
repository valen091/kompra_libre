<?php
class DB {
    private static $i=null;private $c=null;private const O=[
        3=>2,2=>2,1000=>0,1002=>"SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
        1001=>1];private function __construct(){$this->c();}
    private function c(){
        try{$this->c=new PDO(sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4',DB_HOST,DB_NAME),DB_USER,DB_PASS,self::O);
            $this->c->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
            $this->c->exec("SET SESSION time_zone='America/Montevideo'");
        }catch(PDOException$e){throw new RuntimeException('Error de conexión a la base de datos',500);}
    }
    public static function gI(){return self::$i??=new self();}
    public function gC(){return $this->c??$this->c();}
    private function __clone(){}
    public function __wakeup(){throw new RuntimeException('No se puede deserializar');}
}
function getDB(){return DB::gI()->gC();}
function getDBConnection(){
    static$p=null;if($p!==null)return$p;
    $o=[3=>2,2=>2,1000=>0,1002=>"SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"];
    foreach([
        ['mysql:host=localhost;dbname=u472738607_kompra_libre;charset=utf8mb4','u472738607_kompra_libre','Kompralibre1'],
        ['mysql:host=localhost;dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS],
        ['mysql:host=127.0.0.1;dbname=kompra_libre;charset=utf8mb4','root','']
    ]as$c)try{
        $p=new PDO($c[0],$c[1],$c[2],$o);$p->setAttribute(3,30);
        $p->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO'");
        $p->exec("SET SESSION time_zone='America/Montevideo'");return$p;
    }catch(PDOException$e){continue;}
    throw new RuntimeException('Error de conexión a la base de datos');
}