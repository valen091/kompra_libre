<?php
require_once __DIR__ . '/config.php';

function sanitize($data) {
    return is_array($data) ? array_map('sanitize', $data) : htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: " . APP_URL . $url);
    exit;
}

function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}

function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function uploadFile($file, $directory = '') {
    $targetDir = UPLOAD_DIR . $directory;
    if (!file_exists($targetDir)) mkdir($targetDir, 0777, true);
    $fileName = uniqid() . '_' . basename($file['name']);
    $targetPath = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
    if (!in_array($fileType, ALLOWED_EXTENSIONS)) throw new Exception('Tipo de archivo no permitido.');
    if ($file['size'] > MAX_UPLOAD_SIZE) throw new Exception('El archivo excede el tamaño máximo permitido.');
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) throw new Exception('Error al subir el archivo.');
    return '/uploads/' . $directory . $fileName;
}

function formatPrice($price) {
    return '$' . number_format($price, 2, ',', '.');
}

function generateSlug($string) {
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $string)));
    return preg_replace('/-+/', '-', $slug);
}

function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function isSeller() {
    return isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['seller', 'admin']);
}

function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

function generateJWT($payload) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload = array_merge(['iat' => time(), 'exp' => time() + JWT_EXPIRE, 'jti' => bin2hex(random_bytes(32))], $payload);
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($payload)));
    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

function validateJWT($token) {
    $tokenParts = explode('.', $token);
    if (count($tokenParts) !== 3) return false;
    list($base64UrlHeader, $base64UrlPayload, $signature) = $tokenParts;
    $header = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64UrlHeader)), true);
    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64UrlPayload)), true);
    if (!$header || !$payload || !isset($header['alg']) || $header['alg'] !== 'HS256' || !isset($payload['exp']) || $payload['exp'] < time()) return false;
    $validSignature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, JWT_SECRET, true);
    $base64UrlValidSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($validSignature));
    return hash_equals($signature, $base64UrlValidSignature) ? $payload : false;
    return $payload;
}