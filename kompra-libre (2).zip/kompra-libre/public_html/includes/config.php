<?php
define('APP_NAME', 'Kompra Libre');
define('APP_URL', 'https://kompralibre.shop/');
define('APP_DEBUG', true);

define('DB_HOST', 'localhost');
define('DB_NAME', 'u472738607_kompra_libre');
define('DB_USER', 'u472738607_kompra_libre');
define('DB_PASS', 'Kompralibre1');

ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', isset($_SERVER['HTTPS']));
ini_set('session.cookie_samesite', 'Lax');
session_name('kompra_libre_session');
session_set_cookie_params(['lifetime' => 86400, 'path' => '/', 'domain' => $_SERVER['HTTP_HOST'], 'secure' => isset($_SERVER['HTTPS']), 'httponly' => true, 'samesite' => 'Lax']);
session_start();

define('SESSION_NAME', 'kompra_libre_session');
define('SESSION_LIFETIME', 86400);

define('JWT_SECRET', 'tu_clave_secreta_muy_segura_aqui_2024_kompra_libre');
define('JWT_EXPIRE', 86400);

define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024);
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

// Configuración de zona horaria
date_default_timezone_set('America/Montevideo');

// Iniciar sesión de forma silenciosa
@session_name(SESSION_NAME);
@session_set_cookie_params([
    'lifetime' => SESSION_LIFETIME,
    'path' => '/',
    'domain' => '',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);
@session_start();