<?php
// ✅ SETUP ULTRA ROBUSTO - TODO EN PHP SIN ARCHIVOS SQL
// Compatible con cualquier versión de MySQL/MariaDB
header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>";
echo "<html><head><title>Setup Kompra Libre - 100% PHP</title>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
    .container { max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
    .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 10px 0; border: 1px solid #c3e6cb; }
    .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 10px 0; border: 1px solid #f5c6cb; }
    .info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 10px 0; border: 1px solid #bee5eb; }
    .step { border-left: 4px solid #007cba; padding: 15px; margin: 15px 0; }
    .btn { background: #007cba; color: white; padding: 15px 30px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin: 10px; }
    .btn:hover { background: #005a8b; }
    table { width: 100%; border-collapse: collapse; margin: 15px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
</style>";
echo "</head><body>";
echo "<div class='container'>";

echo "<h1>🛠️ SETUP 100% PHP - SIN ARCHIVOS SQL</h1>";
echo "<p>Configuración ultra-robusta que funciona en cualquier servidor</p>";

// Incluir configuración
try {
    require_once __DIR__ . '/includes/config.php';
    require_once __DIR__ . '/includes/db.php';

    $pdo = getDB();
    echo "<div class='success'>✅ Conexión a base de datos exitosa</div>";

    // PASO 1: Crear tablas con PHP (sin ENUM problemáticos)
    echo "<div class='step'>";
    echo "<h3>📋 PASO 1: Creando tablas con PHP...</h3>";

    try {
        // Crear tabla users
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(120) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            user_role VARCHAR(20) NOT NULL DEFAULT 'buyer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_email (email)
        )");
        echo "<div class='success'>✅ Tabla users creada</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Tabla users ya existe</div>";
    }

    try {
        // Crear tabla categories
        $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(120) NOT NULL,
            slug VARCHAR(120) NOT NULL,
            UNIQUE KEY unique_slug (slug)
        )");
        echo "<div class='success'>✅ Tabla categories creada</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Tabla categories ya existe</div>";
    }

    try {
        // Crear tabla sellers
        $pdo->exec("CREATE TABLE IF NOT EXISTS sellers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            shop_alias VARCHAR(120),
            reputation INT DEFAULT 0
        )");
        echo "<div class='success'>✅ Tabla sellers creada</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Tabla sellers ya existe</div>";
    }

    try {
        // Crear tabla admins
        $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL
        )");
        echo "<div class='success'>✅ Tabla admins creada</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Tabla admins ya existe</div>";
    }

    try {
        // Crear tabla products (sin ENUM problemáticos)
        $pdo->exec("CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            seller_id INT NOT NULL,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            stock INT NOT NULL DEFAULT 0,
            product_condition VARCHAR(20) DEFAULT 'nuevo',
            category_id INT,
            visible INT DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_products_title (title),
            INDEX idx_products_category (category_id)
        )");
        echo "<div class='success'>✅ Tabla products creada</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Tabla products ya existe</div>";
    }

    echo "</div>";

    // PASO 2: Insertar 3 cuentas demo
    echo "<div class='step'>";
    echo "<h3>👤 PASO 2: Creando 3 cuentas demo...</h3>";

    // Usuario demo (comprador)
    try {
        $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, user_role) VALUES
            ('Demo Comprador', 'comprador@demo.com', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer')");
        echo "<div class='success'>✅ Usuario demo (comprador) creado</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Usuario demo (comprador) ya existe</div>";
    }

    // Vendedor demo
    try {
        $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, user_role) VALUES
            ('Demo Vendedor', 'vendedor@demo.com', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller')");
        echo "<div class='success'>✅ Usuario demo (vendedor) creado</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Usuario demo (vendedor) ya existe</div>";
    }

    // Admin demo
    try {
        $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, user_role) VALUES
            ('Demo Admin', 'admin@demo.com', '\$2y\$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin')");
        echo "<div class='success'>✅ Usuario demo (admin) creado</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Usuario demo (admin) ya existe</div>";
    }

    echo "</div>";

    // PASO 3: Configurar vendedores y admins
    echo "<div class='step'>";
    echo "<h3>🏪 PASO 3: Configurando vendedores y admins...</h3>";

    try {
        $pdo->exec("INSERT IGNORE INTO sellers (user_id, shop_alias)
            SELECT id, 'Tienda Demo' FROM users WHERE email = 'vendedor@demo.com'");
        echo "<div class='success'>✅ Vendedor configurado</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Vendedor ya existe</div>";
    }

    try {
        $pdo->exec("INSERT IGNORE INTO admins (user_id)
            SELECT id FROM users WHERE email = 'admin@demo.com'");
        echo "<div class='success'>✅ Admin configurado</div>";
    } catch (Exception $e) {
        echo "<div class='info'>✅ Admin ya existe</div>";
    }

    echo "</div>";

    // PASO 4: Insertar categorías
    echo "<div class='step'>";
    echo "<h3>🏷️ PASO 4: Insertando categorías...</h3>";

    $categories = [
        ['Electrónica', 'electronica'],
        ['Ropa', 'ropa'],
        ['Hogar', 'hogar'],
        ['Deportes', 'deportes'],
        ['Libros', 'libros'],
        ['Automóvil', 'automovil'],
        ['Belleza', 'belleza'],
        ['Juguetes', 'juguetes'],
        ['Música', 'musica'],
        ['Salud', 'salud']
    ];

    foreach ($categories as $cat) {
        try {
            $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('{$cat[0]}', '{$cat[1]}')");
        } catch (Exception $e) {
            // Ignorar duplicados
        }
    }
    echo "<div class='success'>✅ " . count($categories) . " categorías insertadas</div>";
    echo "</div>";

    // PASO 5: Insertar productos
    echo "<div class='step'>";
    echo "<h3>📦 PASO 5: Insertando productos...</h3>";

    // Obtener el ID del vendedor
    $stmt = $pdo->query("SELECT id FROM sellers WHERE shop_alias = 'Tienda Demo'");
    $seller_id = $stmt->fetch()['id'];

    if ($seller_id) {
        $productos = [
            ['iPhone 15 Pro Max', 'El iPhone más avanzado con cámara profesional', 1299.99, 1],
            ['MacBook Air M3', 'Laptop ultraligera con chip M3', 1099.99, 1],
            ['Camiseta Deportiva Nike', 'Camiseta transpirable para entrenamientos', 29.99, 2],
            ['Juego de Sartenes', 'Set de 3 sartenes antiadherentes', 89.99, 3],
            ['Balón de Fútbol Adidas', 'Balón oficial tamaño 5', 39.99, 4],
            ['Clean Code - Libro', 'Libro sobre buenas prácticas de programación', 49.99, 5],
            ['Auriculares Bluetooth Sony', 'Auriculares inalámbricos con cancelación de ruido', 199.99, 1],
            ['Zapatillas Running Adidas', 'Zapatillas deportivas para running', 89.99, 4],
            ['Lámpara de Escritorio LED', 'Lámpara articulada con luz LED regulable', 45.99, 3],
            ['Chaqueta Impermeable', 'Chaqueta resistente al agua para outdoor', 79.99, 2],
            ['Televisor 4K Samsung 55"', 'Smart TV con resolución 4K y HDR', 899.99, 1],
            ['Reloj Inteligente Apple Watch', 'Apple Watch Series 9 con GPS', 399.99, 1],
            ['Sofá de 3 plazas', 'Sofá moderno y cómodo para sala', 599.99, 3],
            ['Bicicleta Mountain Bike', 'Bicicleta todo terreno con 21 velocidades', 299.99, 4],
            ['Guitarra Acústica Yamaha', 'Guitarra acústica de madera', 199.99, 9]
        ];

        $productos_insertados = 0;
        foreach ($productos as $prod) {
            try {
                $pdo->exec("INSERT IGNORE INTO products (seller_id, title, description, price, stock, product_condition, category_id, visible) VALUES
                    ($seller_id, '{$prod[0]}', '{$prod[1]}', {$prod[2]}, 10, 'nuevo', {$prod[3]}, 1)");
                $productos_insertados++;
            } catch (Exception $e) {
                // Ignorar duplicados
            }
        }

        echo "<div class='success'>✅ $productos_insertados productos insertados</div>";
    } else {
        echo "<div class='error'>❌ No se pudo obtener el ID del vendedor</div>";
    }

    echo "</div>";

    // PASO 6: Verificación final
    echo "<div class='step'>";
    echo "<h3>📊 PASO 6: Verificación final...</h3>";

    $stats = [
        'usuarios' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
        'categorias' => $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn(),
        'productos' => $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn(),
        'vendedores' => $pdo->query("SELECT COUNT(*) FROM sellers")->fetchColumn(),
        'admins' => $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn()
    ];

    echo "<table>";
    echo "<tr><th>Tipo</th><th>Cantidad</th><th>Estado</th></tr>";
    echo "<tr><td>👤 Usuarios Totales</td><td>{$stats['usuarios']}</td><td>" . ($stats['usuarios'] >= 3 ? "✅ OK" : "❌ Faltan") . "</td></tr>";
    echo "<tr><td>🏷️ Categorías</td><td>{$stats['categorias']}</td><td>" . ($stats['categorias'] >= 5 ? "✅ OK" : "❌ Faltan") . "</td></tr>";
    echo "<tr><td>📦 Productos Visibles</td><td>{$stats['productos']}</td><td>" . ($stats['productos'] >= 10 ? "✅ OK" : "❌ Faltan") . "</td></tr>";
    echo "<tr><td>🏪 Vendedores</td><td>{$stats['vendedores']}</td><td>" . ($stats['vendedores'] >= 1 ? "✅ OK" : "❌ Faltan") . "</td></tr>";
    echo "<tr><td>👨‍💼 Admins</td><td>{$stats['admins']}</td><td>" . ($stats['admins'] >= 1 ? "✅ OK" : "❌ Faltan") . "</td></tr>";
    echo "</table>";
    echo "</div>";

    // Mostrar cuentas demo
    echo "<div class='step'>";
    echo "<h3>🔐 CUENTAS DEMO CREADAS:</h3>";
    echo "<table>";
    echo "<tr><th>Rol</th><th>Email</th><th>Contraseña</th><th>Panel</th></tr>";

    $cuentas = $pdo->query("SELECT name, email, user_role FROM users ORDER BY user_role, email")->fetchAll();
    foreach ($cuentas as $cuenta) {
        $pass = 'demo123';
        $panel = ($cuenta['user_role'] == 'admin') ? 'Panel Admin' :
                 (($cuenta['user_role'] == 'seller') ? 'Panel Vendedor' : 'Panel Usuario');
        echo "<tr><td>{$cuenta['user_role']}</td><td>{$cuenta['email']}</td><td><code>$pass</code></td><td>$panel</td></tr>";
    }
    echo "</table>";
    echo "</div>";

    // Estado final
    $todo_ok = ($stats['usuarios'] >= 3) && ($stats['categorias'] >= 5) && ($stats['productos'] >= 10);

    echo "<div class='" . ($todo_ok ? 'success' : 'error') . "'>";
    if ($todo_ok) {
        echo "<h2>🎉 ¡SETUP COMPLETADO EXITOSAMENTE!</h2>";
        echo "<p>✅ Todas las tablas creadas<br>";
        echo "✅ 3 cuentas demo configuradas<br>";
        echo "✅ {$stats['categorias']} categorías insertadas<br>";
        echo "✅ {$stats['productos']} productos visibles<br>";
        echo "✅ APIs listas para usar</p>";
        echo "<p><a href='https://kompralibre.shop' class='btn'>🚀 Ir al sitio web</a></p>";
    } else {
        echo "<h2>⚠️ SETUP INCOMPLETO</h2>";
        echo "<p>Algunos datos no se insertaron correctamente. Revisa los errores anteriores.</p>";
        echo "<p><button class='btn' onclick='location.reload()'>🔄 Reintentar</button></p>";
    }
    echo "</div>";

} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<h3>❌ ERROR DE CONEXIÓN</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "<h4>🔧 Soluciones:</h4>";
    echo "<ul>";
    echo "<li>Verifica que la base de datos u472738607_kompra_libre existe</li>";
    echo "<li>Verifica las credenciales en config.php</li>";
    echo "<li>Usa PHPMyAdmin con los archivos SQL corregidos</li>";
    echo "</ul>";
    echo "<p><strong>Archivos SQL corregidos:</strong><br>";
    echo "<a href='sql/1-tablas-corregido.sql'>📁 1-tablas-corregido.sql</a><br>";
    echo "<a href='sql/2-datos-corregido.sql'>📁 2-datos-corregido.sql</a></p>";
    echo "</div>";
}

echo "</div>";
echo "</body></html>";
?>
