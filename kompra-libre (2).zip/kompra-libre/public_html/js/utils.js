export async function api(path) {
  try {
    const baseUrl = ''; // Deja esto vacío para rutas relativas
    const url = `${baseUrl}${path}`;
    console.log('API Request:', url);

    const r = await fetch(url, {
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });

    console.log('API Response Status:', r.status, r.statusText);

    if (!r.ok) {
      const errorText = await r.text().catch(() => 'No error text available');
      const errorData = await r.json().catch(() => ({}));

      console.error('API Error Response:', {
        status: r.status,
        statusText: r.statusText,
        errorText,
        errorData,
        url
      });

      throw new Error(`HTTP ${r.status}: ${errorData.error || errorData.message || 'Error en la solicitud'}`);
    }

    const data = await r.json();
    console.log('API Response Data:', data);
    return data;
  } catch (error) {
    console.error('Error en la petición:', error);
    throw error;
  }
}

export async function apiPost(path, body) {
  const r = await fetch(path, { 
    method: 'POST', 
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }, 
    body: JSON.stringify(body), 
    credentials: 'include' 
  });
  try { 
    return await r.json(); 
  } catch(e) { 
    return { ok: r.ok, status: r.status }; 
  }
}

export async function apiPut(path, body) {
  const r = await fetch(path, { 
    method: 'PUT', 
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }, 
    body: JSON.stringify(body), 
    credentials: 'include' 
  });
  return r.json();
}

export async function apiDel(path) {
  const r = await fetch(path, { 
    method: 'DELETE', 
    headers: {
      'Accept': 'application/json'
    },
    credentials: 'include' 
  });
  return r.json();
}