import { api } from './utils.js';

let page = 1;
const limit = window.innerWidth < 768 ? 6 : 9; // Menos productos en mobile para mejor performance

// Update limit on resize
window.addEventListener('resize', () => {
    const newLimit = window.innerWidth < 768 ? 6 : 9;
    if (newLimit !== limit) {
        limit = newLimit;
        page = 1; // Reset to first page
        loadProducts();
    }
});

async function loadCategories() {
    try {
        // Intentar cargar categorías reales primero
        try {
            const cats = await api('api/categories');
            const sel = document.getElementById('f_categoria');
            if (sel) {
                sel.innerHTML = '<option value="">Todas las categorías</option>' +
                    cats.data.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
            }
        } catch (realError) {
            console.warn('Error con API real, usando API simplificada:', realError);

            // Fallback a API simplificada
            const cats = await api('api/categories-simple');
            const sel = document.getElementById('f_categoria');
            if (sel) {
                sel.innerHTML = '<option value="">Todas las categorías</option>' +
                    cats.data.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
            }
        }
    } catch (error) {
        console.error('Error al cargar categorías (incluso con fallback):', error);
    }
}

async function loadProducts() {
    try {
        const q = document.getElementById('q')?.value || '';
        const category = document.getElementById('f_categoria')?.value || '';
        const priceMin = document.getElementById('f_pmin')?.value || '';
        const priceMax = document.getElementById('f_pmax')?.value || '';
        const cond = document.getElementById('f_cond')?.value || '';

        const params = new URLSearchParams({
            q,
            category,
            price_min: priceMin,
            price_max: priceMax,
            condition: cond,
            page,
            limit
        }).toString();

        // Intentar cargar productos reales primero
        try {
            const res = await api(`api/products?${params}`);
            renderProducts(res.data.products);
        } catch (realError) {
            console.warn('Error con API real de productos, usando API simplificada:', realError);

            // Fallback a API simplificada
            const res = await api(`api/products-simple?${params}`);
            renderProducts(res.data.products);
        }

    } catch (error) {
        console.error('Error al cargar productos:', error);
        const cont = document.getElementById('productos');
        if (cont) {
            cont.innerHTML = `
                <div class="col-span-full text-center py-10">
                    <div class="text-red-500 mb-2">Error al cargar los productos</div>
                    <div class="text-gray-600 mb-4">${error.message}</div>
                    <button onclick="location.reload()" class="text-blue-500 hover:underline">
                        Reintentar
                    </button>
                </div>
            `;
        }
    }
}

function renderProducts(products) {
    const cont = document.getElementById('productos');
    if (cont) {
        cont.innerHTML = products.map(p => `
            <article class="bg-white p-3 sm:p-4 rounded-lg shadow-sm hover:shadow-md transition-all duration-300 product-card group">
                <a href="producto.html?id=${p.id}" class="block">
                    <div class="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-3">
                        <img src="${p.cover || 'https://via.placeholder.com/300x300/3483FA/FFFFFF?text=' + encodeURIComponent(p.title)}"
                             alt="${p.title}"
                             class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                             loading="lazy">
                    </div>
                    <h3 class="font-semibold text-gray-900 line-clamp-2 h-12 text-sm sm:text-base leading-tight">${p.title}</h3>
                    <div class="text-xs sm:text-sm text-gray-500 mb-2">${p.category_name || 'Sin categoría'}</div>
                    <div class="text-lg sm:text-xl font-bold text-green-600 mb-1 price">$${parseFloat(p.price).toFixed(2)}</div>
                    <div class="text-xs text-gray-400 flex items-center gap-1">
                        <span class="${p.condition === 'nuevo' ? 'text-green-600' : 'text-blue-600'}">${p.condition === 'nuevo' ? '●' : '●'}</span>
                        <span>${p.condition === 'nuevo' ? 'Nuevo' : 'Usado'}</span>
                    </div>
                </a>
            </article>
        `).join('');
    }

    // Actualizar paginación
    const pageEl = document.getElementById('page');
    if (pageEl) {
        pageEl.textContent = page;
    }
}

// Sincronizar filtros mobile y desktop
function syncFilters() {
    const desktopCategory = document.getElementById('f_categoria');
    const mobileCategory = document.getElementById('f_categoria_mobile');
    const desktopPriceMin = document.getElementById('f_pmin');
    const mobilePriceMin = document.getElementById('f_pmin_mobile');
    const desktopPriceMax = document.getElementById('f_pmax');
    const mobilePriceMax = document.getElementById('f_pmax_mobile');
    const desktopCond = document.getElementById('f_cond');
    const mobileCond = document.getElementById('f_cond_mobile');

    // Función para sincronizar valores
    function syncValues() {
        if (desktopCategory && mobileCategory) {
            mobileCategory.value = desktopCategory.value;
        }
        if (desktopPriceMin && mobilePriceMin) {
            mobilePriceMin.value = desktopPriceMin.value;
        }
        if (desktopPriceMax && mobilePriceMax) {
            mobilePriceMax.value = desktopPriceMax.value;
        }
        if (desktopCond && mobileCond) {
            mobileCond.value = desktopCond.value;
        }
    }

    // Función para aplicar filtros desde mobile
    function applyMobileFilters() {
        if (desktopCategory && mobileCategory) {
            desktopCategory.value = mobileCategory.value;
        }
        if (desktopPriceMin && mobilePriceMin) {
            desktopPriceMin.value = mobilePriceMin.value;
        }
        if (desktopPriceMax && mobilePriceMax) {
            desktopPriceMax.value = mobilePriceMax.value;
        }
        if (desktopCond && mobileCond) {
            desktopCond.value = mobileCond.value;
        }
        page = 1;
        loadProducts();
    }

    // Sincronizar al cargar
    syncValues();

    // Sincronizar cambios en desktop a mobile
    if (desktopCategory) desktopCategory.addEventListener('change', syncValues);
    if (desktopPriceMin) desktopPriceMin.addEventListener('input', syncValues);
    if (desktopPriceMax) desktopPriceMax.addEventListener('input', syncValues);
    if (desktopCond) desktopCond.addEventListener('change', syncValues);

    // Aplicar filtros mobile
    const mobileBtnFiltrar = document.getElementById('btnFiltrarMobile');
    if (mobileBtnFiltrar) {
        mobileBtnFiltrar.addEventListener('click', () => {
            applyMobileFilters();
            // Cerrar panel mobile
            const mobileFilters = document.getElementById('mobileFilters');
            if (mobileFilters) {
                mobileFilters.classList.add('hidden');
            }
        });
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', async () => {
    await loadCategories();
    await loadProducts();

    // Sincronizar filtros mobile y desktop
    syncFilters();

    // Buscar al hacer clic en el botón
    const btnBuscar = document.getElementById('btnBuscar');
    if (btnBuscar) {
        btnBuscar.addEventListener('click', () => {
            page = 1;
            loadProducts();
        });
    }

    // Buscar al presionar Enter en el input
    function setupSearchInput() {
        const searchInput = document.getElementById('q');
        if (!searchInput) {
            console.warn('Search input element not found');
            return;
        }

        // Asegurarse de que el input sea visible y habilitado
        if (searchInput.offsetParent === null || searchInput.disabled) {
            console.warn('Search input is not visible or is disabled');
            return;
        }

        const handleSearch = (e) => {
            if (e.key === 'Enter' || e.type === 'click') {
                e.preventDefault();
                page = 1;
                loadProducts();

                // Opcional: Quitar el foco del input después de buscar
                if (e.type === 'keypress') {
                    searchInput.blur();
                }
            }
        };

        // Agregar event listeners
        searchInput.addEventListener('keypress', handleSearch);

        // También manejar el clic en el botón de búsqueda
        const searchButton = document.querySelector('.search-button, [type="submit"], button[type="button"]');
        if (searchButton) {
            searchButton.addEventListener('click', handleSearch);
        }
    }

    // Configurar el input de búsqueda
    setupSearchInput();

    // Filtros
    const btnFiltrar = document.getElementById('btnFiltrar');
    if (btnFiltrar) {
        btnFiltrar.addEventListener('click', () => {
            page = 1;
            loadProducts();
        });
    }

    // Paginación
    const prevBtn = document.getElementById('prev');
    const nextBtn = document.getElementById('next');

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (page > 1) {
                page--;
                loadProducts();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            page++;
            loadProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }

    // Autocompletado de búsqueda
    const searchInput = document.getElementById('q');
    const datalist = document.getElementById('sugs');
    let timeoutId;

    if (searchInput && datalist) {
        searchInput.addEventListener('input', () => {
            clearTimeout(timeoutId);
            const query = searchInput.value.trim();

            if (query.length < 2) {
                datalist.innerHTML = '';
                return;
            }

            timeoutId = setTimeout(async () => {
                try {
                    const suggestions = await api(`/api/search/suggest?q=${encodeURIComponent(query)}`);
                    datalist.innerHTML = suggestions.map(s =>
                        `<option value="${s.title}">`
                    ).join('');
                } catch (error) {
                    console.error('Error al obtener sugerencias:', error);
                }
            }, 300);
        });
    }
});