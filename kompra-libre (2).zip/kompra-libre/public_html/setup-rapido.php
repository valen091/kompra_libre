<?php
// Setup ultra simple - solo lo esencial
header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>";
echo "<html><head><title>Setup Rápido</title>";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
    .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
    .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin: 5px 0; }
    .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin: 5px 0; }
    .info { background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 5px; margin: 5px 0; }
    .btn { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
</style>";
echo "</head><body>";
echo "<div class='container'>";

echo "<h1>🛠️ SETUP RÁPIDO - SOLO LO ESENCIAL</h1>";

// Incluir configuración
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    echo "<div class='success'>✅ Conexión a base de datos exitosa</div>";
    echo "<div class='info'>Base de datos: " . DB_NAME . "</div>";

    // Insertar datos básicos
    echo "<h3>📝 Insertando datos...</h3>";

    // 3 cuentas demo
    $demoUsers = [
        ['Demo Comprador', 'comprador@gmail.com', 'buyer'],
        ['Demo Vendedor', 'vendedor@gmail.com', 'seller'],
        ['Demo Admin', 'admin@gmail.com', 'admin']
    ];

    foreach ($demoUsers as $user) {
        try {
            $passwordHash = password_hash('demo123', PASSWORD_DEFAULT);
            $pdo->exec("INSERT IGNORE INTO users (name, email, password_hash, role) VALUES ('{$user[0]}', '{$user[1]}', '{$passwordHash}', '{$user[2]}')");
            echo "<div class='success'>✅ Usuario {$user[1]} creado</div>";
        } catch (Exception $e) {
            echo "<div class='info'>✅ Usuario {$user[1]} ya existe</div>";
        }
    }

    // Categorías básicas
    $categories = ['Electrónica', 'Ropa', 'Hogar', 'Deportes', 'Libros'];
    foreach ($categories as $cat) {
        try {
            $pdo->exec("INSERT IGNORE INTO categories (name, slug) VALUES ('$cat', LOWER('$cat'))");
        } catch (Exception $e) {
            // Ignorar duplicados
        }
    }
    echo "<div class='success'>✅ " . count($categories) . " categorías insertadas</div>";

    // Productos básicos
    try {
        $stmt = $pdo->query("SELECT id FROM users WHERE email = 'vendedor@demo.com'");
        $sellerId = $stmt->fetch()['id'];

        if ($sellerId) {
            $productos = [
                ['iPhone 15 Pro', 1299.99, 1],
                ['MacBook Air M3', 1099.99, 1],
                ['Camiseta Nike', 29.99, 2],
                ['Balón Adidas', 39.99, 4],
                ['Clean Code Libro', 49.99, 5]
            ];

            foreach ($productos as $prod) {
                $pdo->exec("INSERT IGNORE INTO products (seller_id, title, description, price, stock, product_condition, category_id, visible) VALUES
                    ($sellerId, '{$prod[0]}', 'Producto de ejemplo', {$prod[1]}, 10, 'nuevo', {$prod[2]}, 1)");
            }
            echo "<div class='success'>✅ " . count($productos) . " productos insertados</div>";
        } else {
            echo "<div class='error'>❌ No se pudo obtener el ID del vendedor</div>";
        }

        echo "</div>";

        // Insertar pedido de ejemplo para las reseñas
        echo "<div class='step'>";
        echo "<h3>🛒 Insertando pedido de ejemplo...</h3>";

        try {
            $stmt = $pdo->query("SELECT id FROM users WHERE email = 'comprador@gmail.com'");
            $buyer = $stmt->fetch();

            if ($buyer) {
                $pdo->exec("INSERT IGNORE INTO orders (order_number, user_id, seller_id, subtotal, shipping_cost, total_amount, order_status, payment_status, shipping_method_id) VALUES
                    ('KL20241027-000001', {$buyer['id']}, 1, 1449999.98, 299.99, 1450299.97, 'entregado', 'completado', 1)");

                // Insertar items del pedido
                $pdo->exec("INSERT IGNORE INTO order_items (order_id, product_id, product_title, product_price, quantity, subtotal) VALUES
                    (1, 1, 'iPhone 15 Pro Max 256GB', 1299999.99, 1, 1299999.99),
                    (1, 2, 'MacBook Air M3 13\" 8GB 256GB', 1099999.99, 1, 1099999.99),
                    (1, 3, 'Camiseta Deportiva Nike Dri-FIT', 29999.99, 1, 29999.99),
                    (1, 4, 'Juego de Sartenes Antiaderentes 3 Piezas', 89999.99, 1, 89999.99),
                    (1, 5, 'Balón de Fútbol Adidas FIFA Approved', 39999.99, 1, 39999.99),
                    (1, 6, 'Clean Code: A Handbook of Agile Software Craftsmanship', 49999.99, 1, 49999.99)");

                echo "<div class='success'>✅ Pedido de ejemplo insertado con items</div>";
            }
        } catch (Exception $e) {
            echo "<div class='info'>✅ Pedido ya existe</div>";
        }

        echo "</div>";
        echo "<h3>📊 RESULTADO FINAL</h3>";
        $stats = [
            'usuarios' => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
            'categorias' => $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn(),
            'productos' => $pdo->query("SELECT COUNT(*) FROM products WHERE visible = 1")->fetchColumn(),
            'pedidos' => $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn(),
            'order_items' => $pdo->query("SELECT COUNT(*) FROM order_items")->fetchColumn(),
            'reseñas' => $pdo->query("SELECT COUNT(*) FROM reviews")->fetchColumn()
        ];

        echo "<div class='success'>";
        echo "<h4>✅ SETUP COMPLETADO</h4>";
        echo "<ul>";
        echo "<li>👤 Usuarios: {$stats['usuarios']}</li>";
        echo "<li>🏷️ Categorías: {$stats['categorias']}</li>";
        echo "<li>📦 Productos: {$stats['productos']}</li>";
        echo "<li>🛒 Pedidos: {$stats['pedidos']}</li>";
        echo "<li>📋 Items de pedido: {$stats['order_items']}</li>";
        echo "<li>⭐ Reseñas: {$stats['reseñas']}</li>";
        echo "</ul>";
        echo "<p><strong>🎉 ¡TODO LISTO!</strong></p>";
        echo "<p><a href='https://kompralibre.shop' class='btn'>🚀 Ir al sitio</a></p>";
        echo "</div>";

} catch (Exception $e) {
    echo "<div class='error'>❌ Error: " . $e->getMessage() . "</div>";
    echo "<p><a href='setup-directo.html' class='btn'>🔄 Setup Visual</a></p>";
}

echo "</div>";
echo "</body></html>";
?>
