<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$endpoint = str_replace('/api/', '', $request_uri);
$endpoint = explode('?', $endpoint)[0];
if (isset($_GET['endpoint'])) { $endpoint = $_GET['endpoint']; unset($_GET['endpoint']); }
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/db.php';
function getDBConnection() {
    $credentials = [
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => 'Kompralibre1'],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'root', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'u472738607_kompra_libre', 'user' => 'u472738607_kompra_libre', 'pass' => ''],
        ['host' => 'localhost', 'db' => 'kompra_libre', 'user' => 'root', 'pass' => ''],
    ];
    foreach ($credentials as $cred) {
        try {
            $pdo = new PDO("mysql:host={$cred['host']};dbname={$cred['db']};charset=utf8", $cred['user'], $cred['pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $pdo;
        } catch (PDOException $e) { continue; }
    }
    http_response_code(500);
    echo json_encode(['error' => 'No se pudo conectar a la base de datos.']);
    exit;
}

if ($endpoint === 'admin/dashboard' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Acceso denegado. Solo administradores.']);
            exit;
        }
        $pdo = getDB();
        $stats = ['total_users' => 0, 'active_products' => 0, 'monthly_sales' => 0, 'total_categories' => 0, 'recent_activity' => []];
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM users");
        $stats['total_users'] = (int)$stmt->fetch()['count'];
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM products WHERE visible = 1");
        $stats['active_products'] = (int)$stmt->fetch()['count'];
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM categories");
        $stats['total_categories'] = (int)$stmt->fetch()['count'];
        $currentMonth = date('Y-m');
        $stmt = $pdo->query("SELECT COALESCE(SUM(total), 0) as monthly_sales FROM orders WHERE DATE_FORMAT(created_at, '%Y-%m') = '$currentMonth'");
        $stats['monthly_sales'] = (float)$stmt->fetch()['monthly_sales'];
        echo json_encode($stats);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener datos del dashboard: ' . $e->getMessage()]);
    }
    exit;
}

if ($endpoint === 'categories' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $pdo = getDB();
        $stmt = $pdo->query('SELECT id, name, slug, description, icon, parent_id FROM categories ORDER BY sort_order, name');
        echo json_encode(['data' => $stmt->fetchAll()]);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener categorías: ' . $e->getMessage()]);
    }
    exit;
}

if ($endpoint === 'products' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $pdo = getDB();
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 9;
        $offset = ($page - 1) * $limit;
        $where = ['1=1'];
        $params = [];
        if (!empty($_GET['q'])) { $where[] = 'title LIKE :search'; $params[':search'] = '%' . $_GET['q'] . '%'; }
        if (!empty($_GET['category'])) { $where[] = 'category_id = :category'; $params[':category'] = $_GET['category']; }
        if (!empty($_GET['price_min'])) { $where[] = 'price >= :price_min'; $params[':price_min'] = floatval($_GET['price_min']); }
        if (!empty($_GET['price_max'])) { $where[] = 'price <= :price_max'; $params[':price_max'] = floatval($_GET['price_max']); }
        if (!empty($_GET['condition'])) { $where[] = 'product_condition = :condition'; $params[':condition'] = $_GET['condition']; }
        $whereClause = implode(' AND ', $where);
        $countStmt = $pdo->prepare("SELECT COUNT(*) as total FROM products WHERE $whereClause AND visible = 1");
        $countStmt->execute($params);
        $total = $countStmt->fetch()['total'];
        $stmt = $pdo->prepare("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE $whereClause AND p.visible = 1 ORDER BY p.created_at DESC LIMIT :limit OFFSET :offset");
        $params[':limit'] = $limit;
        $params[':offset'] = $offset;
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $stmt->execute();
        echo json_encode([
            'data' => [
                'products' => $stmt->fetchAll(),
                'page' => $page,
                'total' => (int)$total,
                'limit' => $limit
            ]
        ]);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener productos: ' . $e->getMessage()]);
    }
    exit;
}

if ($endpoint === 'search/suggest' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $q = isset($_GET['q']) ? trim($_GET['q']) : '';
    if (empty($q)) { echo json_encode([]); exit; }
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT DISTINCT title FROM products WHERE title LIKE :search AND visible = 1 LIMIT 5");
        $stmt->execute([':search' => "%$q%"]);
        echo json_encode(array_map(fn($title) => ['title' => $title], $stmt->fetchAll(PDO::FETCH_COLUMN)));
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener sugerencias: ' . $e->getMessage()]);
    }
    exit;
}

if ($endpoint === 'auth/login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['email']) || empty($data['password'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Email y contraseña son obligatorios']);
            exit;
        }
        if (!preg_match('/@gmail\.com$/', $data['email'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Solo se permiten cuentas de Gmail (@gmail.com)']);
            exit;
        }
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT id, name, email, password_hash, user_role FROM users WHERE email = ?");
        $stmt->execute([$data['email']]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($data['password'], $user['password_hash'])) {
            http_response_code(401);
            echo json_encode(['error' => 'Credenciales inválidas']);
            exit;
        }
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['user_role'];
        $_SESSION['user_name'] = $user['name'];
        $token = generateJWT(['user_id' => $user['id'], 'user_name' => $user['name'], 'role' => $user['user_role']]);
        echo json_encode([
            'success' => true,
            'message' => 'Login exitoso',
            'user' => ['id' => $user['id'], 'name' => $user['name'], 'email' => $user['email'], 'role' => $user['user_role']],
            'token' => $token
        ]);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error en el login: ' . $e->getMessage()]);
    }
    exit;
}

if ($endpoint === 'auth/register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data['name']) || empty($data['email']) || empty($data['password'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Nombre, email y contraseña son obligatorios']);
            exit;
        }
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['error' => 'Formato de email inválido']);
            exit;
        }
        if (!preg_match('/@gmail\.com$/', $data['email'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Solo se permiten cuentas de Gmail (@gmail.com)']);
            exit;
        }
        $password = $data['password'];
        $errors = [];
        if (strlen($password) < 8) $errors[] = 'La contraseña debe tener al menos 8 caracteres';
        if (!preg_match('/[A-Z]/', $password)) $errors[] = 'La contraseña debe contener al menos una letra mayúscula';
        if (!preg_match('/[a-z]/', $password)) $errors[] = 'La contraseña debe contener al menos una letra minúscula';
        if (!preg_match('/[0-9]/', $password)) $errors[] = 'La contraseña debe contener al menos un número';
        if (!preg_match('/[^A-Za-z0-9]/', $password)) $errors[] = 'La contraseña debe contener al menos un carácter especial';
        $commonPasswords = ['password', '12345678', 'qwerty123', 'abc123456', 'password123', 'admin123', 'demo123', 'test123', 'user123', 'guest123'];
        if (in_array(strtolower($password), $commonPasswords)) $errors[] = 'La contraseña es demasiado común. Elige una más segura';
        if (!empty($errors)) {
            http_response_code(400);
            echo json_encode(['error' => 'La contraseña no cumple con los requisitos de seguridad: ' . implode(', ', $errors)]);
            exit;
        }
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$data['email']]);
        if ($stmt->fetch()) {
            http_response_code(409);
            echo json_encode(['error' => 'El email ya está registrado']);
            exit;
        }
        $role = isset($data['role']) && $data['role'] === 'seller' ? 'seller' : 'buyer';
        $passwordHash = password_hash($data['password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash, user_role, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$data['name'], $data['email'], $passwordHash, $role]);
        $userId = $pdo->lastInsertId();
        if ($role === 'seller') {
            $storeName = $data['store_name'] ?? $data['name'] . ' Store';
            $stmt = $pdo->prepare("INSERT INTO sellers (user_id, shop_alias) VALUES (?, ?)");
            $stmt->execute([$userId, $storeName]);
        }
        $_SESSION['user_id'] = $userId;
        $_SESSION['user_role'] = $role;
        $_SESSION['user_name'] = $data['name'];
        $token = generateJWT(['user_id' => $userId, 'user_name' => $data['name'], 'role' => $role]);
        echo json_encode([
            'success' => true,
            'message' => 'Usuario registrado exitosamente',
            'user' => ['id' => $userId, 'name' => $data['name'], 'email' => $data['email'], 'role' => $role],
            'token' => $token
        ]);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error en el registro: ' . $e->getMessage()]);
    }
    exit;
}

if ($endpoint === 'auth/me' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $headers = getallheaders();
        $token = $headers['Authorization'] ?? '';
        if (empty($token) || !preg_match('/Bearer (.+)/', $token, $matches)) {
            http_response_code(401);
            echo json_encode(['error' => 'Token de autenticación requerido']);
            exit;
        }
        $token = $matches[1];
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['error' => 'Sesión no válida']);
            exit;
        }
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT id, name, email, user_role FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if (!$user) {
            http_response_code(404);
            echo json_encode(['error' => 'Usuario no encontrado']);
            exit;
        }
        echo json_encode($user);
    } catch(PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al obtener información del usuario: ' . $e->getMessage()]);
    }
    exit;
}
http_response_code(404);
echo json_encode(['error' => 'Ruta no encontrada: ' . $endpoint]);
