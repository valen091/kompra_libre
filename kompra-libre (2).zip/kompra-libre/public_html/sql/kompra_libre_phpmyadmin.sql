-- ✅ KOMPRA LIBRE - BASE DE DATOS COMPLETA (VERSIÓN PHPMYADMIN)
-- Sin consultas complejas que puedan fallar en PHPMyAdmin
-- Compatible con MySQL 5.7+ y MariaDB 10.0+

USE u472738607_kompra_libre;

-- =================================================================
-- TABLAS PRINCIPALES (orden correcto para foreign keys)
-- =================================================================

-- Usuarios del sistema (primero - tabla base)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  user_role VARCHAR(20) NOT NULL DEFAULT 'buyer',
  phone VARCHAR(20),
  avatar VARCHAR(255),
  email_verified TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_email (email),
  INDEX idx_users_role (user_role)
);

-- Categorías de productos (segundo - tabla base)
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  description TEXT,
  parent_id INT NULL,
  icon VARCHAR(50),
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_categories_parent (parent_id),
  INDEX idx_categories_slug (slug)
);

-- Métodos de envío (tercero - tabla base)
CREATE TABLE IF NOT EXISTS shipping_methods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  estimated_days VARCHAR(50),
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_shipping_active (active)
);

-- Vendedores (depende de users)
CREATE TABLE IF NOT EXISTS sellers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  shop_alias VARCHAR(120) NOT NULL,
  shop_description TEXT,
  shop_logo VARCHAR(255),
  reputation_score DECIMAL(3,2) DEFAULT 5.00,
  total_sales INT DEFAULT 0,
  total_products INT DEFAULT 0,
  verified TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_seller (user_id),
  INDEX idx_sellers_alias (shop_alias)
);

-- Administradores del sistema (depende de users)
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  permissions TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_admin (user_id)
);

-- Productos (depende de sellers y categories)
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seller_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(200) NOT NULL UNIQUE,
  description TEXT,
  short_description VARCHAR(500),
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2) NULL,
  stock INT NOT NULL DEFAULT 0,
  min_stock_alert INT DEFAULT 5,
  product_condition VARCHAR(20) DEFAULT 'nuevo',
  category_id INT,
  subcategory_id INT,
  brand VARCHAR(100),
  model VARCHAR(100),
  sku VARCHAR(100) UNIQUE,
  weight DECIMAL(8,3),
  dimensions VARCHAR(50),
  visible TINYINT(1) DEFAULT 1,
  featured TINYINT(1) DEFAULT 0,
  view_count INT DEFAULT 0,
  sales_count INT DEFAULT 0,
  rating_average DECIMAL(3,2) DEFAULT 0.00,
  rating_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  FOREIGN KEY (subcategory_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_products_seller (seller_id),
  INDEX idx_products_category (category_id),
  INDEX idx_products_visible (visible),
  INDEX idx_products_featured (featured),
  INDEX idx_products_price (price),
  INDEX idx_products_slug (slug)
);

-- Pedidos (depende de users, sellers y shipping_methods)
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(50) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  seller_id INT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  shipping_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
  tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(10,2) NOT NULL,
  order_status VARCHAR(20) DEFAULT 'pendiente',
  payment_status VARCHAR(20) DEFAULT 'pendiente',
  payment_method VARCHAR(50),
  shipping_method_id INT,
  shipping_address JSON,
  billing_address JSON,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE CASCADE,
  FOREIGN KEY (shipping_method_id) REFERENCES shipping_methods(id) ON DELETE SET NULL,
  INDEX idx_orders_user (user_id),
  INDEX idx_orders_seller (seller_id),
  INDEX idx_orders_status (order_status),
  INDEX idx_orders_number (order_number)
);

-- Items de pedido (depende de orders y products)
CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  product_title VARCHAR(200) NOT NULL,
  product_price DECIMAL(10,2) NOT NULL,
  quantity INT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_order_items_order (order_id)
);

-- Carritos de compra (depende de users)
CREATE TABLE IF NOT EXISTS carts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  session_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_carts_user (user_id),
  INDEX idx_carts_session (session_id)
);

-- Items del carrito (depende de carts y products)
CREATE TABLE IF NOT EXISTS cart_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cart_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cart_id) REFERENCES carts(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  UNIQUE KEY unique_cart_product (cart_id, product_id),
  INDEX idx_cart_items_cart (cart_id)
);

-- Imágenes de productos (depende de products)
CREATE TABLE IF NOT EXISTS product_images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  image_path VARCHAR(255) NOT NULL,
  alt_text VARCHAR(255),
  sort_order INT DEFAULT 0,
  is_primary TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_images_product (product_id),
  INDEX idx_images_primary (is_primary)
);

-- Reseñas de productos (depende de products, orders y users) - AHORA AL FINAL
CREATE TABLE IF NOT EXISTS reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  order_id INT NOT NULL,
  user_id INT NOT NULL,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_title VARCHAR(200),
  review_comment TEXT,
  verified_purchase TINYINT(1) DEFAULT 1,
  helpful_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_review (product_id, user_id),
  INDEX idx_reviews_product (product_id),
  INDEX idx_reviews_rating (rating)
);

-- =================================================================
-- DATOS DE EJEMPLO
-- =================================================================

-- Insertar métodos de envío
INSERT INTO shipping_methods (name, description, price, estimated_days) VALUES
('Envío estándar', 'Entrega en 3-5 días hábiles', 299.99, '3-5 días'),
('Envío express', 'Entrega en 1-2 días hábiles', 599.99, '1-2 días'),
('Retiro en tienda', 'Retirar en punto de venta', 0.00, 'Inmediato'),
('Envío gratis', 'Para compras mayores a $5000', 0.00, '3-5 días');

-- Insertar configuraciones del sistema
INSERT INTO system_settings (setting_key, setting_value, setting_description) VALUES
('site_name', 'Kompra Libre', 'Nombre del sitio'),
('site_description', 'Marketplace educativo de productos variados', 'Descripción del sitio'),
('contact_email', 'admin@kompralibre.shop', 'Email de contacto'),
('min_order_amount', '100.00', 'Monto mínimo de pedido'),
('max_products_per_seller', '1000', 'Máximo productos por vendedor'),
('enable_reviews', '1', 'Permitir reseñas de productos'),
('enable_messaging', '1', 'Permitir mensajería entre usuarios'),
('default_currency', 'ARS', 'Moneda por defecto');

-- Usuarios demo con Gmail
INSERT INTO users (name, email, password_hash, user_role) VALUES
('Demo Comprador', 'comprador@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer'),
('Demo Vendedor', 'vendedor@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller'),
('Demo Admin', 'admin@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Configurar vendedores y admins
INSERT INTO sellers (user_id, shop_alias, shop_description, verified) VALUES
(2, 'Tienda Demo', 'Tienda oficial de demostración con los mejores productos', 1);

INSERT INTO admins (user_id, permissions) VALUES
(3, '["all"]');

-- Categorías principales
INSERT INTO categories (name, slug, description, icon, sort_order) VALUES
('Electrónica', 'electronica', 'Productos electrónicos y tecnología', 'fas fa-laptop', 1),
('Ropa y Accesorios', 'ropa', 'Moda, ropa y accesorios personales', 'fas fa-tshirt', 2),
('Hogar y Jardín', 'hogar', 'Artículos para el hogar y jardín', 'fas fa-home', 3),
('Deportes', 'deportes', 'Artículos deportivos y fitness', 'fas fa-football-ball', 4),
('Libros y Educación', 'libros', 'Libros, cursos y material educativo', 'fas fa-book', 5),
('Automóvil', 'automovil', 'Accesorios y repuestos para autos', 'fas fa-car', 6),
('Belleza y Cuidado Personal', 'belleza', 'Productos de belleza y cuidado personal', 'fas fa-spa', 7),
('Juguetes y Juegos', 'juguetes', 'Juguetes y juegos para todas las edades', 'fas fa-gamepad', 8),
('Música e Instrumentos', 'musica', 'Instrumentos musicales y accesorios', 'fas fa-music', 9),
('Salud y Bienestar', 'salud', 'Productos para la salud y bienestar', 'fas fa-heart', 10),
('Alimentos y Bebidas', 'alimentos', 'Comida, bebidas y productos gourmet', 'fas fa-utensils', 11),
('Arte y Manualidades', 'arte', 'Materiales para arte y manualidades', 'fas fa-palette', 12);

-- Productos de ejemplo
INSERT INTO products (seller_id, title, slug, description, short_description, price, original_price, stock, product_condition, category_id, brand, model, visible, featured) VALUES
(1, 'iPhone 15 Pro Max 256GB', 'iphone-15-pro-max-256gb', 'El iPhone más avanzado con cámara profesional de 48MP, chip A17 Pro y pantalla Super Retina XDR de 6.7 pulgadas.', 'iPhone 15 Pro Max con cámara profesional', 1299999.99, 1399999.99, 10, 'nuevo', 1, 'Apple', 'iPhone 15 Pro Max', 1, 1),
(1, 'MacBook Air M3 13" 8GB 256GB', 'macbook-air-m3-13-8gb-256gb', 'MacBook Air ultraligera con chip M3, 8GB de RAM unificada y 256GB de almacenamiento SSD. Perfecta para estudiantes.', 'MacBook Air con chip M3 ultraligera', 1099999.99, 1199999.99, 5, 'nuevo', 1, 'Apple', 'MacBook Air M3', 1, 1),
(1, 'Camiseta Deportiva Nike Dri-FIT', 'camiseta-deportiva-nike-dri-fit', 'Camiseta transpirable para entrenamientos intensos. Tecnología Dri-FIT que mantiene la piel seca y cómoda.', 'Camiseta deportiva transpirable Nike', 29999.99, 34999.99, 20, 'nuevo', 2, 'Nike', 'Dri-FIT Sports', 1, 0),
(1, 'Juego de Sartenes Antiaderentes 3 Piezas', 'juego-sartenes-antiaderentes-3-piezas', 'Set completo de sartenes antiaderentes con mangos ergonómicos. Incluye 20cm, 24cm y 28cm.', 'Set de sartenes antiaderentes de calidad', 89999.99, 99999.99, 15, 'nuevo', 3, 'KitchenPro', 'Professional Set', 1, 0),
(1, 'Balón de Fútbol Adidas FIFA Approved', 'balon-futbol-adidas-fifa-approved', 'Balón oficial tamaño 5 homologado por FIFA. Perfecto para partidos profesionales y entrenamiento.', 'Balón oficial Adidas tamaño 5', 39999.99, 44999.99, 8, 'nuevo', 4, 'Adidas', 'FIFA Approved', 1, 0),
(1, 'Clean Code: A Handbook of Agile Software Craftsmanship', 'clean-code-handbook-agile-software-craftsmanship', 'Libro fundamental sobre mejores prácticas de programación. Incluye ejemplos reales y consejos de expertos.', 'Libro sobre mejores prácticas de programación', 49999.99, 59999.99, 12, 'usado', 5, 'Prentice Hall', 'Clean Code', 1, 0),
(1, 'Auriculares Bluetooth Sony WH-1000XM5', 'auriculares-bluetooth-sony-wh-1000xm5', 'Auriculares inalámbricos con cancelación de ruido líder en la industria. Hasta 30 horas de batería.', 'Auriculares con cancelación de ruido Sony', 199999.99, 229999.99, 7, 'nuevo', 1, 'Sony', 'WH-1000XM5', 1, 1),
(1, 'Zapatillas Running Adidas Ultraboost 23', 'zapatillas-running-adidas-ultraboost-23', 'Zapatillas deportivas para running con tecnología Boost que proporciona retorno de energía en cada paso.', 'Zapatillas running con tecnología Boost', 89999.99, 99999.99, 15, 'nuevo', 4, 'Adidas', 'Ultraboost 23', 1, 0),
(1, 'Lámpara de Escritorio LED Articulada', 'lampara-escritorio-led-articulada', 'Lámpara articulada con luz LED regulable en intensidad y temperatura de color. Base con cargador USB.', 'Lámpara LED articulada con cargador USB', 45999.99, 55999.99, 10, 'nuevo', 3, 'DeskLight', 'LED Pro', 1, 0),
(1, 'Chaqueta Impermeable Outdoor Adventure', 'chaqueta-impermeable-outdoor-adventure', 'Chaqueta resistente al agua y viento para actividades outdoor. Con capucha y múltiples bolsillos.', 'Chaqueta impermeable para outdoor', 79999.99, 89999.99, 8, 'nuevo', 2, 'Adventure', 'Waterproof Pro', 1, 0),
(1, 'Televisor Smart TV Samsung 55" 4K UHD', 'televisor-smart-tv-samsung-55-4k-uhd', 'Smart TV con resolución 4K UHD, HDR10+ y sistema operativo Tizen. Incluye asistentes de voz.', 'Smart TV 4K UHD 55 pulgadas Samsung', 899999.99, 999999.99, 3, 'nuevo', 1, 'Samsung', 'Crystal UHD', 1, 1),
(1, 'Reloj Inteligente Apple Watch Series 9 GPS', 'reloj-inteligente-apple-watch-series-9-gps', 'Apple Watch Series 9 con GPS, monitor de salud avanzado y hasta 18 horas de batería.', 'Apple Watch Series 9 con GPS', 399999.99, 449999.99, 6, 'nuevo', 1, 'Apple', 'Watch Series 9', 1, 1),
(1, 'Sofá Moderno de 3 Plazas', 'sofa-moderno-3-plazas', 'Sofá moderno y cómodo con tapizado en tela resistente. Ideal para sala de estar o living.', 'Sofá moderno de 3 plazas', 599999.99, 699999.99, 4, 'nuevo', 3, 'HomeStyle', 'Modern Comfort', 1, 0),
(1, 'Bicicleta Mountain Bike 21 Velocidades', 'bicicleta-mountain-bike-21-velocidades', 'Bicicleta todo terreno con 21 velocidades, frenos de disco y suspensión delantera.', 'Bicicleta mountain bike 21 velocidades', 299999.99, 349999.99, 2, 'nuevo', 4, 'BikePro', 'Mountain Trail', 1, 0),
(1, 'Guitarra Acústica Yamaha F310', 'guitarra-acustica-yamaha-f310', 'Guitarra acústica de madera de abeto con cuerdas de nailon. Perfecta para principiantes.', 'Guitarra acústica Yamaha para principiantes', 199999.99, 229999.99, 5, 'nuevo', 9, 'Yamaha', 'F310', 1, 0);

-- Imágenes de productos
INSERT INTO product_images (product_id, image_path, alt_text, sort_order, is_primary) VALUES
(1, '/img/products/iphone-15-pro-1.jpg', 'iPhone 15 Pro Max vista frontal', 1, 1),
(1, '/img/products/iphone-15-pro-2.jpg', 'iPhone 15 Pro Max vista trasera', 2, 0),
(1, '/img/products/iphone-15-pro-3.jpg', 'iPhone 15 Pro Max con cámara', 3, 0),
(2, '/img/products/macbook-air-1.jpg', 'MacBook Air M3 vista lateral', 1, 1),
(2, '/img/products/macbook-air-2.jpg', 'MacBook Air M3 teclado', 2, 0),
(3, '/img/products/nike-shirt-1.jpg', 'Camiseta Nike vista frontal', 1, 1),
(3, '/img/products/nike-shirt-2.jpg', 'Camiseta Nike detalle tela', 2, 0),
(4, '/img/products/sartenes-1.jpg', 'Set de sartenes completo', 1, 1),
(4, '/img/products/sartenes-2.jpg', 'Sartenes antiaderentes', 2, 0),
(5, '/img/products/balon-1.jpg', 'Balón Adidas oficial', 1, 1),
(6, '/img/products/clean-code-1.jpg', 'Libro Clean Code portada', 1, 1);

-- Pedido de ejemplo para las reseñas
INSERT INTO orders (order_number, user_id, seller_id, subtotal, shipping_cost, total_amount, order_status, payment_status, shipping_method_id, created_at) VALUES
('KL20241027-000001', 1, 1, 1449999.98, 299.99, 1450299.97, 'entregado', 'completado', 1, '2024-10-27 10:00:00');

-- Items del pedido
INSERT INTO order_items (order_id, product_id, product_title, product_price, quantity, subtotal) VALUES
(1, 1, 'iPhone 15 Pro Max 256GB', 1299999.99, 1, 1299999.99),
(1, 2, 'MacBook Air M3 13" 8GB 256GB', 1099999.99, 1, 1099999.99),
(1, 3, 'Camiseta Deportiva Nike Dri-FIT', 29999.99, 1, 29999.99),
(1, 4, 'Juego de Sartenes Antiaderentes 3 Piezas', 89999.99, 1, 89999.99),
(1, 5, 'Balón de Fútbol Adidas FIFA Approved', 39999.99, 1, 39999.99),
(1, 6, 'Clean Code: A Handbook of Agile Software Craftsmanship', 49999.99, 1, 49999.99);

-- Reseñas de ejemplo
INSERT INTO reviews (product_id, order_id, user_id, rating, review_title, review_comment, verified_purchase) VALUES
(1, 1, 1, 5, 'Excelente producto', 'El iPhone llegó en perfectas condiciones y funciona de maravilla. La cámara es impresionante.', 1),
(2, 1, 1, 5, 'Perfecta para el trabajo', 'La MacBook Air es rapidísima y la batería dura todo el día. Ideal para estudiantes.', 1),
(3, 1, 1, 4, 'Buena calidad', 'La camiseta es cómoda y transpirable, aunque el talle es un poco pequeño.', 1),
(4, 1, 1, 5, 'Excelentes sartenes', 'Se calientan rápido y no se pega nada. Muy buena calidad por el precio.', 1),
(5, 1, 1, 5, 'Perfecto para jugar', 'Balón de muy buena calidad, igual que los profesionales usan.', 1),
(6, 1, 1, 5, 'Libro fundamental', 'Excelente libro para aprender buenas prácticas de programación. Muy recomendado.', 1);

-- =================================================================
-- ÍNDICES PARA OPTIMIZACIÓN
-- =================================================================

-- Índices para búsquedas
CREATE INDEX idx_products_price_range ON products (price, visible);
CREATE INDEX idx_products_category_visible ON products (category_id, visible);
CREATE INDEX idx_products_seller_visible ON products (seller_id, visible);
CREATE INDEX idx_orders_status_date ON orders (order_status, created_at);
CREATE INDEX idx_messages_conversation_read ON messages (from_user_id, to_user_id, is_read);
CREATE INDEX idx_notifications_user_read ON notifications (user_id, is_read, created_at);

-- Índices para búsquedas fulltext
CREATE FULLTEXT INDEX idx_products_fulltext ON products (title, description, brand, model);
CREATE FULLTEXT INDEX idx_categories_fulltext ON categories (name, description);

-- =================================================================
-- RESULTADO
-- =================================================================

-- Mostrar resumen (sin consultas complejas que fallen en PHPMyAdmin)
SELECT '✅ SETUP COMPLETADO' as status;
SELECT '📊 RESUMEN DE DATOS INSERTADOS' as info;
SELECT CONCAT('👤 Usuarios: ', COUNT(*)) as usuarios FROM users;
SELECT CONCAT('🏷️ Categorías: ', COUNT(*)) as categorias FROM categories;
SELECT CONCAT('📦 Productos: ', COUNT(*)) as productos FROM products WHERE visible = 1;
SELECT CONCAT('🏪 Vendedores: ', COUNT(*)) as vendedores FROM sellers;
SELECT CONCAT('👨‍💼 Admins: ', COUNT(*)) as admins FROM admins;
SELECT CONCAT('📸 Imágenes: ', COUNT(*)) as imagenes FROM product_images;
SELECT CONCAT('🛒 Pedidos: ', COUNT(*)) as pedidos FROM orders;
SELECT CONCAT('📋 Items de pedido: ', COUNT(*)) as order_items FROM order_items;
SELECT CONCAT('⭐ Reseñas: ', COUNT(*)) as reseñas FROM reviews;
