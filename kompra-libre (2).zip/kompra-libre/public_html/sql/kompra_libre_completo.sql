-- ✅ KOMPRA LIBRE - BASE DE DATOS COMPLETA Y OPTIMIZADA
-- Compatible con MySQL 5.7+ y MariaDB 10.0+
-- Sin ENUMs problemáticos, solo VARCHAR para máxima compatibilidad
-- Todo en un solo archivo: Schema + Datos + Triggers + Índices

USE u472738607_kompra_libre;

-- =================================================================
-- TABLAS PRINCIPALES (orden correcto para foreign keys)
-- =================================================================

-- Usuarios del sistema (primero - tabla base)
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  user_role VARCHAR(20) NOT NULL DEFAULT 'buyer',
  phone VARCHAR(20),
  avatar VARCHAR(255),
  email_verified TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_email (email),
  INDEX idx_users_role (user_role)
);

-- Categorías de productos (segundo - tabla base)
CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  description TEXT,
  parent_id INT NULL,
  icon VARCHAR(50),
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_categories_parent (parent_id),
  INDEX idx_categories_slug (slug)
);

-- Métodos de envío (tercero - tabla base)
CREATE TABLE IF NOT EXISTS shipping_methods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  estimated_days VARCHAR(50),
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_shipping_active (active)
);

-- Vendedores (depende de users)
CREATE TABLE IF NOT EXISTS sellers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  shop_alias VARCHAR(120) NOT NULL,
  shop_description TEXT,
  shop_logo VARCHAR(255),
  reputation_score DECIMAL(3,2) DEFAULT 5.00,
  total_sales INT DEFAULT 0,
  total_products INT DEFAULT 0,
  verified TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_seller (user_id),
  INDEX idx_sellers_alias (shop_alias)
);

-- Administradores del sistema (depende de users)
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  permissions TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_admin (user_id)
);

-- Productos (depende de sellers y categories)
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  seller_id INT NOT NULL,
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(200) NOT NULL UNIQUE,
  description TEXT,
  short_description VARCHAR(500),
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2) NULL,
  stock INT NOT NULL DEFAULT 0,
  min_stock_alert INT DEFAULT 5,
  product_condition VARCHAR(20) DEFAULT 'nuevo',
  category_id INT,
  subcategory_id INT,
  brand VARCHAR(100),
  model VARCHAR(100),
  sku VARCHAR(100) UNIQUE,
  weight DECIMAL(8,3),
  dimensions VARCHAR(50),
  visible TINYINT(1) DEFAULT 1,
  featured TINYINT(1) DEFAULT 0,
  view_count INT DEFAULT 0,
  sales_count INT DEFAULT 0,
  rating_average DECIMAL(3,2) DEFAULT 0.00,
  rating_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
  FOREIGN KEY (subcategory_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_products_seller (seller_id),
  INDEX idx_products_category (category_id),
  INDEX idx_products_visible (visible),
  INDEX idx_products_featured (featured),
  INDEX idx_products_price (price),
  INDEX idx_products_slug (slug),
  FULLTEXT idx_products_search (title, description, brand, model)
);

-- Pedidos (depende de users, sellers y shipping_methods)
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(50) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  seller_id INT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  shipping_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
  tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(10,2) NOT NULL,
  order_status VARCHAR(20) DEFAULT 'pendiente',
  payment_status VARCHAR(20) DEFAULT 'pendiente',
  payment_method VARCHAR(50),
  shipping_method_id INT,
  shipping_address JSON,
  billing_address JSON,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE CASCADE,
  FOREIGN KEY (shipping_method_id) REFERENCES shipping_methods(id) ON DELETE SET NULL,
  INDEX idx_orders_user (user_id),
  INDEX idx_orders_seller (seller_id),
  INDEX idx_orders_status (order_status),
  INDEX idx_orders_number (order_number)
);

-- Items de pedido (depende de orders y products)
CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  product_title VARCHAR(200) NOT NULL,
  product_price DECIMAL(10,2) NOT NULL,
  quantity INT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_order_items_order (order_id)
);

-- Carritos de compra (depende de users)
CREATE TABLE IF NOT EXISTS carts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  session_id VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_carts_user (user_id),
  INDEX idx_carts_session (session_id)
);

-- Items del carrito (depende de carts y products)
CREATE TABLE IF NOT EXISTS cart_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cart_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cart_id) REFERENCES carts(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  UNIQUE KEY unique_cart_product (cart_id, product_id),
  INDEX idx_cart_items_cart (cart_id)
);

-- Imágenes de productos (depende de products)
CREATE TABLE IF NOT EXISTS product_images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  image_path VARCHAR(255) NOT NULL,
  alt_text VARCHAR(255),
  sort_order INT DEFAULT 0,
  is_primary TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_images_product (product_id),
  INDEX idx_images_primary (is_primary)
);

-- Mensajes entre usuarios (depende de users)
CREATE TABLE IF NOT EXISTS messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NULL,
  order_id INT NULL,
  from_user_id INT NOT NULL,
  to_user_id INT NOT NULL,
  subject VARCHAR(255),
  message_body TEXT NOT NULL,
  message_type VARCHAR(20) DEFAULT 'general',
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
  FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_messages_conversation (from_user_id, to_user_id, created_at),
  INDEX idx_messages_read (is_read)
);

-- Notificaciones (depende de users)
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  notification_type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  message TEXT,
  data_payload JSON,
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notifications_user (user_id),
  INDEX idx_notifications_read (is_read)
);

-- Favoritos (depende de users y products)
CREATE TABLE IF NOT EXISTS favorites (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  UNIQUE KEY unique_favorite (user_id, product_id),
  INDEX idx_favorites_user (user_id)
);

-- Búsquedas recientes (depende de users)
CREATE TABLE IF NOT EXISTS search_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  session_id VARCHAR(255),
  search_query VARCHAR(255) NOT NULL,
  results_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_search_user (user_id),
  INDEX idx_search_query (search_query)
);

-- Configuración del sistema (tabla independiente)
CREATE TABLE IF NOT EXISTS system_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value TEXT,
  setting_description VARCHAR(255),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_settings_key (setting_key)
);

-- Logs de actividad (depende de users)
CREATE TABLE IF NOT EXISTS activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50),
  entity_id INT,
  old_values JSON,
  new_values JSON,
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_logs_user (user_id),
  INDEX idx_logs_action (action),
  INDEX idx_logs_entity (entity_type, entity_id)
);

-- Reportes de productos (depende de products y users)
CREATE TABLE IF NOT EXISTS product_reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  user_id INT NOT NULL,
  report_reason VARCHAR(100) NOT NULL,
  description TEXT,
  status VARCHAR(20) DEFAULT 'pendiente',
  admin_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_reports_product (product_id),
  INDEX idx_reports_status (status)
);

-- Reseñas de productos (depende de products, orders y users) - AHORA AL FINAL
CREATE TABLE IF NOT EXISTS reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  order_id INT NOT NULL,
  user_id INT NOT NULL,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review_title VARCHAR(200),
  review_comment TEXT,
  verified_purchase TINYINT(1) DEFAULT 1,
  helpful_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_review (product_id, user_id),
  INDEX idx_reviews_product (product_id),
  INDEX idx_reviews_rating (rating)
);

-- =================================================================
-- DATOS DE EJEMPLO
-- =================================================================

-- Insertar métodos de envío
INSERT INTO shipping_methods (name, description, price, estimated_days) VALUES
('Envío estándar', 'Entrega en 3-5 días hábiles', 299.99, '3-5 días'),
('Envío express', 'Entrega en 1-2 días hábiles', 599.99, '1-2 días'),
('Retiro en tienda', 'Retirar en punto de venta', 0.00, 'Inmediato'),
('Envío gratis', 'Para compras mayores a $5000', 0.00, '3-5 días');

-- Insertar o actualizar configuraciones del sistema
INSERT INTO system_settings (setting_key, setting_value) 
VALUES
('site_name', 'Kompra Libre'),
('site_description', 'Marketplace educativo de productos variados'),
('contact_email', 'admin@kompralibre.shop'),
('min_order_amount', '100.00'),
('max_products_per_seller', '1000'),
('enable_reviews', '1'),
('enable_messaging', '1'),
('default_currency', 'ARS')
ON DUPLICATE KEY UPDATE 
    setting_value = VALUES(setting_value);

-- =================================================================
-- TRIGGERS Y FUNCIONES
-- =================================================================

DELIMITER //

-- Trigger para actualizar timestamp de productos
CREATE TRIGGER update_products_timestamp
BEFORE UPDATE ON products
FOR EACH ROW
BEGIN
  SET NEW.updated_at = CURRENT_TIMESTAMP;
END//

-- Trigger para actualizar timestamp de usuarios
CREATE TRIGGER update_users_timestamp
BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
  SET NEW.updated_at = CURRENT_TIMESTAMP;
END//

-- Trigger para generar número de orden único
CREATE TRIGGER generate_order_number
BEFORE INSERT ON orders
FOR EACH ROW
BEGIN
  IF NEW.order_number IS NULL OR NEW.order_number = '' THEN
    SET NEW.order_number = CONCAT('KL', DATE_FORMAT(NOW(), '%Y%m%d'), LPAD(LAST_INSERT_ID() + 1, 6, '0'));
  END IF;
END//

-- Trigger para actualizar contador de ventas del vendedor
CREATE TRIGGER update_seller_sales
AFTER INSERT ON order_items
FOR EACH ROW
BEGIN
  UPDATE sellers s
  JOIN products p ON p.id = NEW.product_id
  SET s.total_sales = s.total_sales + NEW.quantity
  WHERE s.id = p.seller_id;
END//

-- Trigger para actualizar rating promedio del producto
CREATE TRIGGER update_product_rating
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
  UPDATE products
  SET rating_average = (
    SELECT AVG(rating) FROM reviews WHERE product_id = NEW.product_id
  ),
  rating_count = (
    SELECT COUNT(*) FROM reviews WHERE product_id = NEW.product_id
  )
  WHERE id = NEW.product_id;
END//

-- Función para calcular distancia de búsqueda
CREATE FUNCTION calculate_relevance_score(
  search_term VARCHAR(255),
  product_title VARCHAR(200),
  product_description TEXT,
  product_brand VARCHAR(100)
) RETURNS DECIMAL(10,4)
READS SQL DATA
DETERMINISTIC
BEGIN
  DECLARE score DECIMAL(10,4) DEFAULT 0.00;

  -- Coincidencia exacta en título
  IF LOWER(product_title) = LOWER(search_term) THEN
    SET score = score + 10.0;
  END IF;

  -- Coincidencia parcial en título
  IF LOWER(product_title) LIKE CONCAT('%', LOWER(search_term), '%') THEN
    SET score = score + 5.0;
  END IF;

  -- Coincidencia en descripción
  IF LOWER(product_description) LIKE CONCAT('%', LOWER(search_term), '%') THEN
    SET score = score + 2.0;
  END IF;

  -- Coincidencia en marca
  IF LOWER(product_brand) LIKE CONCAT('%', LOWER(search_term), '%') THEN
    SET score = score + 3.0;
  END IF;

  RETURN score;
END//

DELIMITER ;

-- =================================================================
-- VISTAS ÚTILES
-- =================================================================

-- Vista de productos con información completa
CREATE OR REPLACE VIEW products_complete AS
SELECT
  p.*,
  c.name as category_name,
  c.slug as category_slug,
  s.shop_alias,
  s.shop_logo,
  u.name as seller_name,
  u.email as seller_email,
  (SELECT image_path FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as main_image,
  (SELECT COUNT(*) FROM product_images WHERE product_id = p.id) as image_count,
  (SELECT COUNT(*) FROM favorites WHERE product_id = p.id) as favorite_count,
  (SELECT COUNT(*) FROM reviews WHERE product_id = p.id) as review_count
FROM products p
LEFT JOIN categories c ON p.category_id = c.id
LEFT JOIN sellers s ON p.seller_id = s.id
LEFT JOIN users u ON s.user_id = u.id;

-- Vista de pedidos con información completa
CREATE OR REPLACE VIEW orders_complete AS
SELECT
  o.*,
  u.name as buyer_name,
  u.email as buyer_email,
  s.shop_alias as seller_shop,
  sm.name as shipping_method_name,
  (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) as item_count,
  (SELECT SUM(quantity) FROM order_items WHERE order_id = o.id) as total_quantity
FROM orders o
LEFT JOIN users u ON o.user_id = u.id
LEFT JOIN sellers s ON o.seller_id = s.id
LEFT JOIN shipping_methods sm ON o.shipping_method_id = sm.id;

-- Vista de estadísticas de vendedores
CREATE OR REPLACE VIEW seller_stats AS
SELECT
  s.*,
  u.name as user_name,
  u.email as user_email,
  (SELECT COUNT(*) FROM products WHERE seller_id = s.id AND visible = 1) as active_products,
  (SELECT COUNT(*) FROM orders WHERE seller_id = s.id) as total_orders,
  (SELECT SUM(quantity) FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE o.seller_id = s.id) as total_items_sold,
  (SELECT AVG(rating) FROM reviews r JOIN products p ON r.product_id = p.id WHERE p.seller_id = s.id) as average_rating,
  (SELECT COUNT(*) FROM reviews r JOIN products p ON r.product_id = p.id WHERE p.seller_id = s.id) as total_reviews
FROM sellers s
LEFT JOIN users u ON s.user_id = u.id;

-- =================================================================
-- DATOS DE EJEMPLO
-- =================================================================

-- Usuarios demo con Gmail
INSERT INTO users (name, email, password_hash, user_role) VALUES
('Demo Comprador', 'comprador@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'buyer'),
('Demo Vendedor', 'vendedor@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'seller'),
('Demo Admin', 'admin@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Configurar vendedores y admins
INSERT INTO sellers (user_id, shop_alias, shop_description, verified) VALUES
(2, 'Tienda Demo', 'Tienda oficial de demostración con los mejores productos', 1);

INSERT INTO admins (user_id, permissions) VALUES
(3, '["all"]');

-- Categorías principales
INSERT INTO categories (name, slug, description, icon, sort_order) VALUES
('Electrónica', 'electronica', 'Productos electrónicos y tecnología', 'fas fa-laptop', 1),
('Ropa y Accesorios', 'ropa', 'Moda, ropa y accesorios personales', 'fas fa-tshirt', 2),
('Hogar y Jardín', 'hogar', 'Artículos para el hogar y jardín', 'fas fa-home', 3),
('Deportes', 'deportes', 'Artículos deportivos y fitness', 'fas fa-football-ball', 4),
('Libros y Educación', 'libros', 'Libros, cursos y material educativo', 'fas fa-book', 5),
('Automóvil', 'automovil', 'Accesorios y repuestos para autos', 'fas fa-car', 6),
('Belleza y Cuidado Personal', 'belleza', 'Productos de belleza y cuidado personal', 'fas fa-spa', 7),
('Juguetes y Juegos', 'juguetes', 'Juguetes y juegos para todas las edades', 'fas fa-gamepad', 8),
('Música e Instrumentos', 'musica', 'Instrumentos musicales y accesorios', 'fas fa-music', 9),
('Salud y Bienestar', 'salud', 'Productos para la salud y bienestar', 'fas fa-heart', 10),
('Alimentos y Bebidas', 'alimentos', 'Comida, bebidas y productos gourmet', 'fas fa-utensils', 11),
('Arte y Manualidades', 'arte', 'Materiales para arte y manualidades', 'fas fa-palette', 12);

-- Productos de ejemplo
INSERT INTO products (seller_id, title, slug, description, short_description, price, original_price, stock, product_condition, category_id, brand, model, visible, featured) VALUES
(1, 'iPhone 15 Pro Max 256GB', 'iphone-15-pro-max-256gb', 'El iPhone más avanzado con cámara profesional de 48MP, chip A17 Pro y pantalla Super Retina XDR de 6.7 pulgadas.', 'iPhone 15 Pro Max con cámara profesional', 1299999.99, 1399999.99, 10, 'nuevo', 1, 'Apple', 'iPhone 15 Pro Max', 1, 1),
(1, 'MacBook Air M3 13" 8GB 256GB', 'macbook-air-m3-13-8gb-256gb', 'MacBook Air ultraligera con chip M3, 8GB de RAM unificada y 256GB de almacenamiento SSD. Perfecta para estudiantes.', 'MacBook Air con chip M3 ultraligera', 1099999.99, 1199999.99, 5, 'nuevo', 1, 'Apple', 'MacBook Air M3', 1, 1),
(1, 'Camiseta Deportiva Nike Dri-FIT', 'camiseta-deportiva-nike-dri-fit', 'Camiseta transpirable para entrenamientos intensos. Tecnología Dri-FIT que mantiene la piel seca y cómoda.', 'Camiseta deportiva transpirable Nike', 29999.99, 34999.99, 20, 'nuevo', 2, 'Nike', 'Dri-FIT Sports', 1, 0),
(1, 'Juego de Sartenes Antiaderentes 3 Piezas', 'juego-sartenes-antiaderentes-3-piezas', 'Set completo de sartenes antiaderentes con mangos ergonómicos. Incluye 20cm, 24cm y 28cm.', 'Set de sartenes antiaderentes de calidad', 89999.99, 99999.99, 15, 'nuevo', 3, 'KitchenPro', 'Professional Set', 1, 0),
(1, 'Balón de Fútbol Adidas FIFA Approved', 'balon-futbol-adidas-fifa-approved', 'Balón oficial tamaño 5 homologado por FIFA. Perfecto para partidos profesionales y entrenamiento.', 'Balón oficial Adidas tamaño 5', 39999.99, 44999.99, 8, 'nuevo', 4, 'Adidas', 'FIFA Approved', 1, 0),
(1, 'Clean Code: A Handbook of Agile Software Craftsmanship', 'clean-code-handbook-agile-software-craftsmanship', 'Libro fundamental sobre mejores prácticas de programación. Incluye ejemplos reales y consejos de expertos.', 'Libro sobre mejores prácticas de programación', 49999.99, 59999.99, 12, 'usado', 5, 'Prentice Hall', 'Clean Code', 1, 0),
(1, 'Auriculares Bluetooth Sony WH-1000XM5', 'auriculares-bluetooth-sony-wh-1000xm5', 'Auriculares inalámbricos con cancelación de ruido líder en la industria. Hasta 30 horas de batería.', 'Auriculares con cancelación de ruido Sony', 199999.99, 229999.99, 7, 'nuevo', 1, 'Sony', 'WH-1000XM5', 1, 1),
(1, 'Zapatillas Running Adidas Ultraboost 23', 'zapatillas-running-adidas-ultraboost-23', 'Zapatillas deportivas para running con tecnología Boost que proporciona retorno de energía en cada paso.', 'Zapatillas running con tecnología Boost', 89999.99, 99999.99, 15, 'nuevo', 4, 'Adidas', 'Ultraboost 23', 1, 0),
(1, 'Lámpara de Escritorio LED Articulada', 'lampara-escritorio-led-articulada', 'Lámpara articulada con luz LED regulable en intensidad y temperatura de color. Base con cargador USB.', 'Lámpara LED articulada con cargador USB', 45999.99, 55999.99, 10, 'nuevo', 3, 'DeskLight', 'LED Pro', 1, 0),
(1, 'Chaqueta Impermeable Outdoor Adventure', 'chaqueta-impermeable-outdoor-adventure', 'Chaqueta resistente al agua y viento para actividades outdoor. Con capucha y múltiples bolsillos.', 'Chaqueta impermeable para outdoor', 79999.99, 89999.99, 8, 'nuevo', 2, 'Adventure', 'Waterproof Pro', 1, 0),
(1, 'Televisor Smart TV Samsung 55" 4K UHD', 'televisor-smart-tv-samsung-55-4k-uhd', 'Smart TV con resolución 4K UHD, HDR10+ y sistema operativo Tizen. Incluye asistentes de voz.', 'Smart TV 4K UHD 55 pulgadas Samsung', 899999.99, 999999.99, 3, 'nuevo', 1, 'Samsung', 'Crystal UHD', 1, 1),
(1, 'Reloj Inteligente Apple Watch Series 9 GPS', 'reloj-inteligente-apple-watch-series-9-gps', 'Apple Watch Series 9 con GPS, monitor de salud avanzado y hasta 18 horas de batería.', 'Apple Watch Series 9 con GPS', 399999.99, 449999.99, 6, 'nuevo', 1, 'Apple', 'Watch Series 9', 1, 1),
(1, 'Sofá Moderno de 3 Plazas', 'sofa-moderno-3-plazas', 'Sofá moderno y cómodo con tapizado en tela resistente. Ideal para sala de estar o living.', 'Sofá moderno de 3 plazas', 599999.99, 699999.99, 4, 'nuevo', 3, 'HomeStyle', 'Modern Comfort', 1, 0),
(1, 'Bicicleta Mountain Bike 21 Velocidades', 'bicicleta-mountain-bike-21-velocidades', 'Bicicleta todo terreno con 21 velocidades, frenos de disco y suspensión delantera.', 'Bicicleta mountain bike 21 velocidades', 299999.99, 349999.99, 2, 'nuevo', 4, 'BikePro', 'Mountain Trail', 1, 0),
(1, 'Guitarra Acústica Yamaha F310', 'guitarra-acustica-yamaha-f310', 'Guitarra acústica de madera de abeto con cuerdas de nailon. Perfecta para principiantes.', 'Guitarra acústica Yamaha para principiantes', 199999.99, 229999.99, 5, 'nuevo', 9, 'Yamaha', 'F310', 1, 0);

-- Pedido de ejemplo para las reseñas
INSERT INTO orders (order_number, user_id, seller_id, subtotal, shipping_cost, total_amount, order_status, payment_status, shipping_method_id, created_at) VALUES
('KL20241027-000001', 1, 1, 1449999.98, 299.99, 1450299.97, 'entregado', 'completado', 1, '2024-10-27 10:00:00');

-- Items del pedido
INSERT INTO order_items (order_id, product_id, product_title, product_price, quantity, subtotal) VALUES
(1, 1, 'iPhone 15 Pro Max 256GB', 1299999.99, 1, 1299999.99),
(1, 2, 'MacBook Air M3 13" 8GB 256GB', 1099999.99, 1, 1099999.99),
(1, 3, 'Camiseta Deportiva Nike Dri-FIT', 29999.99, 1, 29999.99),
(1, 4, 'Juego de Sartenes Antiaderentes 3 Piezas', 89999.99, 1, 89999.99),
(1, 5, 'Balón de Fútbol Adidas FIFA Approved', 39999.99, 1, 39999.99),
(1, 6, 'Clean Code: A Handbook of Agile Software Craftsmanship', 49999.99, 1, 49999.99);

-- Reseñas de ejemplo
INSERT INTO reviews (product_id, order_id, user_id, rating, review_title, review_comment, verified_purchase) VALUES
(1, 1, 1, 5, 'Excelente producto', 'El iPhone llegó en perfectas condiciones y funciona de maravilla. La cámara es impresionante.', 1),
(2, 1, 1, 5, 'Perfecta para el trabajo', 'La MacBook Air es rapidísima y la batería dura todo el día. Ideal para estudiantes.', 1),
(3, 1, 1, 4, 'Buena calidad', 'La camiseta es cómoda y transpirable, aunque el talle es un poco pequeño.', 1),
(4, 1, 1, 5, 'Excelentes sartenes', 'Se calientan rápido y no se pega nada. Muy buena calidad por el precio.', 1),
(5, 1, 1, 5, 'Perfecto para jugar', 'Balón de muy buena calidad, igual que los profesionales usan.', 1),
(6, 1, 1, 5, 'Libro fundamental', 'Excelente libro para aprender buenas prácticas de programación. Muy recomendado.', 1);

-- =================================================================
-- ÍNDICES ADICIONALES PARA OPTIMIZACIÓN
-- =================================================================

-- Índices para búsquedas
CREATE INDEX idx_products_price_range ON products (price, visible);
CREATE INDEX idx_products_category_visible ON products (category_id, visible);
CREATE INDEX idx_products_seller_visible ON products (seller_id, visible);
CREATE INDEX idx_orders_status_date ON orders (order_status, created_at);
CREATE INDEX idx_messages_conversation_read ON messages (from_user_id, to_user_id, is_read);
CREATE INDEX idx_notifications_user_read ON notifications (user_id, is_read, created_at);

-- Índices para búsquedas fulltext
CREATE FULLTEXT INDEX idx_products_fulltext ON products (title, description, brand, model);
CREATE FULLTEXT INDEX idx_categories_fulltext ON categories (name, description);

-- =================================================================
-- VERIFICACIÓN FINAL
-- =================================================================

-- Mostrar resumen de datos insertados
SELECT
  '📊 RESUMEN DE DATOS INSERTADOS' as info
UNION ALL
SELECT CONCAT('👤 Usuarios: ', COUNT(*)) FROM users
UNION ALL
SELECT CONCAT('🏷️ Categorías: ', COUNT(*)) FROM categories
UNION ALL
SELECT CONCAT('📦 Productos: ', COUNT(*)) FROM products WHERE visible = 1
UNION ALL
SELECT CONCAT('🏪 Vendedores: ', COUNT(*)) FROM sellers
UNION ALL
SELECT CONCAT('👨‍💼 Admins: ', COUNT(*)) FROM admins
UNION ALL
SELECT CONCAT('📸 Imágenes: ', COUNT(*)) FROM product_images
UNION ALL
SELECT CONCAT('⭐ Reseñas: ', COUNT(*)) FROM reviews
UNION ALL
SELECT CONCAT('🛒 Métodos de envío: ', COUNT(*)) FROM shipping_methods
UNION ALL
SELECT CONCAT('📋 Configuraciones: ', COUNT(*)) FROM system_settings;

-- Mostrar cuentas demo
SELECT '🔐 CUENTAS DEMO CREADAS' as info
UNION ALL
SELECT CONCAT('👤 ', user_role, ': ', email, ' (contraseña: demo123)') as demo_info FROM users ORDER BY user_role;

SELECT * FROM (
    SELECT '🏆 PRODUCTOS DESTACADOS' as info, 0 as sort_order, 0 as price
    UNION ALL
    SELECT 
        CONCAT('⭐ ', title, ' - $', FORMAT(price, 2)) as product_info,
        1 as sort_order,
        price
    FROM products
    WHERE featured = 1
) as results
ORDER BY sort_order, price DESC;