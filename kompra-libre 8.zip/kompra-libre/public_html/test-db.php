<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

try {
    $db = getDB();
    echo "✅ Conexión exitosa a la base de datos!";
    echo "<br>Host: " . DB_HOST;
    echo "<br>DB: " . DB_NAME;
    echo "<br>User: " . DB_USER;
} catch (Exception $e) {
    echo "❌ Error de conexión: " . $e->getMessage();
}
?>
