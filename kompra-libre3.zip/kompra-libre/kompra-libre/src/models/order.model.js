
import { pool } from '../config/db.js';
export async function createOrder(user_id){
  const conn = await pool.getConnection();
  try{
    await conn.beginTransaction();
    const [c]=await conn.query('SELECT id FROM carts WHERE user_id=?',[user_id]);
    if(!c[0]) throw new Error('No cart');
    const cart_id=c[0].id;
    const [items]=await conn.query('SELECT ci.*, p.price FROM cart_items ci JOIN products p ON p.id=ci.product_id WHERE cart_id=?',[cart_id]);
    let total=0; for(const it of items){ total += Number(it.price)*it.quantity; }
    const method_id = 1; const shipping_cost = 0;
    const [or]=await conn.query('INSERT INTO orders (user_id,total,status,shipping_method_id,shipping_cost) VALUES (?,?,?,?,?)',[user_id,total,'pendiente',method_id,shipping_cost]);
    const order_id=or.insertId;
    for(const it of items){ await conn.query('INSERT INTO order_items (order_id,product_id,price_unit,quantity) VALUES (?,?,?,?)',[order_id,it.product_id,it.price,it.quantity]); }
    await conn.query('DELETE FROM cart_items WHERE cart_id=?',[cart_id]);
    await conn.commit(); return order_id;
  }catch(e){ await conn.rollback(); throw e; } finally{ conn.release(); }
}
export async function listOrders(user_id){ const [r]=await pool.query('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC',[user_id]); return r; }
export async function adminSetStatus(order_id,status){ await pool.query('UPDATE orders SET status=? WHERE id=?',[status,order_id]); }
