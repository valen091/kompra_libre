
import { pool } from '../config/db.js';
async function ensureCart(user_id){ const [r]=await pool.query('SELECT * FROM carts WHERE user_id=?',[user_id]); if(r[0]) return r[0].id; const [x]=await pool.query('INSERT INTO carts (user_id) VALUES (?)',[user_id]); return x.insertId; }
export async function getCart(user_id){ const cart_id=await ensureCart(user_id); const [items]=await pool.query('SELECT ci.id,ci.quantity,p.title,p.price FROM cart_items ci JOIN products p ON p.id=ci.product_id WHERE ci.cart_id=?',[cart_id]); return { cart_id, items }; }
export async function addToCart(user_id,product_id,quantity){ const cart_id=await ensureCart(user_id); const [[row]] = await pool.query('SELECT * FROM cart_items WHERE cart_id=? AND product_id=?',[cart_id,product_id]); if(row){ await pool.query('UPDATE cart_items SET quantity=quantity+? WHERE id=?',[quantity,row.id]); return;} await pool.query('INSERT INTO cart_items (cart_id,product_id,quantity) VALUES (?,?,?)',[cart_id,product_id,quantity]); }
export async function updateCartItem(item_id,delta){ await pool.query('UPDATE cart_items SET quantity=GREATEST(quantity+?,1) WHERE id=?',[delta,item_id]); }
export async function deleteCartItem(item_id){ await pool.query('DELETE FROM cart_items WHERE id=?',[item_id]); }
