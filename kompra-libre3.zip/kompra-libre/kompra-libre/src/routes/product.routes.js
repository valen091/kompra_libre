
import { Router } from 'express';
import multer from 'multer';
import { requireAuth, requireRole } from '../middlewares/auth.js';
import { list, get, create, edit, remove, reviews, addReviewCtrl, report, sellerProducts } from '../controllers/product.controller.js';

const storage = multer.diskStorage({
  destination: (req,file,cb)=>cb(null, 'public/img/uploads'),
  filename: (req,file,cb)=>cb(null, Date.now()+'-'+file.originalname.replace(/\s+/g,'_'))
});
const upload = multer({ storage, limits:{ fileSize: 5*1024*1024 } });

const r = Router();
r.get('/', list);
r.get('/:id', get);
r.post('/', requireAuth, requireRole('seller'), upload.single('image'), create);
r.put('/:id', requireAuth, requireRole('seller'), edit);
r.delete('/:id', requireAuth, requireRole('seller'), remove);
r.get('/:id/reviews', reviews);
r.post('/:id/reviews', requireAuth, addReviewCtrl);
r.post('/:id/report', requireAuth, report);
r.get('/me/seller', requireAuth, requireRole('seller'), sellerProducts); // backup path
r.post('/:id/favorite', requireAuth, (req,res)=>res.json({ok:true}));
export default r;
