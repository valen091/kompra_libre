import { listCategories } from '../models/category.model.js'; export async function categories(req,res){ res.json(await listCategories()); }
