# Changelog

## 1.0.0 - 2025-09-19
- Entrega inicial completa Kompra Libre
