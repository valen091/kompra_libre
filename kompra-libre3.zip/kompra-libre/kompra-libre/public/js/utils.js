
export async function api(path){
  const r = await fetch(path, { credentials:'include' });
  if(!r.ok) throw new Error('HTTP '+r.status);
  return r.json();
}
export async function apiPost(path, body){
  const r = await fetch(path, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body), credentials:'include' });
  try { return await r.json(); } catch(e){ return { ok: r.ok }; }
}
export async function apiPut(path, body){
  const r = await fetch(path, { method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body), credentials:'include' });
  return r.json();
}
export async function apiDel(path){
  const r = await fetch(path, { method:'DELETE', credentials:'include' });
  return r.json();
}
