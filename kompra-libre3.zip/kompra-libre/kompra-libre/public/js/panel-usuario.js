import { api } from '/js/utils.js';
async function load(){ const orders = await api('/api/orders'); document.getElementById('panel').innerHTML = orders.map(o=>`<div class='border p-2 rounded mb-2'><div>Pedido #${o.id} — ${o.status} — $${o.total}</div></div>`).join(''); } load();
