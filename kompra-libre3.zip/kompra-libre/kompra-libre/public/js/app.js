
import { api } from '/js/utils.js';
let page = 1; const limit = 9;
async function loadCategories(){
  const cats = await api('/api/categories');
  const sel = document.getElementById('f_categoria');
  sel.innerHTML = '<option value="">Todas</option>' + cats.map(c=>`<option value="${c.id}">${c.name}</option>`).join('');
}
async function loadProducts(){
  const q = document.getElementById('q')?.value || '';
  const category = document.getElementById('f_categoria')?.value || '';
  const priceMin = document.getElementById('f_pmin')?.value || '';
  const priceMax = document.getElementById('f_pmax')?.value || '';
  const cond = document.getElementById('f_cond')?.value || '';
  const res = await api(`/api/products?q=${encodeURIComponent(q)}&category=${category}&price_min=${priceMin}&price_max=${priceMax}&condition=${cond}&page=${page}&limit=${limit}`);
  const cont = document.getElementById('productos');
  cont.innerHTML = res.items.map(p=>`
    <article class="bg-white p-3 rounded shadow">
      <a href="/producto.html?id=${p.id}">
        <img src="${p.cover}" class="w-full h-40 object-cover rounded" alt="${p.title}">
        <h3 class="mt-2 font-semibold">${p.title}</h3>
      </a>
      <div class="text-green-700 font-semibold">$${p.price}</div>
    </article>`).join('');
  document.getElementById('page').textContent = res.page;
}
document.getElementById('btnBuscar')?.addEventListener('click', ()=>{ page=1; loadProducts(); });
document.getElementById('btnFiltrar')?.addEventListener('click', ()=>{ page=1; loadProducts(); });
document.getElementById('prev')?.addEventListener('click', ()=>{ if(page>1){ page--; loadProducts(); }});
document.getElementById('next')?.addEventListener('click', ()=>{ page++; loadProducts(); });

// Autocomplete
const qInput = document.getElementById('q'); const dl = document.getElementById('sugs'); let t=null;
qInput?.addEventListener('input', ()=>{
  clearTimeout(t);
  t=setTimeout(async()=>{
    const q = qInput.value.trim(); if(!q) return;
    const r = await fetch('/api/search/suggest?q='+encodeURIComponent(q));
    const items = await r.json();
    dl.innerHTML = items.map(i=>`<option value="${i.title}">`).join('');
  }, 200);
});

await loadCategories(); await loadProducts();
