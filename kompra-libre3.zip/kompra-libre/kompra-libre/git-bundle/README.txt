Include a real git bundle if you initialize a repo and run `git bundle create`.
