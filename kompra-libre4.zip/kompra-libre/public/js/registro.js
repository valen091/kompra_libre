// public/js/registro.js
const form = document.getElementById('formRegistro');
const msg  = document.getElementById('msg');

const API = {
  register: '/api/auth/register',
  login: '/login.html', // adónde mandamos tras registrarse
};

// Inyecta link a login si faltaba
(function ensureLoginLink() {
  if (!form) return;
  if (document.getElementById('loginLinkAutogen')) return;
  const p = document.createElement('p');
  p.id = 'loginLinkAutogen';
  p.className = 'mt-2 text-center text-sm text-gray-600';
  p.innerHTML = `¿Ya tienes cuenta?
    <a href="/login.html" class="text-[#3483FA] underline hover:no-underline">Inicia sesión</a>`;
  form.appendChild(p);
})();

function setBusy(isBusy) {
  const btn = form.querySelector('button[type="submit"], button') || null;
  if (!btn) return;
  btn.disabled = isBusy;
  btn.classList.toggle('opacity-60', isBusy);
  btn.textContent = isBusy ? 'Creando cuenta…' : 'Registrarme';
}

function showMessage(text, type = 'error') {
  if (!msg) return;
  msg.className = `text-sm mt-2 ${type === 'error' ? 'text-red-500' : 'text-green-600'}`;
  msg.textContent = text || '';
}

async function postJSON(url, data) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(data),
  });
  let payload = null;
  try { payload = await res.json(); } catch {}
  return { ok: res.ok, status: res.status, data: payload };
}

form?.addEventListener('submit', async (e) => {
  e.preventDefault();
  showMessage('');
  setBusy(true);

  const fd       = new FormData(form);
  const name     = String(fd.get('name') || '').trim();
  const email    = String(fd.get('email') || '').trim().toLowerCase();
  const password = String(fd.get('password') || '');
  const role     = String(fd.get('role') || 'buyer');

  // Validaciones rápidas de cliente
  if (name.length < 2)        return setBusy(false), showMessage('El nombre debe tener al menos 2 caracteres.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setBusy(false), showMessage('Email inválido.');
  if (password.length < 6)    return setBusy(false), showMessage('La contraseña debe tener 6 o más caracteres.');
  if (!['buyer','seller'].includes(role)) return setBusy(false), showMessage('Rol inválido.');

  try {
    const { ok, status, data } = await postJSON(API.register, { name, email, password, role });

    if (!ok) {
      const backendMsg = (data && (data.message || data.error)) || 'No se pudo crear la cuenta.';
      setBusy(false);
      return showMessage(`${backendMsg} ${status ? `(HTTP ${status})` : ''}`);
    }

    window.location.assign(`${API.login}?email=${encodeURIComponent(email)}`);

  } catch (err) {
    console.error(err);
    setBusy(false);
    showMessage('Error de red. Intenta de nuevo.');
  }
});
