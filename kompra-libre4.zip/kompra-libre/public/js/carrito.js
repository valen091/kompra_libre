
import { api, apiPost, apiDel, apiPut } from '/js/utils.js';
async function load(){
  const cart = await api('/api/cart');
  const cont = document.getElementById('items');
  let total = 0;
  cont.innerHTML = cart.items.map(it=>{
    total += it.price * it.quantity;
    return `<div class="flex justify-between border p-2 rounded">
      <div>${it.title} x ${it.quantity}</div>
      <div>$${(it.price*it.quantity).toFixed(2)}</div>
      <div>
        <button data-id="${it.id}" class="btn-less border px-2">-</button>
        <button data-id="${it.id}" class="btn-more border px-2">+</button>
        <button data-id="${it.id}" class="btn-del border px-2">🗑</button>
      </div>
    </div>`;
  }).join('');
  document.getElementById('total').textContent = 'Total: $'+total.toFixed(2);
  cont.querySelectorAll('.btn-less').forEach(b=>b.onclick=()=>apiPut('/api/cart/'+b.dataset.id,{quantity:-1}).then(load));
  cont.querySelectorAll('.btn-more').forEach(b=>b.onclick=()=>apiPut('/api/cart/'+b.dataset.id,{quantity:1}).then(load));
  cont.querySelectorAll('.btn-del').forEach(b=>b.onclick=()=>apiDel('/api/cart/'+b.dataset.id).then(load));
}
document.getElementById('btnCheckout').addEventListener('click', async ()=>{
  const res = await apiPost('/api/orders', {});
  alert('Pedido: #'+res.id); location.href = '/panel-usuario.html';
});
load();
