// public/js/login.js
const form = document.getElementById('formLogin');
const msg  = document.getElementById('msg');
const emailInput = document.getElementById('email');

const API_LOGIN = '/api/auth/login';
const REDIRECT_OK = '/'; // a dónde ir tras login OK

// Si viene ?email=... desde el registro, precarga
const params = new URLSearchParams(window.location.search);
const emailFromReg = params.get('email');
if (emailFromReg) emailInput.value = emailFromReg;

function setBusy(isBusy) {
  const btn = form.querySelector('button');
  btn.disabled = isBusy;
  btn.classList.toggle('opacity-60', isBusy);
  btn.textContent = isBusy ? 'Ingresando…' : 'Ingresar';
}

function showMessage(text, type = 'error') {
  msg.className = `text-sm mt-2 ${type === 'error' ? 'text-red-500' : 'text-green-600'}`;
  msg.textContent = text || '';
}

async function postJSON(url, data) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include', // para cookie HttpOnly
    body: JSON.stringify(data),
  });
  let payload = null;
  try { payload = await res.json(); } catch {}
  return { ok: res.ok, status: res.status, data: payload };
}

form?.addEventListener('submit', async (e) => {
  e.preventDefault();
  showMessage('');
  setBusy(true);

  const fd       = new FormData(form);
  const email    = String(fd.get('email') || '').trim().toLowerCase();
  const password = String(fd.get('password') || '');

  if (!email || !password) { setBusy(false); return showMessage('Completa email y contraseña.'); }

  try {
    const { ok, status, data } = await postJSON(API_LOGIN, { email, password });
    if (!ok) {
      const backendMsg = (data && (data.message || data.error)) || 'Credenciales inválidas.';
      setBusy(false);
      return showMessage(`${backendMsg} ${status ? `(HTTP ${status})` : ''}`);
    }

    // ✅ Login OK: el backend setea cookie HttpOnly; redirige al Home (o panel)
    window.location.assign(REDIRECT_OK);

  } catch (err) {
    console.error(err);
    setBusy(false);
    showMessage('Error de red. Intenta de nuevo.');
  }
});
