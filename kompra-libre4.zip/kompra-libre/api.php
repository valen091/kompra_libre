<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$request = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];

// Endpoint: /api/categories
if ($method === 'GET' && preg_match('#^/api/categories#', $request)) {
    // Simulando una respuesta de categorías
    echo json_encode([
        ['id' => 1, 'name' => 'Electrónica'],
        ['id' => 2, 'name' => 'Ropa'],
        ['id' => 3, 'name' => 'Hogar'],
        ['id' => 4, 'name' => 'Deportes'],
        ['id' => 5, 'name' => 'Juguetes']
    ]);
    exit;
}

// Endpoint: /api/products
if ($method === 'GET' && preg_match('#^/api/products#', $request)) {
    // Parámetros de consulta
    $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 9;
    
    // Simulando una respuesta de productos
    $products = [];
    for ($i = 0; $i < $limit; $i++) {
        $products[] = [
            'id' => $i + 1,
            'title' => 'Producto ' . ($i + 1),
            'price' => rand(100, 10000) / 100,
            'cover' => '/img/productos/prod' . (($i % 5) + 1) . '.jpg'
        ];
    }
    
    echo json_encode([
        'items' => $products,
        'page' => $page,
        'total' => 50,
        'limit' => $limit
    ]);
    exit;
}

// Si no se encontró la ruta
http_response_code(404);
echo json_encode(['error' => 'Ruta no encontrada']);