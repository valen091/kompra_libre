import { pool } from '../config/db.js'; export async function listCategories(){ const [r]=await pool.query('SELECT id,name,slug,parent_id FROM categories ORDER BY name ASC'); return r; }
