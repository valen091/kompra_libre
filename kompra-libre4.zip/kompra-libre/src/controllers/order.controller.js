
import { createOrder, listOrders, adminSetStatus } from '../models/order.model.js';
export async function checkout(req,res){ const id = await createOrder(req.user.id); res.json({ id }); }
export async function myOrders(req,res){ const rows = await listOrders(req.user.id); res.json(rows); }
export async function setStatus(req,res){ await adminSetStatus(req.params.id, req.body.status); res.json({ ok:true }); }
