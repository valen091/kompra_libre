
import { verifyJwt } from '../config/jwt.js';
export function requireAuth(req,res,next){
  const token = req.cookies?.token;
  if(!token) return res.status(401).json({error:'No autenticado'});
  try{ req.user = verifyJwt(token); next(); }catch(e){ return res.status(401).json({error:'Token inválido'}); }
}
export function requireRole(role){
  return (req,res,next)=>{
    if(!req.user) return res.status(401).json({error:'No autenticado'});
    if(req.user.role !== role && req.user.role !== 'admin') return res.status(403).json({error:'No autorizado'});
    next();
  };
}
