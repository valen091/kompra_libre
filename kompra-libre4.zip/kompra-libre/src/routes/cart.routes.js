
import { Router } from 'express';
import { requireAuth } from '../middlewares/auth.js';
import { getMyCart, addItem, updateItem, deleteItem } from '../controllers/cart.controller.js';
const r = Router();
r.get('/', requireAuth, getMyCart);
r.post('/', requireAuth, addItem);
r.put('/:itemId', requireAuth, updateItem);
r.delete('/:itemId', requireAuth, deleteItem);
export default r;
