
import { Router } from 'express';
import { requireAuth } from '../middlewares/auth.js';
import { me, updateProfile, changePassword, favorites } from '../controllers/user.controller.js';
const r = Router();
r.get('/me', requireAuth, me);
r.put('/me', requireAuth, updateProfile);
r.put('/me/password', requireAuth, changePassword);
r.get('/me/favorites', requireAuth, favorites);
export default r;
