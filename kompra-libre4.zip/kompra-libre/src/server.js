import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import authRoutes from './routes/auth.routes.js';

const app = express();

// Middlewares
app.use(express.json());
app.use(cookieParser());

// CORS si accedes desde mismo origen no hace falta; si usas otro, habilita:
// import cors from 'cors';
// app.use(cors({ origin: 'http://localhost:3000', credentials: true }));

// Static
const PUBLIC_DIR = path.join(process.cwd(), 'public');
app.use(express.static(PUBLIC_DIR));
app.get('/', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

// API
app.use('/api/auth', authRoutes);
// ... el resto de tus rutas API aquí ...

const PORT = Number(process.env.PORT || 3000);
app.listen(PORT, () => console.log(`Kompra Libre on http://localhost:${PORT}`));
